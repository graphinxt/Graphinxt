<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Free AI Business Growth Planner | Graphinxt</title>
    <meta name="description" content="Free AI tool: share your business, location & audience and get a personalized 1-year growth plan with online + offline marketing and a PDF download.">
    <meta name="robots" content="index, follow, max-image-preview:large">
     <link rel="stylesheet" href="../assets/style.css">
    <link rel="stylesheet" href="../assets/header.css">
    <link rel="canonical" href="https://graphinxt.com/growth-planner">
    <meta property="og:site_name" content="Graphinxt">
    <meta property="og:type" content="website">
    <meta property="og:title" content="Free AI Business Growth Planner — Your 1-Year Success Plan | Graphinxt">

    <meta property="og:description" content="Get a personalized 1-year growth plan for your business in minutes — online + offline marketing, quarterly milestones, downloadable PDF. Free, no signup to start.">
    <meta property="og:url" content="https://graphinxt.com/growth-planner">
    <meta property="og:image" content="https://graphinxt.com/assets/og-cover.jpg">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:image" content="https://graphinxt.com/assets/og-cover.jpg">
<link rel="shortcut icon" href="../assets/favicon.ico" type="image/x-icon">
        <link rel="icon" href="../assets/favicon.ico" type="image/x-icon">
   
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@200;300;400;500;800&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@graph": [
        { "@type": "BreadcrumbList", "itemListElement": [
            { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://graphinxt.com/" },
            { "@type": "ListItem", "position": 2, "name": "Free Tools", "item": "https://graphinxt.com/tools" },
            { "@type": "ListItem", "position": 3, "name": "Business Growth Planner", "item": "https://graphinxt.com/growth-planner" } ] },
        { "@type": "WebApplication", "name": "AI Business Growth Planner", "url": "https://graphinxt.com/growth-planner", "applicationCategory": "BusinessApplication", "operatingSystem": "Any", "offers": { "@type": "Offer", "price": "0", "priceCurrency": "USD" }, "description": "Generate a personalized 1-year business growth plan with quarterly milestones, online and offline marketing suggestions, and a downloadable PDF." },
        { "@type": "FAQPage", "mainEntity": [
            { "@type": "Question", "name": "Is the AI Business Growth Planner really free?", "acceptedAnswer": { "@type": "Answer", "text": "Yes. You can generate your full 1-year plan and read every section for free. Saving your plan to return later is also free — you just enter your email so the tool can greet you and reload your plan on your next visit." } },
            { "@type": "Question", "name": "What does the 1-year plan include?", "acceptedAnswer": { "@type": "Answer", "text": "A quarter-by-quarter roadmap across four phases, online marketing suggestions (website, SEO, ads, social), offline marketing suggestions tailored to your business type and location, quick wins for your first 30 days, and a mapping of which Graphinxt services fit each stage. You can download it all as a branded PDF." } },
            { "@type": "Question", "name": "Do I need an account?", "acceptedAnswer": { "@type": "Answer", "text": "No account is needed to generate and download your plan. Optionally entering your email lets the planner save your plan on your device so it can welcome you back and show your next step when you return." } }
        ] }
      ]
    }
    </script>
<script async src="https://www.googletagmanager.com/gtag/js?id=G-58PYC27MPE"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date()); gtag('config', 'G-58PYC27MPE');
</script>
<script>
  !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window, document,'script','https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '2162187584315430'); fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=2162187584315430&ev=PageView&noscript=1" /></noscript>
<script>
  window.trackConversion = function(eventName, params) {
    params = params || {};
    try { if (typeof gtag === 'function') gtag('event', eventName, params); } catch(e) {}
    try { if (typeof fbq === 'function') fbq('trackCustom', eventName, params); } catch(e) {}
  };
</script>
    <style>
        :root { --bg-dark:#363638; --bg-darker:#2a2a2c; --brand-gold:#e9c46f; --text-main:#fff; --text-muted:#a1a1a5; --card-bg:rgba(255,255,255,0.02); --border-light:rgba(233,196,111,0.12); --border-glow:rgba(233,196,111,0.4); --nav-bg:rgba(42,42,44,0.4); --ok:#7ec97e; }
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Montserrat',sans-serif; scroll-behavior:smooth; }
        @media(max-width:880px){ .nav-links{display:none;} }
        .btn-primary { background:#fff; color:var(--bg-dark)!important; padding:0.95rem 2.3rem; border-radius:30px; font-weight:800; text-transform:uppercase; letter-spacing:1px; text-decoration:none; display:inline-block; font-size:0.78rem; border:none; transition:all .3s; cursor:pointer; }
        .btn-primary:hover { background:var(--brand-gold); color:#fff!important; transform:scale(1.05); }
        .btn-outline { background:transparent; color:var(--brand-gold); padding:0.95rem 2.3rem; border-radius:30px; font-weight:600; text-transform:uppercase; letter-spacing:1px; text-decoration:none; border:1px solid var(--border-light); display:inline-block; font-size:0.76rem; transition:all .3s; cursor:pointer; }
        .btn-outline:hover { border-color:var(--brand-gold); }
        section { padding:4rem 5%; max-width:1000px; margin:0 auto; position:relative; z-index:1; }
        .hero-sec { padding-top:13rem; padding-bottom:1rem; text-align:center; }
        .eyebrow { font-size:0.75rem; color:var(--brand-gold); text-transform:uppercase; letter-spacing:3px; margin-bottom:1.2rem; display:inline-block; }
        .hero-sec h1 { font-size:clamp(2rem,5vw,3.2rem); font-weight:200; line-height:1.15; margin-bottom:1.2rem; }
        .hero-sec h1 strong { font-weight:800; background:linear-gradient(to right,#ffffff,var(--brand-gold)); -webkit-background-clip:text; background-clip:text; -webkit-text-fill-color:transparent; color:var(--brand-gold); }
        .hero-sec p { color:var(--text-muted); max-width:620px; margin:0 auto 1.5rem; font-weight:300; }
        .welcome-back { max-width:760px; margin:0 auto 2rem; background:linear-gradient(135deg,rgba(233,196,111,0.09),transparent); border:1px solid var(--border-glow); border-radius:18px; padding:1.4rem 1.6rem; display:none; text-align:left; }
        .welcome-back.show { display:block; }
        .tool-card { background:var(--card-bg); border:1px solid var(--border-light); border-radius:28px; padding:3rem; max-width:820px; margin:0 auto; }
        @media(max-width:700px){ .tool-card{padding:2rem 1.4rem;} }
        .step-dots { display:flex; justify-content:center; gap:0.5rem; margin-bottom:2rem; }
        .step-dot { width:36px; height:4px; border-radius:2px; background:var(--border-light); transition:background .3s; }
        .step-dot.active { background:var(--brand-gold); }
        .q-label { font-size:1.3rem; font-weight:200; text-align:center; margin-bottom:0.4rem; }
        .q-label strong { font-weight:800; color:var(--brand-gold); }
        .q-help { font-size:0.82rem; color:var(--text-muted); text-align:center; margin-bottom:1.6rem; font-weight:300; }
        .t-input, .t-select, .t-area { width:100%; background:var(--bg-darker); border:1px solid var(--border-light); color:var(--text-main); padding:1rem 1.4rem; border-radius:16px; font-size:0.95rem; outline:none; font-family:inherit; margin-bottom:1rem; }
        .t-input:focus, .t-select:focus, .t-area:focus { border-color:var(--brand-gold); }
        .chip-row { display:flex; flex-wrap:wrap; gap:0.6rem; justify-content:center; margin-bottom:1.4rem; }
        .chip { border:1px solid var(--border-light); color:var(--text-muted); padding:0.5rem 1.2rem; border-radius:30px; font-size:0.8rem; cursor:pointer; transition:all .2s; background:transparent; font-family:inherit; }
        .chip:hover, .chip.sel { border-color:var(--brand-gold); color:var(--brand-gold); }
        .nav-row { display:flex; justify-content:space-between; gap:1rem; margin-top:0.5rem; }
        .run-btn { background:var(--brand-gold); color:var(--bg-dark)!important; padding:1rem 2rem; border-radius:30px; font-weight:800; text-transform:uppercase; letter-spacing:1px; border:none; font-size:0.78rem; cursor:pointer; transition:all .3s; }
        .run-btn:hover { transform:scale(1.03); }
        .ghost-btn { background:transparent; border:1px solid var(--border-light); color:var(--text-muted); padding:1rem 2rem; border-radius:30px; font-size:0.72rem; text-transform:uppercase; letter-spacing:1px; cursor:pointer; font-family:inherit; }
        .ghost-btn:hover { color:var(--brand-gold); border-color:var(--brand-gold); }
        .ai-sim { display:none; text-align:center; padding:2rem 0; }
        .ai-sim.show { display:block; }
        .ai-sim .dot { display:inline-block; width:8px; height:8px; border-radius:50%; background:var(--brand-gold); margin:0 3px; animation:bounce 1.2s infinite; }
        .ai-sim .dot:nth-child(2){animation-delay:.2s;} .ai-sim .dot:nth-child(3){animation-delay:.4s;}
        @keyframes bounce { 0%,80%,100%{transform:translateY(0);opacity:.4;} 40%{transform:translateY(-8px);opacity:1;} }
        .ai-sim-text { color:var(--text-muted); font-size:0.9rem; margin-top:1rem; font-weight:300; }
        /* PLAN */
        .plan { display:none; }
        .plan.show { display:block; animation:fadeUp .5s ease; }
        @keyframes fadeUp { from{opacity:0;transform:translateY(12px);} to{opacity:1;transform:translateY(0);} }
        .plan-head { text-align:center; margin-bottom:2.5rem; }
        .plan-head .eyebrow { margin-bottom:0.6rem; }
        .plan-head h2 { font-size:clamp(1.6rem,4vw,2.3rem); font-weight:200; }
        .plan-head h2 strong { font-weight:800; color:var(--brand-gold); }
        .plan-summary { background:var(--bg-darker); border:1px solid var(--border-light); border-radius:16px; padding:1.4rem 1.6rem; margin-bottom:2rem; font-size:0.9rem; color:var(--text-muted); font-weight:300; }
        .plan-summary strong { color:var(--text-main); font-weight:600; }
        .sec-title { font-size:1.05rem; color:var(--brand-gold); font-weight:600; margin:2rem 0 1rem; display:flex; align-items:center; gap:0.6rem; }
        .quarter { background:var(--card-bg); border:1px solid var(--border-light); border-left:3px solid var(--brand-gold); border-radius:0 14px 14px 0; padding:1.3rem 1.5rem; margin-bottom:1rem; }
        .quarter h4 { font-size:0.95rem; margin-bottom:0.2rem; }
        .quarter .qtag { font-size:0.62rem; text-transform:uppercase; letter-spacing:1.5px; color:var(--brand-gold); font-weight:700; }
        .quarter ul { list-style:none; margin-top:0.6rem; }
        .quarter li { font-size:0.83rem; color:var(--text-muted); font-weight:300; padding:0.28rem 0 0.28rem 1.5rem; position:relative; }
        .quarter li::before { content:'→'; color:var(--brand-gold); position:absolute; left:0; }
        .two-col { display:grid; grid-template-columns:1fr 1fr; gap:1.2rem; }
        @media(max-width:640px){ .two-col{grid-template-columns:1fr;} }
        .mkt-box { background:var(--card-bg); border:1px solid var(--border-light); border-radius:14px; padding:1.3rem 1.5rem; }
        .mkt-box h4 { font-size:0.9rem; margin-bottom:0.7rem; display:flex; align-items:center; gap:0.5rem; }
        .mkt-box ul { list-style:none; }
        .mkt-box li { font-size:0.82rem; color:var(--text-muted); font-weight:300; padding:0.3rem 0 0.3rem 1.4rem; position:relative; }
        .mkt-box li::before { content:'•'; color:var(--brand-gold); position:absolute; left:0.3rem; }
        .grx-map { background:linear-gradient(135deg,rgba(233,196,111,0.06),transparent); border:1px solid var(--border-glow); border-radius:16px; padding:1.5rem; margin-top:1rem; }
        .grx-map .row { display:flex; justify-content:space-between; gap:1rem; align-items:center; padding:0.7rem 0; border-bottom:1px solid var(--border-light); flex-wrap:wrap; }
        .grx-map .row:last-child { border-bottom:none; }
        .grx-map .need { font-size:0.85rem; font-weight:300; color:var(--text-muted); flex:1; min-width:160px; }
        .grx-map .pkg-link { font-size:0.72rem; color:var(--brand-gold); text-decoration:none; font-weight:700; text-transform:uppercase; letter-spacing:0.5px; white-space:nowrap; }
        .grx-map .pkg-link:hover { text-decoration:underline; }
        .plan-actions { display:flex; gap:0.8rem; flex-wrap:wrap; justify-content:center; margin:2.5rem 0 1rem; }
        .save-box { background:var(--bg-darker); border:1px solid var(--border-light); border-radius:16px; padding:1.5rem; margin-top:1.5rem; text-align:center; }
        .save-box.saved { border-color:var(--ok); }
        .save-row { display:flex; gap:0.6rem; max-width:420px; margin:1rem auto 0; flex-wrap:wrap; }
        .save-row input { flex:1; min-width:180px; background:var(--bg-dark); border:1px solid var(--border-light); color:var(--text-main); padding:0.8rem 1.2rem; border-radius:30px; outline:none; font-family:inherit; font-size:0.85rem; }
        /* CHAT */
        .planner-chat { max-width:820px; margin:2rem auto 0; background:var(--card-bg); border:1px solid var(--border-light); border-radius:20px; overflow:hidden; }
        .pc-head { background:rgba(233,196,111,0.08); padding:1rem 1.4rem; font-size:0.85rem; font-weight:600; display:flex; align-items:center; gap:0.5rem; }
        .pc-head .live { width:8px; height:8px; border-radius:50%; background:var(--ok); box-shadow:0 0 8px var(--ok); }
        .pc-body { padding:1.2rem 1.4rem; max-height:340px; overflow-y:auto; display:flex; flex-direction:column; gap:0.8rem; }
        .pc-msg { padding:0.7rem 1rem; border-radius:14px; font-size:0.85rem; max-width:85%; line-height:1.5; }
        .pc-bot { background:var(--bg-darker); border:1px solid var(--border-light); align-self:flex-start; color:var(--text-muted); }
        .pc-bot a { color:var(--brand-gold); }
        .pc-user { background:var(--brand-gold); color:var(--bg-dark); align-self:flex-end; font-weight:500; }
        .pc-input { display:flex; gap:0.6rem; padding:1rem 1.4rem; border-top:1px solid var(--border-light); }
        .pc-input input { flex:1; background:var(--bg-darker); border:1px solid var(--border-light); color:var(--text-main); padding:0.8rem 1.2rem; border-radius:30px; outline:none; font-family:inherit; font-size:0.85rem; }
        .pc-input button { background:var(--brand-gold); color:var(--bg-dark); border:none; padding:0 1.4rem; border-radius:30px; font-weight:800; cursor:pointer; font-size:0.75rem; text-transform:uppercase; }
        .disclaimer { font-size:0.68rem; color:var(--text-muted); opacity:0.7; text-align:center; max-width:640px; margin:1.5rem auto 0; }
        .faq-item { border-bottom:1px solid var(--border-light); padding:1.3rem 0; max-width:760px; margin:0 auto; }
        .faq-item h3 { font-size:0.98rem; font-weight:600; margin-bottom:0.4rem; }
        .faq-item p { font-size:0.85rem; color:var(--text-muted); font-weight:300; }
        footer { padding:4rem 5%; text-align:center; border-top:1px solid var(--border-light); color:var(--text-muted); font-size:0.8rem; }
        footer a { color:var(--brand-gold); text-decoration:none; }
        .footer-links-row { display:flex; gap:1.4rem; justify-content:center; flex-wrap:wrap; margin-bottom:1.2rem; }
        .footer-links-row a { color:var(--text-muted); font-size:0.72rem; text-transform:uppercase; letter-spacing:1px; }
        .footer-links-row a:hover { color:var(--brand-gold); }
    </style>
</head>
<body>
    <canvas id="bg-canvas"></canvas>
    <div class="ambient-glow"></div>
       <?php include '../header.php';?>

    <header class="hero-sec">
        <span class="eyebrow">Free AI Tool · Your 1-Year Success Plan</span>
        <h1>The AI Business <strong>Growth Planner</strong></h1>
        <p>Tell us about your business, and get a personalized 12-month growth plan — quarterly milestones, online <em>and</em> offline marketing, quick wins, and a clear next step. Download it as a PDF, and save it to pick up where you left off.</p>
        <div class="welcome-back" id="welcome-back"></div>
    </header>

    <section style="padding-top:1rem;">
        <div class="tool-card" id="planner-card">
            <div class="step-dots" id="step-dots"></div>

            <!-- STEP 0 -->
            <div class="pstep" data-step="0">
                <div class="q-label">What's your <strong>business</strong>?</div>
                <div class="q-help">Your business or idea name, and what you sell.</div>
                <input type="text" id="p-name" class="t-input" placeholder="Business name (e.g. Bloom Coffee Co.)" autocomplete="off">
                <input type="text" id="p-services" class="t-input" placeholder="What you offer (e.g. specialty coffee & pastries)" autocomplete="off">
                <div class="nav-row"><span></span><button class="run-btn" onclick="planStep(1)">Next →</button></div>
            </div>

            <!-- STEP 1 -->
            <div class="pstep" data-step="1" style="display:none;">
                <div class="q-label">Which <strong>industry</strong>?</div>
                <div class="q-help">Pick the closest — it shapes your marketing mix.</div>
                <div class="chip-row" id="p-industry-chips"></div>
                <div class="nav-row"><button class="ghost-btn" onclick="planStep(0)">← Back</button><button class="run-btn" onclick="planStep(2)">Next →</button></div>
            </div>

            <!-- STEP 2 -->
            <div class="pstep" data-step="2" style="display:none;">
                <div class="q-label">Where are you <strong>based</strong>?</div>
                <div class="q-help">City and country — this drives local and offline suggestions.</div>
                <input type="text" id="p-location" class="t-input" placeholder="City, Country (e.g. Manchester, UK)" autocomplete="off">
                <div class="nav-row"><button class="ghost-btn" onclick="planStep(1)">← Back</button><button class="run-btn" onclick="planStep(3)">Next →</button></div>
            </div>

            <!-- STEP 3 -->
            <div class="pstep" data-step="3" style="display:none;">
                <div class="q-label">Who are your <strong>customers</strong>?</div>
                <div class="q-help">Describe your ideal customer, and where you are today.</div>
                <input type="text" id="p-audience" class="t-input" placeholder="Target audience (e.g. young professionals, local families)" autocomplete="off">
                <select id="p-stage" class="t-select" aria-label="Business stage">
                    <option value="idea">Just an idea / pre-launch</option>
                    <option value="new">Launched, under 1 year</option>
                    <option value="growing">Established, want to grow</option>
                    <option value="stuck">Established, growth has stalled</option>
                </select>
                <div class="nav-row"><button class="ghost-btn" onclick="planStep(2)">← Back</button><button class="run-btn" onclick="generatePlan()">Build My 1-Year Plan →</button></div>
            </div>

            <!-- LOADING -->
            <div class="ai-sim" id="plan-sim">
                <span class="dot"></span><span class="dot"></span><span class="dot"></span>
                <div class="ai-sim-text" id="plan-sim-text">Analyzing your business…</div>
            </div>
        </div>

        <!-- PLAN OUTPUT -->
        <div class="plan" id="plan-output"></div>
    </section>

    <!-- FAQ -->
    <section style="padding-top:1rem;">
        <div style="text-align:center; margin-bottom:2rem;"><h2 style="font-size:clamp(1.5rem,3.5vw,2.1rem); font-weight:200;">Common <strong style="color:var(--brand-gold); font-weight:800;">Questions</strong></h2></div>
        <div class="faq-item"><h3>Is this really free?</h3><p>Yes — build your full 1-year plan, read every section, and download the PDF at no cost. Saving your plan to return later is free too; you just add your email so the planner can welcome you back.</p></div>
        <div class="faq-item"><h3>What's in the plan?</h3><p>A quarter-by-quarter 12-month roadmap, online marketing (website, SEO, ads, social) and offline marketing suggestions tailored to your industry and location, 30-day quick wins, and which Graphinxt services fit each stage.</p></div>
        <div class="faq-item"><h3>Can Graphinxt build this for me?</h3><p>Yes. The plan shows exactly which of our <a href="/solutions" style="color:var(--brand-gold);">growth packages</a> map to each stage — from a $300 diagnosis to full monthly partnerships. The first strategy call is free.</p></div>
    </section>

    <script>
    (function(){
        window.addEventListener('scroll',()=>{document.getElementById('navbar').classList.toggle('scrolled',document.documentElement.scrollTop>30);});
        function cap(s){return s?s.charAt(0).toUpperCase()+s.slice(1):s;}
        function esc(s){const d=document.createElement('div');d.textContent=s==null?'':s;return d.innerHTML;}
        function lsGet(k){try{return window.localStorage.getItem(k);}catch(e){return null;}}
        function lsSet(k,v){try{window.localStorage.setItem(k,v);}catch(e){}}

        // ---- industry data drives the whole plan ----
        const INDUSTRIES = {
            'Food & Hospitality': { off:['Local flyer drops & menu leaflets in a 2km radius','Partner with nearby offices for lunch catering','Loyalty punch cards & launch-week tasting event','Local newspaper / community magazine feature'], on:['Google Business Profile with photos & menu','Instagram-first: food photography & reels','Local SEO: "[dish] in [city]" pages','WhatsApp ordering & Google review campaign'], channels:'Instagram, Google Maps, local partnerships' },
            'Retail & E-commerce': { off:['Pop-up stalls at local markets & fairs','Packaging inserts with referral codes','In-store events & seasonal window displays','Local radio spots for big promotions'], on:['SEO product pages & Google Shopping','Meta & Instagram Shopping ads with retargeting','Email list with abandoned-cart flow','UGC & influencer seeding'], channels:'Meta/Instagram Shopping, Google, email' },
            'Professional Services': { off:['Networking groups (BNI, chamber of commerce)','Speaking at local business events','Printed case-study one-pagers for referrals','Direct mail to a targeted local list'], on:['LinkedIn thought-leadership & outreach','Google Search ads on high-intent terms','SEO service + city landing pages','Case studies & testimonials on-site'], channels:'LinkedIn, Google Search, referrals' },
            'Home & Trade Services': { off:['Van & vehicle branding (a moving billboard)','Door hangers & leaflets in target streets','Local sponsorship (sports club, school fair)','Referral incentives for past customers'], on:['Google Business Profile + review drive','Google Local Services & Search ads','"[service] in [city]" SEO pages','WhatsApp click-to-quote'], channels:'Google Maps/Search, local print, referrals' },
            'Health & Wellness': { off:['Free intro workshops or taster sessions','Partner with gyms, clinics & pharmacies','Community noticeboards & wellness fairs','Print in local lifestyle magazines'], on:['Instagram & TikTok educational content','Google Search for treatment terms','Booking system + Google reviews','Email nurture with tips & offers'], channels:'Instagram, Google, local partnerships' },
            'Tech & SaaS': { off:['Industry conferences & meetups','Printed leave-behinds for enterprise demos','Sponsor niche community events','Direct outreach to target accounts'], on:['SEO content & comparison pages','LinkedIn + Google Search ads','Product-led free trial funnel','Email onboarding & retargeting'], channels:'LinkedIn, Google, content/SEO' },
            'Creative & Agency': { off:['Portfolio showcases at local creative events','Collaborations with complementary studios','Printed portfolio pieces for pitches','Awards submissions for credibility'], on:['Instagram & Behance/Dribbble presence','SEO for "[service] agency [city]"','LinkedIn case studies','Referral & testimonial engine'], channels:'Instagram, LinkedIn, referrals' },
            'Other / General': { off:['Local networking & community events','Flyers & printed materials in your area','Partnerships with complementary businesses','Referral & word-of-mouth incentives'], on:['Google Business Profile & local SEO','Meta & Google ads to your audience','Consistent social content','Email list & review campaign'], channels:'Google, Meta, local partnerships' }
        };

        const data = { name:'', services:'', industry:'Other / General', location:'', audience:'', stage:'growing', created:null };
        let current = 0;

        // step dots
        const dots = document.getElementById('step-dots');
        for (let i=0;i<4;i++){ const d=document.createElement('div'); d.className='step-dot'+(i===0?' active':''); dots.appendChild(d); }
        // industry chips
        const chipWrap = document.getElementById('p-industry-chips');
        Object.keys(INDUSTRIES).forEach(k=>{ const b=document.createElement('button'); b.className='chip'; b.textContent=k; b.onclick=()=>{ chipWrap.querySelectorAll('.chip').forEach(c=>c.classList.remove('sel')); b.classList.add('sel'); data.industry=k; }; chipWrap.appendChild(b); });
        chipWrap.firstChild.classList.add('sel'); data.industry = Object.keys(INDUSTRIES)[0];

        window.planStep = function(n){
            if (current===0 && n===1){ data.name=document.getElementById('p-name').value.trim(); data.services=document.getElementById('p-services').value.trim(); if(!data.name){document.getElementById('p-name').focus();return;} }
            if (current===2 && n===3){ data.location=document.getElementById('p-location').value.trim(); }
            document.querySelectorAll('.pstep').forEach(s=>s.style.display='none');
            document.querySelector('.pstep[data-step="'+n+'"]').style.display='block';
            dots.querySelectorAll('.step-dot').forEach((d,i)=>d.classList.toggle('active',i<=n));
            current=n;
        };

        function q(label, tag, items){ return '<div class="quarter"><span class="qtag">'+tag+'</span><h4>'+label+'</h4><ul>'+items.map(i=>'<li>'+esc(i)+'</li>').join('')+'</ul></div>'; }

        window.generatePlan = function(){
            data.audience=document.getElementById('p-audience').value.trim();
            data.stage=document.getElementById('p-stage').value;
            data.location=document.getElementById('p-location').value.trim()||data.location;
            if(!data.services){ data.services='your products and services'; }
            data.created=Date.now();
            window.trackConversion('tool_used',{tool:'growth_planner',stage:data.stage,industry:data.industry,page:'/growth-planner'});
            document.querySelectorAll('.pstep').forEach(s=>s.style.display='none');
            const sim=document.getElementById('plan-sim'); sim.classList.add('show');
            const phrases=['Analyzing your business…','Mapping your market & audience…','Building your 12-month roadmap…','Adding online & offline tactics…','Finalizing your plan…'];
            let i=0; const st=document.getElementById('plan-sim-text'); st.textContent=phrases[0];
            const iv=setInterval(()=>{i++;if(i<phrases.length)st.textContent=phrases[i];},520);
            setTimeout(()=>{ clearInterval(iv); sim.classList.remove('show'); document.getElementById('planner-card').style.display='none'; renderPlan(); saveProgress(); },2700);
        };

        function buildPlan(){
            const ind=INDUSTRIES[data.industry]||INDUSTRIES['Other / General'];
            const loc=data.location||'your area';
            const aud=data.audience||'your ideal customers';
            const stageIntro={ idea:'You\u2019re pre-launch, so Q1 is about foundations and proof before spend.', new:'You\u2019re early, so the focus is traction and learning what converts.', growing:'You have a base \u2014 this plan is about compounding and systemising growth.', stuck:'Growth has stalled, so we start by finding and fixing the leak before adding fuel.' }[data.stage];
            const quarters=[
                q('Q1 · Foundation (Months 1\u20133)','Set the base',[
                    data.stage==='idea'?'Lock brand basics: name, logo, colours, one-line positioning':'Audit current website & presence \u2014 fix what leaks leads',
                    'Launch or optimize a conversion-focused website',
                    'Set up Google Business Profile & core social profiles for '+loc,
                    'Install analytics & tracking so every later decision has data',
                    'Publish 3\u20134 cornerstone pages targeting what '+aud+' search for' ]),
                q('Q2 · Traction (Months 4\u20136)','Get first momentum',[
                    'Start paid ads on your highest-intent channel ('+ind.channels.split(',')[0].trim()+')',
                    'Begin a consistent content rhythm (2\u20134 posts/week)',
                    'Launch a review & testimonial drive \u2014 aim for 10+ genuine reviews',
                    'Test one offline tactic: '+ind.off[0].toLowerCase(),
                    'Build an email/WhatsApp list and send your first campaigns' ]),
                q('Q3 · Scale (Months 7\u20139)','Double down on winners',[
                    'Scale the ad channels & offers that proved profitable',
                    'Expand SEO: add service/location pages & 4\u20136 blog articles',
                    'Add retargeting so warm visitors convert cheaper',
                    'Introduce a referral or loyalty mechanism',
                    'Layer a second offline tactic: '+ind.off[1].toLowerCase() ]),
                q('Q4 · Systemize (Months 10\u201312)','Make growth repeatable',[
                    'Document what works into a repeatable monthly playbook',
                    'Automate: chatbot, email flows, booking/quoting',
                    'Review the year\u2019s numbers; set next-year targets',
                    'Deepen community & partnerships in '+loc,
                    'Consider a monthly growth partner to keep momentum' ])
            ];
            return { stageIntro, quarters, ind };
        }

        function grxMap(){
            // map needs -> packages by stage
            const rows=[
                ['A website that turns visitors into enquiries','Lead Engine Website','/solutions#pkg-website'],
                ['Ads that actually bring leads (not just clicks)','Ads Rescue & Accelerator','/solutions#pkg-ads'],
                ['Consistent social content without the daily grind','Social Growth System','/solutions#pkg-social'],
                ['A 24/7 assistant that answers & captures leads','AI Business Assistant','/solutions#pkg-assistant'],
                ['One team accountable for all of it, monthly','Monthly Growth Partnerships','/solutions#monthly']
            ];
            if(data.stage==='idea'||data.stage==='new') rows.unshift(['A clear, validated starting roadmap','90-Day Customer Growth Plan','/solutions#pkg-plan']);
            if(data.stage==='stuck') rows.unshift(['Find exactly why growth stalled','90-Day Customer Growth Plan','/solutions#pkg-plan']);
            return '<div class="grx-map">'+rows.map(r=>'<div class="row"><span class="need">'+esc(r[0])+'</span><a class="pkg-link" href="'+r[2]+'">'+esc(r[1])+' →</a></div>').join('')+'</div>';
        }

        function renderPlan(){
            const p=buildPlan();
            const ind=p.ind;
            const quickWins=[
                'Claim & complete your Google Business Profile today \u2014 it\u2019s free and drives local calls',
                'Add a WhatsApp click-to-chat button to your site & socials',
                'Ask your 5 happiest customers for a Google review this week',
                'Write one clear sentence: what you do, for whom, in '+(data.location||'your area')
            ];
            const html =
                '<div class="plan-head"><span class="eyebrow">Personalized Plan</span><h2>'+esc(data.name)+'\u2019s <strong>1-Year Growth Plan</strong></h2></div>'+
                '<div class="plan-summary"><strong>Business:</strong> '+esc(data.services)+' &nbsp;·&nbsp; <strong>Industry:</strong> '+esc(data.industry)+' &nbsp;·&nbsp; <strong>Location:</strong> '+esc(data.location||'\u2014')+' &nbsp;·&nbsp; <strong>Audience:</strong> '+esc(data.audience||'\u2014')+'<br><br>'+esc(p.stageIntro)+'</div>'+
                '<div class="sec-title">\uD83D\uDE80 Your First 30 Days (Quick Wins)</div>'+
                '<div class="mkt-box"><ul>'+quickWins.map(w=>'<li>'+esc(w)+'</li>').join('')+'</ul></div>'+
                '<div class="sec-title">\uD83D\uDCC5 The 12-Month Roadmap</div>'+p.quarters.join('')+
                '<div class="sec-title">\uD83D\uDCE3 Your Marketing Mix</div>'+
                '<div class="two-col">'+
                    '<div class="mkt-box"><h4>\uD83D\uDCBB Online Marketing</h4><ul>'+ind.on.map(x=>'<li>'+esc(x)+'</li>').join('')+'</ul></div>'+
                    '<div class="mkt-box"><h4>\uD83D\uDCCD Offline Marketing</h4><ul>'+ind.off.map(x=>'<li>'+esc(x)+'</li>').join('')+'</ul></div>'+
                '</div>'+
                '<div class="sec-title">\u2728 How Graphinxt Can Help</div>'+
                '<p style="font-size:0.85rem;color:var(--text-muted);font-weight:300;margin-bottom:0.5rem;">Based on your plan, here\u2019s exactly what we\u2019d do for you \u2014 and where to start:</p>'+
                grxMap()+
                '<div class="plan-actions">'+
                    '<button class="btn-primary" onclick="downloadPlanPDF()">\u2b07 Download Plan as PDF</button>'+
                    '<a class="btn-outline" data-pkg="planner" target="_blank" rel="noopener" href="'+waLink()+'">Discuss My Plan on WhatsApp</a>'+
                '</div>'+
                saveBoxHTML()+
                chatHTML()+
                '<p class="disclaimer">This plan is generated from what you told us as a practical starting framework \u2014 a free strategy call tailors it to your exact numbers. Your details are stored only in this browser unless you contact us.</p>';
            const out=document.getElementById('plan-output');
            out.innerHTML=html; out.classList.add('show');
            wireChat();
            if(out.scrollIntoView) out.scrollIntoView({behavior:'smooth',block:'start'});
        }

        function waLink(){
            const msg='Hi Graphinxt! I built my 1-Year Growth Plan on your site.\nBusiness: '+data.name+' ('+data.services+')\nIndustry: '+data.industry+'\nLocation: '+data.location+'\nAudience: '+data.audience+'\nStage: '+data.stage+'\nI\u2019d like to discuss how you can help me execute it.';
            return 'https://wa.me/971564785139?text='+encodeURIComponent(msg);
        }

        function saveBoxHTML(){
            const saved=lsGet('grx_planner_email');
            if(saved) return '<div class="save-box saved"><strong>\u2713 Plan saved for '+esc(saved)+'</strong><div style="font-size:0.8rem;color:var(--text-muted);margin-top:0.4rem;">We\u2019ll welcome you back and show your next step when you return on this device.</div></div>';
            return '<div class="save-box"><strong>Save your plan & get a reminder path</strong><div style="font-size:0.8rem;color:var(--text-muted);margin-top:0.4rem;">Add your email so the planner remembers you and shows your next step next time.</div><div class="save-row"><input type="email" id="save-email" placeholder="you@business.com" autocomplete="email"><button class="run-btn" onclick="savePlanEmail()">Save Plan</button></div></div>';
        }

        window.savePlanEmail = function(){
            const el=document.getElementById('save-email'); const v=(el.value||'').trim();
            if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v)){ el.placeholder='Enter a valid email'; el.value=''; return; }
            lsSet('grx_planner_email',v); saveProgress();
            window.trackConversion('planner_email_saved',{page:'/growth-planner'});
            // hand the lead to you via WhatsApp (client-side capture)
            const box=el.closest('.save-box'); box.classList.add('saved');
            box.innerHTML='<strong>\u2713 Saved for '+esc(v)+'</strong><div style="font-size:0.8rem;color:var(--text-muted);margin-top:0.5rem;">Your plan will reload next time you visit on this device. Want us to send a copy & next steps? <a href="'+waLink()+'" target="_blank" rel="noopener" style="color:var(--brand-gold);">Message us on WhatsApp \u2192</a></div>';
        };

        function saveProgress(){
            try{ lsSet('grx_planner_data', JSON.stringify({data:data, savedAt:Date.now()})); }catch(e){}
        }

        // ---- PDF ----
        window.downloadPlanPDF = function(){
            if(!(window.jspdf&&window.jspdf.jsPDF)){ return; }
            window.trackConversion('planner_pdf_download',{page:'/growth-planner'});
            const doc=new window.jspdf.jsPDF(); const p=buildPlan(); const ind=p.ind;
            const M=16; let y=0; const W=210;
            function header(){ doc.setFillColor(54,54,56); doc.rect(0,0,W,30,'F'); doc.setTextColor(233,196,111); doc.setFontSize(17); doc.setFont(undefined,'bold'); doc.text('GRAPHINXT.',M,14); doc.setTextColor(255,255,255); doc.setFontSize(9); doc.setFont(undefined,'normal'); doc.text('1-Year Business Growth Plan',M,22); y=40; }
            function need(h){ if(y+h>282){ doc.addPage(); y=20; } }
            function h(t){ need(12); doc.setTextColor(214,175,55); doc.setFontSize(12); doc.setFont(undefined,'bold'); doc.text(t,M,y); y+=7; }
            function body(lines,bullet){ doc.setTextColor(55,55,55); doc.setFontSize(9.5); doc.setFont(undefined,'normal'); lines.forEach(function(t){ const wrapped=doc.splitTextToSize((bullet?'\u2022  ':'')+t,W-M*2); need(wrapped.length*5+2); doc.text(wrapped,M+(bullet?2:0),y); y+=wrapped.length*5+1.5; }); }
            header();
            doc.setTextColor(30,30,30); doc.setFontSize(16); doc.setFont(undefined,'bold'); need(10); doc.text((data.name||'Your Business')+' — Growth Plan',M,y); y+=8;
            doc.setFontSize(9.5); doc.setFont(undefined,'normal'); doc.setTextColor(90,90,90);
            body(['Business: '+(data.services||'—'),'Industry: '+data.industry,'Location: '+(data.location||'—'),'Audience: '+(data.audience||'—'),'Generated: '+new Date().toLocaleDateString()]);
            y+=2; body([p.stageIntro]); y+=3;
            h('The 12-Month Roadmap');
            [['Q1 · Foundation (Months 1-3)',0],['Q2 · Traction (Months 4-6)',1],['Q3 · Scale (Months 7-9)',2],['Q4 · Systemize (Months 10-12)',3]].forEach(function(qq){
                need(10); doc.setTextColor(30,30,30); doc.setFontSize(10.5); doc.setFont(undefined,'bold'); doc.text(qq[0],M,y); y+=6;
                const tmp=document.createElement('div'); tmp.innerHTML=p.quarters[qq[1]];
                const items=Array.prototype.map.call(tmp.querySelectorAll('li'),function(li){return li.textContent;});
                body(items,true); y+=2;
            });
            h('Online Marketing'); body(ind.on,true); y+=2;
            h('Offline Marketing'); body(ind.off,true); y+=3;
            h('How Graphinxt Can Help');
            body(['Explore matching growth packages at graphinxt.com/solutions','Book a free strategy call: reach@graphinxt.com','WhatsApp: wa.me/971564785139']);
            need(14); doc.setFillColor(233,196,111); doc.roundedRect(M,y,W-M*2,12,3,3,'F'); doc.setTextColor(54,54,56); doc.setFontSize(10); doc.setFont(undefined,'bold'); doc.text('Ready to execute this plan? Graphinxt can build it with you — graphinxt.com/solutions',M+4,y+7.5); 
            doc.save('graphinxt-growth-plan-'+(data.name||'business').toLowerCase().replace(/[^a-z0-9]+/g,'-').slice(0,24)+'.pdf');
        };

        // ---- planner chat (guided, context-aware) ----
        function chatHTML(){
            return '<div class="planner-chat" id="planner-chat">'+
                '<div class="pc-head"><span class="live"></span> Chat with your Growth Planner</div>'+
                '<div class="pc-body" id="pc-body"></div>'+
                '<div class="pc-input"><input type="text" id="pc-in" placeholder="Ask about your plan…" autocomplete="off"><button onclick="pcSend()">Send</button></div>'+
            '</div>';
        }
        const CHAT_LOG_KEY='grx_planner_chat';
        function pcAdd(text,who,noLog){
            const b=document.getElementById('pc-body'); if(!b) return;
            const m=document.createElement('div'); m.className='pc-msg '+(who==='user'?'pc-user':'pc-bot'); m.innerHTML=text; b.appendChild(m); b.scrollTop=b.scrollHeight;
            if(!noLog){ try{ const log=JSON.parse(lsGet(CHAT_LOG_KEY)||'[]'); log.push({who:who,text:m.textContent,at:Date.now()}); lsSet(CHAT_LOG_KEY,JSON.stringify(log.slice(-50))); }catch(e){} }
        }
        function pcReply(t){
            const s=t.toLowerCase();
            if(/logo|brand|identity|colour|color|visual/.test(s)) return 'Yes \u2014 branding is one of our core services. For '+esc(data.name||'your business')+' we design logos, colour palettes, and a full visual identity that works across your website, social, and print. Try our free <a href="/tools#startup-kit-tool">branding kit</a> for instant name, palette and logo concepts, or see our <a href="/services/branding">branding service</a> and <a href="/portfolio">portfolio</a>. Want us to quote a full brand package?';
            if(/name|naming|business name/.test(s)) return 'Naming is tricky \u2014 our free <a href="/tools#startup-kit-tool">startup kit</a> generates name ideas, taglines and domain checks in seconds. For a done-for-you brand (name + logo + identity), our <a href="/services/branding">branding team</a> can take it end to end.';
            if(/video|reel|edit|animation/.test(s)) return 'We do video too \u2014 reels, promos, and edits that fit your social plan. It pairs well with the <a href="/solutions#social-management">social packages</a>. See examples in our <a href="/portfolio">portfolio</a>.';
            if(/email|newsletter|mailing/.test(s)) return 'Email marketing is a Q2\u2013Q3 move for '+esc(data.name||'your business')+' \u2014 a list plus automated flows (welcome, abandoned enquiry, offers) is one of the cheapest revenue channels. We set this up inside the monthly <a href="/solutions#monthly">Growth partnerships</a>.';
            if(/competitor|rival|competition/.test(s)) return 'Smart to look at competitors. Our <a href="/solutions#pkg-plan">$300 90-Day Growth Plan</a> includes a 3-competitor analysis \u2014 rankings, ads, and positioning \u2014 so you know exactly where the gaps are.';
            if(/portfolio|example|work|case stud/.test(s)) return 'Take a look at our <a href="/portfolio">portfolio</a> \u2014 real client sites across the UK, Canada, New Zealand and more. Every project there started with a plan like the one you just built.';
            if(/website|site/.test(s)) return 'For '+esc(data.name||'your business')+', a conversion-focused website is Q1 priority. Our <a href="/solutions#pkg-website">Lead Engine Website</a> ($950) builds exactly that. Want me to note it for your strategy call?';
            if(/ad|advertis|google ads|facebook|meta/.test(s)) return 'Start ads in Q2 on your highest-intent channel. Try the free <a href="/tools#budget-architect">budget planner</a> to project leads, or our <a href="/solutions#pkg-ads">Ads Rescue</a> ($700) sets it up properly.';
            if(/social|instagram|content|post/.test(s)) return 'Your industry does well on '+esc((INDUSTRIES[data.industry]||INDUSTRIES['Other / General']).channels)+'. The <a href="/solutions#social-management">social packages</a> (from $500/mo) run it for you.';
            if(/seo|rank|google|search/.test(s)) return 'SEO compounds \u2014 begin in Q1 with your Google Business Profile and "[service] in '+esc(data.location||'your city')+'" pages. Free tools to start: <a href="/tools#meta-generator">meta generator</a> & <a href="/tools#web-diagnostic">site diagnostic</a>.';
            if(/cost|price|how much|budget|afford/.test(s)) return 'Our packages run $300\u2013$5,000 one-time plus monthly plans from $149. The <a href="/solutions#pkg-plan">$300 Growth Plan</a> is the risk-free start \u2014 and it\u2019s credited if you continue. Full list: <a href="/solutions">solutions</a>.';
            if(/offline|flyer|print|local/.test(s)) return 'Great question \u2014 for '+esc(data.industry)+' in '+esc(data.location||'your area')+', strong offline moves: '+esc((INDUSTRIES[data.industry]||INDUSTRIES['Other / General']).off.slice(0,2).join('; '))+'. All of it is in your PDF.';
            if(/next|start|begin|step|first/.test(s)) return nextStepMsg();
            if(/thank|great|good|nice|ok/.test(s)) return 'You\u2019re welcome! Download your plan as a PDF so you have it handy, and whenever you\u2019re ready, <a href="'+waLink()+'" target="_blank" rel="noopener">message us</a> to build it together.';
            return 'Happy to help with that! I can talk through your <strong>website</strong>, <strong>branding &amp; logo</strong>, <strong>ads</strong>, <strong>social</strong>, <strong>SEO</strong>, <strong>video</strong>, <strong>email</strong>, <strong>competitors</strong>, <strong>offline marketing</strong>, or <strong>costs</strong> \u2014 or type "next step". For anything specific to '+esc(data.name||'your business')+', the fastest route is a quick chat: <a href="'+waLink()+'" target="_blank" rel="noopener">message our team on WhatsApp \u2192</a>.';
        }
        function nextStepMsg(){
            const st=data.stage;
            if(st==='idea'||st==='new') return 'Your next step: lock your foundations \u2014 brand, website, Google Business Profile. The <a href="/solutions#pkg-plan">$300 90-Day Growth Plan</a> maps it precisely, or start free with our <a href="/tools">toolbox</a>. Shall I open WhatsApp so we can talk it through?';
            if(st==='stuck') return 'Your next step: diagnose the leak before spending more. Run the free <a href="/tools#web-diagnostic">website diagnostic</a>, then the <a href="/solutions#pkg-plan">$300 Growth Plan</a> pinpoints the fix. <a href="'+waLink()+'" target="_blank" rel="noopener">Talk to us</a> when ready.';
            return 'Your next step: turn the roadmap into monthly action. A <a href="/solutions#monthly">monthly growth partnership</a> keeps it moving, or pick the single package that unblocks you most. Want a free strategy call? <a href="'+waLink()+'" target="_blank" rel="noopener">Message us</a>.';
        }
        window.pcSend=function(){
            const inp=document.getElementById('pc-in'); const t=(inp.value||'').trim(); if(!t) return;
            pcAdd(esc(t),'user'); inp.value='';
            window.trackConversion('planner_chat_msg',{page:'/growth-planner'});
            setTimeout(()=>pcAdd(pcReply(t),'bot'),700);
        };
        function wireChat(){
            const inp=document.getElementById('pc-in'); if(inp) inp.addEventListener('keypress',e=>{if(e.key==='Enter')pcSend();});
            pcAdd('Hi'+(data.name?' from '+esc(data.name):'')+'! Your 1-year plan is ready above. '+nextStepMsg(),'bot',true);
        }

        // ---- RETURN VISIT ----
        (function(){
            let saved=null; try{ saved=JSON.parse(lsGet('grx_planner_data')||'null'); }catch(e){}
            const email=lsGet('grx_planner_email');
            if(saved&&saved.data&&saved.data.name){
                const wb=document.getElementById('welcome-back');
                const when=saved.savedAt?new Date(saved.savedAt).toLocaleDateString():'';
                wb.innerHTML='<strong style="color:var(--brand-gold);">\uD83D\uDC4B Welcome back'+(email?', '+esc(email.split('@')[0]):'')+'!</strong><div style="font-size:0.85rem;color:var(--text-muted);margin:0.4rem 0 0.9rem;font-weight:300;">We saved your plan for <strong style="color:var(--text-main);">'+esc(saved.data.name)+'</strong>'+(when?' from '+when:'')+'. Pick up where you left off, or start fresh.</div><div style="display:flex;gap:0.6rem;flex-wrap:wrap;"><button class="run-btn" id="resume-btn">Reload My Plan</button><button class="ghost-btn" id="fresh-btn">Start New Plan</button></div>';
                wb.classList.add('show');
                document.getElementById('resume-btn').onclick=function(){
                    Object.assign(data,saved.data);
                    window.trackConversion('planner_return_resume',{page:'/growth-planner'});
                    document.getElementById('planner-card').style.display='none'; wb.classList.remove('show'); renderPlan();
                };
                document.getElementById('fresh-btn').onclick=function(){
                    try{ window.localStorage.removeItem('grx_planner_data'); window.localStorage.removeItem('grx_planner_chat'); }catch(e){}
                    wb.classList.remove('show');
                };
            }
        })();
    })();
    </script>

    <script>
    // Animated gold-particle background — matches Graphinxt homepage
    (function() {
        var canvas = document.getElementById('bg-canvas');
        if (!canvas) return;
        var ctx = (canvas.getContext) ? canvas.getContext('2d') : null;
        if (!ctx) return;
        if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
        var particles = [], w, h, animationId;
        function resize(){ w = canvas.width = window.innerWidth; h = canvas.height = window.innerHeight; }
        resize(); window.addEventListener('resize', resize);
        function create(){
            var count = Math.min(Math.floor(w / 18), 70); particles = [];
            for (var i=0;i<count;i++){ particles.push({ x:Math.random()*w, y:Math.random()*h, r:Math.random()*1.8+0.4, vy:-(Math.random()*0.4+0.1), vx:(Math.random()-0.5)*0.2, alpha:Math.random()*0.5+0.1, pulse:Math.random()*Math.PI*2, pulseSpeed:Math.random()*0.02+0.005 }); }
        }
        create();
        function animate(){
            if (!ctx) return;
            ctx.clearRect(0,0,w,h);
            particles.forEach(function(p){
                p.y+=p.vy; p.x+=p.vx; p.pulse+=p.pulseSpeed;
                var a = p.alpha*(0.5+0.5*Math.sin(p.pulse));
                if (p.y<-10){ p.y=h+10; p.x=Math.random()*w; }
                if (p.x<-10) p.x=w+10; if (p.x>w+10) p.x=-10;
                var g = ctx.createRadialGradient(p.x,p.y,0,p.x,p.y,p.r*6);
                g.addColorStop(0,'rgba(233,196,111,'+a+')'); g.addColorStop(1,'rgba(233,196,111,0)');
                ctx.fillStyle=g; ctx.beginPath(); ctx.arc(p.x,p.y,p.r*6,0,Math.PI*2); ctx.fill();
                ctx.fillStyle='rgba(233,196,111,'+(a*1.5)+')'; ctx.beginPath(); ctx.arc(p.x,p.y,p.r,0,Math.PI*2); ctx.fill();
            });
            animationId = requestAnimationFrame(animate);
        }
        function start(){ if(!animationId) animate(); }
        function stop(){ if(animationId){ cancelAnimationFrame(animationId); animationId=null; if(ctx) ctx.clearRect(0,0,w,h);} }
        function checkTheme(){ if(document.body.classList.contains('light-mode')) stop(); else start(); }
        checkTheme();
        var tt = document.getElementById('theme-toggle') || document.getElementById('theme-toggle-btn');
        if (tt) tt.addEventListener('click', function(){ setTimeout(checkTheme, 60); });
    })();
    </script>
 <?php include '../footer.php';?>
 <script src="../assets/js/script.js"></script>

    </body>
</html>
