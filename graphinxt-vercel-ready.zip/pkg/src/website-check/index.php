<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Free Website SEO & Performance Check | Graphinxt</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <meta name="description" content="Free instant website snapshot across SEO, AEO-readiness, performance, mobile & security — with a prioritized action plan and PDF report.">
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="https://graphinxt.com/website-check">
    <meta property="og:site_name" content="Graphinxt">
    <meta property="og:type" content="website">
    <meta property="og:title" content="Website Intelligence — Free Instant Snapshot | Graphinxt">
    <meta property="og:description" content="See what your website is actually telling Google — free, instant, shareable.">
    <meta property="og:url" content="https://graphinxt.com/website-check">
    <meta property="og:image" content="https://graphinxt.com/assets/og-cover.jpg">
    <meta name="twitter:card" content="summary_large_image">
     <link rel="stylesheet" href="../assets/style.css">
     <link rel="stylesheet" href="../assets/header.css">
        <link rel="shortcut icon" href="../assets/favicon.ico" type="image/x-icon">
        <link rel="icon" href="../assets/favicon.ico" type="image/x-icon">
    
    <meta name="twitter:image" content="https://graphinxt.com/assets/og-cover.jpg">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@200;300;400;500;800&display=swap" rel="stylesheet">

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "WebApplication",
      "name": "Graphinxt Website Intelligence",
      "url": "https://graphinxt.com/website-check",
      "applicationCategory": "SEO Tool",
      "offers": { "@type": "Offer", "price": "0", "priceCurrency": "USD" },
      "description": "Free instant website health snapshot covering SEO, AEO readiness, performance, mobile experience, and security."
    }
    </script>

<!-- ===== ANALYTICS & CONVERSION TRACKING ===== -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-58PYC27MPE"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-58PYC27MPE');
</script>
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '2162187584315430');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=2162187584315430&ev=PageView&noscript=1" /></noscript>
<script>
  window.trackConversion = function(eventName, params) {
    params = params || {};
    try { if (typeof gtag === 'function') gtag('event', eventName, params); } catch(e) {}
    try { if (typeof fbq === 'function') fbq('trackCustom', eventName, params); } catch(e) {}
  };
  document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('a[href*="wa.me"]').forEach(function(el) {
      el.addEventListener('click', function() { window.trackConversion('whatsapp_click', { page: window.location.pathname }); });
    });
  });
</script>
<script src="https://cdn.jsdelivr.net/npm/@emailjs/browser@4/dist/email.min.js"></script>
<!-- ===== END ANALYTICS ===== -->

    <style>
        :root {
            --bg-dark: #363638; --bg-darker: #2a2a2c; --brand-gold: #e9c46f; --brand-gold-hover: #d4ae58;
            --text-main: #ffffff; --text-muted: #a1a1a5; --card-bg: rgba(255,255,255,0.02);
            --border-light: rgba(233,196,111,0.12); --border-glow: rgba(233,196,111,0.4);
            --nav-bg: rgba(42,42,44,0.4); --nav-bg-scrolled: rgba(30,30,32,0.8);
        }
        section { padding: 5rem 5%; max-width: 1100px; margin: 0 auto; position: relative; z-index: 1; }
        .hero-sec { padding-top: 14rem; text-align: center; }
        .eyebrow { font-size: 0.75rem; color: var(--brand-gold); text-transform: uppercase; letter-spacing: 3px; margin-bottom: 1.2rem; display: inline-block; }
        .hero-sec h1 { font-size: clamp(2rem, 5vw, 3.4rem); font-weight: 200; line-height: 1.15; margin-bottom: 1.2rem; }
        .hero-sec h1 strong { font-weight:800; background:linear-gradient(to right,#ffffff,var(--brand-gold)); -webkit-background-clip:text; background-clip:text; -webkit-text-fill-color:transparent; color:var(--brand-gold); }
        .hero-sec p { color: var(--text-muted); max-width: 560px; margin: 0 auto 2.5rem; font-weight: 300; }

        .tool-card { background: var(--card-bg); border: 1px solid var(--border-light); border-radius: 28px; padding: 3rem; max-width: 720px; margin: 0 auto; }
        .snapshot-input-row { display: flex; gap: 0.8rem; flex-wrap: wrap; justify-content: center; }
        .snapshot-input { flex: 1; min-width: 220px; background: var(--bg-darker); border: 1px solid var(--border-light); color: var(--text-main); padding: 1rem 1.4rem; border-radius: 30px; font-size: 0.95rem; outline: none; }
        .snapshot-input:focus { border-color: var(--brand-gold); }
        .snapshot-btn { background: var(--brand-gold); color: var(--bg-dark) !important; padding: 1rem 2rem; border-radius: 30px; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; border: none; font-size: 0.76rem; white-space: nowrap; cursor: pointer; transition: all .3s; }
        .snapshot-btn:hover { transform: scale(1.05); }
        .snapshot-btn:disabled { opacity: 0.6; }
        .snapshot-hint { font-size: 0.7rem; color: var(--text-muted); opacity: 0.7; margin-top: 1rem; text-align: center; }

        .snapshot-results { display: none; margin-top: 2.5rem; }
        .snapshot-results.show { display: block; animation: fadeIn .6s ease; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(14px); } to { opacity: 1; transform: translateY(0); } }
        .snapshot-top { display: flex; align-items: center; justify-content: center; gap: 2.2rem; flex-wrap: wrap; margin-bottom: 2rem; }
        .snapshot-ring-wrap { position: relative; width: 150px; height: 150px; flex-shrink: 0; }
        .snapshot-ring-wrap svg { transform: rotate(-90deg); width: 100%; height: 100%; }
        .snapshot-ring-bg { fill: none; stroke: var(--border-light); stroke-width: 8; }
        .snapshot-ring-fill { fill: none; stroke: var(--brand-gold); stroke-width: 8; stroke-linecap: round; transition: stroke-dashoffset 1.3s cubic-bezier(.165,.84,.44,1); }
        .snapshot-ring-label { position: absolute; inset: 0; display: flex; flex-direction: column; align-items: center; justify-content: center; }
        .snapshot-ring-num { font-size: 2.2rem; font-weight: 800; }
        .snapshot-ring-sub { font-size: 0.62rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1px; }
        .snapshot-verdict { max-width: 320px; text-align: left; }
        .domain-echo { font-family: monospace; color: var(--brand-gold); font-size: 0.82rem; margin-bottom: 0.4rem; word-break: break-all; }
        .snapshot-verdict p { color: var(--text-muted); font-size: 0.85rem; font-weight: 300; }
        .benchmark-line { font-size: 0.72rem; color: var(--text-muted); margin-top: 0.6rem; }
        .benchmark-line strong { color: var(--brand-gold); }

        .snapshot-categories { display: grid; grid-template-columns: repeat(auto-fit, minmax(190px,1fr)); gap: 1rem; margin-bottom: 1.5rem; text-align: left; }
        .snapshot-cat { background: var(--bg-darker); border: 1px solid var(--border-light); border-radius: 14px; padding: 1.2rem 1.3rem; }
        .snapshot-cat-head { display: flex; justify-content: space-between; margin-bottom: 0.6rem; font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.5px; }
        .snapshot-cat-head span:last-child { color: var(--brand-gold); font-weight: 800; }
        .snapshot-cat-bar { height: 5px; border-radius: 3px; background: var(--border-light); overflow: hidden; }
        .snapshot-cat-fill { height: 100%; width: 0%; background: var(--brand-gold); border-radius: 3px; transition: width 1.1s cubic-bezier(.165,.84,.44,1); }
        .snapshot-cat-tip { font-size: 0.72rem; color: var(--text-muted); margin-top: 0.6rem; font-weight: 300; }

        .history-row { background: var(--bg-darker); border: 1px dashed var(--border-light); border-radius: 14px; padding: 1rem 1.3rem; margin-bottom: 1.5rem; font-size: 0.78rem; color: var(--text-muted); display: none; }
        .history-row.show { display: block; }
        .history-row strong { color: var(--brand-gold); }

        .share-row { display: flex; gap: 0.8rem; flex-wrap: wrap; justify-content: center; margin-bottom: 2rem; }
        .disclaimer { font-size: 0.68rem; color: var(--text-muted); opacity: 0.6; text-align: center; max-width: 600px; margin: 0 auto 2rem; }

        .tiers-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px,1fr)); gap: 1.5rem; margin-top: 3rem; }
        .tier-card { background: var(--card-bg); border: 1px solid var(--border-light); border-radius: 20px; padding: 2.2rem; }
        .tier-card.highlight { border-color: var(--border-glow); background: linear-gradient(135deg, rgba(233,196,111,0.06), transparent); }
        .tier-card h3 { font-size: 1.1rem; margin-bottom: 0.5rem; }
        .tier-price { font-size: 1.8rem; font-weight: 800; color: var(--brand-gold); margin-bottom: 1rem; }
        .tier-price span { font-size: 0.75rem; color: var(--text-muted); font-weight: 400; }
        .tier-card ul { list-style: none; margin-bottom: 1.5rem; }
        .tier-card li { font-size: 0.82rem; color: var(--text-muted); padding: 0.4rem 0; padding-left: 1.3rem; position: relative; }
        .tier-card li::before { content: '✓'; position: absolute; left: 0; color: var(--brand-gold); }
        .waitlist-badge { display: inline-block; font-size: 0.6rem; text-transform: uppercase; letter-spacing: 1px; background: rgba(233,196,111,0.14); color: var(--brand-gold); padding: 3px 10px; border-radius: 20px; margin-bottom: 1rem; }

        .waitlist-form { display: none; flex-direction: column; gap: 0.9rem; margin-top: 1.2rem; }
        .waitlist-form.show { display: flex; }
        .waitlist-form input { background: var(--bg-darker); border: 1px solid var(--border-light); color: var(--text-main); padding: 0.85rem 1.1rem; border-radius: 10px; font-size: 0.85rem; outline: none; }
        .waitlist-form input:focus { border-color: var(--brand-gold); }
        .waitlist-success { display: none; color: var(--brand-gold); font-size: 0.82rem; margin-top: 1rem; }
        .waitlist-success.show { display: block; }

        footer { padding: 4rem 5%; text-align: center; border-top: 1px solid var(--border-light); color: var(--text-muted); font-size: 0.8rem; }
        footer a { color: var(--brand-gold); text-decoration: none; }
    </style>
</head>
<body>
    <canvas id="bg-canvas"></canvas>
    <div class="ambient-glow"></div>
            <?php include '../header.php';?>

    <header class="hero-sec">
        <span class="eyebrow">Free Tool · No Signup</span>
        <h1>What's Your Website Actually <strong>Telling Google?</strong></h1>
        <p>Run an instant snapshot across Performance, SEO, AEO-readiness, Mobile, and Security. Bookmark this page — check back anytime to see if your score has moved.</p>
    </header>

    <section style="padding-top:0;">
        <div class="tool-card">
            <div class="snapshot-input-row">
                <input type="text" id="snapshot-input" class="snapshot-input" placeholder="yourwebsite.com" autocomplete="off">
                <button id="snapshot-btn" class="snapshot-btn" onclick="runSnapshot()">Run Snapshot →</button>
            </div>
            <div class="snapshot-hint">Takes 3 seconds. Works on any domain. Nothing to install.</div>

            <div class="history-row" id="history-row"></div>

            <div class="snapshot-results" id="snapshot-results">
                <div class="snapshot-top">
                    <div class="snapshot-ring-wrap">
                        <svg viewBox="0 0 120 120">
                            <circle class="snapshot-ring-bg" cx="60" cy="60" r="52"></circle>
                            <circle class="snapshot-ring-fill" id="snapshot-ring-fill" cx="60" cy="60" r="52" stroke-dasharray="327" stroke-dashoffset="327"></circle>
                        </svg>
                        <div class="snapshot-ring-label">
                            <div class="snapshot-ring-num" id="snapshot-ring-num">0</div>
                            <div class="snapshot-ring-sub">Overall</div>
                        </div>
                    </div>
                    <div class="snapshot-verdict">
                        <div class="domain-echo" id="snapshot-domain">—</div>
                        <p id="snapshot-verdict-text">Analyzing...</p>
                        <div class="benchmark-line" id="benchmark-line"></div>
                    </div>
                </div>

                <div class="snapshot-categories" id="snapshot-categories"></div>

                <div id="snap-action-plan" style="margin-top:2rem;"></div>

                <div style="margin-top:2rem; border:1px solid var(--border-light); border-radius:16px; padding:1.4rem;">
                    <div style="font-size:0.8rem; color:var(--brand-gold); font-weight:600; margin-bottom:0.8rem;">Advanced: Compare vs a Competitor</div>
                    <div style="display:flex; gap:0.8rem; flex-wrap:wrap;">
                        <input type="text" id="compare-input" class="snapshot-input" placeholder="competitor.com" autocomplete="off" style="flex:1; min-width:200px;">
                        <button class="snapshot-btn" onclick="runCompare()" style="white-space:nowrap;">Compare →</button>
                    </div>
                    <div id="compare-results" style="margin-top:1.2rem;"></div>
                </div>

                <div class="share-row" style="margin-top:1.5rem;">
                    <button class="btn-outline" onclick="downloadSnapPDF()" style="cursor:pointer;">Download PDF Report</button>
                </div>

                <div class="share-row">
                    <button class="btn-outline" id="copy-link-btn" onclick="copyShareLink()" style="border:none; cursor:pointer;">🔗 Copy Shareable Link</button>
                </div>

                <p class="disclaimer">This is a heuristic preliminary snapshot based on your URL structure — not a full technical crawl. The benchmark line is a general reference point, not live competitor data. Our team runs the real audit (Core Web Vitals, live schema validation) free when you book a call.</p>

                <div class="share-row">
                    <a href="/#contact" class="btn-primary">Book Your Free Full Audit</a>
                    <a href="https://wa.me/971564785139" target="_blank" class="btn-outline">Ask on WhatsApp</a>
                </div>
            </div>
        </div>
    </section>

    <section>
        <div style="text-align:center; max-width:600px; margin: 0 auto 2.5rem;">
            <h2 style="font-size:clamp(1.5rem,3vw,2.2rem); font-weight:200; margin-bottom:0.8rem;">Want it <strong style="color:var(--brand-gold); font-weight:800;">monitored</strong>, not just checked once?</h2>
            <p style="color:var(--text-muted); font-weight:300; font-size:0.9rem;">Premium monitoring with real Core Web Vitals, live schema validation, and monthly reports is launching soon. Join the waitlist and we'll notify you.</p>
        </div>
        <div class="tiers-grid" id="waitlist">
            <div class="tier-card">
                <h3>Free Snapshot</h3>
                <div class="tier-price">$0</div>
                <ul>
                    <li>Instant heuristic score</li>
                    <li>5 category breakdown</li>
                    <li>Shareable result link</li>
                    <li>Unlimited re-checks</li>
                </ul>
                <div class="btn-outline" style="text-align:center; opacity:0.6; cursor:default;">You're using this now</div>
            </div>
            <div class="tier-card highlight">
                <span class="waitlist-badge">Launching Soon</span>
                <h3>Premium Monitoring</h3>
                <div class="tier-price">TBD <span>/mo</span></div>
                <ul>
                    <li>Real Core Web Vitals via Lighthouse</li>
                    <li>Live schema &amp; structured data validation</li>
                    <li>Monthly email report</li>
                    <li>Priority support from our team</li>
                </ul>
                <button class="btn-primary" style="width:100%; border:none;" onclick="toggleWaitlist()">Join the Waitlist</button>
                <form class="waitlist-form" id="waitlist-form">
                    <input type="text" id="wl-name" placeholder="Your name" required>
                    <input type="email" id="wl-email" placeholder="Email address" required>
                    <input type="text" id="wl-domain" placeholder="Your website (optional)">
                    <button type="submit" class="btn-primary" style="border:none;">Notify Me When It's Live</button>
                </form>
                <div class="waitlist-success" id="waitlist-success">✓ You're on the list — we'll email you the moment it launches.</div>
            </div>
        </div>
    </section>

    <footer>
        © 2026 Graphinxt Digital Content Creator FZ LLC · <a href="mailto:reach@graphinxt.com">reach@graphinxt.com</a>
    
        <div style="margin-top:1rem;"><a href="/privacy" style="color:var(--text-muted,#a1a1a5); font-size:0.72rem; text-transform:uppercase; letter-spacing:1px; text-decoration:none;">Privacy Policy</a></div>
    </footer>

    <script>
        // Scroll nav shadow
        window.addEventListener('scroll', () => {
            document.getElementById('navbar').classList.toggle('scrolled', document.documentElement.scrollTop > 30);
        });

        const RING_CIRCUMFERENCE = 327;
        const snapInput = document.getElementById('snapshot-input');
        const snapBtn = document.getElementById('snapshot-btn');
        const snapResults = document.getElementById('snapshot-results');
        const snapDomain = document.getElementById('snapshot-domain');
        const snapVerdict = document.getElementById('snapshot-verdict-text');
        const snapRingFill = document.getElementById('snapshot-ring-fill');
        const snapRingNum = document.getElementById('snapshot-ring-num');
        const snapCategories = document.getElementById('snapshot-categories');
        const historyRow = document.getElementById('history-row');
        const benchmarkLine = document.getElementById('benchmark-line');
        const BENCHMARK_SCORE = 58; // general reference point for a typical small-business site, not live data

        function hashString(str) { let h = 5381; for (let i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) >>> 0; return h; }
        function seededRange(seed, min, max, salt) { const h = hashString(seed + '::' + salt); return min + (h % (max - min + 1)); }
        function cleanDomain(raw) { let d = raw.trim().toLowerCase(); d = d.replace(/^https?:\/\//, '').replace(/^www\./, '').split('/')[0]; return d; }

        function analyzeDomain(raw) {
            const hadHttps = /^https:\/\//i.test(raw.trim());
            const domain = cleanDomain(raw);
            const parts = domain.split('.');
            const tld = parts[parts.length - 1] || '';
            const sld = parts.length > 1 ? parts[parts.length - 2] : domain;
            const knownTlds = ['com','co','io','net','org','uk','ca','au','nz','dev','ai'];
            const cleanTld = knownTlds.includes(tld);
            const hasHyphen = sld.includes('-');
            const hasNumbers = /\d/.test(sld);
            const nameLength = sld.length;
            const cats = {};
            cats.security = hadHttps ? seededRange(domain, 82, 98, 'sec') : seededRange(domain, 35, 55, 'sec');
            let seo = seededRange(domain, 55, 80, 'seo');
            if (cleanTld) seo += 6; if (!hasHyphen) seo += 4; if (!hasNumbers) seo += 3;
            if (nameLength > 0 && nameLength <= 12) seo += 5;
            cats.seo = Math.min(seo, 97);
            cats.aeo = seededRange(domain, 28, 58, 'aeo');
            cats.performance = seededRange(domain, 48, 82, 'perf');
            cats.mobile = seededRange(domain, 55, 88, 'mob');
            const overall = Math.round((cats.security + cats.seo + cats.aeo + cats.performance + cats.mobile) / 5);
            const tips = {
                security: hadHttps ? 'HTTPS detected — good baseline trust signal for Google.' : 'No HTTPS detected — this is a hard ranking and trust factor.',
                seo: hasHyphen || hasNumbers ? 'Domain structure has hyphens/numbers, which can dilute brand clarity.' : 'Clean domain structure — good SEO foundation.',
                aeo: 'Most sites lack FAQPage, Organization, and Service schema — worth a live check.',
                performance: 'Core Web Vitals need a real Lighthouse crawl to verify — estimated here.',
                mobile: 'Mobile usability estimated — real audit checks tap targets and breakpoints.'
            };
            return { domain, overall, cats, tips, hadHttps };
        }

        function animateRing(score) {
            const offset = RING_CIRCUMFERENCE - (RING_CIRCUMFERENCE * score / 100);
            requestAnimationFrame(() => { snapRingFill.style.strokeDashoffset = offset; });
            let cur = 0; const step = Math.max(1, Math.round(score / 40));
            const timer = setInterval(() => { cur += step; if (cur >= score) { cur = score; clearInterval(timer); } snapRingNum.innerText = cur; }, 20);
        }
        function verdictFor(score) {
            if (score >= 80) return 'Strong foundation. A full audit would likely surface refinement, not structural fixes.';
            if (score >= 60) return 'Solid but leaving visibility on the table — particularly around AEO readiness.';
            return 'Meaningful gaps likely exist across technical SEO and structured data.';
        }
        const CAT_LABELS = { performance: 'Performance', seo: 'SEO', aeo: 'AEO Readiness', mobile: 'Mobile Experience', security: 'Security' };
        const PLAN_FIXES = {
            security: ['Install a free SSL certificate (Let\u2019s Encrypt) and force HTTPS site-wide', 'Add security headers: HSTS, X-Content-Type-Options, X-Frame-Options'],
            seo: ['Write unique title tags (<60 chars) and meta descriptions (<155) for every page', 'Fix internal linking: every important page should be reachable in 2 clicks'],
            aeo: ['Add FAQPage, Organization, and Service schema (JSON-LD) to key pages', 'Rewrite key H2s as questions and answer them in the first sentence below'],
            performance: ['Compress and lazy-load images (WebP), and remove unused scripts', 'Enable caching/CDN \u2014 aim for LCP under 2.5s on mobile'],
            mobile: ['Check tap targets are 44px+ and text is 16px+ without zooming', 'Test every form on a real phone \u2014 mobile forms lose the most leads']
        };
        function renderActionPlan(result) {
            const box = document.getElementById('snap-action-plan');
            if (!box) return;
            const ranked = Object.keys(result.cats).sort((x, y) => result.cats[x] - result.cats[y]).slice(0, 3);
            box.innerHTML = '<div style="font-size:0.8rem; color:var(--brand-gold); font-weight:600; margin-bottom:0.8rem;">Advanced: Your Priority Action Plan</div>' +
                ranked.map((k, i) => {
                    const impact = i === 0 ? 'High impact' : (i === 1 ? 'Medium impact' : 'Quick win');
                    return '<div style="border:1px solid var(--border-light); border-radius:14px; padding:1rem 1.2rem; margin-bottom:0.7rem;">' +
                        '<div style="display:flex; justify-content:space-between; gap:1rem; margin-bottom:0.5rem;"><strong style="font-size:0.85rem;">' + (i+1) + '. Fix ' + CAT_LABELS[k] + ' (' + result.cats[k] + '/100)</strong><span style="font-size:0.62rem; color:var(--brand-gold); text-transform:uppercase; letter-spacing:1px;">' + impact + '</span></div>' +
                        PLAN_FIXES[k].map(f => '<div style="font-size:0.8rem; color:var(--text-muted); font-weight:300; padding:0.2rem 0;">\u2192 ' + f + '</div>').join('') +
                    '</div>';
                }).join('');
        }
        window.runCompare = function() {
            const inp = document.getElementById('compare-input');
            const raw = inp.value.trim();
            if (!raw || !window._lastSnap) { inp.focus(); return; }
            if (window.trackConversion) trackConversion('tool_used', { tool: 'snapshot_compare', page: '/website-check' });
            const them = analyzeDomain(raw);
            const you = window._lastSnap;
            let wins = 0, rows = Object.keys(CAT_LABELS).map(k => {
                const lead = you.cats[k] >= them.cats[k];
                if (lead) wins++;
                return '<div style="display:flex; align-items:center; gap:0.8rem; font-size:0.8rem; padding:0.45rem 0; border-bottom:1px solid var(--border-light);">' +
                    '<span style="flex:1; color:var(--text-muted);">' + CAT_LABELS[k] + '</span>' +
                    '<span style="font-weight:700; width:34px; text-align:right; color:' + (lead ? 'var(--brand-gold)' : 'var(--text-main)') + ';">' + you.cats[k] + '</span>' +
                    '<span style="font-size:0.62rem; color:var(--text-muted); width:24px; text-align:center;">vs</span>' +
                    '<span style="width:34px; font-weight:700; color:' + (!lead ? 'var(--brand-gold)' : 'var(--text-main)') + ';">' + them.cats[k] + '</span>' +
                '</div>';
            }).join('');
            document.getElementById('compare-results').innerHTML =
                '<div style="font-size:0.75rem; color:var(--text-muted); margin-bottom:0.6rem;"><strong style="color:var(--text-main);">' + you.domain + '</strong> vs <strong style="color:var(--text-main);">' + them.domain + '</strong> \u2014 you lead in ' + wins + ' of 5 categories (heuristic estimate)</div>' + rows;
        };
        window.downloadSnapPDF = function() {
            const r = window._lastSnap;
            if (!r) return;
            if (!(window.jspdf && window.jspdf.jsPDF)) return;
            if (window.trackConversion) trackConversion('tool_used', { tool: 'snapshot_pdf', page: '/website-check' });
            const doc = new window.jspdf.jsPDF();
            doc.setFillColor(54,54,56); doc.rect(0,0,210,32,'F');
            doc.setTextColor(233,196,111); doc.setFontSize(18); doc.setFont(undefined,'bold'); doc.text('GRAPHINXT.', 14, 15);
            doc.setTextColor(255,255,255); doc.setFontSize(10); doc.setFont(undefined,'normal');
            doc.text('Website Growth Snapshot \u00b7 ' + r.domain + ' \u00b7 ' + new Date().toLocaleDateString(), 14, 24);
            doc.setTextColor(40,40,40); let y = 46;
            doc.setFontSize(14); doc.setFont(undefined,'bold'); doc.text('Overall Score: ' + r.overall + ' / 100', 14, y); y += 11;
            doc.setFontSize(10); doc.setFont(undefined,'normal');
            Object.keys(CAT_LABELS).forEach(k => { doc.text(CAT_LABELS[k] + ': ' + r.cats[k] + ' / 100 \u2014 ' + r.tips[k], 16, y, { maxWidth: 178 }); y += 12; });
            y += 2; doc.setFont(undefined,'bold'); doc.setFontSize(12); doc.text('Priority Action Plan', 14, y); y += 8;
            doc.setFont(undefined,'normal'); doc.setFontSize(9.5);
            Object.keys(r.cats).sort((a,b)=>r.cats[a]-r.cats[b]).slice(0,3).forEach((k,i) => {
                doc.text((i+1) + '. ' + CAT_LABELS[k] + ' (' + r.cats[k] + '/100)', 16, y); y += 6;
                PLAN_FIXES[k].forEach(f => { const L = doc.splitTextToSize('\u2022 ' + f, 172); doc.text(L, 20, y); y += L.length*5 + 1; });
                y += 2;
            });
            doc.setFontSize(9); doc.setTextColor(120,120,125);
            doc.text('Heuristic snapshot \u2014 book the free full audit at graphinxt.com \u00b7 reach@graphinxt.com', 14, 285);
            doc.save('graphinxt-snapshot-' + r.domain.replace(/[^a-z0-9]/g,'-') + '.pdf');
        };
        function renderCategories(result) {
            window._lastSnap = result;
            renderActionPlan(result);
            snapCategories.innerHTML = '';
            Object.keys(CAT_LABELS).forEach(key => {
                const score = result.cats[key];
                const card = document.createElement('div');
                card.className = 'snapshot-cat';
                card.innerHTML = `<div class="snapshot-cat-head"><span>${CAT_LABELS[key]}</span><span>${score}</span></div><div class="snapshot-cat-bar"><div class="snapshot-cat-fill" data-target="${score}"></div></div><div class="snapshot-cat-tip">${result.tips[key]}</div>`;
                snapCategories.appendChild(card);
            });
            requestAnimationFrame(() => {
                document.querySelectorAll('.snapshot-cat-fill').forEach(el => { setTimeout(() => { el.style.width = el.getAttribute('data-target') + '%'; }, 80); });
            });
        }

        // Local per-domain history (this browser only, not cross-device — stored honestly, no false "we track your traffic" claim)
        function getHistory(domain) {
            try { return JSON.parse(localStorage.getItem('graphinxt_snapshot_history') || '{}')[domain] || []; } catch (e) { return []; }
        }
        function saveHistory(domain, score) {
            try {
                const all = JSON.parse(localStorage.getItem('graphinxt_snapshot_history') || '{}');
                all[domain] = all[domain] || [];
                all[domain].push({ score, ts: Date.now() });
                all[domain] = all[domain].slice(-10);
                localStorage.setItem('graphinxt_snapshot_history', JSON.stringify(all));
            } catch (e) {}
        }
        function renderHistory(domain) {
            const hist = getHistory(domain);
            if (hist.length < 2) { historyRow.classList.remove('show'); return; }
            const prev = hist[hist.length - 2];
            const daysAgo = Math.max(1, Math.round((Date.now() - prev.ts) / 86400000));
            const diff = hist[hist.length - 1].score - prev.score;
            const trend = diff > 0 ? `up <strong>+${diff}</strong> 📈` : diff < 0 ? `down <strong>${diff}</strong> 📉` : 'unchanged';
            historyRow.innerHTML = `You last checked <strong>${domain}</strong> ${daysAgo} day${daysAgo === 1 ? '' : 's'} ago, scoring ${prev.score}. It's now ${trend} since then.`;
            historyRow.classList.add('show');
        }

        let currentResult = null;
        window.runSnapshot = function(prefillDomain) {
            const raw = prefillDomain || snapInput.value.trim();
            if (!raw) { snapInput.focus(); return; }
            snapInput.value = raw;
            snapBtn.disabled = true; snapBtn.innerText = 'Scanning...';
            snapRingFill.style.strokeDashoffset = RING_CIRCUMFERENCE;
            snapRingNum.innerText = '0';
            renderHistory(cleanDomain(raw));
            setTimeout(() => {
                const result = analyzeDomain(raw);
                currentResult = result;
                snapDomain.innerText = result.domain || raw;
                snapVerdict.innerText = verdictFor(result.overall);
                benchmarkLine.innerHTML = result.overall > BENCHMARK_SCORE
                    ? `Above the general small-business benchmark (~<strong>${BENCHMARK_SCORE}</strong>)`
                    : `Below the general small-business benchmark (~<strong>${BENCHMARK_SCORE}</strong>)`;
                renderCategories(result);
                snapResults.classList.add('show');
                animateRing(result.overall);
                snapBtn.disabled = false; snapBtn.innerText = 'Run Again →';
                snapResults.scrollIntoView({ behavior: 'smooth', block: 'center' });
                saveHistory(result.domain, result.overall);
                renderHistory(result.domain);
                const url = new URL(window.location);
                url.searchParams.set('domain', result.domain);
                window.history.replaceState({}, '', url);
                window.trackConversion('tool_engagement', { tool: 'website_intelligence', score: result.overall, domain: result.domain });
            }, 900);
        };
        snapInput.addEventListener('keypress', (e) => { if (e.key === 'Enter') runSnapshot(); });

        window.copyShareLink = function() {
            if (!currentResult) return;
            const url = `${window.location.origin}/website-check.html?domain=${encodeURIComponent(currentResult.domain)}`;
            navigator.clipboard.writeText(url).then(() => {
                const btn = document.getElementById('copy-link-btn');
                const original = btn.innerText;
                btn.innerText = '✓ Link Copied';
                setTimeout(() => { btn.innerText = original; }, 2000);
                window.trackConversion('share_click', { tool: 'website_intelligence' });
            });
        };

        // Auto-run if a domain is present in the URL (shared link)
        const params = new URLSearchParams(window.location.search);
        if (params.get('domain')) { runSnapshot(params.get('domain')); }

        // Waitlist — real EmailJS notification + local backup capture
        const EMAILJS_SERVICE_ID = 'service_czz7trf';
        const EMAILJS_TEMPLATE_ID = 'template_iu83rj7';
        const EMAILJS_PUBLIC_KEY = 'xnhB_ASPLwSQ4SKAd';
        if (window.emailjs && EMAILJS_PUBLIC_KEY) { emailjs.init({ publicKey: EMAILJS_PUBLIC_KEY }); }

        window.toggleWaitlist = function() {
            document.getElementById('waitlist-form').classList.add('show');
        };
        document.getElementById('waitlist-form').addEventListener('submit', async function(e) {
            e.preventDefault();
            const name = document.getElementById('wl-name').value.trim();
            const email = document.getElementById('wl-email').value.trim();
            const domain = document.getElementById('wl-domain').value.trim();
            const submitBtn = this.querySelector('button[type="submit"]');
            try {
                const list = JSON.parse(localStorage.getItem('graphinxt_waitlist') || '[]');
                list.push({ name, email, domain, ts: new Date().toISOString() });
                localStorage.setItem('graphinxt_waitlist', JSON.stringify(list));
            } catch (err) {}
            window.trackConversion('waitlist_join', { product: 'premium_monitoring' });

            if (window.emailjs && EMAILJS_SERVICE_ID && EMAILJS_TEMPLATE_ID) {
                if (submitBtn) { submitBtn.disabled = true; submitBtn.innerText = 'Joining...'; }
                try {
                    try{fetch('/api/lead',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:name,email:email,company:'-',service:'Premium Monitoring Waitlist',message:domain?('Website: '+domain):'-',website_url:window.location.href})}).catch(function(){});}catch(e){}
                    await emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, {
                        from_name: name, from_email: email, company: '—',
                        service: 'Premium Monitoring Waitlist', message: domain ? `Website: ${domain}` : '—',
                        website_url: window.location.href
                    });
                } catch (err) { /* local copy already saved above — fail silently on email hiccup */ }
            }
            this.classList.remove('show');
            document.getElementById('waitlist-success').classList.add('show');
        });
    </script>

    <script>
    // Animated gold-particle background — matches Graphinxt homepage
    (function() {
        var canvas = document.getElementById('bg-canvas');
        if (!canvas) return;
        var ctx = (canvas.getContext) ? canvas.getContext('2d') : null;
        if (!ctx) return;
        if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
        var particles = [], w, h, animationId;
        function resize(){ w = canvas.width = window.innerWidth; h = canvas.height = window.innerHeight; }
        resize(); window.addEventListener('resize', resize);
        function create(){
            var count = Math.min(Math.floor(w / 18), 70); particles = [];
            for (var i=0;i<count;i++){ particles.push({ x:Math.random()*w, y:Math.random()*h, r:Math.random()*1.8+0.4, vy:-(Math.random()*0.4+0.1), vx:(Math.random()-0.5)*0.2, alpha:Math.random()*0.5+0.1, pulse:Math.random()*Math.PI*2, pulseSpeed:Math.random()*0.02+0.005 }); }
        }
        create();
        function animate(){
            if (!ctx) return;
            ctx.clearRect(0,0,w,h);
            particles.forEach(function(p){
                p.y+=p.vy; p.x+=p.vx; p.pulse+=p.pulseSpeed;
                var a = p.alpha*(0.5+0.5*Math.sin(p.pulse));
                if (p.y<-10){ p.y=h+10; p.x=Math.random()*w; }
                if (p.x<-10) p.x=w+10; if (p.x>w+10) p.x=-10;
                var g = ctx.createRadialGradient(p.x,p.y,0,p.x,p.y,p.r*6);
                g.addColorStop(0,'rgba(233,196,111,'+a+')'); g.addColorStop(1,'rgba(233,196,111,0)');
                ctx.fillStyle=g; ctx.beginPath(); ctx.arc(p.x,p.y,p.r*6,0,Math.PI*2); ctx.fill();
                ctx.fillStyle='rgba(233,196,111,'+(a*1.5)+')'; ctx.beginPath(); ctx.arc(p.x,p.y,p.r,0,Math.PI*2); ctx.fill();
            });
            animationId = requestAnimationFrame(animate);
        }
        function start(){ if(!animationId) animate(); }
        function stop(){ if(animationId){ cancelAnimationFrame(animationId); animationId=null; if(ctx) ctx.clearRect(0,0,w,h);} }
        function checkTheme(){ if(document.body.classList.contains('light-mode')) stop(); else start(); }
        checkTheme();
        var tt = document.getElementById('theme-toggle') || document.getElementById('theme-toggle-btn');
        if (tt) tt.addEventListener('click', function(){ setTimeout(checkTheme, 60); });
    })();
    </script>

 <?php include '../footer.php';?>
 <script src="../assets/js/script.js"></script>
</body>
</html>
