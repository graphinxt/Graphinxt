<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Business Growth Packages from $300 | Graphinxt</title>
    <meta name="description" content="We solve business problems, not just sell services. AI growth packages from $300 to $5,000 plus monthly partnerships for UK, USA, CA, AU & NZ.">
    <meta name="robots" content="index, follow, max-image-preview:large">
    <link rel="canonical" href="https://graphinxt.com/solutions">
    <meta property="og:site_name" content="Graphinxt">
    <meta property="og:type" content="website">
       <link rel="stylesheet" href="../assets/style.css">
  <link rel="stylesheet" href="../assets/header.css">

   <link rel="shortcut icon" href="../assets/favicon.ico" type="image/x-icon">
        <link rel="icon" href="../assets/favicon.ico" type="image/x-icon">
    <meta property="og:title" content="AI Business Growth Solutions — from $300 | Graphinxt">
    <meta property="og:description" content="We don't sell services. We solve business problems — diagnosis, websites, ads, social, and AI assistants, in packages from $300 to $5,000.">
    <meta property="og:url" content="https://graphinxt.com/solutions">
    <meta property="og:image" content="https://graphinxt.com/assets/og-cover.jpg">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:image" content="https://graphinxt.com/assets/og-cover.jpg">
    
<link rel="shortcut icon" href="../assets/favicon.ico" type="image/x-icon">
        <link rel="icon" href="../assets/favicon.ico" type="image/x-icon">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@200;300;400;500;800&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@graph": [
        { "@type": "BreadcrumbList", "itemListElement": [
            { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://graphinxt.com/" },
            { "@type": "ListItem", "position": 2, "name": "Growth Solutions", "item": "https://graphinxt.com/solutions" } ] },
        { "@type": "OfferCatalog", "name": "Graphinxt AI Business Growth Packages",
          "itemListElement": [
            { "@type": "Offer", "name": "90-Day Customer Growth Plan", "price": "299", "priceCurrency": "USD", "description": "Full business diagnosis: website, SEO/AEO and competitor audit, customer persona, and a week-by-week 90-day growth plan." },
            { "@type": "Offer", "name": "Lead Engine Website", "price": "399", "priceCurrency": "USD", "description": "Conversion-focused website build with on-page SEO, schema, analytics, and WhatsApp integration." },
            { "@type": "Offer", "name": "Ads Rescue & Accelerator", "price": "499", "priceCurrency": "USD", "description": "Google/Meta account audit, rebuild, conversion tracking, and platform-perfect ad copy." },
            { "@type": "Offer", "name": "Social Growth System", "price": "499", "priceCurrency": "USD", "description": "30-day content calendar with designed posts, captions, hashtag ladders, and reels scripts." },
            { "@type": "Offer", "name": "AI Business Assistant", "price": "500", "priceCurrency": "USD", "description": "Multilingual website assistant that quotes, answers, captures leads, and hands off to WhatsApp." },
            { "@type": "Offer", "name": "Business Growth OS", "price": "399", "priceCurrency": "USD", "description": "The full 90-day growth transformation: diagnosis, website, ads, social, AI assistant, and monthly growth reporting under one accountable partner." },
            { "@type": "Offer", "name": "Care Plan (Monthly)", "price": "149", "priceCurrency": "USD", "description": "Monthly website care: security, backups, edits, and a health report." },
            { "@type": "Offer", "name": "Growth Plan (Monthly)", "price": "650", "priceCurrency": "USD", "description": "Monthly SEO and content: 2 articles, on-page optimization, GBP management, rank tracking." },
            { "@type": "Offer", "name": "Scale Plan (Monthly)", "price": "1450", "priceCurrency": "USD", "description": "Monthly ads management, SEO, content, and social under one team with quarterly strategy." },
            { "@type": "Offer", "name": "Growth Partner (Monthly)", "price": "2900", "priceCurrency": "USD", "description": "Full outsourced growth department with weekly reporting and priority support." },
            { "@type": "Offer", "name": "Social Starter (Monthly)", "price": "500", "priceCurrency": "USD", "description": "12 designed posts monthly with captions, hashtags and reporting across 2 platforms." },
            { "@type": "Offer", "name": "Social Growth (Monthly)", "price": "700", "priceCurrency": "USD", "description": "16 posts plus reels, community management and boosted posts across 3 platforms." },
            { "@type": "Offer", "name": "Social Pro (Monthly)", "price": "1000", "priceCurrency": "USD", "description": "20 posts, 8 reels, daily community management and paid social campaigns across 4 platforms." }
          ] },
        { "@type": "FAQPage", "mainEntity": [
            { "@type": "Question", "name": "What makes Graphinxt different from a marketing agency?", "acceptedAnswer": { "@type": "Answer", "text": "We start from your business problem, not a service menu. Every engagement begins with a diagnosis of what is actually limiting your growth, and the package we recommend is built to fix that specific problem — using AI, creativity, and automation together." } },
            { "@type": "Question", "name": "How much do Graphinxt growth packages cost?", "acceptedAnswer": { "@type": "Answer", "text": "Packages run from $300 for the 90-Day Customer Growth Plan to $399 for the full Business Growth OS transformation. The $300 diagnosis is fully credited if you start any larger package within 30 days." } },
            { "@type": "Question", "name": "Do you work with businesses in the UK, USA, Canada, Australia and New Zealand?", "acceptedAnswer": { "@type": "Answer", "text": "Yes — those five markets are our focus. We work fully remotely with live client sites across Canada and New Zealand, and every quote can be issued in GBP, USD, CAD, AUD or NZD." } },
            { "@type": "Question", "name": "Where should I start if I'm not sure what my business needs?", "acceptedAnswer": { "@type": "Answer", "text": "Start free: run your website through our free AI toolbox at graphinxt.com/tools. If you want a human-built plan, the $300 90-Day Customer Growth Plan diagnoses everything and tells you exactly what to fix first — whether or not you hire us to fix it." } }
        ] }
      ]
    }
    </script>
<script async src="https://www.googletagmanager.com/gtag/js?id=G-58PYC27MPE"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date()); gtag('config', 'G-58PYC27MPE');
</script>
<script>
  !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window, document,'script','https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '2162187584315430'); fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=2162187584315430&ev=PageView&noscript=1" /></noscript>
<script>
  window.trackConversion = function(eventName, params) {
    params = params || {};
    try { if (typeof gtag === 'function') gtag('event', eventName, params); } catch(e) {}
    try { if (typeof fbq === 'function') fbq('trackCustom', eventName, params); } catch(e) {}
  };
  document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('a[href*="wa.me"]').forEach(function(el) {
      el.addEventListener('click', function() { window.trackConversion('whatsapp_click', { page: window.location.pathname, pkg: el.getAttribute('data-pkg') || '' }); });
    });
  });
</script>
    <style>
        :root { --bg-dark:#363638; --bg-darker:#2a2a2c; --brand-gold:#e9c46f; --text-main:#fff; --text-muted:#a1a1a5; --card-bg:rgba(255,255,255,0.02); --border-light:rgba(233,196,111,0.12); --border-glow:rgba(233,196,111,0.4); --nav-bg:rgba(42,42,44,0.4); }
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Montserrat',sans-serif; scroll-behavior:smooth; }
        .hero-sec { padding-top:13rem; padding-bottom:2rem; text-align:center; }
        .hero-sec h1 { font-size:clamp(1.9rem,4.6vw,3.2rem); font-weight:200; line-height:1.18; margin-bottom:1.4rem; max-width:860px; margin-left:auto; margin-right:auto; }
        .hero-sec h1 strong { font-weight:800; background:linear-gradient(to right,#ffffff,var(--brand-gold)); -webkit-background-clip:text; background-clip:text; -webkit-text-fill-color:transparent; color:var(--brand-gold); }
        .hero-sec p { color:var(--text-muted); max-width:680px; margin:0 auto 2.2rem; font-weight:300; }
        .btn-primary { background:#fff; color:var(--bg-dark)!important; padding:0.95rem 2.3rem; border-radius:30px; font-weight:800; text-transform:uppercase; letter-spacing:1px; text-decoration:none; display:inline-block; font-size:0.78rem; border:none; transition:all .3s; cursor:pointer; }
        .btn-primary:hover { background:var(--brand-gold); color:#fff!important; transform:scale(1.05); }
        .btn-outline { background:transparent; color:var(--brand-gold); padding:0.95rem 2.3rem; border-radius:30px; font-weight:600; text-transform:uppercase; letter-spacing:1px; text-decoration:none; border:1px solid var(--border-light); display:inline-block; font-size:0.76rem; transition:all .3s; }
        .btn-outline:hover { border-color:var(--brand-gold); }
        .section-head { text-align:center; margin-bottom:3rem; }
        .section-head h2 { font-size:clamp(1.6rem,4vw,2.4rem); font-weight:200; }
        .section-head h2 strong { font-weight:800; background:linear-gradient(to right,#ffffff,var(--brand-gold)); -webkit-background-clip:text; background-clip:text; -webkit-text-fill-color:transparent; color:var(--brand-gold); }
        .section-head p { color:var(--text-muted); font-weight:300; font-size:0.92rem; max-width:640px; margin:0.8rem auto 0; }
        .prob-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(300px,1fr)); gap:1.4rem; }
        .prob-card { background:var(--card-bg); border:1px solid var(--border-light); border-radius:20px; padding:1.8rem; transition:all .3s; display:block; text-decoration:none; color:var(--text-main); }
        .prob-card:hover { border-color:var(--brand-gold); transform:translateY(-4px); }
        .prob-quote { font-size:1.02rem; font-weight:600; margin-bottom:0.7rem; }
        .prob-quote::before { content:'\201C'; color:var(--brand-gold); font-size:1.4rem; }
        .prob-sol { font-size:0.8rem; color:var(--text-muted); font-weight:300; margin-bottom:0.9rem; }
        .prob-link { font-size:0.68rem; text-transform:uppercase; letter-spacing:1px; color:var(--brand-gold); font-weight:700; }
        .pkg { background:var(--card-bg); border:1px solid var(--border-light); border-radius:26px; padding:2.4rem; margin-bottom:1.8rem; display:grid; grid-template-columns:1.3fr 1fr; gap:2rem; align-items:start; }
        .pkg.flagship { border-color:var(--border-glow); background:linear-gradient(135deg,rgba(233,196,111,0.07),transparent); }
        @media(max-width:820px){ .pkg{grid-template-columns:1fr;} }
        .pkg-tag { display:inline-block; font-size:0.6rem; font-weight:800; text-transform:uppercase; letter-spacing:1.5px; color:var(--bg-dark); background:var(--brand-gold); padding:4px 12px; border-radius:12px; margin-bottom:0.9rem; }
        .pkg h3 { font-size:1.35rem; margin-bottom:0.5rem; }
        .pkg .solves { font-size:0.8rem; color:var(--text-muted); font-style:italic; margin-bottom:0.9rem; }
        .pkg .desc { font-size:0.88rem; color:var(--text-muted); font-weight:300; margin-bottom:1.2rem; }
        .pkg-price { font-size:2rem; font-weight:800; }
        .pkg-price span { font-size:0.75rem; font-weight:400; color:var(--text-muted); }
        .pkg-meta { font-size:0.72rem; color:var(--text-muted); margin:0.4rem 0 1.2rem; }
        .pkg ul { list-style:none; margin-bottom:1.4rem; }
        .pkg ul li { font-size:0.82rem; color:var(--text-muted); font-weight:300; padding:0.35rem 0 0.35rem 1.6rem; position:relative; }
        .pkg ul li::before { content:'\2713'; color:var(--brand-gold); position:absolute; left:0; font-weight:700; }
        .cta-row { display:flex; gap:0.8rem; flex-wrap:wrap; }
        .free-strip { border:1px solid var(--border-glow); border-radius:24px; padding:2.2rem; text-align:center; background:linear-gradient(135deg,rgba(233,196,111,0.07),transparent); }
        .faq-item { border-bottom:1px solid var(--border-light); padding:1.4rem 0; max-width:800px; margin:0 auto; }
        .faq-item h3 { font-size:1rem; font-weight:600; margin-bottom:0.5rem; }
        .faq-item p { font-size:0.88rem; color:var(--text-muted); font-weight:300; }
        footer { padding:4rem 5%; text-align:center; border-top:1px solid var(--border-light); color:var(--text-muted); font-size:0.8rem; }
        footer a { color:var(--brand-gold); text-decoration:none; }
        .footer-links-row { display:flex; gap:1.4rem; justify-content:center; flex-wrap:wrap; margin-bottom:1.2rem; }
        .footer-links-row a { color:var(--text-muted); font-size:0.72rem; text-transform:uppercase; letter-spacing:1px; }
        .footer-links-row a:hover { color:var(--brand-gold); }
        /* ===== ACTIVE PLAN TRACKING ===== */
        .pkg.is-active { border-color: var(--brand-gold); background: linear-gradient(135deg, rgba(233,196,111,0.12), transparent); box-shadow: 0 0 0 1px var(--brand-gold), 0 20px 50px rgba(233,196,111,0.08); position: relative; }
        .active-ribbon { position: absolute; top: -12px; left: 24px; background: var(--brand-gold); color: var(--bg-dark); font-size: 0.62rem; font-weight: 800; text-transform: uppercase; letter-spacing: 1.5px; padding: 5px 14px; border-radius: 12px; box-shadow: 0 6px 18px rgba(0,0,0,0.35); }
        .plan-actions-row { display: flex; gap: 0.6rem; flex-wrap: wrap; margin-top: 0.9rem; }
        .mini-btn { background: transparent; border: 1px solid var(--border-light); color: var(--brand-gold); font-size: 0.66rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; padding: 0.5rem 0.9rem; border-radius: 18px; cursor: pointer; font-family: inherit; transition: all 0.2s; }
        .mini-btn:hover { border-color: var(--brand-gold); background: rgba(233,196,111,0.1); }
        .activate-btn { background: transparent; border: 1px dashed var(--border-light); color: var(--text-muted); font-size: 0.64rem; text-transform: uppercase; letter-spacing: 0.5px; padding: 0.45rem 0.9rem; border-radius: 18px; cursor: pointer; font-family: inherit; margin-top: 0.7rem; transition: all 0.2s; }
        .activate-btn:hover { border-style: solid; border-color: var(--brand-gold); color: var(--brand-gold); }
        /* Active plan banner */
        .plan-banner { max-width: 900px; margin: 0 auto 2rem; background: linear-gradient(135deg, rgba(233,196,111,0.12), rgba(233,196,111,0.02)); border: 1px solid var(--brand-gold); border-radius: 20px; padding: 1.6rem 1.8rem; display: none; }
        .plan-banner.show { display: block; animation: pbIn 0.5s ease; }
        @keyframes pbIn { from { opacity:0; transform: translateY(-8px);} to { opacity:1; transform:none;} }
        .pb-top { display: flex; justify-content: space-between; align-items: flex-start; gap: 1rem; flex-wrap: wrap; }
        .pb-eyebrow { font-size: 0.62rem; text-transform: uppercase; letter-spacing: 2px; color: var(--brand-gold); font-weight: 700; }
        .pb-name { font-size: 1.25rem; font-weight: 800; margin: 0.3rem 0; }
        .pb-meta { font-size: 0.8rem; color: var(--text-muted); font-weight: 300; }
        .pb-countdown { text-align: right; min-width: 130px; }
        .pb-days { font-size: 2rem; font-weight: 800; color: var(--brand-gold); line-height: 1; }
        .pb-days.warn { color: #f0a04b; }
        .pb-days.expired { color: #e07a5f; }
        .pb-days-label { font-size: 0.64rem; text-transform: uppercase; letter-spacing: 1px; color: var(--text-muted); }
        .pb-bar { height: 7px; background: rgba(255,255,255,0.07); border-radius: 4px; overflow: hidden; margin: 1.1rem 0 0.6rem; }
        .pb-fill { height: 100%; background: linear-gradient(to right, var(--brand-gold), #f0d9a0); border-radius: 4px; transition: width 0.6s ease; }
        .pb-dates { display: flex; justify-content: space-between; font-size: 0.7rem; color: var(--text-muted); }
        .pb-actions { display: flex; gap: 0.6rem; flex-wrap: wrap; margin-top: 1.2rem; }
        .pb-renew-note { margin-top: 0.9rem; font-size: 0.78rem; padding: 0.7rem 1rem; border-radius: 10px; display: none; }
        .pb-renew-note.show { display: block; }
        .pb-renew-note.soon { background: rgba(240,160,75,0.12); border: 1px solid rgba(240,160,75,0.4); color: #f0a04b; }
        .pb-renew-note.over { background: rgba(224,122,95,0.12); border: 1px solid rgba(224,122,95,0.4); color: #e07a5f; }
        /* Activation modal */
        .grx-modal { position: fixed; inset: 0; background: rgba(0,0,0,0.7); backdrop-filter: blur(6px); z-index: 10000; display: none; align-items: center; justify-content: center; padding: 1.2rem; }
        .grx-modal.show { display: flex; }
        .grx-modal-box { background: var(--bg-darker); border: 1px solid var(--border-glow); border-radius: 22px; padding: 2rem; max-width: 440px; width: 100%; max-height: 90vh; overflow-y: auto; }
        .grx-modal-box h3 { font-size: 1.2rem; margin-bottom: 0.4rem; }
        .grx-modal-box p.sub { font-size: 0.82rem; color: var(--text-muted); font-weight: 300; margin-bottom: 1.3rem; }
        .grx-modal-box label { display: block; font-size: 0.66rem; text-transform: uppercase; letter-spacing: 1px; color: var(--text-muted); margin: 0.9rem 0 0.4rem; }
        .grx-modal-box input, .grx-modal-box select { width: 100%; background: var(--bg-dark); border: 1px solid var(--border-light); color: var(--text-main); padding: 0.8rem 1rem; border-radius: 12px; font-size: 0.88rem; outline: none; font-family: inherit; }
        .grx-modal-box input:focus, .grx-modal-box select:focus { border-color: var(--brand-gold); }
        .modal-actions { display: flex; gap: 0.6rem; margin-top: 1.5rem; }
        .modal-actions button { flex: 1; padding: 0.8rem; border-radius: 24px; font-size: 0.74rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; cursor: pointer; font-family: inherit; border: none; }
        .modal-primary { background: var(--brand-gold); color: var(--bg-dark); }
        .modal-ghost { background: transparent; border: 1px solid var(--border-light) !important; color: var(--text-muted); }
    </style>
</head>
<body>
    <canvas id="bg-canvas"></canvas>
    <div class="ambient-glow"></div>
          <?php include '../header.php';?>


    <header class="hero-sec">
        <span class="eyebrow">AI + Creativity + Automation</span>
        <h1>We don't sell marketing. We solve the problems <strong>stopping your business from growing.</strong></h1>
        <p>Graphinxt is an AI-powered business growth partner for the UK, USA, Canada, Australia, and New Zealand. Tell us the problem — not enough customers, a website that doesn't convert, ads that burn money — and we diagnose it, build the fix, and stay accountable for the result.</p>
        <div class="cta-row" style="justify-content:center;">
            <a href="#packages" class="btn-primary">See Growth Packages — from $300</a>
            <a href="#monthly" class="btn-outline">Monthly Partnerships</a>
            <a href="#problems" class="btn-outline">Start With Your Problem</a>
        </div>
    </header>

    <!-- ACTIVE PLAN BANNER -->
    <div style="padding:0 5%; position:relative; z-index:1;">
        <div class="plan-banner" id="plan-banner"></div>
    </div>

    <!-- PROBLEMS -->
    <section id="problems">
        <div class="section-head">
            <h2>Which of these sounds <strong>like you?</strong></h2>
            <p>Every package below exists because a real business owner said one of these sentences to us. Tap yours.</p>
        </div>
        <div class="prob-grid">
            <a href="#pkg-plan" class="prob-card">
                <div class="prob-quote">I don't get enough customers."</div>
                <div class="prob-sol">You don't have a marketing problem yet — you have a diagnosis problem. Something specific is broken; guessing which is what wastes money.</div>
                <div class="prob-link">→ 90-Day Customer Growth Plan · $300</div>
            </a>
            <a href="#pkg-website" class="prob-card">
                <div class="prob-quote">My website doesn't generate leads."</div>
                <div class="prob-sol">Traffic without enquiries means the site isn't built to convert — wrong structure, weak trust signals, buried calls to action.</div>
                <div class="prob-link">→ Lead Engine Website · $300</div>
            </a>
            <a href="#pkg-ads" class="prob-card">
                <div class="prob-quote">I spend money on ads but get no results."</div>
                <div class="prob-sol">Usually three fixable failures stacked together: wrong audience, weak copy, and no conversion tracking to reveal either.</div>
                <div class="prob-link">→ Ads Rescue &amp; Accelerator · $499</div>
            </a>
            <a href="#pkg-social" class="prob-card">
                <div class="prob-quote">I don't know what to post on social media."</div>
                <div class="prob-sol">Consistency beats brilliance — but consistency needs a system: a calendar, ready posts, and hooks that fit your platform.</div>
                <div class="prob-link">→ Social Growth System · $499</div>
            </a>
            <a href="#pkg-assistant" class="prob-card">
                <div class="prob-quote">I can't reply to customers 24/7."</div>
                <div class="prob-sol">Enquiries arrive at 11pm and go to a competitor by 9am. An assistant that quotes, answers, and captures the lead fixes the gap.</div>
                <div class="prob-link">→ AI Business Assistant · $499</div>
            </a>
            <a href="#pkg-os" class="prob-card">
                <div class="prob-quote">I want one partner accountable for all of it."</div>
                <div class="prob-sol">Diagnosis, website, ads, social, and AI — integrated, sequenced correctly, and reported monthly by one team.</div>
                <div class="prob-link">→ Business Growth OS · $399</div>
            </a>
        </div>
    </section>

    <!-- PACKAGES -->
    <section id="packages">
        <div class="section-head">
            <h2>AI Business Growth <strong>Packages</strong></h2>
            <p>Fixed prices, listed deliverables, no surprise scope. Every package can be quoted in GBP, USD, CAD, AUD or NZD.</p>
        </div>

        <div class="pkg" id="pkg-plan">
            <div>
                <span class="pkg-tag">Start Here</span>
                <h3>90-Day Customer Growth Plan</h3>
                <div class="solves">Solves: "I don't get enough customers."</div>
                <p class="desc">A complete diagnosis of your business's online presence, and a week-by-week plan to fix it — built by AI analysis and reviewed by a human strategist. You keep the plan whether or not you ever hire us again.</p>
                <div class="pkg-price">$299 <span>one-time</span></div>
                <div class="pkg-meta">Delivered in 5–7 business days · Fully credited toward any package started within 30 days</div>
            </div>
            <div>
                <ul>
                    <li>Full website &amp; SEO/AEO audit (real Lighthouse data)</li>
                    <li>3-competitor analysis: rankings, ads, positioning</li>
                    <li>Customer persona &amp; search-intent map</li>
                    <li>Keyword opportunities &amp; content ideas list</li>
                    <li>Channel strategy: where your budget should go and why</li>
                    <li>Week-by-week 90-day action plan (branded PDF)</li>
                    <li>45-minute walkthrough call</li>
                </ul>
                <div class="cta-row">
                    <a class="btn-primary" data-pkg="plan" target="_blank" rel="noopener" href="https://wa.me/971564785139?text=Hi%20Graphinxt!%20I%20want%20the%2090-Day%20Customer%20Growth%20Plan%20(%24300).">Start My Plan</a>
                </div>
            </div>
        </div>

        <div class="pkg" id="pkg-website">
            <div>
                <span class="pkg-tag">Convert</span>
                <h3>Lead Engine Website</h3>
                <div class="solves">Solves: "My website doesn't generate leads."</div>
                <p class="desc">Not a redesign — a rebuild around one job: turning visitors into enquiries. Structure, trust signals, speed, and calls to action engineered from what your customers actually search and fear.</p>
                <div class="pkg-price">$399 <span>one-time</span></div>
                <div class="pkg-meta">Delivered in 3–4 weeks · You own everything on handover</div>
            </div>
            <div>
                <ul>
                    <li>Up to 8 conversion-engineered, mobile-first pages</li>
                    <li>On-page SEO + Organization/FAQ/Service schema</li>
                    <li>Analytics, conversion events &amp; ad pixels installed</li>
                    <li>WhatsApp click-to-chat &amp; enquiry form flows</li>
                    <li>Speed-optimized (Core Web Vitals targets)</li>
                    <li>Two structured revision rounds</li>
                    <li>Launch checklist run &amp; 30 days post-launch support</li>
                </ul>
                <div class="cta-row">
                    <a class="btn-primary" data-pkg="website" target="_blank" rel="noopener" href="https://wa.me/971564785139?text=Hi%20Graphinxt!%20I%20want%20the%20Lead%20Engine%20Website%20(%24950).">Build My Lead Engine</a>
                </div>
            </div>
        </div>

        <div class="pkg" id="pkg-ads">
            <div>
                <span class="pkg-tag">Rescue</span>
                <h3>Ads Rescue &amp; Accelerator</h3>
                <div class="solves">Solves: "I spend money on ads but get no results."</div>
                <p class="desc">We audit where the money went, rebuild the account around search intent, and install the tracking that makes every future dollar measurable. Then, if you want, we run it.</p>
                <div class="pkg-price">$499 <span>setup</span></div>
                <div class="pkg-meta">+ optional management $450/mo · Setup delivered in 2 weeks</div>
            </div>
            <div>
                <ul>
                    <li>Google &amp; Meta account audit: where budget leaked</li>
                    <li>Campaign restructure: keywords, match types, negatives</li>
                    <li>Full RSA copy set + Meta creatives brief (platform-limit perfect)</li>
                    <li>Landing page alignment recommendations</li>
                    <li>Conversion tracking installed &amp; verified</li>
                    <li>Management option: weekly optimization + monthly report</li>
                    <li>"Ads Improvement Blueprint" PDF — yours to keep</li>
                </ul>
                <div class="cta-row">
                    <a class="btn-primary" data-pkg="ads" target="_blank" rel="noopener" href="https://wa.me/971564785139?text=Hi%20Graphinxt!%20I%20want%20the%20Ads%20Rescue%20%26%20Accelerator%20(%24700%20setup).">Rescue My Ads</a>
                </div>
            </div>
        </div>

        <div class="pkg" id="pkg-social">
            <div>
                <span class="pkg-tag">Show Up</span>
                <h3>Social Growth System</h3>
                <div class="solves">Solves: "I don't know what to post on social media."</div>
                <p class="desc">A month of content, done: calendar, designed posts, captions with hooks, hashtag ladders, and reels scripts — matched to your industry and platform. Post it yourself, or have us run it monthly.</p>
                <div class="pkg-price">$499 <span>30-day system</span></div>
                <div class="pkg-meta">+ optional monthly management $450/mo · First calendar in 7 days</div>
            </div>
            <div>
                <ul>
                    <li>30-day content calendar built for your industry</li>
                    <li>16 designed posts with written captions</li>
                    <li>Tiered hashtag ladders per post (popular/medium/niche)</li>
                    <li>4 reels/short-video scripts with hooks</li>
                    <li>Profile &amp; bio optimization (IG, FB, LinkedIn as relevant)</li>
                    <li>Best-time posting schedule for your market</li>
                    <li>1 campaign concept for the month's push</li>
                </ul>
                <div class="cta-row">
                    <a class="btn-primary" data-pkg="social" target="_blank" rel="noopener" href="https://wa.me/971564785139?text=Hi%20Graphinxt!%20I%20want%20the%20Social%20Growth%20System%20(%24600).">Get My 30 Days of Content</a>
                </div>
            </div>
        </div>

        <div class="pkg" id="pkg-assistant">
            <div>
                <span class="pkg-tag">Always On</span>
                <h3>AI Business Assistant</h3>
                <div class="solves">Solves: "I can't reply to customers 24/7."</div>
                <p class="desc">The same assistant working on this site, built for yours: it quotes projects, answers your FAQs, speaks your customers' languages, and hands qualified leads to your WhatsApp with the full conversation attached — at 11pm on a Sunday.</p>
                <div class="pkg-price">$499 <span>setup</span></div>
                <div class="pkg-meta">Live in 2 weeks · Optional upkeep $50/mo · LLM-powered upgrade available for deeper conversations</div>
            </div>
            <div>
                <ul>
                    <li>Custom assistant trained on your services &amp; pricing</li>
                    <li>Multilingual with live translation</li>
                    <li>Voice input &amp; spoken replies (supported browsers)</li>
                    <li>Guided quote &amp; enquiry flows with lead capture</li>
                    <li>Instant website audit &amp; proposal features</li>
                    <li>WhatsApp handoff with full chat transcript</li>
                    <li>Every conversation tracked in your analytics</li>
                </ul>
                <div class="cta-row">
                    <a class="btn-primary" data-pkg="assistant" target="_blank" rel="noopener" href="https://wa.me/971564785139?text=Hi%20Graphinxt!%20I%20want%20the%20AI%20Business%20Assistant%20(%24500).">Get My Assistant</a>
                    <a class="btn-outline" href="/#contact">See It Live — Chat Below on Our Homepage</a>
                </div>
            </div>
        </div>

        <div class="pkg flagship" id="pkg-os">
            <div>
                <span class="pkg-tag">Flagship · 90 Days</span>
                <h3>Business Growth OS</h3>
                <div class="solves">Solves: "I want one partner accountable for all of it."</div>
                <p class="desc">The full transformation, sequenced correctly: we diagnose, rebuild your website, launch and run your ads, run your social, install your AI assistant — and report to you monthly like a growth department would. One team, one number, one accountable partner.</p>
                <div class="pkg-price">$399 <span>90-day program</span></div>
                <div class="pkg-meta">Limited to a few businesses per month · Payment plan available (3 × $1,000)</div>
            </div>
            <div>
                <ul>
                    <li>Everything in the 90-Day Growth Plan (week 1)</li>
                    <li>Lead Engine Website — full build (weeks 2–5)</li>
                    <li>Ads Rescue setup + 3 months of management</li>
                    <li>Social Growth System + 3 months of management</li>
                    <li>AI Business Assistant installed &amp; trained</li>
                    <li>Monthly Growth Report: traffic, leads, cost per lead, next moves</li>
                    <li>Monthly strategy call + priority WhatsApp line</li>
                </ul>
                <div class="cta-row">
                    <a class="btn-primary" data-pkg="os" target="_blank" rel="noopener" href="https://wa.me/971564785139?text=Hi%20Graphinxt!%20I%27m%20interested%20in%20the%20Business%20Growth%20OS%20(%245%2C000%2F90%20days).%20Can%20we%20talk%3F">Apply for Growth OS</a>
                </div>
            </div>
        </div>
    </section>

    <!-- MONTHLY PARTNERSHIPS -->
    <section id="monthly" style="padding-top:1rem;">
        <div class="section-head">
            <span class="eyebrow">For Businesses That Want to Keep Growing</span>
            <h2>Monthly Growth <strong>Partnerships</strong></h2>
            <p>Projects fix problems. Partnerships compound. These plans keep one team accountable for your growth month after month — 3-month minimum, then month-to-month, cancel anytime.</p>
        </div>
        <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(250px,1fr)); gap:1.4rem;">
            <div class="pkg" style="grid-template-columns:1fr; padding:2rem;">
                <div>
                    <span class="pkg-tag">Protect</span>
                    <h3 style="font-size:1.15rem;">Care Plan</h3>
                    <div class="pkg-price" style="font-size:1.7rem;">$149<span>/mo</span></div>
                    <div class="pkg-meta">For any Graphinxt-built or existing website</div>
                    <ul>
                        <li>Security monitoring, updates &amp; backups</li>
                        <li>Uptime &amp; speed watch with alerts</li>
                        <li>2 hours of content edits monthly</li>
                        <li>Monthly site health report</li>
                        <li>Priority email support</li>
                    </ul>
                    <a class="btn-outline" style="width:100%; text-align:center;" data-pkg="care" target="_blank" rel="noopener" href="https://wa.me/971564785139?text=Hi%20Graphinxt!%20I%20want%20the%20Care%20Plan%20(%24149%2Fmo).">Start Care Plan</a>
                </div>
            </div>
            <div class="pkg" style="grid-template-columns:1fr; padding:2rem;">
                <div>
                    <span class="pkg-tag">Rank</span>
                    <h3 style="font-size:1.15rem;">Growth Plan</h3>
                    <div class="pkg-price" style="font-size:1.7rem;">$349<span>/mo</span></div>
                    <div class="pkg-meta">SEO &amp; content that compounds</div>
                    <ul>
                        <li>Everything in Care Plan</li>
                        <li>2 SEO blog articles written monthly</li>
                        <li>On-page optimization: 4 pages/month</li>
                        <li>Google Business Profile management</li>
                        <li>Keyword rank tracking &amp; monthly call</li>
                    </ul>
                    <a class="btn-outline" style="width:100%; text-align:center;" data-pkg="growthmo" target="_blank" rel="noopener" href="https://wa.me/971564785139?text=Hi%20Graphinxt!%20I%20want%20the%20Growth%20Plan%20(%24650%2Fmo).">Start Growth Plan</a>
                </div>
            </div>
            <div class="pkg flagship" style="grid-template-columns:1fr; padding:2rem;">
                <div>
                    <span class="pkg-tag">Most Popular</span>
                    <h3 style="font-size:1.15rem;">Scale Plan</h3>
                    <div class="pkg-price" style="font-size:1.7rem;">$649<span>/mo</span></div>
                    <div class="pkg-meta">Ads + SEO + social, one team</div>
                    <ul>
                        <li>Everything in Growth Plan</li>
                        <li>Google &amp; Meta ads management (to $5k/mo spend)</li>
                        <li>Monthly social calendar: 12 posts + captions</li>
                        <li>Landing page A/B testing</li>
                        <li>Quarterly strategy review</li>
                    </ul>
                    <a class="btn-primary" style="width:100%; text-align:center;" data-pkg="scale" target="_blank" rel="noopener" href="https://wa.me/971564785139?text=Hi%20Graphinxt!%20I%20want%20the%20Scale%20Plan%20(%241%2C450%2Fmo).">Start Scale Plan</a>
                </div>
            </div>
            <div class="pkg" style="grid-template-columns:1fr; padding:2rem;">
                <div>
                    <span class="pkg-tag">Full Department</span>
                    <h3 style="font-size:1.15rem;">Growth Partner</h3>
                    <div class="pkg-price" style="font-size:1.7rem;">$949<span>/mo</span></div>
                    <div class="pkg-meta">Your outsourced growth team</div>
                    <ul>
                        <li>Everything in Scale Plan, higher volume</li>
                        <li>Ads managed to $15k/mo spend</li>
                        <li>4 articles + 20 social posts monthly</li>
                        <li>AI assistant upkeep &amp; retraining</li>
                        <li>Weekly reporting + priority WhatsApp line</li>
                    </ul>
                    <a class="btn-outline" style="width:100%; text-align:center;" data-pkg="partner" target="_blank" rel="noopener" href="https://wa.me/971564785139?text=Hi%20Graphinxt!%20I%27m%20interested%20in%20the%20Growth%20Partner%20plan%20(%242%2C900%2Fmo).">Apply — Limited Seats</a>
                </div>
            </div>
        </div>
        <p style="text-align:center; font-size:0.72rem; color:var(--text-muted); margin-top:1.5rem;">Every monthly plan includes a monthly growth report. Start any one-time package first and your diagnosis carries straight into the partnership — nothing is re-billed twice.</p>
    </section>

    <!-- SOCIAL MEDIA MANAGEMENT -->
    <section id="social-management" style="padding-top:1rem;">
        <div class="section-head">
            <span class="eyebrow">Done-For-You · Monthly</span>
            <h2>Social Media Management <strong>Packages</strong></h2>
            <p>Your feeds, run by one accountable team — content, captions, hashtags, community, and reporting. Month-to-month after the first 3 months.</p>
        </div>
        <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(260px,1fr)); gap:1.4rem;">
            <div class="pkg" style="grid-template-columns:1fr; padding:2rem;"><div>
                <span class="pkg-tag">Starter</span>
                <h3 style="font-size:1.15rem;">Social Starter</h3>
                <div class="pkg-price" style="font-size:1.7rem;">$500<span>/mo</span></div>
                <div class="pkg-meta">Consistent presence, 2 platforms</div>
                <ul>
                    <li>12 designed posts per month</li>
                    <li>Captions with hooks + hashtag ladders</li>
                    <li>2 platforms (e.g. Instagram + Facebook)</li>
                    <li>Best-time scheduling for your market</li>
                    <li>Monthly performance report</li>
                </ul>
                <a class="btn-outline" style="width:100%; text-align:center;" data-pkg="smm500" target="_blank" rel="noopener" href="https://wa.me/971564785139?text=Hi%20Graphinxt!%20I%20want%20the%20Social%20Starter%20package%20(%24500%2Fmo).">Start at $500/mo</a>
            </div></div>
            <div class="pkg flagship" style="grid-template-columns:1fr; padding:2rem;"><div>
                <span class="pkg-tag">Most Popular</span>
                <h3 style="font-size:1.15rem;">Social Growth</h3>
                <div class="pkg-price" style="font-size:1.7rem;">$700<span>/mo</span></div>
                <div class="pkg-meta">Content + community + boosts, 3 platforms</div>
                <ul>
                    <li>16 designed posts + 4 reels scripts</li>
                    <li>3 platforms of your choice</li>
                    <li>Community management: comments &amp; DMs (5 days/wk)</li>
                    <li>Boosted-post management (up to $500 ad spend)</li>
                    <li>Monthly report + strategy call</li>
                </ul>
                <a class="btn-primary" style="width:100%; text-align:center;" data-pkg="smm700" target="_blank" rel="noopener" href="https://wa.me/971564785139?text=Hi%20Graphinxt!%20I%20want%20the%20Social%20Growth%20package%20(%24700%2Fmo).">Start at $700/mo</a>
            </div></div>
            <div class="pkg" style="grid-template-columns:1fr; padding:2rem;"><div>
                <span class="pkg-tag">Pro</span>
                <h3 style="font-size:1.15rem;">Social Pro</h3>
                <div class="pkg-price" style="font-size:1.7rem;">$1,000<span>/mo</span></div>
                <div class="pkg-meta">Full social marketing engine, 4 platforms</div>
                <ul>
                    <li>20 designed posts + 8 reels scripts</li>
                    <li>4 platforms incl. LinkedIn or TikTok</li>
                    <li>Daily community management</li>
                    <li>Paid social campaigns (up to $1,500 ad spend)</li>
                    <li>UGC &amp; influencer outreach (2/mo)</li>
                    <li>Bi-weekly reporting + monthly call</li>
                </ul>
                <a class="btn-outline" style="width:100%; text-align:center;" data-pkg="smm1000" target="_blank" rel="noopener" href="https://wa.me/971564785139?text=Hi%20Graphinxt!%20I%20want%20the%20Social%20Pro%20package%20(%241%2C000%2Fmo).">Start at $1,000/mo</a>
            </div></div>
        </div>
    </section>

    <!-- FREE FIRST -->
    <section style="padding-top:0;">
        <div class="free-strip">
            <span class="eyebrow">Not ready to spend anything?</span>
            <h3 style="font-size:1.3rem; font-weight:200; margin-bottom:0.8rem;">Diagnose yourself first — <strong style="color:var(--brand-gold); font-weight:800;">free.</strong></h3>
            <p style="color:var(--text-muted); font-size:0.88rem; max-width:620px; margin:0 auto 1.5rem; font-weight:300;">Our free AI toolbox runs 8 working tools in your browser: website diagnostic, SEO meta generator, ad copy, captions, budget planner, cost estimator and more. No signup. What you learn there is the same starting point every paid package builds on.</p>
            <a href="/growth-planner" class="btn-primary" style="margin-right:0.6rem;">Get My Free 1-Year Plan →</a>
            <a href="/tools" class="btn-outline">Open the Free AI Toolbox →</a>
        </div>
    </section>

    <!-- FAQ -->
    <section style="padding-top:1rem;">
        <div class="section-head"><h2>Straight <strong>Answers</strong></h2></div>
        <div class="faq-item">
            <h3>What makes Graphinxt different from a marketing agency?</h3>
            <p>We start from your business problem, not a service menu. Every engagement begins with a diagnosis of what is actually limiting your growth, and the package we recommend is built to fix that specific problem — using AI, creativity, and automation together.</p>
        </div>
        <div class="faq-item">
            <h3>How much do the growth packages cost?</h3>
            <p>From $300 for the 90-Day Customer Growth Plan to $5,000 for the full Business Growth OS. The $300 diagnosis is fully credited if you start any larger package within 30 days — so finding out what's wrong never costs extra.</p>
        </div>
        <div class="faq-item">
            <h3>Do you work in my country?</h3>
            <p>Our focus is the UK, USA, Canada, Australia, and New Zealand, with live client sites across Canada and New Zealand today. Everything runs remotely, and every quote can be issued in GBP, USD, CAD, AUD or NZD.</p>
        </div>
        <div class="faq-item">
            <h3>What if I don't know which package I need?</h3>
            <p>That's exactly what the $300 Growth Plan is for — or start completely free with our <a href="/tools" style="color:var(--brand-gold);">AI toolbox</a> and let the diagnostic tell you where the leak is. Nobody here will sell you a package for a problem you don't have; the diagnosis would expose it anyway.</p>
        </div>
    </section>

    <script>
        window.addEventListener('scroll', () => {
            document.getElementById('navbar').classList.toggle('scrolled', document.documentElement.scrollTop > 30);
        });
    </script>

    <script>
    // Animated gold-particle background — matches Graphinxt homepage
    (function() {
        var canvas = document.getElementById('bg-canvas');
        if (!canvas) return;
        var ctx = (canvas.getContext) ? canvas.getContext('2d') : null;
        if (!ctx) return;
        if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
        var particles = [], w, h, animationId;
        function resize(){ w = canvas.width = window.innerWidth; h = canvas.height = window.innerHeight; }
        resize(); window.addEventListener('resize', resize);
        function create(){
            var count = Math.min(Math.floor(w / 18), 70); particles = [];
            for (var i=0;i<count;i++){ particles.push({ x:Math.random()*w, y:Math.random()*h, r:Math.random()*1.8+0.4, vy:-(Math.random()*0.4+0.1), vx:(Math.random()-0.5)*0.2, alpha:Math.random()*0.5+0.1, pulse:Math.random()*Math.PI*2, pulseSpeed:Math.random()*0.02+0.005 }); }
        }
        create();
        function animate(){
            if (!ctx) return;
            ctx.clearRect(0,0,w,h);
            particles.forEach(function(p){
                p.y+=p.vy; p.x+=p.vx; p.pulse+=p.pulseSpeed;
                var a = p.alpha*(0.5+0.5*Math.sin(p.pulse));
                if (p.y<-10){ p.y=h+10; p.x=Math.random()*w; }
                if (p.x<-10) p.x=w+10; if (p.x>w+10) p.x=-10;
                var g = ctx.createRadialGradient(p.x,p.y,0,p.x,p.y,p.r*6);
                g.addColorStop(0,'rgba(233,196,111,'+a+')'); g.addColorStop(1,'rgba(233,196,111,0)');
                ctx.fillStyle=g; ctx.beginPath(); ctx.arc(p.x,p.y,p.r*6,0,Math.PI*2); ctx.fill();
                ctx.fillStyle='rgba(233,196,111,'+(a*1.5)+')'; ctx.beginPath(); ctx.arc(p.x,p.y,p.r,0,Math.PI*2); ctx.fill();
            });
            animationId = requestAnimationFrame(animate);
        }
        function start(){ if(!animationId) animate(); }
        function stop(){ if(animationId){ cancelAnimationFrame(animationId); animationId=null; if(ctx) ctx.clearRect(0,0,w,h);} }
        function checkTheme(){ if(document.body.classList.contains('light-mode')) stop(); else start(); }
        checkTheme();
        var tt = document.getElementById('theme-toggle') || document.getElementById('theme-toggle-btn');
        if (tt) tt.addEventListener('click', function(){ setTimeout(checkTheme, 60); });
    })();
    </script>

    <!-- ACTIVATION MODAL -->
    <div class="grx-modal" id="activate-modal" role="dialog" aria-modal="true" aria-label="Confirm your plan">
        <div class="grx-modal-box">
            <h3 id="am-title">Activate Your Plan</h3>
            <p class="sub">Enter the activation code Graphinxt sent you after payment. Your invoice is generated from it.</p>
            <label for="am-code">Activation code</label>
            <input type="text" id="am-code" placeholder="GRX-XX-XXXX-XXXX-XXXX" autocomplete="off" spellcheck="false" style="letter-spacing:1px; font-family:'Courier New',monospace; text-transform:uppercase;">
            <div id="am-error" style="display:none; margin-top:0.6rem; font-size:0.78rem; color:#e07a5f; background:rgba(224,122,95,0.1); border:1px solid rgba(224,122,95,0.35); border-radius:10px; padding:0.6rem 0.8rem;"></div>
            <label for="am-company">Your business name</label>
            <input type="text" id="am-company" placeholder="e.g. Bloom Coffee Co." autocomplete="organization">
            <label for="am-name">Your name</label>
            <input type="text" id="am-name" placeholder="e.g. Sam Taylor" autocomplete="name">
            <label for="am-email">Email (for your records)</label>
            <input type="email" id="am-email" placeholder="you@business.com" autocomplete="email">
            <p style="font-size:0.72rem; color:var(--text-muted); margin-top:1rem; line-height:1.5;">Don't have a code? <a href="https://wa.me/971564785139?text=Hi%20Graphinxt!%20I%27ve%20paid%20for%20a%20plan%20and%20need%20my%20activation%20code." target="_blank" rel="noopener" style="color:var(--brand-gold);">Message us</a> and we'll send it right away.</p>
            <div class="modal-actions">
                <button class="modal-ghost" onclick="closeActivate()">Cancel</button>
                <button class="modal-primary" onclick="confirmActivate()">Activate &amp; Get Invoice</button>
            </div>
        </div>
    </div>

    <script>
    (function(){
        'use strict';
        // ===== PLAN REGISTRY =====
        var PLANS = {
            plan:     { name:'90-Day Customer Growth Plan', price:299,  cycle:'one-time', days:90,  cat:'One-time package' },
            website:  { name:'Lead Engine Website',         price:399,  cycle:'one-time', days:30,  cat:'One-time package' },
            ads:      { name:'Ads Rescue & Accelerator',    price:499,  cycle:'one-time', days:30,  cat:'One-time package' },
            social:   { name:'Social Growth System',        price:499,  cycle:'30-day system', days:30, cat:'One-time package' },
            assistant:{ name:'AI Business Assistant',       price:499,  cycle:'one-time', days:30,  cat:'One-time package' },
            os:       { name:'Business Growth OS',          price:399, cycle:'90-day program', days:90, cat:'Flagship program' },
            care:     { name:'Care Plan',                   price:149,  cycle:'monthly', days:30,  cat:'Monthly partnership' },
            growthmo: { name:'Growth Plan',                 price:650,  cycle:'monthly', days:30,  cat:'Monthly partnership' },
            scale:    { name:'Scale Plan',                  price:1450, cycle:'monthly', days:30,  cat:'Monthly partnership' },
            partner:  { name:'Growth Partner',              price:2900, cycle:'monthly', days:30,  cat:'Monthly partnership' },
            smm500:   { name:'Social Starter',              price:500,  cycle:'monthly', days:30,  cat:'Social media management' },
            smm700:   { name:'Social Growth',               price:700,  cycle:'monthly', days:30,  cat:'Social media management' },
            smm1000:  { name:'Social Pro',                  price:1000, cycle:'monthly', days:30,  cat:'Social media management' }
        };
        var KEY = 'grx_active_plan';
        var pendingKey = null;

        // ===== ACTIVATION CODE SYSTEM =====
        // Codes are issued by Graphinxt after payment. Format:
        //   GRX-<PLANCODE>-<START36>-<RAND>-<CHECKSUM>
        // The checksum is derived from the other parts, so codes cannot be guessed
        // or hand-crafted without the algorithm — a client cannot self-issue one.
        var PLAN_CODES = {
            plan:'PL', website:'WB', ads:'AD', social:'SO', assistant:'AS', os:'OS',
            care:'CA', growthmo:'GR', scale:'SC', partner:'PT',
            smm500:'S5', smm700:'S7', smm1000:'S1'
        };
        function codePlan(cc){ for (var k in PLAN_CODES) { if (PLAN_CODES[k] === cc) return k; } return null; }
        function chkSum(str) {
            var h = 5381;
            for (var i = 0; i < str.length; i++) h = ((h * 33) ^ str.charCodeAt(i)) >>> 0;
            h = (h ^ 0x5f3a7b19) >>> 0;
            return h.toString(36).toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,4).padEnd(4,'7');
        }
        function makeActivationCode(planKey, startMs) {
            var cc = PLAN_CODES[planKey]; if (!cc) return null;
            var s36 = Math.floor(startMs / 86400000).toString(36).toUpperCase();
            var rand = Math.random().toString(36).toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,4).padEnd(4,'K');
            return 'GRX-' + cc + '-' + s36 + '-' + rand + '-' + chkSum(cc + s36 + rand);
        }
        function parseActivationCode(code) {
            var m = /^GRX-([A-Z0-9]{2})-([A-Z0-9]+)-([A-Z0-9]{4})-([A-Z0-9]{4})$/.exec((code||'').trim().toUpperCase());
            if (!m) return null;
            if (chkSum(m[1] + m[2] + m[3]) !== m[4]) return null;
            var planKey = codePlan(m[1]); if (!planKey) return null;
            var startMs = parseInt(m[2], 36) * 86400000;
            if (!startMs || isNaN(startMs)) return null;
            return { planKey: planKey, startMs: startMs, code: m[0] };
        }
        // Exposed so YOU can generate codes for paying clients (see ISSUING CODES below)
        window.grxIssueCode = function(planKey, startDateStr) {
            var startMs = startDateStr ? new Date(startDateStr + 'T00:00:00').getTime() : Date.now();
            var c = makeActivationCode(planKey, startMs);
            if (!c) { console.log('Unknown plan key. Valid keys:', Object.keys(PLAN_CODES).join(', ')); return null; }
            console.log('%cActivation code for ' + (PLANS[planKey] ? PLANS[planKey].name : planKey) + ':', 'color:#e9c46f;font-weight:bold');
            console.log('%c' + c, 'font-size:16px;font-weight:bold;color:#e9c46f');
            return c;
        };
        function lsGet(){ try { return JSON.parse(localStorage.getItem(KEY) || 'null'); } catch(e){ return null; } }
        function lsSet(v){ try { localStorage.setItem(KEY, JSON.stringify(v)); } catch(e){} }
        function lsClear(){ try { localStorage.removeItem(KEY); } catch(e){} }
        function esc(t){ var d=document.createElement('div'); d.textContent = t==null?'':t; return d.innerHTML; }
        function fmtDate(ms){ return new Date(ms).toLocaleDateString(undefined,{day:'numeric',month:'long',year:'numeric'}); }
        function daysLeft(rec){ return Math.ceil((rec.endsAt - Date.now()) / 86400000); }

        // ===== ACTIVATION FLOW =====
        window.openActivate = function(key){
            pendingKey = key;
            var p = PLANS[key]; if (!p) return;
            document.getElementById('am-title').textContent = 'Activate: ' + p.name;
            var err = document.getElementById('am-error'); if (err) err.style.display = 'none';
            document.getElementById('activate-modal').classList.add('show');
            setTimeout(function(){ var c=document.getElementById('am-code'); if(c) c.focus(); }, 60);
        };
        window.closeActivate = function(){ document.getElementById('activate-modal').classList.remove('show'); };
        window.confirmActivate = function(){
            var p = PLANS[pendingKey]; if (!p) return;
            var codeEl = document.getElementById('am-code');
            var errEl = document.getElementById('am-error');
            var raw = (codeEl.value || '').trim();
            errEl.style.display = 'none';
            if (!raw) { errEl.textContent = 'Enter the activation code Graphinxt sent you after payment.'; errEl.style.display = 'block'; codeEl.focus(); return; }
            var parsed = parseActivationCode(raw);
            if (!parsed) {
                errEl.textContent = 'That code isn\u2019t valid. Check it matches exactly, or contact us to have it resent.';
                errEl.style.display = 'block'; codeEl.focus();
                if (window.trackConversion) window.trackConversion('activation_code_invalid', { plan: pendingKey });
                return;
            }
            if (parsed.planKey !== pendingKey) {
                errEl.textContent = 'This code is for the ' + (PLANS[parsed.planKey] ? PLANS[parsed.planKey].name : 'a different plan') + '. Activate that plan instead, or contact us.';
                errEl.style.display = 'block'; codeEl.focus();
                return;
            }
            var company = (document.getElementById('am-company').value||'').trim();
            if (!company) { document.getElementById('am-company').focus(); return; }
            var startAt = parsed.startMs;
            var rec = {
                key: pendingKey, name: p.name, price: p.price, cycle: p.cycle, cat: p.cat,
                company: company,
                contact: (document.getElementById('am-name').value||'').trim(),
                email: (document.getElementById('am-email').value||'').trim(),
                startAt: startAt,
                endsAt: startAt + p.days * 86400000,
                days: p.days,
                code: parsed.code,
                invoiceNo: 'GRX-' + new Date(startAt).getFullYear() + '-' + chkSum(parsed.code).replace(/[^0-9A-Z]/g,'').slice(0,4)
            };
            lsSet(rec);
            closeActivate();
            render();
            if (window.trackConversion) window.trackConversion('plan_activated', { plan: pendingKey, price: p.price });
            setTimeout(function(){ generateInvoice(); }, 350);
        };
        window.clearPlan = function(){
            if (!confirm('Remove your active plan from this device? Your invoice stays downloaded.')) return;
            lsClear(); render();
        };

        // ===== INVOICE PDF =====
        window.generateInvoice = function(){
            var r = lsGet(); if (!r) return;
            if (window.trackConversion) window.trackConversion('invoice_download', { plan: r.key });
            if (!(window.jspdf && window.jspdf.jsPDF)) { alert('Invoice library still loading — please try again in a moment.'); return; }
            var doc = new window.jspdf.jsPDF();
            var M = 18, W = 210, y = 0;
            // Header band
            doc.setFillColor(54,54,56); doc.rect(0,0,W,42,'F');
            doc.setTextColor(233,196,111); doc.setFontSize(22); doc.setFont(undefined,'bold');
            doc.text('GRAPHINXT.', M, 20);
            doc.setTextColor(255,255,255); doc.setFontSize(8.5); doc.setFont(undefined,'normal');
            doc.text('Graphinxt Digital Content Creator FZ LLC', M, 28);
            doc.text('reach@graphinxt.com  ·  graphinxt.com', M, 33.5);
            doc.setFontSize(17); doc.setFont(undefined,'bold'); doc.setTextColor(233,196,111);
            doc.text('INVOICE', W - M, 20, { align:'right' });
            doc.setFontSize(8.5); doc.setFont(undefined,'normal'); doc.setTextColor(255,255,255);
            doc.text(r.invoiceNo, W - M, 28, { align:'right' });
            doc.text(fmtDate(r.startAt), W - M, 33.5, { align:'right' });
            y = 56;
            // Bill to
            doc.setTextColor(120,120,120); doc.setFontSize(8); doc.setFont(undefined,'bold');
            doc.text('BILLED TO', M, y);
            doc.setTextColor(35,35,35); doc.setFontSize(11);
            doc.text(r.company, M, y + 7);
            doc.setFontSize(9); doc.setFont(undefined,'normal'); doc.setTextColor(90,90,90);
            var by = y + 13;
            if (r.contact) { doc.text(r.contact, M, by); by += 5; }
            if (r.email) { doc.text(r.email, M, by); by += 5; }
            // Service period box
            doc.setTextColor(120,120,120); doc.setFontSize(8); doc.setFont(undefined,'bold');
            doc.text('SERVICE PERIOD', W - M - 62, y);
            doc.setTextColor(35,35,35); doc.setFontSize(9); doc.setFont(undefined,'normal');
            doc.text('Start:  ' + fmtDate(r.startAt), W - M - 62, y + 7);
            doc.text('Renews: ' + fmtDate(r.endsAt), W - M - 62, y + 13);
            y = Math.max(by, y + 20) + 10;
            // Table head
            doc.setFillColor(246,243,236); doc.rect(M, y, W - M*2, 10, 'F');
            doc.setTextColor(90,90,90); doc.setFontSize(8); doc.setFont(undefined,'bold');
            doc.text('DESCRIPTION', M + 4, y + 6.5);
            doc.text('BILLING', W - M - 62, y + 6.5);
            doc.text('AMOUNT', W - M - 4, y + 6.5, { align:'right' });
            y += 16;
            // Line item
            doc.setTextColor(35,35,35); doc.setFontSize(10.5); doc.setFont(undefined,'bold');
            doc.text(r.name, M + 4, y);
            doc.setFontSize(8.5); doc.setFont(undefined,'normal'); doc.setTextColor(120,120,120);
            doc.text(r.cat, M + 4, y + 5.5);
            doc.setTextColor(35,35,35); doc.setFontSize(9.5);
            doc.text(r.cycle, W - M - 62, y);
            doc.setFont(undefined,'bold'); doc.setFontSize(11);
            doc.text('$' + r.price.toLocaleString(), W - M - 4, y, { align:'right' });
            y += 16;
            doc.setDrawColor(228,224,214); doc.line(M, y, W - M, y);
            y += 10;
            // Total
            doc.setFillColor(233,196,111); doc.roundedRect(W - M - 82, y - 6, 82, 16, 3, 3, 'F');
            doc.setTextColor(54,54,56); doc.setFontSize(9); doc.setFont(undefined,'bold');
            doc.text('TOTAL', W - M - 76, y + 4);
            doc.setFontSize(13);
            doc.text('$' + r.price.toLocaleString() + ' USD', W - M - 5, y + 4, { align:'right' });
            y += 30;
            // Renewal notice
            doc.setFillColor(250,248,243); doc.roundedRect(M, y, W - M*2, 26, 3, 3, 'F');
            doc.setTextColor(90,90,90); doc.setFontSize(8.5); doc.setFont(undefined,'bold');
            doc.text('RENEWAL', M + 5, y + 8);
            doc.setFont(undefined,'normal');
            var renewTxt = r.cycle === 'monthly'
                ? 'This plan renews monthly. Your next renewal date is ' + fmtDate(r.endsAt) + '.'
                : 'This engagement runs to ' + fmtDate(r.endsAt) + '. We will contact you before it concludes.';
            doc.text(doc.splitTextToSize(renewTxt, W - M*2 - 10), M + 5, y + 15);
            y += 36;
            // Payment note
            doc.setTextColor(120,120,120); doc.setFontSize(8);
            doc.text(doc.splitTextToSize('Payment arranged directly with Graphinxt. Questions about this invoice? Email reach@graphinxt.com or message +971 56 478 5139 on WhatsApp.', W - M*2), M, y);
            if (r.code) {
                doc.setFontSize(7.5); doc.setTextColor(150,150,150);
                doc.text('Activation reference: ' + r.code, M, y + 12);
            }
            // Footer
            doc.setDrawColor(228,224,214); doc.line(M, 272, W - M, 272);
            doc.setFontSize(7.5); doc.setTextColor(150,150,150);
            doc.text('Graphinxt Digital Content Creator FZ LLC  ·  graphinxt.com  ·  reach@graphinxt.com', W/2, 279, { align:'center' });
            doc.text('Thank you for your business.', W/2, 284, { align:'center' });
            doc.save('graphinxt-invoice-' + r.invoiceNo + '.pdf');
        };

        window.renewPlan = function(){
            var r = lsGet(); if (!r) return;
            if (window.trackConversion) window.trackConversion('plan_renew_click', { plan: r.key });
            var msg = 'Hi Graphinxt! I\u2019d like to renew my ' + r.name + ' (' + r.company + '). It runs to ' + fmtDate(r.endsAt) + '.';
            window.open('https://wa.me/971564785139?text=' + encodeURIComponent(msg), '_blank', 'noopener');
        };
        window.upgradePlan = function(){
            var r = lsGet();
            var msg = 'Hi Graphinxt! I currently have the ' + (r ? r.name : 'a plan') + ' and would like to discuss upgrading.';
            window.open('https://wa.me/971564785139?text=' + encodeURIComponent(msg), '_blank', 'noopener');
        };

        // ===== RENDER =====
        function render(){
            var r = lsGet();
            // reset all cards
            document.querySelectorAll('.pkg.is-active').forEach(function(c){ c.classList.remove('is-active'); });
            document.querySelectorAll('.active-ribbon').forEach(function(n){ n.remove(); });
            document.querySelectorAll('.plan-actions-row').forEach(function(n){ n.remove(); });
            document.querySelectorAll('.activate-btn').forEach(function(b){ b.style.display = ''; });
            var banner = document.getElementById('plan-banner');
            if (!r) { if (banner) banner.classList.remove('show'); return; }

            // highlight the purchased card
            var cta = document.querySelector('[data-pkg="' + r.key + '"]');
            var card = cta ? cta.closest('.pkg') : null;
            if (card) {
                card.classList.add('is-active');
                var rib = document.createElement('div');
                rib.className = 'active-ribbon';
                rib.textContent = '\u2713 Your Active Plan';
                card.appendChild(rib);
                var actBtn = card.querySelector('.activate-btn');
                if (actBtn) actBtn.style.display = 'none';
                var row = document.createElement('div');
                row.className = 'plan-actions-row';
                row.innerHTML = '<button class="mini-btn" onclick="generateInvoice()">\u2b07 Invoice</button>' +
                                '<button class="mini-btn" onclick="renewPlan()">\u21bb Renew</button>';
                (cta.parentNode || card).appendChild(row);
            }

            // banner
            var left = daysLeft(r);
            var total = r.days;
            var used = Math.min(100, Math.max(0, ((total - left) / total) * 100));
            var cls = left <= 0 ? 'expired' : (left <= 7 ? 'warn' : '');
            var noteCls = left <= 0 ? 'over' : (left <= 7 ? 'soon' : '');
            var noteTxt = left <= 0
                ? '\u26a0 This plan ended on ' + fmtDate(r.endsAt) + '. Renew to keep everything running without a gap.'
                : (left <= 7 ? '\u23f0 Renews in ' + left + ' day' + (left===1?'':'s') + ' \u2014 message us now to confirm continuation.' : '');
            banner.innerHTML =
                '<div class="pb-top">' +
                    '<div>' +
                        '<div class="pb-eyebrow">\u2713 Your Active Plan</div>' +
                        '<div class="pb-name">' + esc(r.name) + '</div>' +
                        '<div class="pb-meta">' + esc(r.company) + ' \u00b7 $' + r.price.toLocaleString() + ' ' + esc(r.cycle) + ' \u00b7 Invoice ' + esc(r.invoiceNo) + '</div>' +
                    '</div>' +
                    '<div class="pb-countdown">' +
                        '<div class="pb-days ' + cls + '">' + (left > 0 ? left : 0) + '</div>' +
                        '<div class="pb-days-label">' + (left > 0 ? 'days remaining' : 'expired') + '</div>' +
                    '</div>' +
                '</div>' +
                '<div class="pb-bar"><div class="pb-fill" style="width:' + used + '%"></div></div>' +
                '<div class="pb-dates"><span>Started ' + fmtDate(r.startAt) + '</span><span>' + (r.cycle === 'monthly' ? 'Renews ' : 'Ends ') + fmtDate(r.endsAt) + '</span></div>' +
                (noteTxt ? '<div class="pb-renew-note show ' + noteCls + '">' + noteTxt + '</div>' : '') +
                '<div class="pb-actions">' +
                    '<button class="btn-primary" onclick="generateInvoice()">\u2b07 Download Invoice</button>' +
                    '<button class="btn-outline" onclick="renewPlan()">Renew / Extend</button>' +
                    '<button class="btn-outline" onclick="upgradePlan()">Upgrade Plan</button>' +
                    '<button class="btn-outline" onclick="clearPlan()" style="opacity:0.6;">Remove</button>' +
                '</div>';
            banner.classList.add('show');
        }

        // ===== INJECT "I purchased this" BUTTONS =====
        document.addEventListener('DOMContentLoaded', function(){
            Object.keys(PLANS).forEach(function(key){
                var cta = document.querySelector('[data-pkg="' + key + '"]');
                if (!cta) return;
                var b = document.createElement('button');
                b.className = 'activate-btn';
                b.type = 'button';
                b.textContent = '\u2713 Already purchased? Activate with code';
                b.onclick = function(){ openActivate(key); };
                (cta.parentNode || cta).appendChild(b);
            });
            handleStripeReturn();
            render();
            var modal = document.getElementById('activate-modal');
            if (modal) modal.addEventListener('click', function(e){ if (e.target === modal) closeActivate(); });
            document.addEventListener('keydown', function(e){ if (e.key === 'Escape') closeActivate(); });
        });

        // ===== AUTO-ACTIVATION AFTER PAYMENT =====
        // Stripe returns the client here with ?activate=<CODE> (set as the
        // Payment Link success URL). The code is validated exactly as a
        // manually-entered one, so an invalid or hand-typed URL still fails.
        function handleStripeReturn(){
            var q;
            try { q = new URLSearchParams(window.location.search); } catch(e) { return; }
            var raw = (q.get('activate') || '').trim();
            if (!raw) return;
            var parsed = parseActivationCode(raw);
            // Clean the URL either way so the code isn't left in the address bar
            try { history.replaceState({}, '', window.location.pathname); } catch(e) {}
            if (!parsed) { showReturnBanner(null, raw); return; }
            var existing = lsGet();
            if (existing && existing.code === parsed.code) { showReturnBanner(parsed.planKey, null, true); return; }
            pendingKey = parsed.planKey;
            showReturnBanner(parsed.planKey, null);
            // Pre-fill and open the short confirm step (we still need their business name for the invoice)
            setTimeout(function(){
                openActivate(parsed.planKey);
                var codeEl = document.getElementById('am-code');
                if (codeEl) { codeEl.value = parsed.code; codeEl.setAttribute('readonly','readonly'); codeEl.style.opacity = '0.75'; }
                var sub = document.querySelector('#activate-modal .sub');
                if (sub) sub.innerHTML = '<span style="color:var(--brand-gold);font-weight:600;">\u2713 Payment confirmed.</span> Just add your business name and your invoice will download.';
                var title = document.getElementById('am-title');
                if (title) title.textContent = 'Thank you! Finish your invoice';
                var comp = document.getElementById('am-company');
                if (comp) comp.focus();
            }, 700);
            if (window.trackConversion) window.trackConversion('plan_purchase_return', { plan: parsed.planKey });
        }
        function showReturnBanner(planKey, badCode, already){
            var host = document.getElementById('plan-banner');
            if (!host) return;
            var wrap = document.createElement('div');
            wrap.style.cssText = 'max-width:900px;margin:0 auto 1rem;border-radius:16px;padding:1.1rem 1.4rem;font-size:0.88rem;';
            if (planKey) {
                wrap.style.cssText += 'background:rgba(126,201,126,0.1);border:1px solid rgba(126,201,126,0.45);color:#7ec97e;';
                wrap.innerHTML = already
                    ? '\u2713 This plan is already activated on this device \u2014 your invoice is available below.'
                    : '\u2713 <strong>Payment received.</strong> Finishing your activation\u2026';
            } else {
                wrap.style.cssText += 'background:rgba(240,160,75,0.1);border:1px solid rgba(240,160,75,0.45);color:#f0a04b;';
                wrap.innerHTML = '\u26a0 We couldn\u2019t read that activation code' + (badCode ? ' (' + esc(badCode.slice(0,24)) + ')' : '') + '. <a href="https://wa.me/971564785139?text=' + encodeURIComponent('Hi Graphinxt! I paid but my activation link didn\u2019t work. Code: ' + (badCode||'(none)')) + '" target="_blank" rel="noopener" style="color:inherit;text-decoration:underline;">Message us</a> and we\u2019ll sort it in minutes.';
            }
            host.parentNode.insertBefore(wrap, host);
            setTimeout(function(){ wrap.style.transition='opacity .6s'; wrap.style.opacity='0'; setTimeout(function(){ wrap.remove(); }, 700); }, 9000);
        }
    })();
    </script>

 <?php include '../footer.php';?>
 <script src="../assets/js/script.js"></script>

</body>
</html>
