<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Services — Web, Branding, Ads, SEO & AI | Graphinxt</title>
    <meta name="description" content="Explore Graphinxt services: web development, branding, paid ads, SEO/AEO, social, video, and AI solutions — with transparent pricing.">
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="https://graphinxt.com/services">
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='14' fill='%23363638'/%3E%3Ctext x='32' y='44' font-family='Georgia, serif' font-size='36' font-weight='800' fill='%23e9c46f' text-anchor='middle'%3EG%3C/text%3E%3C/svg%3E">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@200;300;400;500;800&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@emailjs/browser@4/dist/email.min.js"></script>
      <link rel="stylesheet" href="../assets/style.css">
        <link rel="stylesheet" href="../assets/header.css">
    <style>
        :root {
            --bg-dark: #363638; --bg-darker: #2a2a2c; --brand-gold: #e9c46f; --brand-gold-hover: #d4ae58;
            --text-main: #ffffff; --text-muted: #a1a1a5; --card-bg: rgba(255,255,255,0.02);
            --border-light: rgba(233,196,111,0.12); --border-glow: rgba(233,196,111,0.4);
            --ai-glow: rgba(233,196,111,0.08); --gradient-start: #ffffff;
            --nav-bg: rgba(42,42,44,0.4); --nav-bg-scrolled: rgba(30,30,32,0.8);
            --overlay-gradient: linear-gradient(to top, rgba(30,30,32,0.95), transparent);
        }
        body.light-mode {
            --bg-dark: #faf8f5; --bg-darker: #ffffff; --text-main: #1a1a1a; --text-muted: #6b6b70;
            --card-bg: rgba(0,0,0,0.015); --border-light: rgba(0,0,0,0.06); --border-glow: rgba(217,164,74,0.9);
            --ai-glow: rgba(217,164,74,0.12); --gradient-start: #1a1a1a;
            --nav-bg: rgba(255,255,255,0.6); --nav-bg-scrolled: rgba(255,255,255,0.95);
            --overlay-gradient: linear-gradient(to top, rgba(255,255,255,0.95), transparent);
        }
        body.light-mode .feature-item { background: rgba(255,255,255,0.7); border-color: rgba(0,0,0,0.08); }
        body.light-mode .pricing-card { background: rgba(255,255,255,0.7); }
        body.light-mode .pricing-card.featured { background: rgba(217,164,74,0.04); }
        body.light-mode .process-node { background: rgba(255,255,255,0.7); }
        body.light-mode .related-service-card { background: rgba(255,255,255,0.7); }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Montserrat', sans-serif; cursor: none; scroll-behavior: smooth; }
        body { background-color: var(--bg-dark); color: var(--text-main); overflow-x: hidden; line-height: 1.6; transition: background-color 0.6s cubic-bezier(0.165,0.84,0.44,1), color 0.6s ease; }
        body::before { content: ""; position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: url('data:image/svg+xml;utf8,%3Csvg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg"%3E%3Cfilter id="noise"%3E%3CfeTurbulence type="fractalNoise" baseFrequency="0.8" numOctaves="4" stitchTiles="stitch"/%3E%3C/filter%3E%3Crect width="100%25" height="100%25" filter="url(%23noise)" opacity="0.04"/%3E%3C/svg%3E'); pointer-events: none; z-index: 99999; }
        h1, h2, h3, .logo { font-weight: 800; }
        .cursor-dot { width: 6px; height: 6px; background-color: var(--brand-gold); position: fixed; border-radius: 50%; z-index: 100000; pointer-events: none; transform: translate(-50%,-50%); transition: width 0.2s, height 0.2s; }
        .cursor-outline { width: 40px; height: 40px; border: 1px solid var(--brand-gold); position: fixed; border-radius: 50%; z-index: 100000; pointer-events: none; transform: translate(-50%,-50%); transition: width 0.3s, height 0.3s, background-color 0.3s, border-color 0.3s; }
.breadcrumb-nav{
    margin-top: 12rem;
}
         .hero-section { min-height: 65vh; display: flex; align-items: center; justify-content: center; padding: 10rem 5% 4rem; position: relative; text-align: center; overflow: hidden; }
        .hero-content { z-index: 2; max-width: 900px; }
        .subheading { font-size: 0.85rem; color: var(--brand-gold); text-transform: uppercase; letter-spacing: 6px; margin-bottom: 2rem; display: block; font-weight: 500; }
        .hero-section h1 { font-size: clamp(2.5rem, 6vw, 5rem); line-height: 1.05; margin-bottom: 2rem; font-weight: 200; letter-spacing: -2px; }
        .hero-section h1 strong { font-weight: 800; background: linear-gradient(to right, var(--gradient-start), var(--brand-gold)); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
        .hero-section p { font-size: 1.1rem; color: var(--text-muted); margin-bottom: 2.5rem; max-width: 650px; margin-left: auto; margin-right: auto; line-height: 1.8; font-weight: 300; }
        #bg-canvas { position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; z-index: 0; pointer-events: none; }
        body.light-mode #bg-canvas { display: none; }
        .ambient-glow { position: absolute; border-radius: 50%; filter: blur(140px); opacity: 0.15; z-index: 1; pointer-events: none; }
        .glow-top { width: 60vw; height: 60vw; background: radial-gradient(circle, var(--brand-gold) 0%, transparent 70%); top: -30vw; left: 20vw; }

        section { padding: 6rem 5%; position: relative; z-index: 2; }
        .section-header { text-align: left; margin-bottom: 4rem; max-width: 1200px; margin-left: auto; margin-right: auto; }
        .section-header h2 { font-size: clamp(2rem, 4vw, 3.5rem); font-weight: 200; line-height: 1.1; letter-spacing: -1px; }
        .section-header h2 strong { font-weight: 800; color: var(--brand-gold); }
        .section-header p { color: var(--text-muted); font-size: 1rem; max-width: 600px; text-transform: uppercase; letter-spacing: 2px; font-weight: 500; margin-top: 1rem; }

        .fade-in { opacity: 0; transform: translateY(40px); transition: opacity 1s cubic-bezier(0.165,0.84,0.44,1), transform 1s cubic-bezier(0.165,0.84,0.44,1); }
        .fade-in.visible { opacity: 1; transform: translateY(0); }

        /* FEATURES LIST */
        .features-list { max-width: 1000px; margin: 0 auto; display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5rem; }
        .feature-item { background: #353535; border: 1px solid #4d4d4d; border-radius: 20px; padding: 2rem; transition: all 0.4s ease; display: flex; gap: 1rem; align-items: flex-start; }
        .feature-item:hover { border-color: var(--border-glow); transform: translateY(-4px); }
        .feature-check { width: 24px; height: 24px; border-radius: 50%; border: 1px solid var(--brand-gold); display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
        .feature-check svg { width: 14px; height: 14px; stroke: var(--brand-gold); fill: none; stroke-width: 2.5; }
        .feature-item h4 { font-size: 1rem; font-weight: 500; margin-bottom: 0.25rem; color: var(--text-main); }
        .feature-item p { color: var(--text-muted); font-size: 0.85rem; line-height: 1.5; font-weight: 300; }

        /* PRICING TIERS */
        .pricing-grid { max-width: 1200px; margin: 0 auto; display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem; }
        .pricing-card { background: var(--card-bg); border: 1px solid var(--border-light); border-radius: 24px; padding: 3rem 2.5rem; transition: all 0.5s cubic-bezier(0.165,0.84,0.44,1); position: relative; overflow: hidden; display: flex; flex-direction: column; }
        .pricing-card:hover { border-color: var(--border-glow); transform: translateY(-8px); }
        .pricing-card.featured { border-color: var(--brand-gold); background: rgba(233,196,111,0.02); box-shadow: 0 20px 50px var(--ai-glow); }
        .pricing-card.featured::before { content: 'Most Popular'; position: absolute; top: 1.5rem; right: -3rem; background: var(--brand-gold); color: var(--bg-dark); font-size: 0.65rem; font-weight: 800; padding: 4px 3.5rem; transform: rotate(45deg); text-transform: uppercase; letter-spacing: 1px; }
        .pricing-tier-name { font-size: 0.8rem; color: var(--brand-gold); text-transform: uppercase; letter-spacing: 2px; font-weight: 800; margin-bottom: 0.5rem; }
        .pricing-amount { font-size: clamp(2.5rem, 5vw, 4rem); font-weight: 200; color: var(--text-main); line-height: 1; margin-bottom: 0.25rem; }
        .pricing-amount strong { font-weight: 800; color: var(--brand-gold); }
        .pricing-period { font-size: 0.9rem; color: var(--text-muted); margin-bottom: 2rem; font-weight: 300; }
        .pricing-desc { color: var(--text-muted); font-size: 0.9rem; line-height: 1.7; font-weight: 300; margin-bottom: 2rem; flex-grow: 1; }
        .pricing-features { list-style: none; margin-bottom: 2rem; flex-grow: 1; }
        .pricing-features li { display: flex; align-items: flex-start; gap: 0.75rem; color: var(--text-main); font-size: 0.9rem; font-weight: 300; margin-bottom: 0.75rem; line-height: 1.4; }
        .pricing-features li::before { content: '✓'; color: var(--brand-gold); font-weight: 800; flex-shrink: 0; }
        .pricing-btn { text-align: center; }
        .embed-frame-wrap { max-width: 1200px; margin: 0 auto; border: 1px solid var(--border-light); border-radius: 24px; overflow: hidden; background: var(--card-bg); }
        .embed-frame { width: 100%; height: 840px; border: none; display: block; }
        @media(max-width: 768px) { .embed-frame { height: 1350px; } }
        .pricing-expand-toggle { margin-top: 1.25rem; width: 100%; background: transparent; border: 1px solid var(--border-light); border-radius: 30px; padding: 0.65rem 1rem; color: var(--brand-gold); font-size: 0.72rem; text-transform: uppercase; letter-spacing: 1px; font-weight: 600; cursor: none; transition: all 0.3s; display: flex; align-items: center; justify-content: center; gap: 0.5rem; }
        .pricing-expand-toggle:hover { border-color: var(--brand-gold); }
        .pricing-expand-toggle .chev { transition: transform 0.3s; }
        .pricing-card.expanded .pricing-expand-toggle .chev { transform: rotate(180deg); }
        .pricing-expand { max-height: 0; overflow: hidden; transition: max-height 0.5s ease; }
        .pricing-card.expanded .pricing-expand { max-height: 1600px; }
        .pricing-expand-inner { padding-top: 1.5rem; }
        .pricing-expand-title { font-size: 0.95rem; font-weight: 300; margin-bottom: 1rem; text-align: center; }
        .pricing-expand-title strong { font-weight: 800; color: var(--brand-gold); }
        .pricing-portfolio-frame { width: 100%; height: 420px; border: 1px solid var(--border-light); border-radius: 16px; background: var(--bg-darker); }
        .pricing-expand-actions { display: flex; gap: 0.75rem; justify-content: center; margin-top: 1.25rem; flex-wrap: wrap; }
        .wa-btn { background: #25D366; color: #fff; border: none; border-radius: 30px; padding: 0.7rem 1.5rem; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; font-size: 0.72rem; text-decoration: none; display: inline-flex; align-items: center; }
        .wa-btn:hover { opacity: 0.9; }

        /* ADVANCED SEO/AEO AUDIT TOOL */
        .audit-card { background: var(--card-bg); border: 1px solid var(--border-light); border-radius: 28px; padding: 3rem; max-width: 900px; margin: 0 auto; }
        .audit-input-row { display: flex; gap: 0.8rem; flex-wrap: wrap; justify-content: center; margin-bottom: 0.8rem; }
        .audit-input { flex: 1; min-width: 240px; background: var(--bg-darker); border: 1px solid var(--border-light); color: var(--text-main); padding: 1rem 1.4rem; border-radius: 30px; font-size: 0.95rem; outline: none; cursor: text; }
        .audit-input:focus { border-color: var(--brand-gold); }
        .audit-run-btn { background: var(--brand-gold); color: var(--bg-dark) !important; padding: 1rem 2.2rem; border-radius: 30px; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; border: none; font-size: 0.78rem; white-space: nowrap; cursor: pointer; transition: all .3s; }
        .audit-run-btn:hover { transform: scale(1.04); }
        .audit-run-btn:disabled { opacity: 0.6; cursor: default; }
        .audit-hint { text-align: center; font-size: 0.7rem; color: var(--text-muted); opacity: 0.7; margin-bottom: 1.5rem; }
        .audit-loading { display: none; text-align: center; padding: 2rem 0; color: var(--text-muted); font-size: 0.85rem; }
        .audit-loading.show { display: block; }
        .audit-loading .spinner { width: 32px; height: 32px; border: 3px solid var(--border-light); border-top-color: var(--brand-gold); border-radius: 50%; margin: 0 auto 1rem; animation: auditSpin 0.9s linear infinite; }
        @keyframes auditSpin { to { transform: rotate(360deg); } }

        .audit-results { display: none; margin-top: 2rem; }
        .audit-results.show { display: block; animation: auditFadeIn .5s ease; }
        @keyframes auditFadeIn { from { opacity:0; transform: translateY(12px);} to { opacity:1; transform: translateY(0);} }
        .audit-source-tag { display: inline-block; font-size: 0.62rem; text-transform: uppercase; letter-spacing: 1px; font-weight: 700; padding: 4px 12px; border-radius: 20px; margin-bottom: 1.5rem; }
        .audit-source-tag.real { background: rgba(110,231,160,0.14); color: #6ee7a0; }
        .audit-source-tag.fallback { background: rgba(233,196,111,0.14); color: var(--brand-gold); }

        .audit-score-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(140px,1fr)); gap: 1rem; margin-bottom: 2rem; }
        .audit-score-card { background: var(--bg-darker); border: 1px solid var(--border-light); border-radius: 16px; padding: 1.4rem 1rem; text-align: center; }
        .audit-score-num { font-size: 1.8rem; font-weight: 800; margin-bottom: 0.3rem; }
        .audit-score-num.good { color: #6ee7a0; }
        .audit-score-num.mid { color: var(--brand-gold); }
        .audit-score-num.poor { color: #e88a7e; }
        .audit-score-label { font-size: 0.65rem; text-transform: uppercase; letter-spacing: 0.5px; color: var(--text-muted); }

        .audit-cwv-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px,1fr)); gap: 1rem; margin-bottom: 2rem; }
        .audit-cwv-card { background: var(--bg-darker); border: 1px solid var(--border-light); border-radius: 16px; padding: 1.2rem 1.3rem; }
        .audit-cwv-head { display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 0.4rem; }
        .audit-cwv-head span:first-child { font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.5px; color: var(--text-main); }
        .audit-cwv-value { font-size: 1.3rem; font-weight: 800; }
        .audit-cwv-tag { font-size: 0.6rem; text-transform: uppercase; letter-spacing: 0.5px; padding: 2px 8px; border-radius: 10px; }
        .audit-cwv-tag.good { background: rgba(110,231,160,0.14); color: #6ee7a0; }
        .audit-cwv-tag.mid { background: rgba(233,196,111,0.14); color: var(--brand-gold); }
        .audit-cwv-tag.poor { background: rgba(232,138,126,0.14); color: #e88a7e; }

        .audit-section-title { font-size: 0.95rem; font-weight: 500; margin: 2rem 0 1rem; color: var(--brand-gold); }
        .audit-suggestions { list-style: none; }
        .audit-suggestions li { font-size: 0.84rem; color: var(--text-muted); font-weight: 300; padding: 0.6rem 0; padding-left: 1.4rem; position: relative; border-bottom: 1px solid var(--border-light); }
        .audit-suggestions li:last-child { border-bottom: none; }
        .audit-suggestions li::before { content: '→'; position: absolute; left: 0; color: var(--brand-gold); }

        .audit-cta-row { display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap; margin-top: 2.5rem; }
        .audit-disclaimer { font-size: 0.68rem; color: var(--text-muted); opacity: 0.65; text-align: center; max-width: 640px; margin: 1.5rem auto 0; }

        .audit-email-gate { display: none; margin-top: 1.5rem; background: var(--bg-darker); border: 1px dashed var(--border-light); border-radius: 16px; padding: 1.5rem; }
        .audit-email-gate.show { display: block; }
        .audit-email-row { display: flex; gap: 0.7rem; flex-wrap: wrap; margin-top: 1rem; }
        .audit-email-row input { flex: 1; min-width: 180px; background: var(--card-bg); border: 1px solid var(--border-light); color: var(--text-main); padding: 0.8rem 1rem; border-radius: 10px; font-size: 0.85rem; outline: none; }
        .audit-email-success { display: none; color: #6ee7a0; font-size: 0.82rem; margin-top: 0.8rem; }

        /* AI Search Simulator */
        .ai-sim-card { background: var(--bg-darker); border: 1px solid var(--border-light); border-radius: 16px; padding: 1.5rem; margin-bottom: 1rem; }
        .ai-sim-label { display: inline-flex; align-items: center; gap: 6px; font-size: 0.62rem; text-transform: uppercase; letter-spacing: 1px; font-weight: 700; color: var(--text-muted); margin-bottom: 1rem; }
        .ai-sim-label .dot { width: 6px; height: 6px; border-radius: 50%; background: var(--brand-gold); }
        .ai-sim-bubble { border-radius: 14px; padding: 1rem 1.2rem; font-size: 0.85rem; line-height: 1.6; max-width: 92%; }
        .ai-sim-bubble.query { background: rgba(255,255,255,0.05); color: var(--text-main); margin-bottom: 0.8rem; font-weight: 500; }
        .ai-sim-bubble.answer { border: 1px solid var(--border-light); color: var(--text-muted); font-weight: 300; margin-left: auto; }
        .ai-sim-bubble.answer.confident { border-color: rgba(110,231,160,0.35); background: rgba(110,231,160,0.05); }
        .ai-sim-bubble.answer.hedging { border-color: rgba(232,138,126,0.35); background: rgba(232,138,126,0.05); }
        .ai-sim-bubble.answer.partial { border-color: rgba(233,196,111,0.35); background: rgba(233,196,111,0.05); }
        .ai-sim-tier-tag { display: inline-block; font-size: 0.6rem; text-transform: uppercase; letter-spacing: 0.5px; font-weight: 700; padding: 2px 10px; border-radius: 10px; margin-bottom: 0.6rem; }
        .ai-sim-tier-tag.confident { background: rgba(110,231,160,0.14); color: #6ee7a0; }
        .ai-sim-tier-tag.hedging { background: rgba(232,138,126,0.14); color: #e88a7e; }
        .ai-sim-tier-tag.partial { background: rgba(233,196,111,0.14); color: var(--brand-gold); }
        .ai-sim-note { font-size: 0.7rem; color: var(--text-muted); opacity: 0.65; margin-top: 1rem; }
        .audit-email-success.show { display: block; }

        /* ENQUIRY FORM */
        .enquiry-wrapper { max-width: 800px; margin: 0 auto; background: var(--card-bg); border: 1px solid var(--border-light); border-radius: 32px; padding: 4rem; backdrop-filter: blur(20px); transition: all 0.4s ease; }
        .enquiry-wrapper:hover { border-color: var(--border-glow); }
        .enquiry-wrapper h3 { font-size: 2rem; font-weight: 200; margin-bottom: 0.5rem; }
        .enquiry-wrapper h3 strong { font-weight: 800; color: var(--brand-gold); }
        .enquiry-wrapper > p { color: var(--text-muted); font-size: 1rem; margin-bottom: 2.5rem; font-weight: 300; }
        .dynamic-form { display: flex; flex-direction: column; gap: 2rem; }
        .dynamic-form input, .dynamic-form textarea, .dynamic-form select { width: 100%; padding: 1rem 0; background: transparent; border: none; border-bottom: 1px solid var(--border-light); color: var(--text-main); outline: none; transition: border-color 0.3s, color 0.6s ease; font-size: 1rem; font-weight: 300; resize: none; cursor: none; }
        .dynamic-form input:focus, .dynamic-form textarea:focus, .dynamic-form select:focus { border-color: var(--brand-gold); }
        .dynamic-form input::placeholder, .dynamic-form textarea::placeholder { color: var(--text-muted); text-transform: uppercase; font-size: 0.8rem; letter-spacing: 1px; }
        .dynamic-form select { appearance: none; -webkit-appearance: none; }
        .dynamic-form select option { background: var(--bg-darker); color: var(--text-main); }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 2rem; }
        @media(max-width: 600px) { .form-row { grid-template-columns: 1fr; } .enquiry-wrapper { padding: 2.5rem; } }
        .form-success { display: none; text-align: center; padding: 3rem 0; }
        .form-success.show { display: block; }
        .form-success svg { width: 48px; height: 48px; stroke: var(--brand-gold); fill: none; stroke-width: 1.5; margin: 0 auto 1.5rem; }
        .form-success h4 { font-size: 1.8rem; font-weight: 500; margin-bottom: 0.5rem; }
        .form-success p { color: var(--text-muted); }
        .form-group { display: flex; flex-direction: column; gap: 1.75rem; }
        .form-group-title { font-size: 0.72rem; color: var(--brand-gold); text-transform: uppercase; letter-spacing: 2.5px; font-weight: 700; padding-bottom: 0.85rem; border-bottom: 1px solid var(--border-light); }
        .form-field { display: flex; flex-direction: column; }
        .form-field label { font-size: 0.68rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1.5px; font-weight: 500; margin-bottom: 0.3rem; transition: color 0.3s; }
        .form-field:focus-within label { color: var(--brand-gold); }
        .chip-group { display: flex; flex-wrap: wrap; gap: 0.6rem; }
        .chip { padding: 0.55rem 1.15rem; border: 1px solid var(--border-light); border-radius: 30px; font-size: 0.76rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px; font-weight: 500; cursor: none; transition: all 0.3s ease; background: transparent; font-family: inherit; }
        .chip:hover { border-color: var(--border-glow); color: var(--text-main); }
        .chip.active { background: var(--brand-gold); border-color: var(--brand-gold); color: var(--bg-dark); font-weight: 700; }
        .form-note { font-size: 0.78rem; color: var(--text-muted); font-weight: 300; margin-top: 0.25rem; }
        .form-note strong { color: var(--brand-gold); font-weight: 600; }
        @media(max-width: 600px) { .form-triple { grid-template-columns: 1fr; } }

        /* PROCESS */
        .process-timeline-v2 { max-width: 1200px; margin: 0 auto; display: grid; grid-template-columns: repeat(4, 1fr); gap: 2rem; position: relative; }
        .process-line { position: absolute; top: 40px; left: 12.5%; right: 12.5%; height: 2px; background: linear-gradient(90deg, transparent, var(--brand-gold), transparent); z-index: 0; opacity: 0.5; }
        .process-node { position: relative; text-align: center; padding: 2.5rem 1.5rem 2rem; background: var(--card-bg); border: 1px solid var(--border-light); border-radius: 20px; transition: all 0.5s cubic-bezier(0.165,0.84,0.44,1); }
        .process-node:hover { border-color: var(--brand-gold); transform: translateY(-8px); background: rgba(233,196,111,0.02); }
        .process-node-num { position: absolute; top: -22px; left: 50%; transform: translateX(-50%); width: 44px; height: 44px; border-radius: 50%; background: var(--bg-darker); border: 2px solid var(--brand-gold); display: flex; align-items: center; justify-content: center; font-weight: 800; color: var(--brand-gold); font-size: 0.85rem; z-index: 2; box-shadow: 0 0 20px var(--ai-glow); }
        .process-node-icon { width: 48px; height: 48px; margin: 0.5rem auto 1.2rem; display: flex; align-items: center; justify-content: center; }
        .process-node-icon svg { width: 100%; height: 100%; stroke: var(--brand-gold); fill: none; stroke-width: 1.5; }
        .process-node h4 { font-size: 1.1rem; font-weight: 500; margin-bottom: 0.6rem; color: var(--text-main); }
        .process-node p { color: var(--text-muted); font-size: 0.82rem; line-height: 1.6; font-weight: 300; margin-bottom: 1rem; }
        .process-node-tag { display: inline-block; font-size: 0.62rem; color: var(--brand-gold); text-transform: uppercase; letter-spacing: 1.5px; font-weight: 600; padding: 4px 12px; border: 1px solid var(--border-light); border-radius: 12px; }

        /* RELATED SERVICES */
        .related-services-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1.5rem; max-width: 1200px; margin: 0 auto; }
        .related-service-card { background: var(--card-bg); border: 1px solid var(--border-light); border-radius: 20px; padding: 2rem; transition: all 0.4s cubic-bezier(0.165,0.84,0.44,1); text-decoration: none; display: flex; flex-direction: column; gap: 0.4rem; }
        .related-service-card:hover { border-color: var(--brand-gold); transform: translateY(-6px); background: rgba(233,196,111,0.02); }
        .related-service-card h4 { font-size: 1.05rem; font-weight: 500; color: var(--text-main); }
        .related-service-card p { color: var(--text-muted); font-size: 0.78rem; font-weight: 300; flex-grow: 1; }
        .related-service-link { color: var(--brand-gold); font-size: 0.72rem; text-transform: uppercase; letter-spacing: 1px; font-weight: 600; margin-top: 0.5rem; }

        @media(max-width: 768px) {
            .process-timeline-v2 { grid-template-columns: 1fr; gap: 2.5rem; }
            .process-line { top: 0; bottom: 0; left: 22px; right: auto; width: 2px; height: auto; background: linear-gradient(180deg, transparent, var(--brand-gold), transparent); }
            .process-node { text-align: left; padding: 1.5rem 1rem 1.5rem 3rem; }
            .process-node-num { top: 1.5rem; left: 22px; transform: translateX(-50%); width: 40px; height: 40px; }
            .process-node-icon { margin: 0 0 0.8rem 0; width: 40px; height: 40px; }
        }

        /* FAQ */
        .faq-container { max-width: 800px; margin: 0 auto; }
        .faq-item { border-bottom: 1px solid var(--border-light); transition: border-color 0.4s ease; }
        .faq-item.active { border-color: var(--brand-gold); }
        .faq-question { width: 100%; background: transparent; border: none; color: var(--text-main); font-size: 1.1rem; font-weight: 500; text-align: left; padding: 2rem 0; display: flex; justify-content: space-between; align-items: center; cursor: none; transition: color 0.3s; }
        .faq-question:hover { color: var(--brand-gold); }
        .faq-icon { width: 24px; height: 24px; position: relative; flex-shrink: 0; margin-left: 1rem; }
        .faq-icon::before, .faq-icon::after { content: ''; position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%); background: var(--brand-gold); transition: transform 0.4s ease; }
        .faq-icon::before { width: 16px; height: 2px; }
        .faq-icon::after { width: 2px; height: 16px; }
        .faq-item.active .faq-icon::after { transform: translate(-50%,-50%) rotate(90deg); }
        .faq-answer { max-height: 0; overflow: hidden; transition: max-height 0.4s cubic-bezier(0.165,0.84,0.44,1); }
        .faq-item.active .faq-answer { max-height: 300px; }
        .faq-answer p { color: var(--text-muted); font-size: 0.95rem; line-height: 1.7; font-weight: 300; padding-bottom: 2rem; }

        /* FOOTER */
        footer { padding: 6rem 5% 4rem; text-align: center; border-top: 1px solid var(--border-light); position: relative; z-index: 2; }
        .footer-logo { font-size: clamp(2.5rem, 6vw, 6rem); font-weight: 800; letter-spacing: -2px; margin-bottom: 1rem; color: transparent; -webkit-text-stroke: 1px rgba(255,255,255,0.1); transition: color 0.5s, -webkit-text-stroke 0.5s; text-decoration: none; }
        body.light-mode .footer-logo { -webkit-text-stroke: 1px rgba(0,0,0,0.08); }
        .footer-logo:hover { color: var(--text-main); -webkit-text-stroke: 0; }
        .footer-bottom { margin-top: 2rem; color: var(--text-muted); font-size: 0.8rem; letter-spacing: 1px; text-transform: uppercase; }
        .back-link { display: inline-flex; align-items: center; gap: 0.5rem; color: var(--brand-gold); text-decoration: none; font-size: 0.85rem; text-transform: uppercase; letter-spacing: 1px; font-weight: 600; margin-bottom: 2rem; transition: gap 0.3s; }
        .back-link:hover { gap: 1rem; }

        /* MOBILE NAV */
        .nav-toggle { display: none; flex-direction: column; gap: 5px; background: transparent; border: none; padding: 5px; cursor: none; z-index: 9991; }
        .nav-toggle span { width: 22px; height: 2px; background: var(--text-main); transition: all 0.3s; }
        .nav-toggle.open span:nth-child(1) { transform: translateY(7px) rotate(45deg); }
        .nav-toggle.open span:nth-child(2) { opacity: 0; }
        .nav-toggle.open span:nth-child(3) { transform: translateY(-7px) rotate(-45deg); }
        .mobile-menu { position: fixed; top: 0; right: 0; width: 100%; max-width: 300px; height: 100vh; background: var(--bg-darker); border-left: 1px solid var(--border-light); padding: 6rem 2rem 2rem; transform: translateX(100%); transition: transform 0.5s cubic-bezier(0.165,0.84,0.44,1); z-index: 9989; display: flex; flex-direction: column; gap: 0; }
        .mobile-menu.open { transform: translateX(0); }
        .mobile-menu a { color: var(--text-main); text-decoration: none; font-size: 0.9rem; text-transform: uppercase; letter-spacing: 1.5px; font-weight: 500; padding: 1.2rem 0; border-bottom: 1px solid var(--border-light); transition: color 0.3s; }
        .mobile-menu a:hover { color: var(--brand-gold); }
        .mobile-theme-btn { background: transparent; border: none; color: var(--text-main); font-size: 1.1rem; text-align: left; padding: 1.2rem 0; border-bottom: 1px solid var(--border-light); cursor: none; display: flex; align-items: center; gap: 0.6rem; text-transform: uppercase; letter-spacing: 1.5px; font-weight: 500; }
        .mobile-theme-btn:hover { color: var(--brand-gold); }
        .mode-toggle-mobile { background: transparent; border: none; color: var(--text-main); font-size: 1.2rem; display: none; align-items: center; justify-content: center; transition: transform 0.4s ease, color 0.3s; cursor: none; }
        .mode-toggle-mobile:hover { color: var(--brand-gold); transform: rotate(30deg); }

        /* ENQUIRY MODAL */
        #enquiry { position: fixed; inset: 0; z-index: 99992; background: rgba(0,0,0,0.82); backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px); display: none; align-items: flex-start; justify-content: center; overflow-y: auto; padding: 3rem 1rem 2rem; }
        #enquiry.open { display: flex; }
        #enquiry .enquiry-wrapper { position: relative; max-width: 720px; width: 100%; margin: 0 auto; background: var(--bg-darker); border: 1px solid var(--border-glow); border-radius: 24px; padding: 2.75rem; box-shadow: 0 30px 80px rgba(0,0,0,0.5); max-height: 90vh; overflow-y: auto; }
        #enquiry .enquiry-wrapper > h3 { font-size: 1.6rem; font-weight: 300; margin-bottom: 0.35rem; padding-right: 3rem; }
        #enquiry .enquiry-wrapper > h3 strong { font-weight: 800; color: var(--brand-gold); }
        #enquiry .enquiry-wrapper > p { color: var(--text-muted); margin-bottom: 2rem; font-weight: 300; }
        #enquiry .fade-in { opacity: 1 !important; transform: none !important; }
        .enquiry-close { position: absolute; top: 1rem; right: 1rem; width: 40px; height: 40px; border-radius: 50%; background: transparent; border: 1px solid var(--border-light); color: var(--text-muted); font-size: 1.2rem; display: flex; align-items: center; justify-content: center; cursor: none; z-index: 3; transition: all 0.3s; }
        .enquiry-close:hover { border-color: var(--brand-gold); color: var(--brand-gold); transform: rotate(90deg); }
        @media(max-width: 768px) {
            #enquiry { padding: 1rem; }
            #enquiry .enquiry-wrapper { padding: 1.5rem; border-radius: 20px; max-height: 94vh; }
            #enquiry .enquiry-wrapper > h3 { font-size: 1.35rem; padding-right: 2.5rem; }
            #enquiry .form-row { grid-template-columns: 1fr; gap: 0; }
            #enquiry .dynamic-form { gap: 1.5rem; }
            #enquiry .form-group-title { font-size: 0.66rem; }
        }

        /* WHATSAPP FLOAT */
        .whatsapp-float { position: fixed; right: 22px; bottom: 22px; z-index: 9995; width: 56px; height: 56px; border-radius: 50%; background: #25D366; color: #fff; display: flex; align-items: center; justify-content: center; box-shadow: 0 8px 24px rgba(37,211,102,0.45); transition: transform 0.3s ease; text-decoration: none; animation: waPulse 2.5s infinite; }
        @keyframes waPulse { 0% { box-shadow: 0 8px 24px rgba(37,211,102,0.45), 0 0 0 0 rgba(37,211,102,0.5); } 70% { box-shadow: 0 8px 24px rgba(37,211,102,0.45), 0 0 0 16px rgba(37,211,102,0); } 100% { box-shadow: 0 8px 24px rgba(37,211,102,0.45), 0 0 0 0 rgba(37,211,102,0); } }
        .whatsapp-float:hover { transform: scale(1.1); }
        .whatsapp-float svg { width: 30px; height: 30px; fill: #fff; }

        @media(max-width: 768px) {
            .nav-links { display: none; }
            .nav-toggle { display: flex; }
            .mode-toggle-mobile { display: flex; margin-left: auto; margin-right: 0.5rem; }
            section { padding: 4rem 5%; }
            #enquiry { padding: 1rem; }
            #enquiry .enquiry-wrapper { padding: 1.5rem; }
            .enquiry-close { top: 0.5rem; right: 0.5rem; }
            .whatsapp-float { width: 52px; height: 52px; right: 14px; bottom: 78px; }
            .whatsapp-float svg { width: 26px; height: 26px; }
        }
    </style>

<!-- ===== ANALYTICS & CONVERSION TRACKING =====
     Replace G-58PYC27MPE with your real GA4 Measurement ID (analytics.google.com > Admin > Data Streams)
     Replace 2162187584315430 with your real Meta Pixel ID (business.facebook.com/events_manager > Data Sources)
     Until replaced, these load harmlessly but report no real data.
-->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-58PYC27MPE"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-58PYC27MPE');
</script>
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '2162187584315430');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=2162187584315430&ev=PageView&noscript=1" /></noscript>
<script>
  // Unified conversion helper — fires both GA4 and Meta Pixel from a single call site-wide.
  window.trackConversion = function(eventName, params) {
    params = params || {};
    try { if (typeof gtag === 'function') gtag('event', eventName, params); } catch(e) {}
    try { if (typeof fbq === 'function') fbq('trackCustom', eventName, params); } catch(e) {}
  };
  // Auto-track every outbound WhatsApp click site-wide (no extra wiring needed per page).
  document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('a[href*="wa.me"]').forEach(function(el) {
      el.addEventListener('click', function() { window.trackConversion('whatsapp_click', { page: window.location.pathname }); });
    });
  });
</script>
<!-- ===== END ANALYTICS ===== -->
</head>
<body>
 <!--    <canvas id="bg-canvas"></canvas>
    <div class="ambient-glow glow-top"></div>
    <div class="cursor-dot"></div>
    <div class="cursor-outline"></div>
 -->
    <!-- Navbar -->
            <?php include '../header.php';?>

    <!-- Breadcrumb -->
    <nav class="breadcrumb-nav" id="breadcrumb-nav" aria-label="Breadcrumb"></nav>

    <!-- Service Hero -->
    <section class="hero-section">
        <div class="hero-content fade-in">
            <span class="subheading" id="service-subheading">Graphinxt Service</span>
            <h1 id="service-title">Loading...</h1>
            <p id="service-description"></p>
            <div class="btn-wrap">
                <a href="#pricing" class="btn-primary interactive-el">View Pricing</a>
                <a href="#enquiry" class="btn-outline interactive-el">Request Quote</a>
                <a id="portfolio-link" href="/portfolio" target="_top" class="btn-outline interactive-el">View Portfolio →</a>
            </div>
        </div>
    </section>

    <!-- What's Included -->
    <section id="features">
        <div class="section-header fade-in">
            <h2>What's <strong>Included</strong></h2>
            <p>Full Deliverables Breakdown.</p>
        </div>
        <div class="features-list" id="features-list"></div>
    </section>

    <!-- Startup Kit Promo (Branding only) -->
    <section id="startup-kit-promo" style="display:none; text-align:center;">
        <div class="audit-card fade-in" style="max-width:700px;">
            <span class="snapshot-tag" style="display:inline-block; font-size:0.65rem; text-transform:uppercase; letter-spacing:2px; font-weight:800; background:rgba(233,196,111,0.12); color:var(--brand-gold); padding:0.3rem 0.9rem; border-radius:20px; margin-bottom:1rem;">Free Tool</span>
            <h3 style="font-size:1.4rem; margin-bottom:0.8rem;">Not ready for a full brand yet?</h3>
            <p style="color:var(--text-muted); font-size:0.9rem; margin-bottom:1.5rem;">Try our free Startup Launch Kit Generator — instant name ideas, taglines, and a brand color palette to get you started.</p>
            <a href="/startup-kit" class="btn-outline interactive-el">Generate a Free Launch Kit →</a>
        </div>
    </section>

    <!-- Pricing -->
    <section id="pricing">
        <div class="section-header fade-in">
            <h2>Pricing <strong>Tiers</strong></h2>
            <p>Rough Cost Estimates.</p>
        </div>
        <div class="pricing-grid" id="pricing-grid"></div>
        <p style="text-align: center; color: var(--text-muted); font-size: 0.8rem; margin-top: 3rem; font-weight: 300; max-width: 600px; margin-left: auto; margin-right: auto;">*Prices are rough estimates in USD. Final pricing depends on project scope, complexity, and specific requirements. Contact us for a detailed quote.</p>
    </section>

    <!-- Development Estimator (Web Dev only) -->
    <section id="dev-estimator" style="display:none;">
        <style>
            .estimator-wrapper { max-width: 1000px; margin: 0 auto; display: grid; grid-template-columns: 1.4fr 1fr; gap: 2.5rem; align-items: start; }
            .estimator-controls { display: flex; flex-direction: column; gap: 2rem; }
            .estimator-field { display: flex; flex-direction: column; gap: 0.75rem; }
            .estimator-field label { font-size: 0.7rem; color: var(--brand-gold); text-transform: uppercase; letter-spacing: 2px; font-weight: 700; }
            .estimator-field input[type="range"] { -webkit-appearance: none; appearance: none; width: 100%; height: 4px; background: var(--border-light); border-radius: 4px; outline: none; }
            .estimator-field input[type="range"]::-webkit-slider-thumb { -webkit-appearance: none; appearance: none; width: 20px; height: 20px; border-radius: 50%; background: var(--brand-gold); cursor: none; box-shadow: 0 0 12px var(--ai-glow); }
            .estimator-field input[type="range"]::-moz-range-thumb { width: 20px; height: 20px; border: none; border-radius: 50%; background: var(--brand-gold); cursor: none; }
            .est-addon-list { display: flex; flex-direction: column; gap: 0.85rem; }
            .est-addon { display: flex; align-items: center; gap: 0.75rem; color: var(--text-main); font-size: 0.9rem; font-weight: 400; cursor: none; }
            .est-addon input { width: 18px; height: 18px; accent-color: var(--brand-gold); cursor: none; }
            .estimator-output { background: var(--card-bg); border: 1px solid var(--border-glow); border-radius: 24px; padding: 3rem 2.5rem; text-align: center; box-shadow: inset 0 0 30px var(--ai-glow); position: sticky; top: 6rem; }
            .est-label { font-size: 0.72rem; color: var(--brand-gold); text-transform: uppercase; letter-spacing: 2.5px; font-weight: 700; margin-bottom: 1rem; }
            .est-price { font-size: clamp(2.5rem, 5vw, 3.5rem); font-weight: 200; color: var(--text-main); line-height: 1; margin-bottom: 1rem; }
            .est-price strong { font-weight: 800; color: var(--brand-gold); }
            .est-note { color: var(--text-muted); font-size: 0.78rem; line-height: 1.6; font-weight: 300; margin-top: 0.5rem; }
            @media(max-width: 768px) { .estimator-wrapper { grid-template-columns: 1fr; } .estimator-output { position: static; } }
        </style>
        <div class="section-header fade-in">
            <h2>Development <strong>Estimator</strong></h2>
            <p>Get an Instant Project Cost Estimate.</p>
        </div>
        <div class="embed-frame-wrap fade-in">
            <iframe src="/index.html#embed=ai-estimator" title="Development Estimator" loading="lazy" class="embed-frame"></iframe>
        </div>
    </section>

    <!-- Marketing Architect (Ads only) -->
    <section id="mkt-architect-embed" style="display:none;">
        <div class="section-header fade-in">
            <h2>Marketing <strong>Architect</strong></h2>
            <p>Predictive Media Modeling Matrix.</p>
        </div>
        <div class="embed-frame-wrap fade-in">
            <iframe src="/index.html#embed=marketing-architect" title="Marketing Architect" loading="lazy" class="embed-frame"></iframe>
        </div>
    </section>

    <!-- Advanced SEO/AEO Audit (SEO service only) -->
    <section id="seo-audit-embed" style="display:none;">
        <div class="section-header fade-in">
            <span class="snapshot-tag" style="display:inline-block; font-size:0.65rem; text-transform:uppercase; letter-spacing:2px; font-weight:800; background:rgba(233,196,111,0.12); color:var(--brand-gold); padding:0.3rem 0.9rem; border-radius:20px; margin-bottom:1rem;">Free Full Audit</span>
            <h2>The Real <strong>SEO &amp; AEO Audit</strong></h2>
            <p>Not a domain-name guess — this pulls genuine Google Lighthouse data: real Core Web Vitals, real technical SEO signals, and real accessibility &amp; best-practices scores for the exact URL you enter.</p>
        </div>
        <div class="audit-card fade-in">
            <div class="audit-input-row">
                <input type="text" id="audit-url-input" class="audit-input interactive-el" placeholder="yourwebsite.com" autocomplete="off">
                <button id="audit-run-btn" class="audit-run-btn interactive-el" onclick="runFullAudit()">Run Full Audit →</button>
            </div>
            <div class="audit-hint">Powered by Google PageSpeed Insights (Lighthouse) — real data, not estimated. Takes 10–30 seconds.</div>

            <div class="audit-loading" id="audit-loading">
                <div class="spinner"></div>
                <div id="audit-loading-text">Requesting a live Lighthouse audit from Google...</div>
            </div>

            <div class="audit-results" id="audit-results">
                <span class="audit-source-tag" id="audit-source-tag">Real Data</span>

                <div class="audit-score-grid" id="audit-score-grid"></div>

                <div class="audit-section-title">Core Web Vitals</div>
                <div class="audit-cwv-row" id="audit-cwv-row"></div>

                <div class="audit-section-title">AEO &amp; Structured Data Readiness</div>
                <p id="audit-aeo-summary" style="font-size:0.85rem; color:var(--text-muted); font-weight:300; margin-bottom:1rem;"></p>

                <div class="audit-section-title">How AI Search Sees You</div>
                <div class="ai-sim-card" id="ai-sim-card"></div>

                <div class="audit-section-title">Top Improvement Suggestions</div>
                <ul class="audit-suggestions" id="audit-suggestions"></ul>

                <p class="audit-disclaimer" id="audit-disclaimer"></p>

                <div class="audit-cta-row">
                    <button class="btn-primary interactive-el" style="border:none; cursor:pointer;" onclick="downloadAuditPDF()">Download Branded PDF Report</button>
                    <button class="btn-outline interactive-el" style="cursor:pointer;" onclick="toggleEmailGate()">Email Me a Copy</button>
                </div>

                <div class="audit-email-gate" id="audit-email-gate">
                    <p style="font-size:0.82rem; color:var(--text-muted);">We'll email you the report and pass a copy to our team so we can follow up with tailored recommendations.</p>
                    <form class="audit-email-row" id="audit-email-form">
                        <input type="text" id="audit-name" placeholder="Your name" required>
                        <input type="email" id="audit-email" placeholder="Your email" required>
                        <button type="submit" class="btn-primary interactive-el" style="border:none; cursor:pointer;">Send Report</button>
                    </form>
                    <div class="audit-email-success" id="audit-email-success">✓ Sent — check your inbox, and thank you, our team will follow up shortly.</div>
                </div>
            </div>
        </div>
    </section>

    <!-- Process -->
    <section id="process">
        <div class="section-header fade-in">
            <h2>Our <strong>Process</strong></h2>
            <p>From Concept to Delivery.</p>
        </div>
        <div class="process-timeline-v2 fade-in">
            <div class="process-line"></div>
        </div>
    </section>

    <!-- Related Services -->
    <section id="related-services">
        <div class="section-header fade-in">
            <h2>Related <strong>Services</strong></h2>
            <p>Explore More Capabilities.</p>
        </div>
        <div class="related-services-grid fade-in" id="related-services-grid"></div>
    </section>

    <!-- FAQ -->
    <section id="faq">
        <div class="section-header fade-in">
            <h2>Common <strong>Questions</strong></h2>
            <p>Service-Specific FAQs.</p>
        </div>
        <div class="faq-container fade-in" id="faq-container"></div>
    </section>

    <!-- Enquiry Form -->
    <section id="enquiry">
        <div class="enquiry-wrapper fade-in">
            <button class="enquiry-close" id="enquiry-close" aria-label="Close">✕</button>
            <h3>Request a <strong>Quote</strong></h3>
            <p>Tell us about your project and we'll send a detailed proposal within 24 hours.</p>
            <form id="enquiry-form" class="dynamic-form">
                <!-- Your Details -->
                <div class="form-group">
                    <div class="form-group-title">Your Details</div>
                    <div class="form-row">
                        <div class="form-field"><label>Full Name *</label><input type="text" name="name" required class="interactive-el"></div>
                        <div class="form-field"><label>Email Address *</label><input type="email" name="email" required class="interactive-el"></div>
                    </div>
                    <div class="form-row">
                        <div class="form-field"><label>Phone Number</label><input type="tel" name="phone" class="interactive-el"></div>
                        <div class="form-field"><label>Company / Brand</label><input type="text" name="company" class="interactive-el"></div>
                    </div>
                    <div class="form-field"><label>Website / URL</label><input type="url" name="website" placeholder="https://" class="interactive-el"></div>
                </div>

                <!-- Project Scope -->
                <div class="form-group">
                    <div class="form-group-title">Project Scope</div>
                    <div class="form-field">
                        <label>Services Interested In</label>
                        <div class="chip-group" id="service-chips"></div>
                        <span class="form-note">Select all that apply — <strong>multi-select</strong></span>
                    </div>
                    <div class="form-row">
                        <div class="form-field"><label>Preferred Tier</label><select name="tier" id="tier-select" class="interactive-el">
                            <option value="" disabled selected>Select tier</option>
                            <option value="Starter">Starter</option>
                            <option value="Professional">Professional</option>
                            <option value="Enterprise">Enterprise</option>
                            <option value="Custom">Not Sure / Custom</option>
                        </select></div>
                        <div class="form-field"><label>Estimated Budget</label><select name="budget" class="interactive-el">
                            <option value="" disabled selected>Select range</option>
                            <option value="Under $1,000">Under $1,000</option>
                            <option value="$1,000 – $5,000">$1,000 – $5,000</option>
                            <option value="$5,000 – $10,000">$5,000 – $10,000</option>
                            <option value="$10,000 – $25,000">$10,000 – $25,000</option>
                            <option value="$25,000+">$25,000+</option>
                        </select></div>
                    </div>
                    <div class="form-field"><label>Project Timeline</label><select name="timeline" class="interactive-el">
                        <option value="" disabled selected>Select timeline</option>
                        <option value="ASAP">ASAP / Rush</option>
                        <option value="1-3 months">1 – 3 months</option>
                        <option value="3-6 months">3 – 6 months</option>
                        <option value="6+ months">6+ months</option>
                        <option value="Just exploring">Just exploring</option>
                    </select></div>
                </div>

                <!-- Project Brief -->
                <div class="form-group">
                    <div class="form-group-title">Project Brief</div>
                    <div class="form-field"><label>Project Requirements</label><textarea name="requirements" rows="5" placeholder="Tell us about your goals, audience, and specific needs..." class="interactive-el"></textarea></div>
                    <div class="form-field">
                        <label>Preferred Contact Method</label>
                        <div class="chip-group" id="contact-chips"></div>
                    </div>
                </div>

                <button type="submit" class="btn-primary interactive-el" style="align-self: flex-start;">Submit Enquiry</button>
            </form>
            <div class="form-success" id="form-success">
                <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
                <h4>Enquiry Submitted!</h4>
                <p>Thank you for your interest. Our team will review your requirements and send a detailed proposal within 24 hours.</p>
            </div>
        </div>
    </section>
 <?php include '../footer.php';?>
       <!-- <script src="../assets/js/script.js"></script> -->


    <!-- WhatsApp Floating Button -->
    <!-- Sticky Mobile CTA -->
    <div class="sticky-mobile-cta">
        <a href="#enquiry" class="btn-primary interactive-el">Get a Quote</a>
        <a href="https://wa.me/971564785139" target="_blank" class="btn-outline interactive-el">WhatsApp</a>
    </div>

    <a href="https://wa.me/971564785139" target="_blank" class="whatsapp-float" aria-label="Chat on WhatsApp"><svg viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51l-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.247-.694.247-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg></a>

    <script>
        // Service Data
        const services = {
            branding: {
                title: 'Brand <strong>Identity</strong>',
                subheading: 'Branding & Identity Architecture',
                description: 'Distinctive visual systems, logo architecture, and identity frameworks that command attention across every touchpoint. We craft brands that resonate across cultures and scale across borders.',
                features: [
                    { title: 'Logo Architecture', desc: 'Primary, secondary, and responsive logo variants engineered for every medium.' },
                    { title: 'Brand Guidelines', desc: 'Comprehensive rulebook covering usage, typography, color, and spacing.' },
                    { title: 'Visual System', desc: 'Color palettes, typography scales, iconography, and graphic elements.' },
                    { title: 'Brand Strategy', desc: 'Positioning, messaging framework, and brand voice definition.' },
                    { title: 'Asset Library', desc: 'Business cards, letterheads, social templates, and presentation decks.' },
                    { title: 'Brand Book', desc: 'Complete brand bible for internal teams and external partners.' }
                ],
                tiers: [
                    { name: 'Logo Design', price: '$199+', period: 'one-time', desc: 'Primary logo + variants with source files.', features: ['1 Primary Logo + 2 Variants', 'Source Files (AI, SVG, PNG)', 'Black & White Versions', 'Usage Guide', '3 Revision Rounds'], featured: false },
                    { name: 'Brand Guidelines', price: '$299', period: 'one-time', desc: 'Complete rulebook for consistent branding.', features: ['Logo Usage Rules', 'Color Palette & Codes', 'Typography System', 'Iconography Guide', 'Do\'s & Don\'ts', 'Print-Ready PDF Brand Book'], featured: false },
                    { name: 'Banners', price: '$25', period: 'per banner', desc: 'Web & social banners in all sizes.', features: ['Custom Banner Design', 'All Standard Sizes', 'Web & Social Formats', 'Editable Source File', '2 Revision Rounds'], featured: false },
                    { name: 'Menu Design', price: 'from $10', period: 'per page', desc: 'Basic $10 · Standard $20 · Premium $35 per page.', features: ['Basic / Standard / Premium Tiers', 'Print-Ready Layout', 'Custom Typography', 'Food Photography Layout', '5+ Pages = 20% Discount'], featured: false },
                    { name: 'Flyer Design', price: '$15', period: 'per flyer', desc: 'Single-sided promotional flyer.', features: ['Custom Flyer Artwork', 'Print-Ready Files', 'CMYK Color Setup', '2 Revision Rounds'], featured: false },
                    { name: 'Poster Design', price: '$20', period: 'per poster', desc: 'Eye-catching custom posters.', features: ['Custom Poster Artwork', 'Print-Ready Files', 'Multiple Size Options', '2 Revision Rounds'], featured: false },
                    { name: 'Indoor / Outdoor Branding', price: 'Custom', period: 'quote', desc: 'Pricing depends on size, quantity & requirements.', features: ['Signage & Boards', 'Roll-up Banners', 'Vehicle Wraps', 'Storefront Branding', 'Event Branding', 'Site Survey & Quote'], featured: false },
                    { name: 'Custom Package', price: '20% OFF', period: 'bundle', desc: 'Select any services and build your bundle — get 20% off.', features: ['Mix & Match Any Services', 'Tailored to Your Needs', '20% Discount on Total', 'Dedicated Brand Strategist', 'Priority Delivery', 'Flexible Revisions'], featured: true }
                ],
                pricingNote: 'Each category has its own pricing. Build a custom package with any combination and get 20% off the total.',
                faqs: [
                    { q: 'How long does a branding project take?', a: 'Starter packages take 1–2 weeks. Professional takes 3–4 weeks. Enterprise rebrands typically span 6–8 weeks depending on scope and stakeholder input.' },
                    { q: 'Do you provide the source files?', a: 'Yes, all final deliverables include editable source files (AI, PSD, Figma) along with export-ready formats for print and digital use.' },
                    { q: 'Can you rebrand an existing business?', a: 'Absolutely. We specialize in brand evolution — refreshing existing identities while preserving brand equity and recognition.' }
                ]
            },
            web: {
                title: 'Web <strong>Development</strong>',
                subheading: 'Web Engineering & Architecture',
                description: 'High-performance, scalable web platforms built with precision architecture and cutting-edge frameworks. From corporate sites to complex web applications, we engineer for speed, SEO, and conversion.',
                features: [
                    { title: 'Custom Design', desc: 'Bespoke UI/UX design crafted for your brand and optimized for conversion.' },
                    { title: 'Responsive Build', desc: 'Flawless experience across mobile, tablet, and desktop devices.' },
                    { title: 'CMS Integration', desc: 'Content management systems for easy ongoing updates and maintenance.' },
                    { title: 'Performance Optimization', desc: 'Sub-2s load times, Core Web Vitals compliance, and edge caching.' },
                    { title: 'SEO Architecture', desc: 'Semantic HTML, structured data, and technical SEO built into the foundation.' },
                    { title: 'Analytics & Tracking', desc: 'GA4, conversion tracking, and heat mapping integration.' },
                    { title: '1-Year Domain, Server & Business Email', desc: 'Domain registration, hosting, and professional business email included free for the first year.' },
                    { title: 'Brand Logo Design', desc: 'A custom brand logo included with every website package.' },
                    { title: '1-Month Social Media Management', desc: 'One month of social media management included to launch your presence.' },
                    { title: '1-Month Marketing Demo', desc: 'One month of Google/Meta Ads management free — ad spend budget is provided by the client.' }
                ],
                tiers: [
                    { name: 'Starter', price: '$500', period: 'one-time', desc: 'Professional 3-page website for small businesses.', features: ['3 Custom Pages', 'Responsive Design', 'Basic SEO Setup', 'Contact Form', 'Mobile Optimized', '2 Revision Rounds'] },
                    { name: 'Professional', price: '$2,000', period: 'one-time', desc: 'Full-featured website with CMS and advanced functionality.', features: ['10+ Custom Pages', 'CMS Integration', 'Advanced SEO Architecture', 'Blog/News Module', 'Analytics Integration', 'Performance Optimization', '4 Revision Rounds'] },
                    { name: 'Enterprise', price: '$5,000+', period: 'one-time', desc: 'Custom web application with complex integrations.', features: ['Unlimited Pages', 'Custom Web Application', 'API Integrations', 'User Authentication System', 'Advanced Database Architecture', 'Cloud Infrastructure Setup', 'Dedicated Project Manager'] }
                ],
                faqs: [
                    { q: 'What technologies do you use?', a: 'We use modern frameworks including React, Next.js, Node.js, and cloud platforms like AWS and Vercel. Technology choices are based on your specific requirements.' },
                    { q: 'Do you provide hosting?', a: 'We set up and configure hosting on your preferred platform (AWS, Vercel, Netlify, etc.). We can also manage hosting ongoing as part of a maintenance retainer.' },
                    { q: 'Will I be able to update content myself?', a: 'Yes, all Professional and Enterprise tiers include a CMS that lets you edit text, images, and pages without technical knowledge.' }
                ]
            },
            app: {
                title: 'App <strong>Development</strong>',
                subheading: 'iOS & Android Mobile Engineering',
                description: 'Native and cross-platform mobile applications engineered for performance, scalability, and seamless user experience. From MVP to enterprise-grade apps with complex backend systems.',
                features: [
                    { title: 'Cross-Platform', desc: 'Single codebase for iOS and Android using React Native or Flutter.' },
                    { title: 'Native Performance', desc: 'Smooth 60fps animations and native module integrations.' },
                    { title: 'Backend API', desc: 'Scalable server architecture with REST/GraphQL APIs and real-time features.' },
                    { title: 'Push Notifications', desc: 'Engagement-driven notification system with segmentation and scheduling.' },
                    { title: 'App Store Deployment', desc: 'Full submission and approval management for App Store and Play Store.' },
                    { title: 'Analytics Integration', desc: 'User behavior tracking, funnel analysis, and crash reporting.' }
                ],
                tiers: [
                    { name: 'Starter', price: '$3,000', period: 'one-time', desc: 'Single-platform MVP with core features.', features: ['iOS or Android (Single Platform)', '5 Core Screens', 'Basic Backend API', 'User Authentication', 'Push Notifications', 'App Store Submission'] },
                    { name: 'Professional', price: '$8,000', period: 'one-time', desc: 'Cross-platform app with rich features.', features: ['iOS + Android (Cross-Platform)', '15+ Screens', 'Advanced Backend API', 'Real-time Features', 'Payment Integration', 'Analytics Dashboard', '3 Months Bug Support'] },
                    { name: 'Enterprise', price: '$15,000+', period: 'one-time', desc: 'Full-featured enterprise app with complex systems.', features: ['Everything in Professional', 'Custom Native Modules', 'Advanced Backend Architecture', 'Admin Dashboard', 'Multi-role Authentication', 'Third-party API Ecosystem', '12 Months Maintenance'] }
                ],
                faqs: [
                    { q: 'Native or cross-platform?', a: 'We recommend cross-platform (React Native/Flutter) for most projects — it delivers near-native performance at lower cost. For graphics-heavy apps (games, AR), native may be better.' },
                    { q: 'How long does app development take?', a: 'MVPs take 6–8 weeks. Professional apps take 12–16 weeks. Enterprise apps with complex backends can span 4–6 months.' },
                    { q: 'Do you handle App Store approval?', a: 'Yes, we manage the full submission process for both Apple App Store and Google Play Store, including resolving any review feedback.' }
                ]
            },
            ads: {
                title: 'Google Ads / <strong>Meta Ads</strong>',
                subheading: 'Performance Media & Paid Advertising',
                description: 'Predictive media modeling, hyper-local ad architecture, and multi-platform campaign orchestration. We maximize ROI across Google Ads, Meta (Facebook/Instagram), TikTok, and LinkedIn.',
                features: [
                    { title: 'Campaign Strategy', desc: 'Full-funnel campaign architecture from awareness to conversion.' },
                    { title: 'Audience Targeting', desc: 'Precision audience modeling with lookalikes, retargeting, and intent segmentation.' },
                    { title: 'Creative Production', desc: 'Ad creative across formats — static, carousel, video, and stories.' },
                    { title: 'Bid Optimization', desc: 'Automated bid strategies with manual oversight for maximum efficiency.' },
                    { title: 'Conversion Tracking', desc: 'Pixel setup, UTM tagging, and cross-platform attribution modeling.' },
                    { title: 'Marketing Architect', desc: 'A dedicated strategist who designs, orchestrates, and optimizes your entire media architecture end-to-end.' },
                    { title: 'Monthly Reporting', desc: 'Transparent performance dashboards with actionable insights.' }
                ],
                tiers: [
                    { name: 'Free 1-Month Demo', price: '$0', period: '1 month', desc: 'Try our campaign management free for 30 days — ad spend budget is provided by the client.', features: ['Full Campaign Setup', '1 Platform (Google or Meta)', 'Audience Targeting', '2 Ad Creatives', 'Conversion Tracking', 'Performance Report', 'No Management Fee'], featured: true },
                    { name: 'Starter', price: '$500', period: '/month', desc: 'Management for ad spend up to $2,000/month.', features: ['1 Platform (Google or Meta)', 'Campaign Setup & Management', 'Basic Audience Targeting', '2 Ad Creatives / month', 'Conversion Tracking Setup', 'Monthly Performance Report'], featured: false },
                    { name: 'Professional', price: '$1,200', period: '/month', desc: 'Multi-platform management for growing brands.', features: ['2 Platforms (Google + Meta)', 'Advanced Audience Modeling', '5 Ad Creatives / month', 'A/B Testing Framework', 'Landing Page Optimization', 'Bi-weekly Strategy Calls', 'Detailed Reporting Dashboard'], featured: false },
                    { name: 'Enterprise', price: '$2,500+', period: '/month', desc: 'Full-funnel multi-platform orchestration.', features: ['3+ Platforms (Google, Meta, TikTok)', 'Predictive Budget Allocation', 'Unlimited Ad Creatives', 'Advanced Attribution Modeling', 'Dedicated Account Manager', 'Weekly Strategy Sessions', 'Custom Analytics Dashboard'], featured: false }
                ],
                pricingNote: '🎉 Free 1-month demo available — no management fee. Ad spend budget is provided by the client.',
                faqs: [
                    { q: 'Is ad spend included in the management fee?', a: 'No, ad spend is separate. Our fees cover strategy, setup, management, creative, and reporting. You set the ad budget directly with the platforms.' },
                    { q: 'What is the minimum ad budget you manage?', a: 'We recommend a minimum of $1,000/month in ad spend for meaningful results. Lower budgets limit testing and optimization opportunities.' },
                    { q: 'How soon will I see results?', a: 'Initial data comes within the first week. Meaningful optimization typically requires 2–4 weeks of data. Sustainable performance improvements are visible by month 2–3.' }
                ]
            },
            social: {
                title: 'Social Media <strong>Management</strong>',
                subheading: 'Content, Community & Organic Growth',
                description: 'Full-cycle content strategy, community management, and organic growth engines. We build engaged audiences across Instagram, TikTok, LinkedIn, Twitter, and Facebook.',
                features: [
                    { title: 'Content Strategy', desc: 'Platform-specific content calendars aligned with your brand voice and goals.' },
                    { title: 'Content Creation', desc: 'Graphic design, short-form video, and copywriting for every post.' },
                    { title: 'Community Management', desc: 'Comment replies, DM handling, and engagement within 4 hours.' },
                    { title: 'Growth Strategy', desc: 'Hashtag research, trend jacking, and collaboration outreach.' },
                    { title: 'Influencer Outreach', desc: 'Identification, negotiation, and campaign management with relevant creators.' },
                    { title: 'Monthly Analytics', desc: 'Growth metrics, engagement rates, and content performance reports.' }
                ],
                tiers: [
                    { name: 'Starter', price: '$400', period: '/month', desc: 'Essential social presence on 2 platforms.', features: ['2 Platforms', '8 Posts / month', '4 Story Sets / month', 'Basic Community Management', 'Monthly Content Calendar', 'Monthly Performance Report'] },
                    { name: 'Professional', price: '$800', period: '/month', desc: 'Active growth strategy on 4 platforms.', features: ['4 Platforms', '20 Posts / month', 'Daily Stories', 'Active Community Management', 'Hashtag & Trend Strategy', '4 Short-form Videos / month', 'Bi-weekly Strategy Calls'] },
                    { name: 'Enterprise', price: '$1,500+', period: '/month', desc: 'Full-scale social media domination.', features: ['5+ Platforms', 'Daily Posting', 'Multiple Stories Daily', '24/7 Community Management', 'Influencer Outreach (3/month)', '8 Short-form Videos / month', 'Dedicated Social Media Manager', 'Custom Analytics Dashboard'] }
                ],
                faqs: [
                    { q: 'Do you create the content or do we?', a: 'We handle everything — design, copywriting, and video creation. You approve the content calendar before anything goes live.' },
                    { q: 'Which platforms should we be on?', a: 'It depends on your audience. B2B: LinkedIn + Twitter. B2C: Instagram + TikTok. Local: Facebook + Instagram. We recommend based on your target demographic.' },
                    { q: 'How long until we see growth?', a: 'Organic social growth is gradual. Expect noticeable engagement improvements in month 1–2. Follower growth acceleration typically starts month 2–3 with consistent posting.' }
                ]
            },
            seo: {
                title: 'SEO / <strong>AEO</strong>',
                subheading: 'Search & Answer Engine Optimization',
                description: 'Dominate search rankings and AI-generated responses. We optimize for traditional SEO (Google, Bing) and emerging AEO (ChatGPT, Perplexity, Google AI Overviews) to ensure your brand appears everywhere.',
                features: [
                    { title: 'Technical SEO', desc: 'Site speed, structured data, crawlability, and Core Web Vitals optimization.' },
                    { title: 'Keyword Strategy', desc: 'Intent-driven keyword mapping with competitor gap analysis.' },
                    { title: 'Content Optimization', desc: 'On-page SEO with semantic keywords and entity optimization.' },
                    { title: 'Answer Engine Optimization', desc: 'Structured content for AI search engines and LLM training data.' },
                    { title: 'Local SEO', desc: 'Google Business Profile, local citations, and review management.' },
                    { title: 'Link Building', desc: 'Authority backlink acquisition through content and outreach.' }
                ],
                tiers: [
                    { name: 'Starter', price: '$300', period: '/month', desc: 'Local SEO for small businesses.', features: ['Local Keyword Research', 'Google Business Profile Optimization', '10 Optimized Pages', 'Basic Technical Audit', 'Monthly Rank Tracking', 'Monthly Report'] },
                    { name: 'Professional', price: '$600', period: '/month', desc: 'National SEO with content strategy.', features: ['Comprehensive Keyword Strategy', '25 Optimized Pages', 'Technical SEO Audit & Fixes', '4 Blog Posts / month', '5 Authority Backlinks / month', 'AEO Content Structuring', 'Bi-weekly Strategy Calls'] },
                    { name: 'Enterprise', price: '$1,200+', period: '/month', desc: 'International SEO + AEO dominance.', features: ['Multi-Region Keyword Strategy', 'Unlimited Page Optimization', 'Advanced Technical SEO', '8 Blog Posts / month', '15 Authority Backlinks / month', 'Full AEO Optimization', 'Dedicated SEO Manager', 'Custom Dashboard'] }
                ],
                faqs: [
                    { q: 'What is AEO?', a: 'Answer Engine Optimization (AEO) is optimizing content to appear in AI-generated answers from ChatGPT, Google AI Overviews, Perplexity, and similar tools. It complements traditional SEO.' },
                    { q: 'How long until SEO shows results?', a: 'SEO is a long-term strategy. Initial improvements appear in 4–8 weeks. Meaningful traffic growth typically starts months 3–6. Competitive niches may take 6–12 months.' },
                    { q: 'Do you guarantee #1 rankings?', a: 'No legitimate SEO agency guarantees specific rankings — Google\'s algorithm has hundreds of factors. We guarantee transparent, white-hat strategies that consistently improve rankings and traffic.' }
                ]
            },
            ai: {
                title: 'AI <strong>Solutions</strong>',
                subheading: 'Custom AI, Automation & Intelligence',
                description: 'Custom-trained LLM assistants, intelligent automation pipelines, and data-driven decision engines. We build AI systems that understand your domain and transform how your business operates.',
                features: [
                    { title: 'Custom Chatbots', desc: 'AI assistants trained on your data for customer support and lead qualification.' },
                    { title: 'Automation Pipelines', desc: 'Workflow automation connecting your tools with AI-powered decision making.' },
                    { title: 'Data Intelligence', desc: 'Custom analytics engines that extract insights from your business data.' },
                    { title: 'AI Content Generation', desc: 'Brand-voice-trained content engines for marketing at scale.' },
                    { title: 'Vision & OCR', desc: 'Image recognition and document processing automation.' },
                    { title: 'AI Strategy Consulting', desc: 'Roadmap for AI adoption tailored to your industry and capabilities.' }
                ],
                tiers: [
                    { name: 'Starter', price: '$500', period: 'one-time', desc: 'AI chatbot integration for your website.', features: ['Custom Chatbot Widget', 'Trained on Your FAQs', 'Website Integration', 'Basic Analytics', 'Email Lead Capture', '1 Month Support'] },
                    { name: 'Professional', price: '$2,000', period: 'one-time', desc: 'Custom AI assistant with your data.', features: ['Custom AI Assistant', 'Trained on Your Business Data', 'Multi-channel Integration', 'Workflow Automation (3 processes)', 'Advanced Analytics Dashboard', '3 Months Support'] },
                    { name: 'Enterprise', price: '$5,000+', period: 'one-time', desc: 'Full AI automation ecosystem.', features: ['Everything in Professional', 'Custom Model Fine-tuning', 'Complex Automation Pipelines', 'API Ecosystem Integration', 'AI Content Generation Engine', 'Vision/OCR Capabilities', 'Dedicated AI Engineer', '12 Months Support'] }
                ],
                faqs: [
                    { q: 'What AI models do you use?', a: 'We work with GPT-4, Claude, Gemini, and open-source models (Llama, Mistral). Model choice depends on your use case, budget, and data privacy requirements.' },
                    { q: 'Is my data secure?', a: 'Yes. We use enterprise-grade APIs with data processing agreements. For sensitive data, we can deploy on-premise or private cloud models with zero data retention.' },
                    { q: 'Can AI replace my team?', a: 'Our goal is augmentation, not replacement. AI handles repetitive tasks so your team can focus on high-value work. We design systems that enhance human capabilities.' }
                ]
            },
            packaging: {
                title: 'Packaging <strong>Design</strong>',
                subheading: 'Product Packaging & Visual Systems',
                description: 'Modular packaging blueprints and product design systems that elevate shelf presence and brand consistency. From single products to full retail systems.',
                features: [
                    { title: 'Structural Design', desc: 'Dielines, material specifications, and structural engineering.' },
                    { title: 'Visual Design', desc: 'Label artwork, box design, and retail-ready graphics.' },
                    { title: 'Brand Consistency', desc: 'Cohesive system across product lines and variants.' },
                    { title: 'Print-Ready Files', desc: 'Production-ready files with proper bleed, CMYK, and spot colors.' },
                    { title: '3D Mockups', desc: 'Photorealistic 3D renders for presentations and marketing.' },
                    { title: 'Supplier Coordination', desc: 'Liaison with manufacturers to ensure quality production.' }
                ],
                tiers: [
                    { name: 'Basic', price: '$10', period: 'per product', desc: 'Essential packaging design for single products.', features: ['1 Product Design', 'Label / Box Design', '2 Concept Directions', 'Print-Ready Files', '3D Mockup', '2 Revision Rounds'], featured: false },
                    { name: 'Standard', price: '$20', period: 'per product', desc: 'Enhanced design with premium details.', features: ['1 Product Design', 'Premium Visual Design', 'Multiple Concept Directions', 'Print-Ready Files', '3D Mockup', '4 Revision Rounds'], featured: true },
                    { name: 'Premium', price: '$35', period: 'per product', desc: 'Full premium packaging with structural engineering.', features: ['1 Product Design', 'Premium Finishes (Foil, Emboss)', 'Structural Engineering', 'Full 3D Render Library', 'Print-Ready Files', 'Unlimited Revisions (within scope)'], featured: false }
                ],
                pricingNote: '5+ products receive a 20% discount on the total.',
                faqs: [
                    { q: 'Do you handle production?', a: 'We design and prepare print-ready files. We can recommend trusted manufacturers and coordinate production on your behalf as an add-on service.' },
                    { q: 'Can you work with existing brand guidelines?', a: 'Absolutely. We adapt to your existing brand system, or we can create a complementary packaging identity that evolves your brand.' },
                    { q: 'What materials can you design for?', a: 'We design for all packaging types — boxes, labels, pouches, bottles, cans, shrink wrap, and more. Material recommendations are part of the process.' }
                ]
            },
            video: {
                title: 'Video <strong>Editing</strong>',
                subheading: 'Reels, Motion Graphics & 3D Product Video',
                description: 'Scroll-stopping short reels, polished content creation, precise blog editing, cinematic 3D product videos, and dynamic motion graphics — engineered to convert attention into action.',
                features: [
                    { title: 'Short Reels', desc: 'Punchy vertical reels for Instagram, TikTok, and YouTube Shorts.' },
                    { title: 'Content Creation', desc: 'Full-cycle video content from concept to final cut.' },
                    { title: 'Blog Editing', desc: 'Polished edits for vlogs, tutorials, and long-form content.' },
                    { title: '3D Product Videos', desc: 'Cinematic 3D renders showcasing products from every angle.' },
                    { title: 'Motion Graphics', desc: 'Dynamic animated graphics, lower thirds, and brand intros.' },
                    { title: 'Sound Design', desc: 'Music selection, sound effects, and audio mastering.' }
                ],
                tiers: [
                    { name: 'Starter', price: '$300', period: 'per video', desc: 'Single short-form reel or edit.', features: ['1 Short Reel (up to 60s)', 'Basic Motion Graphics', 'Music & Sound Effects', '1 Revision Round', 'Social-Ready Export'], featured: false },
                    { name: 'Professional', price: '$800', period: 'per video', desc: 'Premium edited video with motion graphics.', features: ['1 Video (up to 3 min)', 'Advanced Motion Graphics', '3D Product Showcase', 'Color Grading', 'Sound Design', '3 Revision Rounds'], featured: true },
                    { name: 'Enterprise', price: '$1,500+', period: 'per video', desc: 'Full cinematic production package.', features: ['Everything in Professional', 'Cinematic 3D Product Video', 'Custom Animation', 'Multi-Format Delivery', 'Dedicated Editor', 'Unlimited Revisions (within scope)'], featured: false }
                ],
                faqs: [
                    { q: 'What formats do you deliver?', a: 'We deliver in all formats — vertical (9:16) for reels, horizontal (16:9) for YouTube, and square (1:1) for feeds. All in 4K-ready resolution.' },
                    { q: 'Do you provide raw footage shooting?', a: 'We handle editing and post-production. For shooting, we can coordinate with local videographers or work with your existing footage.' },
                    { q: 'How fast is turnaround?', a: 'Short reels deliver in 2–3 days. Longer videos take 5–7 days. 3D product videos take 1–2 weeks depending on complexity.' }
                ]
            },
            gameui: {
                title: 'Game <strong>UI/UX</strong>',
                subheading: 'Interactive Game Interface Design',
                description: 'Immersive, intuitive game interfaces and user experiences that keep players engaged. From HUD design to full UX flow architecture for mobile, console, and PC games.',
                features: [
                    { title: 'HUD Design', desc: 'Clean, readable heads-up displays that enhance, not obstruct, gameplay.' },
                    { title: 'UX Flow Architecture', desc: 'Player journey maps, menu flows, and onboarding sequences.' },
                    { title: 'Interactive Prototypes', desc: 'Clickable prototypes to test feel before full production.' },
                    { title: 'Icon & Button Systems', desc: 'Cohesive iconography and interactive element libraries.' },
                    { title: 'Onboarding Flows', desc: 'First-time-user experiences that teach without tutorials.' },
                    { title: 'Playtesting Reports', desc: 'UX testing with actionable recommendations.' }
                ],
                tiers: [
                    { name: 'Starter', price: '$500', period: 'one-time', desc: 'Essential UI for indie or mobile games.', features: ['HUD Design', 'Main Menu Screen', 'Icon Set (15 icons)', '2 Screen Flows', 'Clickable Prototype', '2 Revision Rounds'], featured: false },
                    { name: 'Professional', price: '$1,500', period: 'one-time', desc: 'Complete UI system for commercial games.', features: ['Full HUD System', 'Complete Menu Architecture', 'Icon Library (40+ icons)', 'Onboarding Flow', 'Interactive Prototype', '4 Revision Rounds'], featured: true },
                    { name: 'Enterprise', price: '$3,500+', period: 'one-time', desc: 'Full AAA-grade UX for complex games.', features: ['Everything in Professional', 'Multi-Platform Adaptation', 'Full UX Flow Architecture', 'Playtesting Reports', 'Animation & Micro-interactions', 'Dedicated UX Lead', 'Unlimited Revisions (within scope)'], featured: false }
                ],
                faqs: [
                    { q: 'Which platforms do you design for?', a: 'Mobile, PC, console, and web. We adapt the UI to each platform\'s constraints and interaction patterns.' },
                    { q: 'Do you work with game engines?', a: 'Yes. We deliver assets ready for Unity, Unreal, and Godot, with proper slicing and naming conventions.' },
                    { q: 'Can you redesign an existing game UI?', a: 'Absolutely. We audit your current UI, identify friction points, and redesign for better player retention and clarity.' }
                ]
            },
            revenue: {
                title: 'Revenue <strong>Accelerator</strong>',
                subheading: 'Conversion & Monetization Engineering',
                description: 'Turn the traffic you already have into revenue. We audit your funnel, rebuild the pages that leak money, integrate ad-tech and affiliate monetization where it fits, and run structured conversion-rate experiments so every visitor is worth more.',
                features: [
                    { title: 'Conversion Audit', desc: 'Full-funnel teardown: analytics review, heatmap analysis, and drop-off diagnosis.' },
                    { title: 'Landing Page Engineering', desc: 'Conversion-optimized landing pages built and tested against your current pages.' },
                    { title: 'A/B Testing Program', desc: 'Structured experiments on headlines, offers, forms, and page layouts.' },
                    { title: 'Ad-Tech Integration', desc: 'Display, native, and affiliate monetization placed without wrecking UX or Core Web Vitals.' },
                    { title: 'Checkout & Form Optimization', desc: 'Fewer fields, smarter flows, and trust signals where hesitation happens.' },
                    { title: 'Revenue Reporting', desc: 'A monthly dashboard tying every change to revenue-per-visitor, not vanity metrics.' }
                ],
                tiers: [
                    { name: 'Conversion Audit', price: '$299', period: 'one-time', desc: 'Find out exactly where your funnel leaks.', features: ['Full Analytics Review', 'Funnel Drop-off Map', 'Top 10 Prioritized Fixes', 'Competitor Conversion Benchmark', 'Recorded Walkthrough Video'], featured: false },
                    { name: 'Accelerator', price: '$799', period: 'per month', desc: 'Ongoing CRO with monthly experiments.', features: ['Everything in Audit', '2 Landing Pages Built & Tested', 'Monthly A/B Test Cycle', 'Form & Checkout Optimization', 'Monthly Revenue Report', 'Priority Support'], featured: true },
                    { name: 'Monetization Build', price: 'Custom', period: 'quote', desc: 'Ad-tech and affiliate revenue for content sites.', features: ['Ad Network Setup & Placement', 'Affiliate Program Integration', 'Layout Optimization for RPM', 'Core Web Vitals Protection', 'Revenue Dashboard', 'Ongoing Yield Tuning'], featured: false }
                ],
                pricingNote: 'Start with the one-time audit — if you move to the monthly Accelerator within 30 days, the audit fee is credited in full.',
                faqs: [
                    { q: 'How fast will I see results?', a: 'The audit ships in 5–7 business days. Most clients see their first measurable conversion lift within the first 30-day experiment cycle; monetization revenue typically starts in month one.' },
                    { q: 'Do I need a lot of traffic for this to work?', a: 'For A/B testing you need enough visitors to reach significance — roughly 5,000+ monthly sessions is a good baseline. Below that, we focus on audit-driven fixes and best-practice rebuilds instead of split tests.' },
                    { q: 'Will ads slow down or ruin my site?', a: 'No. We only place monetization that passes Core Web Vitals budgets, and we measure UX impact on every placement. Revenue that costs you rankings is not revenue.' }
                ]
            }
        };

        const serviceProcess = {
            branding: { steps: [
                { title: 'Brand Discovery', desc: 'Audit existing identity, market position, and audience perception.', tag: 'Week 1', icon: 'discovery' },
                { title: 'Identity Design', desc: 'Logo architecture, visual system, and brand voice development.', tag: 'Week 2–3', icon: 'strategy' },
                { title: 'System Build', desc: 'Complete asset library, guidelines, and brand book production.', tag: 'Week 3–4', icon: 'build' },
                { title: 'Brand Launch', desc: 'Internal rollout, training, and external brand activation.', tag: 'Week 4+', icon: 'launch' }
            ]},
            web: { steps: [
                { title: 'Discovery & Audit', desc: 'Technical audit, competitor analysis, and requirements mapping.', tag: 'Week 1', icon: 'discovery' },
                { title: 'UX & Architecture', desc: 'Wireframes, design system, and technical blueprint.', tag: 'Week 2–3', icon: 'strategy' },
                { title: 'Engineering', desc: 'Frontend, backend, CMS, and performance optimization.', tag: 'Week 3–6', icon: 'build' },
                { title: 'Launch & Optimize', desc: 'Deployment, SEO activation, and ongoing optimization.', tag: 'Week 6+', icon: 'launch' }
            ]},
            app: { steps: [
                { title: 'Strategy & Scoping', desc: 'Feature definition, platform strategy, and technical spec.', tag: 'Week 1–2', icon: 'discovery' },
                { title: 'UX & Prototyping', desc: 'Interactive prototypes, design system, and user flows.', tag: 'Week 2–4', icon: 'strategy' },
                { title: 'Development', desc: 'Native build, API integration, and QA testing.', tag: 'Week 4–10', icon: 'build' },
                { title: 'Store Launch', desc: 'Submission, approval management, and post-launch updates.', tag: 'Week 10+', icon: 'launch' }
            ]},
            ads: { steps: [
                { title: 'Audit & Strategy', desc: 'Account audit, competitor research, and funnel mapping.', tag: 'Week 1', icon: 'discovery' },
                { title: 'Campaign Architecture', desc: 'Audience modeling, creative briefs, and tracking setup.', tag: 'Week 1–2', icon: 'strategy' },
                { title: 'Launch & Optimize', desc: 'Campaign deployment, A/B testing, and bid optimization.', tag: 'Ongoing', icon: 'build' },
                { title: 'Scale & Report', desc: 'Budget scaling, creative refresh, and performance reporting.', tag: 'Monthly', icon: 'launch' }
            ]},
            social: { steps: [
                { title: 'Audit & Strategy', desc: 'Platform audit, audience research, and content strategy.', tag: 'Week 1', icon: 'discovery' },
                { title: 'Content Engine', desc: 'Content calendar, templates, and production pipeline.', tag: 'Week 2', icon: 'strategy' },
                { title: 'Active Management', desc: 'Daily posting, community engagement, and trend response.', tag: 'Ongoing', icon: 'build' },
                { title: 'Analyze & Scale', desc: 'Performance analysis, strategy refinement, and growth scaling.', tag: 'Monthly', icon: 'launch' }
            ]},
            seo: { steps: [
                { title: 'Technical Audit', desc: 'Crawl analysis, Core Web Vitals, and site architecture review.', tag: 'Week 1–2', icon: 'discovery' },
                { title: 'Keyword & Content', desc: 'Keyword mapping, content strategy, and on-page optimization.', tag: 'Week 2–4', icon: 'strategy' },
                { title: 'Authority Building', desc: 'Technical fixes, schema markup, and link architecture.', tag: 'Month 1–3', icon: 'build' },
                { title: 'Track & Scale', desc: 'Ranking monitoring, AEO optimization, and ongoing refinement.', tag: 'Ongoing', icon: 'launch' }
            ]},
            ai: { steps: [
                { title: 'Use-Case Discovery', desc: 'Identify automation opportunities and data sources.', tag: 'Week 1', icon: 'discovery' },
                { title: 'Model & Design', desc: 'Architecture design, model selection, and training pipeline.', tag: 'Week 2–4', icon: 'strategy' },
                { title: 'Build & Train', desc: 'Development, training, and integration with your systems.', tag: 'Week 4–8', icon: 'build' },
                { title: 'Deploy & Optimize', desc: 'Production deployment, monitoring, and continuous tuning.', tag: 'Week 8+', icon: 'launch' }
            ]},
            packaging: { steps: [
                { title: 'Concept & Research', desc: 'Market research, material study, and structural concepts.', tag: 'Week 1–2', icon: 'discovery' },
                { title: 'Structural Design', desc: 'Dielines, 3D mockups, and structural engineering.', tag: 'Week 2–3', icon: 'strategy' },
                { title: 'Visual Design', desc: 'Artwork, typography, and print-ready file production.', tag: 'Week 3–4', icon: 'build' },
                { title: 'Production Support', desc: 'Print vendor coordination and quality oversight.', tag: 'Week 4+', icon: 'launch' }
            ]},
            video: { steps: [
                { title: 'Brief & Concept', desc: 'Understand goals, audience, and creative direction.', tag: 'Day 1', icon: 'discovery' },
                { title: 'Storyboard', desc: 'Scene planning, script, and visual storyboard.', tag: 'Day 2–3', icon: 'strategy' },
                { title: 'Edit & Animate', desc: 'Cut, motion graphics, 3D, and sound design.', tag: 'Day 3–6', icon: 'build' },
                { title: 'Review & Deliver', desc: 'Revisions, final export, and multi-format delivery.', tag: 'Day 6–7', icon: 'launch' }
            ]},
            gameui: { steps: [
                { title: 'Research & Wireframes', desc: 'Game analysis, player flow, and screen wireframes.', tag: 'Week 1', icon: 'discovery' },
                { title: 'UI Design System', desc: 'Visual style, icons, and component library.', tag: 'Week 2', icon: 'strategy' },
                { title: 'Prototype & Build', desc: 'Interactive prototype and engine-ready assets.', tag: 'Week 3–4', icon: 'build' },
                { title: 'Test & Deliver', desc: 'Playtesting, refinements, and final handoff.', tag: 'Week 4+', icon: 'launch' }
            ]},
            revenue: { steps: [
                { title: 'Funnel Audit', desc: 'Analytics deep-dive, heatmaps, and leak diagnosis across the funnel.', tag: 'Week 1', icon: 'discovery' },
                { title: 'Experiment Plan', desc: 'Prioritized test roadmap and landing page blueprints.', tag: 'Week 2', icon: 'strategy' },
                { title: 'Build & Test', desc: 'Page builds, A/B tests, and monetization integration.', tag: 'Ongoing', icon: 'build' },
                { title: 'Measure & Scale', desc: 'Revenue-per-visitor reporting and winning-variant rollout.', tag: 'Monthly', icon: 'launch' }
            ]}
        };

        // Get service ID from URL
        const params = new URLSearchParams(window.location.search);
        const __sm = window.location.pathname.match(/^\/services\/([a-z0-9-]+)/);
        const serviceId = (__sm && __sm[1]) || params.get('id') || 'branding';
        const service = services[serviceId] || services.branding;
        const categoryParam = params.get('category');
        const enquireParam = params.get('enquire') === '1';
        if (categoryParam) {
            const reqField = document.querySelector('textarea[name="requirements"]');
            if (reqField) reqField.value = 'I am interested in ' + categoryParam + ' (' + service.subheading + '). ';
        }

        // Show portfolio link filtered to this service
        const portfolioLink = document.getElementById('portfolio-link');
        if (portfolioLink) portfolioLink.href = '/portfolio?service=' + serviceId;

        // Populate content
        document.getElementById('service-subheading').innerText = service.subheading;
        document.getElementById('service-title').innerHTML = service.title;
        document.getElementById('service-description').innerText = service.description;
        document.title = `Graphinxt | ${service.subheading}`;

        // SEO: per-service meta description, canonical, breadcrumb, and structured data
        (function() {
            const plainTitle = service.title.replace(/<[^>]*>/g, '');

            let metaDesc = document.querySelector('meta[name="description"]');
            if (!metaDesc) { metaDesc = document.createElement('meta'); metaDesc.setAttribute('name', 'description'); document.head.appendChild(metaDesc); }
            metaDesc.setAttribute('content', service.description.slice(0, 160));

            let canonical = document.querySelector('link[rel="canonical"]');
            if (!canonical) { canonical = document.createElement('link'); canonical.setAttribute('rel', 'canonical'); document.head.appendChild(canonical); }
            canonical.setAttribute('href', `https://graphinxt.com/services/${serviceId}`);

            const ogTags = {
                'og:type': 'website', 'og:title': `${plainTitle} | Graphinxt`, 'og:description': service.description,
                'og:url': `https://graphinxt.com/services/${serviceId}`,
                'og:image': 'https://graphinxt.com/assets/og-cover.jpg'
            };
            Object.entries(ogTags).forEach(([prop, content]) => {
                let tag = document.querySelector(`meta[property="${prop}"]`);
                if (!tag) { tag = document.createElement('meta'); tag.setAttribute('property', prop); document.head.appendChild(tag); }
                tag.setAttribute('content', content);
            });

            const ldBlocks = [
                {
                    '@context': 'https://schema.org', '@type': 'Service',
                    name: service.subheading, description: service.description,
                    url: `https://graphinxt.com/services/${serviceId}`,
                    provider: { '@type': 'ProfessionalService', name: 'Graphinxt', url: 'https://graphinxt.com/' },
                    areaServed: ['United States', 'United Kingdom', 'Canada', 'Australia', 'New Zealand']
                },
                {
                    '@context': 'https://schema.org', '@type': 'BreadcrumbList',
                    itemListElement: [
                        { '@type': 'ListItem', position: 1, name: 'Home', item: 'https://graphinxt.com/' },
                        { '@type': 'ListItem', position: 2, name: 'Services', item: 'https://graphinxt.com/#services' },
                        { '@type': 'ListItem', position: 3, name: service.subheading, item: `https://graphinxt.com/services/${serviceId}` }
                    ]
                }
            ];
            if (service.faqs && service.faqs.length) {
                ldBlocks.push({
                    '@context': 'https://schema.org', '@type': 'FAQPage',
                    mainEntity: service.faqs.map(f => ({ '@type': 'Question', name: f.q, acceptedAnswer: { '@type': 'Answer', text: f.a } }))
                });
            }
            ldBlocks.forEach(block => {
                const s = document.createElement('script');
                s.type = 'application/ld+json';
                s.text = JSON.stringify(block);
                document.head.appendChild(s);
            });

            // Breadcrumb UI
            const bc = document.getElementById('breadcrumb-nav');
            if (bc) {
                bc.innerHTML = `<a href="/">Home</a><span class="bc-sep">/</span><a href="/#services">Services</a><span class="bc-sep">/</span><span class="bc-current">${plainTitle}</span>`;
            }
        })();

        // Populate features
        document.getElementById('features-list').innerHTML = service.features.map(f => `
            <div class="feature-item fade-in interactive-card">
                <div class="feature-check"><svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg></div>
                <div><h4>${f.title}</h4><p>${f.desc}</p></div>
            </div>
        `).join('');

        // Populate pricing
        document.getElementById('pricing-grid').innerHTML = service.tiers.map((t, i) => {
            const isFeatured = t.featured !== undefined ? t.featured : (i === 1);
            const portSrc = '/portfolio?service=' + serviceId + '&embed=1';
            return `
            <div class="pricing-card fade-in interactive-card ${isFeatured ? 'featured' : ''}" data-tier="${t.name}">
                <div class="pricing-tier-name">${t.name}</div>
                <div class="pricing-amount"><strong>${t.price}</strong></div>
                <div class="pricing-period">${t.period}</div>
                <p class="pricing-desc">${t.desc}</p>
                <ul class="pricing-features">
                    ${t.features.map(f => `<li>${f}</li>`).join('')}
                </ul>
                <div class="pricing-btn"><a href="#enquiry" class="${isFeatured ? 'btn-primary' : 'btn-outline'} interactive-el enquire-tier" data-tier="${t.name}" style="font-size: 0.75rem; padding: 0.7rem 1.5rem;">Get Started</a></div>
                <button type="button" class="pricing-expand-toggle interactive-el">View Recent Work &amp; Details <span class="chev">▾</span></button>
                <div class="pricing-expand">
                    <div class="pricing-expand-inner">
                        <h4 class="pricing-expand-title">Recent <strong>${t.name}</strong> Work</h4>
                        <iframe data-src="${portSrc}" class="pricing-portfolio-frame" loading="lazy"></iframe>
                        <div class="pricing-expand-actions">
                            <button type="button" class="btn-primary interactive-el enquire-tier" data-tier="${t.name}" style="font-size: 0.75rem; padding: 0.7rem 1.5rem;">Enquire about ${t.name}</button>
                            <a href="https://wa.me/971564785139?text=${encodeURIComponent('Hi, I am interested in ' + t.name + ' (' + service.subheading + ').')}" target="_blank" class="wa-btn interactive-el">Chat on WhatsApp</a>
                        </div>
                    </div>
                </div>
            </div>`;
        }).join('');
        document.querySelectorAll('.pricing-expand-toggle').forEach(btn => {
            btn.addEventListener('click', () => {
                const card = btn.closest('.pricing-card');
                card.classList.toggle('expanded');
                if (card.classList.contains('expanded')) {
                    const frame = card.querySelector('.pricing-portfolio-frame');
                    if (frame && !frame.src) frame.src = frame.dataset.src;
                }
            });
        });
        document.querySelectorAll('.enquire-tier').forEach(b => b.addEventListener('click', (e) => {
            e.preventDefault();
            const reqField = document.querySelector('textarea[name="requirements"]');
            if (reqField) reqField.value = 'I am interested in ' + b.dataset.tier + ' (' + service.subheading + '). ';
            openEnquiry();
        }));
        if (service.pricingNote) {
            const noteEl = document.createElement('p');
            noteEl.style.cssText = 'text-align: center; color: var(--brand-gold); font-size: 0.85rem; margin-top: 2rem; font-weight: 500; max-width: 600px; margin-left: auto; margin-right: auto;';
            noteEl.innerText = service.pricingNote;
            document.getElementById('pricing').appendChild(noteEl);
        }

        // Estimator embeds (iframed from homepage estimators)
        const devEstimatorSection = document.getElementById('dev-estimator');
        if (serviceId === 'web' && devEstimatorSection) devEstimatorSection.style.display = 'block';
        const mktArchitectSection = document.getElementById('mkt-architect-embed');
        if (serviceId === 'ads' && mktArchitectSection) mktArchitectSection.style.display = 'block';
        const seoAuditSection = document.getElementById('seo-audit-embed');
        if (serviceId === 'seo' && seoAuditSection) seoAuditSection.style.display = 'block';
        const startupKitPromo = document.getElementById('startup-kit-promo');
        if (serviceId === 'branding' && startupKitPromo) startupKitPromo.style.display = 'block';
        // ===================== ADVANCED SEO/AEO AUDIT ENGINE =====================
        // Uses Google's real PageSpeed Insights (Lighthouse) API — genuine Core Web Vitals
        // and technical SEO/accessibility/best-practices data, not domain-name heuristics.
        // Works without a key at low volume; add PAGESPEED_API_KEY below for reliable quota
        // (free -- console.cloud.google.com then APIs then PageSpeed Insights API then Credentials).
        const PAGESPEED_API_KEY = '';
        const EMAILJS_SERVICE_ID = 'service_czz7trf';
        const EMAILJS_TEMPLATE_ID = 'template_iu83rj7';
        const EMAILJS_PUBLIC_KEY = 'xnhB_ASPLwSQ4SKAd';
        if (window.emailjs && EMAILJS_PUBLIC_KEY) { emailjs.init({ publicKey: EMAILJS_PUBLIC_KEY }); }

        let lastAuditResult = null;

        function cleanAuditDomain(raw) {
            let d = raw.trim().toLowerCase();
            if (!/^https?:\/\//.test(d)) d = 'https://' + d;
            return d;
        }

        function cwvTier(metric, value) {
            const thresholds = { lcp: [2500, 4000], cls: [0.1, 0.25], inp: [200, 500], tbt: [200, 600] };
            const t = thresholds[metric];
            if (value <= t[0]) return 'good';
            if (value <= t[1]) return 'mid';
            return 'poor';
        }
        function scoreTier(score) { return score >= 90 ? 'good' : score >= 50 ? 'mid' : 'poor'; }
        async function fetchLighthouseData(targetUrl) {
            const endpoint = 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed';
            const params = new URLSearchParams({ url: targetUrl, strategy: 'mobile' });
            ['performance', 'seo', 'accessibility', 'best-practices'].forEach(c => params.append('category', c));
            if (PAGESPEED_API_KEY) params.set('key', PAGESPEED_API_KEY);
            const res = await fetch(endpoint + '?' + params.toString());
            if (!res.ok) throw new Error('PageSpeed API error: ' + res.status);
            return res.json();
        }

        function parseLighthouseResult(data, targetUrl) {
            const lr = data.lighthouseResult;
            const audits = lr.audits || {};
            const cats = lr.categories || {};

            const scores = {
                performance: Math.round((cats.performance && cats.performance.score || 0) * 100),
                seo: Math.round((cats.seo && cats.seo.score || 0) * 100),
                accessibility: Math.round((cats.accessibility && cats.accessibility.score || 0) * 100),
                bestPractices: Math.round((cats['best-practices'] && cats['best-practices'].score || 0) * 100)
            };

            const field = data.loadingExperience && data.loadingExperience.metrics;
            let lcpMs, clsScore, inpMs;
            if (field && field.LARGEST_CONTENTFUL_PAINT_MS) {
                lcpMs = field.LARGEST_CONTENTFUL_PAINT_MS.percentile;
                clsScore = ((field.CUMULATIVE_LAYOUT_SHIFT_SCORE && field.CUMULATIVE_LAYOUT_SHIFT_SCORE.percentile) || 0) / 100;
                inpMs = field.INTERACTION_TO_NEXT_PAINT ? field.INTERACTION_TO_NEXT_PAINT.percentile : null;
            } else {
                lcpMs = audits['largest-contentful-paint'] && audits['largest-contentful-paint'].numericValue;
                clsScore = audits['cumulative-layout-shift'] && audits['cumulative-layout-shift'].numericValue;
                inpMs = null;
            }
            const tbtMs = audits['total-blocking-time'] && audits['total-blocking-time'].numericValue;

            const aeoChecks = {
                metaDescription: audits['meta-description'] && audits['meta-description'].score === 1,
                title: audits['document-title'] && audits['document-title'].score === 1,
                canonical: audits['canonical'] && audits['canonical'].score === 1,
                robotsTxt: (audits['robots-txt'] && audits['robots-txt'].score === 1) || (audits['robots-txt'] && audits['robots-txt'].scoreDisplayMode === 'notApplicable'),
                crawlable: audits['is-crawlable'] && audits['is-crawlable'].score === 1,
                httpStatus: audits['http-status-code'] && audits['http-status-code'].score === 1
            };
            const aeoPassCount = Object.values(aeoChecks).filter(Boolean).length;
            const aeoTotal = Object.keys(aeoChecks).length;

            const suggestions = Object.values(audits)
                .filter(function(a) { return a && a.score !== null && a.score !== undefined && a.score < 0.9 && a.title && a.scoreDisplayMode !== 'notApplicable' && a.scoreDisplayMode !== 'informative'; })
                .sort(function(a, b) { return a.score - b.score; })
                .slice(0, 7)
                .map(function(a) { return a.title; });

            return { targetUrl: targetUrl, scores: scores, lcpMs: lcpMs, clsScore: clsScore, inpMs: inpMs, tbtMs: tbtMs, aeoChecks: aeoChecks, aeoPassCount: aeoPassCount, aeoTotal: aeoTotal, suggestions: suggestions, isReal: true };
        }
        function fallbackAuditHeuristic(targetUrl) {
            function hashString(str) { let h = 5381; for (let i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) >>> 0; return h; }
            function seeded(seed, min, max, salt) { return min + (hashString(seed + '::' + salt) % (max - min + 1)); }
            const domain = targetUrl.replace(/^https?:\/\//, '').replace(/^www\./, '').split('/')[0];
            const scores = {
                performance: seeded(domain, 48, 82, 'perf'),
                seo: seeded(domain, 55, 85, 'seo'),
                accessibility: seeded(domain, 50, 85, 'a11y'),
                bestPractices: seeded(domain, 55, 88, 'bp')
            };
            return {
                targetUrl: targetUrl, scores: scores,
                lcpMs: seeded(domain, 1800, 4200, 'lcp'), clsScore: seeded(domain, 2, 22, 'cls') / 100,
                inpMs: null, tbtMs: seeded(domain, 100, 600, 'tbt'),
                aeoChecks: {}, aeoPassCount: seeded(domain, 2, 6, 'aeopc'), aeoTotal: 6,
                suggestions: [
                    'Add or improve meta descriptions on key pages',
                    'Ensure a clear, crawlable internal link structure',
                    'Compress and lazy-load below-the-fold images',
                    'Add Organization, Service, and FAQPage structured data',
                    'Reduce render-blocking CSS/JS on the homepage'
                ],
                isReal: false
            };
        }

        function renderAeoChecklist(target) {
            const results = document.getElementById('audit-results');
            if (!results) return;
            let box = document.getElementById('aeo-checklist');
            if (!box) { box = document.createElement('div'); box.id = 'aeo-checklist'; box.style.marginTop = '2rem'; results.appendChild(box); }
            const items = [
                ['Organization schema (JSON-LD)', 'Tells Google and AI engines who you are \u2014 name, logo, socials.'],
                ['FAQPage schema on service pages', 'Directly feeds AI answers and featured snippets.'],
                ['Question-format H2 headings', 'AI engines quote pages that ask and answer the exact question.'],
                ['Answer-first paragraphs', 'Put the direct answer in the first sentence under each question.'],
                ['Entity clarity', 'Same business name, address, and phone everywhere (site + Google Business Profile).'],
                ['Speakable, quotable sentences', 'Short standalone sentences get lifted into AI overviews.'],
                ['Author/expertise signals', 'About page, credentials, and real names build E-E-A-T trust.'],
                ['Fresh dates on key content', 'AI engines strongly prefer visibly updated content.']
            ];
            box.innerHTML = '<div style="font-size:0.8rem; color:var(--brand-gold); font-weight:600; margin-bottom:0.8rem;">Advanced: AEO Readiness Checklist for ' + String(target).replace(/[<>"]/g,'') + '</div>' +
                items.map(it => '<div style="border-bottom:1px solid var(--border-light); padding:0.7rem 0;"><strong style="font-size:0.85rem;">\u2610 ' + it[0] + '</strong><div style="font-size:0.78rem; color:var(--text-muted); font-weight:300; margin-top:2px;">' + it[1] + '</div></div>').join('') +
                '<div style="font-size:0.68rem; color:var(--text-muted); opacity:0.75; margin-top:0.8rem;">Work through these top-to-bottom \u2014 they are the checks our paid AEO service implements for you. More free tools: <a href="/tools" style="color:var(--brand-gold);">graphinxt.com/tools</a></div>';
        }
        window.runFullAudit = async function() {
            const input = document.getElementById('audit-url-input');
            const btn = document.getElementById('audit-run-btn');
            const loading = document.getElementById('audit-loading');
            const loadingText = document.getElementById('audit-loading-text');
            const results = document.getElementById('audit-results');
            const raw = input.value.trim();
            if (!raw) { input.focus(); return; }
            const targetUrl = cleanAuditDomain(raw);

            btn.disabled = true; btn.innerText = 'Auditing...';
            results.classList.remove('show');
            loading.classList.add('show');
            loadingText.innerText = 'Requesting a live Lighthouse audit from Google...';

            let parsed;
            try {
                const data = await fetchLighthouseData(targetUrl);
                parsed = parseLighthouseResult(data, targetUrl);
            } catch (err) {
                loadingText.innerText = 'Live audit unavailable for this URL -- showing an estimated baseline instead...';
                await new Promise(function(r) { setTimeout(r, 900); });
                parsed = fallbackAuditHeuristic(targetUrl);
            }

            lastAuditResult = parsed;
            renderAuditResults(parsed);
            loading.classList.remove('show');
            renderAeoChecklist(targetUrl); results.classList.add('show');
            btn.disabled = false; btn.innerText = 'Run Again →';
            results.scrollIntoView({ behavior: 'smooth', block: 'start' });
            if (window.trackConversion) window.trackConversion('tool_engagement', { tool: 'seo_audit', real: parsed.isReal, url: targetUrl });
        };
        function renderAuditResults(r) {
            const tag = document.getElementById('audit-source-tag');
            tag.className = 'audit-source-tag ' + (r.isReal ? 'real' : 'fallback');
            tag.innerText = r.isReal ? '✓ Live Google Lighthouse Data' : '≈ Estimated (live audit unavailable for this URL)';

            const scoreGrid = document.getElementById('audit-score-grid');
            const labels = { performance: 'Performance', seo: 'SEO', accessibility: 'Accessibility', bestPractices: 'Best Practices' };
            let scoreHtml = '';
            Object.keys(labels).forEach(function(key) {
                scoreHtml += '<div class="audit-score-card"><div class="audit-score-num ' + scoreTier(r.scores[key]) + '">' + r.scores[key] + '</div><div class="audit-score-label">' + labels[key] + '</div></div>';
            });
            scoreGrid.innerHTML = scoreHtml;

            const cwvRow = document.getElementById('audit-cwv-row');
            const lcpSec = r.lcpMs ? (r.lcpMs / 1000).toFixed(1) + 's' : '—';
            const clsVal = (r.clsScore !== undefined && r.clsScore !== null) ? r.clsScore.toFixed(2) : '—';
            const tierLabel = function(t) { return t === 'good' ? 'Good' : t === 'mid' ? 'Needs Work' : 'Poor'; };
            const lcpTier = cwvTier('lcp', r.lcpMs || 0);
            const clsTier = cwvTier('cls', r.clsScore || 0);
            const useInp = !!r.inpMs;
            const inpLabel = useInp ? 'INP' : 'Total Blocking Time';
            const inpValue = useInp ? (r.inpMs + 'ms') : ((r.tbtMs || 0) + 'ms');
            const inpTier = useInp ? cwvTier('inp', r.inpMs) : cwvTier('tbt', r.tbtMs || 0);
            cwvRow.innerHTML =
                '<div class="audit-cwv-card"><div class="audit-cwv-head"><span>LCP</span><span class="audit-cwv-tag ' + lcpTier + '">' + tierLabel(lcpTier) + '</span></div><div class="audit-cwv-value">' + lcpSec + '</div></div>' +
                '<div class="audit-cwv-card"><div class="audit-cwv-head"><span>CLS</span><span class="audit-cwv-tag ' + clsTier + '">' + tierLabel(clsTier) + '</span></div><div class="audit-cwv-value">' + clsVal + '</div></div>' +
                '<div class="audit-cwv-card"><div class="audit-cwv-head"><span>' + inpLabel + '</span><span class="audit-cwv-tag ' + inpTier + '">' + tierLabel(inpTier) + '</span></div><div class="audit-cwv-value">' + inpValue + '</div></div>';

            const aeoSummary = document.getElementById('audit-aeo-summary');
            aeoSummary.innerText = r.isReal
                ? (r.aeoPassCount + ' of ' + r.aeoTotal + ' core AEO signals detected (meta description, title, canonical URL, crawlability, robots.txt, valid HTTP status). AI answer engines and Google both rely on these fundamentals to understand and cite a page.')
                : ('Estimated ' + r.aeoPassCount + ' of ' + r.aeoTotal + ' core AEO signals present — confirm with a live audit. Most sites are missing structured data (Organization, Service, FAQPage schema) that AI search engines read directly.');

            renderAISearchSimulation(r);

            const sugList = document.getElementById('audit-suggestions');
            sugList.innerHTML = r.suggestions.length ? r.suggestions.map(function(s) { return '<li>' + s + '</li>'; }).join('') : '<li>No major issues detected in the automated checks — nice work.</li>';

            document.getElementById('audit-disclaimer').innerText = r.isReal
                ? 'Scores and Core Web Vitals are real data from Google\'s PageSpeed Insights API (Lighthouse), run against the URL you entered just now. Field (real-user) data is used when Google has enough traffic history for this URL; otherwise lab data is shown.'
                : 'The live Google audit could not reach this URL, so this is a heuristic estimate based on the domain — not a technical crawl. Try again, or book a full manual audit with our team.';
        }
        function renderAISearchSimulation(r) {
            const card = document.getElementById('ai-sim-card');
            const ratio = r.aeoTotal ? r.aeoPassCount / r.aeoTotal : 0;
            const businessName = r.targetUrl.replace(/^https?:\/\//, '').replace(/^www\./, '').split('/')[0];

            let tier, tierLabel, answer;
            if (ratio >= 0.8) {
                tier = 'confident'; tierLabel = 'Likely to be cited confidently';
                answer = `Based on the structured data available — clear title, meta description, and crawlable content — ${businessName} provides enough signal for an AI assistant to describe what it does and reference it with confidence. This is the kind of technical clarity that earns citations instead of getting skipped.`;
            } else if (ratio >= 0.4) {
                tier = 'partial'; tierLabel = 'Partially visible, likely vague';
                answer = `${businessName} has some of the basics in place, but gaps in structured data (missing schema, weak meta description, or crawlability issues) mean an AI assistant could only describe it in general terms — not confidently enough to recommend it over a better-documented competitor.`;
            } else {
                tier = 'hedging'; tierLabel = 'Likely skipped entirely';
                answer = `With this few AEO signals present, an AI assistant likely doesn't have enough structured information to confidently describe ${businessName} at all — it would probably default to a competitor with clearer meta data, schema markup, and crawlable content instead of guessing.`;
            }

            card.innerHTML = `
                <span class="ai-sim-label"><span class="dot"></span>Simulated Example — Illustrative, Not a Live AI Query</span>
                <div class="ai-sim-bubble query">"Can you tell me about ${businessName}?"</div>
                <span class="ai-sim-tier-tag ${tier}">${tierLabel}</span>
                <div class="ai-sim-bubble answer ${tier}">${answer}</div>
                <p class="ai-sim-note">This illustrates how AI assistants reason from structured data — it is not an actual response from ChatGPT, Perplexity, or any AI system. The tier shown is driven by the ${r.aeoPassCount} of ${r.aeoTotal} real AEO signals detected above.</p>
            `;
        }
        window.downloadAuditPDF = function() {
            if (!lastAuditResult || !window.jspdf) return;
            const jsPDF = window.jspdf.jsPDF;
            const doc = new jsPDF();
            const r = lastAuditResult;

            doc.setFillColor(54, 54, 56); doc.rect(0, 0, 210, 32, 'F');
            doc.setTextColor(233, 196, 111); doc.setFontSize(20); doc.setFont(undefined, 'bold');
            doc.text('GRAPHINXT.', 15, 20);
            doc.setTextColor(255,255,255); doc.setFontSize(10); doc.setFont(undefined, 'normal');
            doc.text('SEO & AEO Audit Report', 15, 27);

            doc.setTextColor(20,20,20); doc.setFontSize(11);
            doc.text('Report for: ' + r.targetUrl, 15, 42);
            doc.setFontSize(9); doc.setTextColor(120,120,120);
            doc.text('Generated ' + new Date().toLocaleDateString() + ' -- ' + (r.isReal ? 'Live Google Lighthouse data' : 'Estimated baseline'), 15, 48);

            let y = 60;
            doc.setTextColor(20,20,20); doc.setFontSize(13); doc.setFont(undefined, 'bold');
            doc.text('Scores', 15, y); y += 8;
            doc.setFont(undefined, 'normal'); doc.setFontSize(10);
            const labels = { performance: 'Performance', seo: 'SEO', accessibility: 'Accessibility', bestPractices: 'Best Practices' };
            Object.keys(labels).forEach(function(key) { doc.text(labels[key] + ': ' + r.scores[key] + ' / 100', 15, y); y += 6; });

            y += 6; doc.setFontSize(13); doc.setFont(undefined, 'bold'); doc.text('Core Web Vitals', 15, y); y += 8;
            doc.setFont(undefined, 'normal'); doc.setFontSize(10);
            doc.text('LCP (Largest Contentful Paint): ' + (r.lcpMs ? (r.lcpMs/1000).toFixed(1) + 's' : 'n/a'), 15, y); y += 6;
            doc.text('CLS (Cumulative Layout Shift): ' + ((r.clsScore !== undefined && r.clsScore !== null) ? r.clsScore.toFixed(2) : 'n/a'), 15, y); y += 6;
            doc.text((r.inpMs ? 'INP' : 'Total Blocking Time') + ': ' + (r.inpMs ? r.inpMs + 'ms' : (r.tbtMs||0) + 'ms'), 15, y); y += 10;

            doc.setFontSize(13); doc.setFont(undefined, 'bold'); doc.text('AEO & Structured Data Readiness', 15, y); y += 8;
            doc.setFont(undefined, 'normal'); doc.setFontSize(10);
            const aeoText = doc.splitTextToSize(r.aeoPassCount + ' of ' + r.aeoTotal + ' core AEO signals detected.', 180);
            doc.text(aeoText, 15, y); y += aeoText.length * 6 + 6;

            doc.setFontSize(13); doc.setFont(undefined, 'bold'); doc.text('Top Improvement Suggestions', 15, y); y += 8;
            doc.setFont(undefined, 'normal'); doc.setFontSize(10);
            r.suggestions.slice(0, 7).forEach(function(s) {
                const lines = doc.splitTextToSize('- ' + s, 180);
                doc.text(lines, 15, y); y += lines.length * 6;
                if (y > 270) { doc.addPage(); y = 20; }
            });

            doc.setTextColor(150,150,150); doc.setFontSize(8);
            doc.text('Graphinxt Digital Content Creator FZ LLC -- reach@graphinxt.com -- This report reflects automated checks and is not a substitute for a full manual audit.', 15, 285);

            doc.save('graphinxt-seo-audit-' + r.targetUrl.replace(/[^a-z0-9]/gi,'-') + '.pdf');
            if (window.trackConversion) window.trackConversion('pdf_download', { tool: 'seo_audit' });
        };

        window.toggleEmailGate = function() {
            document.getElementById('audit-email-gate').classList.add('show');
        };
        const auditEmailForm = document.getElementById('audit-email-form');
        if (auditEmailForm) {
            auditEmailForm.addEventListener('submit', async function(e) {
                e.preventDefault();
                if (!lastAuditResult) return;
                const name = document.getElementById('audit-name').value.trim();
                const email = document.getElementById('audit-email').value.trim();
                const r = lastAuditResult;
                const submitBtn = this.querySelector('button[type="submit"]');
                submitBtn.disabled = true; submitBtn.innerText = 'Sending...';

                const summary = 'SEO Audit for ' + r.targetUrl + '\nPerformance: ' + r.scores.performance + ' | SEO: ' + r.scores.seo + ' | Accessibility: ' + r.scores.accessibility + ' | Best Practices: ' + r.scores.bestPractices + '\nTop suggestions: ' + r.suggestions.slice(0,5).join('; ');

                if (window.emailjs && EMAILJS_SERVICE_ID && EMAILJS_TEMPLATE_ID) {
                    try {
                        await emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, {
                            to_email: 'reach@graphinxt.com', from_name: name, from_email: email,
                            website_url: r.targetUrl, report_summary: summary
                        });
                        try {
                            const leads = JSON.parse(localStorage.getItem('graphinxt_leads') || '[]');
                            leads.push({ name: name, email: email, source: 'seo_audit', url: r.targetUrl, ts: new Date().toISOString() });
                            localStorage.setItem('graphinxt_leads', JSON.stringify(leads));
                        } catch (err) {}
                        if (window.trackConversion) window.trackConversion('generate_lead', { source: 'seo_audit_email' });
                        this.style.display = 'none';
                        document.getElementById('audit-email-success').classList.add('show');
                    } catch (err) {
                        window.location.href = 'mailto:reach@graphinxt.com?subject=' + encodeURIComponent('SEO Audit Report -- ' + r.targetUrl) + '&body=' + encodeURIComponent(summary + '\n\nRequested by: ' + name + ' (' + email + ')');
                        submitBtn.disabled = false; submitBtn.innerText = 'Send Report';
                    }
                } else {
                    window.location.href = 'mailto:reach@graphinxt.com?subject=' + encodeURIComponent('SEO Audit Report -- ' + r.targetUrl) + '&body=' + encodeURIComponent(summary + '\n\nRequested by: ' + name + ' (' + email + ')');
                    submitBtn.disabled = false; submitBtn.innerText = 'Send Report';
                }
            });
        }
        // ===================== END SEO/AEO AUDIT ENGINE =====================

        // Populate FAQ
        document.getElementById('faq-container').innerHTML = service.faqs.map(f => `
            <div class="faq-item">
                <button class="faq-question interactive-el">${f.q}<span class="faq-icon"></span></button>
                <div class="faq-answer"><p>${f.a}</p></div>
            </div>
        `).join('');

        // Populate process (service-specific)
        const processIcons = {
            discovery: '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
            strategy: '<rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/>',
            build: '<polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/>',
            launch: '<polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/>'
        };
        const processData = serviceProcess[serviceId] || serviceProcess.branding;
        document.querySelector('.process-timeline-v2').insertAdjacentHTML('beforeend',
            processData.steps.map((s, i) => `
                <div class="process-node interactive-card">
                    <div class="process-node-num">0${i+1}</div>
                    <div class="process-node-icon"><svg viewBox="0 0 24 24">${processIcons[s.icon]}</svg></div>
                    <h4>${s.title}</h4>
                    <p>${s.desc}</p>
                    <span class="process-node-tag">${s.tag}</span>
                </div>
            `).join('')
        );

        // Populate related services
        const relatedServices = Object.entries(services).filter(([id]) => id !== serviceId).slice(0, 4);
        document.getElementById('related-services-grid').innerHTML = relatedServices.map(([id, s]) => `
            <a href="/services/${id}" class="related-service-card interactive-card">
                <h4>${s.title.replace(/<[^>]*>/g, '')}</h4>
                <p>${s.subheading}</p>
                <span class="related-service-link">Explore Service →</span>
            </a>
        `).join('');

        // Theme Logic
        const themeToggleBtn = document.getElementById('theme-toggle');
        const themeToggleMobile = document.getElementById('theme-toggle-mobile');
        const mobileThemeIcon = document.getElementById('mobile-theme-icon');
        const currentTheme = localStorage.getItem('theme');
        function syncThemeIcons() {
            const icon = document.body.classList.contains('light-mode') ? '☾' : '☼';
            if (themeToggleBtn) themeToggleBtn.innerText = icon;
            if (mobileThemeIcon) mobileThemeIcon.innerText = icon;
            const headerMobileIcon = document.getElementById('theme-toggle-mobile-header');
            if (headerMobileIcon) headerMobileIcon.innerText = icon;
        }
        if (currentTheme === 'light') { document.body.classList.add('light-mode'); }
        syncThemeIcons();
        function toggleTheme() {
            document.body.classList.toggle('light-mode');
            localStorage.setItem('theme', document.body.classList.contains('light-mode') ? 'light' : 'dark');
            syncThemeIcons();
        }
        if (themeToggleBtn) themeToggleBtn.addEventListener('click', toggleTheme);
        if (themeToggleMobile) themeToggleMobile.addEventListener('click', toggleTheme);
        const themeToggleMobileHeader = document.getElementById('theme-toggle-mobile-header');
        if (themeToggleMobileHeader) themeToggleMobileHeader.addEventListener('click', toggleTheme);

        // Mobile Menu
        const navToggle = document.getElementById('nav-toggle');
        const mobileMenu = document.getElementById('mobile-menu');
        if (navToggle && mobileMenu) {
            navToggle.addEventListener('click', () => { navToggle.classList.toggle('open'); mobileMenu.classList.toggle('open'); });
            mobileMenu.querySelectorAll('a').forEach(a => a.addEventListener('click', () => { navToggle.classList.remove('open'); mobileMenu.classList.remove('open'); }));
        }

        // Enquiry Modal
        const enquiryModal = document.getElementById('enquiry');
        const enquiryCloseBtn = document.getElementById('enquiry-close');
        function openEnquiry() { if (enquiryModal) { enquiryModal.classList.add('open'); document.body.style.overflow = 'hidden'; } }
        function closeEnquiry() { if (enquiryModal) { enquiryModal.classList.remove('open'); document.body.style.overflow = ''; } }
        document.querySelectorAll('a[href="#enquiry"]').forEach(a => a.addEventListener('click', (e) => { e.preventDefault(); openEnquiry(); }));
        if (enquiryCloseBtn) enquiryCloseBtn.addEventListener('click', closeEnquiry);
        document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeEnquiry(); });
        if (enquiryModal) enquiryModal.addEventListener('click', (e) => { if (e.target === enquiryModal) closeEnquiry(); });
        if (enquireParam) openEnquiry();
        window.addEventListener('message', function(e){ if(e.data && e.data.type === 'openEnquiry') openEnquiry(); });

        // Cursor
        const cursorDot = document.querySelector('.cursor-dot');
        const cursorOutline = document.querySelector('.cursor-outline');
        window.addEventListener('mousemove', (e) => {
            cursorDot.style.left = `${e.clientX}px`; cursorDot.style.top = `${e.clientY}px`;
            cursorOutline.animate({ left: `${e.clientX}px`, top: `${e.clientY}px` }, { duration: 300, fill: "forwards" });
        });
        document.querySelectorAll('a, button, .interactive-el, .interactive-card, input, textarea, select').forEach(el => {
            el.addEventListener('mouseenter', () => {
                cursorOutline.style.transform = 'translate(-50%, -50%) scale(1.5)';
                cursorOutline.style.backgroundColor = document.body.classList.contains('light-mode') ? 'rgba(0,0,0,0.05)' : 'rgba(255,255,255,0.05)';
                cursorDot.style.opacity = '0';
            });
            el.addEventListener('mouseleave', () => {
                cursorOutline.style.transform = 'translate(-50%, -50%) scale(1)';
                cursorOutline.style.backgroundColor = 'transparent'; cursorDot.style.opacity = '1';
            });
        });

        // Scroll
        const navbar = document.querySelector('.navbar');
        const fadeElements = document.querySelectorAll('.fade-in');
        window.addEventListener('scroll', () => {
            if (document.documentElement.scrollTop > 50) navbar.classList.add('scrolled');
            else navbar.classList.remove('scrolled');
            fadeElements.forEach(el => {
                if (el.getBoundingClientRect().top < window.innerHeight - 80) el.classList.add('visible');
            });
        });
        window.dispatchEvent(new Event('scroll'));

        // FAQ Accordion
        document.querySelectorAll('.faq-question').forEach(q => {
            q.addEventListener('click', () => {
                const item = q.parentElement;
                const wasActive = item.classList.contains('active');
                document.querySelectorAll('.faq-item').forEach(i => i.classList.remove('active'));
                if (!wasActive) item.classList.add('active');
            });
        });

        // Enquiry Form
        // Enquiry Form — chips, pre-select & submit
        const serviceLabels = { branding: 'Branding', web: 'Web Dev', app: 'App Dev', ads: 'Paid Ads', social: 'Social Media', seo: 'SEO / AEO', ai: 'AI Solutions', packaging: 'Packaging', video: 'Video Editing', gameui: 'Game UI/UX', revenue: 'Revenue Accelerator' };
        const cursorDotEl = document.querySelector('.cursor-dot');
        const cursorOutlineEl = document.querySelector('.cursor-outline');
        function attachCursor(el) {
            el.addEventListener('mouseenter', () => {
                cursorOutlineEl.style.transform = 'translate(-50%, -50%) scale(1.5)';
                cursorOutlineEl.style.backgroundColor = document.body.classList.contains('light-mode') ? 'rgba(0,0,0,0.05)' : 'rgba(255,255,255,0.05)';
                cursorDotEl.style.opacity = '0';
            });
            el.addEventListener('mouseleave', () => {
                cursorOutlineEl.style.transform = 'translate(-50%, -50%) scale(1)';
                cursorOutlineEl.style.backgroundColor = 'transparent';
                cursorDotEl.style.opacity = '1';
            });
        }

        const serviceChips = document.getElementById('service-chips');
        serviceChips.innerHTML = Object.entries(serviceLabels).map(([id, name]) =>
            `<button type="button" class="chip interactive-el ${id === serviceId ? 'active' : ''}" data-service="${id}">${name}</button>`
        ).join('');
        serviceChips.querySelectorAll('.chip').forEach(c => {
            attachCursor(c);
            c.addEventListener('click', () => c.classList.toggle('active'));
        });

        const contactChips = document.getElementById('contact-chips');
        contactChips.innerHTML = ['Email', 'Phone', 'WhatsApp', 'Video Call'].map((m, i) =>
            `<button type="button" class="chip interactive-el ${i === 0 ? 'active' : ''}" data-contact="${m}">${m}</button>`
        ).join('');
        contactChips.querySelectorAll('.chip').forEach(c => {
            attachCursor(c);
            c.addEventListener('click', () => {
                contactChips.querySelectorAll('.chip').forEach(x => x.classList.remove('active'));
                c.classList.add('active');
            });
        });

        const tierParam = params.get('tier');
        if (tierParam) document.getElementById('tier-select').value = tierParam;

        document.getElementById('enquiry-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            const form = e.target;
            const submitBtn = form.querySelector('button[type="submit"]');
            const selectedService = serviceChips.querySelector('.chip.active')?.dataset.service || serviceId;
            const formData = new FormData(form);
            const data = Object.fromEntries(formData.entries());
            data.serviceInterest = serviceLabels[selectedService] || serviceId;

            try {
                const leads = JSON.parse(localStorage.getItem('graphinxt_leads') || '[]');
                leads.push({ ...data, source: 'service_enquiry', ts: new Date().toISOString() });
                localStorage.setItem('graphinxt_leads', JSON.stringify(leads));
            } catch (err) { /* storage unavailable — fail silently */ }

            const subject = `Service enquiry — ${data.serviceInterest} — ${data.name || ''}`;
            const bodyLines = Object.entries(data).map(([k, v]) => `${k}: ${v || '—'}`).join('\n');

            function showSuccess() {
                form.style.display = 'none';
                const successMsg = document.getElementById('form-success');
                successMsg.querySelector('p').innerText = `Thank you — your enquiry for ${data.serviceInterest || 'your project'} has been received. Our team will review your requirements and send a detailed proposal within 24 hours.`;
                successMsg.classList.add('show');
            }

            if (window.emailjs && EMAILJS_SERVICE_ID && EMAILJS_TEMPLATE_ID) {
                if (submitBtn) { submitBtn.disabled = true; submitBtn.innerText = 'Sending...'; }
                try {
                    await emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, {
                        from_name: data.name || '—', from_email: data.email || '—', company: data.company || '—',
                        service: data.serviceInterest, message: data.requirements || '—', website_url: window.location.href
                    });
                    window.trackConversion('generate_lead', { source: 'service_enquiry', service: data.serviceInterest || serviceId });
                    showSuccess();
                } catch (err) {
                    window.location.href = `mailto:reach@graphinxt.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(bodyLines)}`;
                    window.trackConversion('generate_lead', { source: 'service_enquiry_fallback', service: data.serviceInterest || serviceId });
                    showSuccess();
                }
            } else {
                window.location.href = `mailto:reach@graphinxt.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(bodyLines)}`;
                window.trackConversion('generate_lead', { source: 'service_enquiry', service: data.serviceInterest || serviceId });
                showSuccess();
            }
        });
    </script>

    <script>
    // Animated gold-particle background — matches Graphinxt homepage
    (function() {
        var canvas = document.getElementById('bg-canvas');
        if (!canvas) return;
        var ctx = (canvas.getContext) ? canvas.getContext('2d') : null;
        if (!ctx) return;
        if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
        var particles = [], w, h, animationId;
        function resize(){ w = canvas.width = window.innerWidth; h = canvas.height = window.innerHeight; }
        resize(); window.addEventListener('resize', resize);
        function create(){
            var count = Math.min(Math.floor(w / 18), 70); particles = [];
            for (var i=0;i<count;i++){ particles.push({ x:Math.random()*w, y:Math.random()*h, r:Math.random()*1.8+0.4, vy:-(Math.random()*0.4+0.1), vx:(Math.random()-0.5)*0.2, alpha:Math.random()*0.5+0.1, pulse:Math.random()*Math.PI*2, pulseSpeed:Math.random()*0.02+0.005 }); }
        }
        create();
        function animate(){
            if (!ctx) return;
            ctx.clearRect(0,0,w,h);
            particles.forEach(function(p){
                p.y+=p.vy; p.x+=p.vx; p.pulse+=p.pulseSpeed;
                var a = p.alpha*(0.5+0.5*Math.sin(p.pulse));
                if (p.y<-10){ p.y=h+10; p.x=Math.random()*w; }
                if (p.x<-10) p.x=w+10; if (p.x>w+10) p.x=-10;
                var g = ctx.createRadialGradient(p.x,p.y,0,p.x,p.y,p.r*6);
                g.addColorStop(0,'rgba(233,196,111,'+a+')'); g.addColorStop(1,'rgba(233,196,111,0)');
                ctx.fillStyle=g; ctx.beginPath(); ctx.arc(p.x,p.y,p.r*6,0,Math.PI*2); ctx.fill();
                ctx.fillStyle='rgba(233,196,111,'+(a*1.5)+')'; ctx.beginPath(); ctx.arc(p.x,p.y,p.r,0,Math.PI*2); ctx.fill();
            });
            animationId = requestAnimationFrame(animate);
        }
        function start(){ if(!animationId) animate(); }
        function stop(){ if(animationId){ cancelAnimationFrame(animationId); animationId=null; if(ctx) ctx.clearRect(0,0,w,h);} }
        function checkTheme(){ if(document.body.classList.contains('light-mode')) stop(); else start(); }
        checkTheme();
        var tt = document.getElementById('theme-toggle') || document.getElementById('theme-toggle-btn');
        if (tt) tt.addEventListener('click', function(){ setTimeout(checkTheme, 60); });
    })();
    </script>

</body>
</html>
