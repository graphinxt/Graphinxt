<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portfolio & Case Studies | Graphinxt</title>
    <meta name="description" content="Real client websites and growth projects by Graphinxt across the UK, USA, Canada, Australia & New Zealand. See the work behind the results.">
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="https://graphinxt.com/portfolio">
    <meta property="og:site_name" content="Graphinxt">
    <meta property="og:type" content="website">
    <meta property="og:title" content="Portfolio | Case Studies — Graphinxt">
    <meta property="og:description" content="Real case studies across web architecture, brand identity, and regional marketing.">
      <link rel="stylesheet" href="../assets/style.css">
        <link rel="stylesheet" href="../assets/header.css">
 
   <link rel="shortcut icon" href="../assets/favicon.ico" type="image/x-icon">
        <link rel="icon" href="../assets/favicon.ico" type="image/x-icon">
    <meta property="og:url" content="https://graphinxt.com/portfolio">
    <meta property="og:image" content="https://graphinxt.com/assets/og-cover.jpg">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:image" content="https://graphinxt.com/assets/og-cover.jpg">
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='14' fill='%23363638'/%3E%3Ctext x='32' y='44' font-family='Georgia, serif' font-size='36' font-weight='800' fill='%23e9c46f' text-anchor='middle'%3EG%3C/text%3E%3C/svg%3E">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@200;300;400;500;800&display=swap" rel="stylesheet">

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "CollectionPage",
      "name": "Graphinxt Portfolio",
      "url": "https://graphinxt.com/portfolio",
      "description": "Case studies across web architecture, brand identity, and regional marketing.",
      "isPartOf": { "@type": "WebSite", "name": "Graphinxt", "url": "https://graphinxt.com/" }
    }
    </script>

    <style>
        :root {
            --bg-dark: #363638; --bg-darker: #2a2a2c; --brand-gold: #e9c46f; --brand-gold-hover: #d4ae58;
            --text-main: #ffffff; --text-muted: #a1a1a5; --card-bg: rgba(255,255,255,0.02);
            --border-light: rgba(233,196,111,0.12); --border-glow: rgba(233,196,111,0.4);
            --ai-glow: rgba(233,196,111,0.08); --gradient-start: #ffffff;
            --nav-bg: rgba(42,42,44,0.4); --nav-bg-scrolled: rgba(30,30,32,0.8);
            --overlay-gradient: linear-gradient(to top, rgba(30,30,32,0.95), transparent);
            --modal-overlay: rgba(34,34,36,0.85);
        }
     /*   body.light-mode {
            --bg-dark: #faf8f5; --bg-darker: #ffffff; --text-main: #1a1a1a; --text-muted: #6b6b70;
            --card-bg: rgba(0,0,0,0.015); --border-light: rgba(0,0,0,0.06); --border-glow: rgba(217,164,74,0.9);
            --ai-glow: rgba(217,164,74,0.12); --gradient-start: #1a1a1a;
            --nav-bg: rgba(255,255,255,0.6); --nav-bg-scrolled: rgba(255,255,255,0.95);
            --overlay-gradient: linear-gradient(to top, rgba(255,255,255,0.95), transparent);
            --modal-overlay: rgba(250,248,245,0.9);
        }*/
    /*    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Montserrat', sans-serif; cursor: none; scroll-behavior: smooth; }
        @media (pointer: coarse) { * { cursor: auto !important; } }
        @media (prefers-reduced-motion: reduce) { * { cursor: auto !important; } }
        html:not(.cursor-ready) * { cursor: auto !important; }
        a:focus-visible, button:focus-visible, [tabindex]:focus-visible { outline: 2px solid var(--brand-gold); outline-offset: 3px; border-radius: 4px; }
*/
      /*  body { background-color: var(--bg-dark); color: var(--text-main); overflow-x: hidden; line-height: 1.6; transition: background-color 0.6s cubic-bezier(0.165,0.84,0.44,1), color 0.6s ease; }
        h1, h2, h3, .logo { font-weight: 800; }
*/
      /*  .skip-link { position: fixed; top: -100px; left: 1rem; z-index: 999999; background: var(--brand-gold); color: var(--bg-dark) !important; padding: 0.8rem 1.6rem; border-radius: 8px; font-weight: 700; font-size: 0.85rem; text-decoration: none; transition: top 0.2s ease; }
        .skip-link:focus { top: 1rem; }

        #bg-canvas { position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; z-index: 0; pointer-events: none; }
        body.light-mode #bg-canvas { display: none; }
*/
       /* .cursor-dot { width: 6px; height: 6px; background-color: var(--brand-gold); position: fixed; border-radius: 50%; z-index: 100000; pointer-events: none; transform: translate(-50%,-50%); transition: width 0.2s, height 0.2s; }
        .cursor-outline { width: 40px; height: 40px; border: 1px solid var(--brand-gold); position: fixed; border-radius: 50%; z-index: 100000; pointer-events: none; transform: translate(-50%,-50%); transition: width 0.3s, height 0.3s, background-color 0.3s, border-color 0.3s; }

        .navbar { display: flex; justify-content: space-between; align-items: center; padding: 1rem 2rem; position: fixed; width: 90%; max-width: 1200px; top: 2rem; left: 50%; transform: translateX(-50%); z-index: 9990; background: var(--nav-bg); backdrop-filter: blur(24px); -webkit-backdrop-filter: blur(24px); border: 1px solid var(--border-light); border-radius: 50px; transition: all 0.6s cubic-bezier(0.165,0.84,0.44,1); box-shadow: 0 20px 40px rgba(0,0,0,0.1); }
        .navbar.scrolled { top: 1rem; width: 95%; background: var(--nav-bg-scrolled); border-color: var(--border-glow); }*/
      /*  .logo { font-size: 1.5rem; letter-spacing: -0.5px; text-decoration: none; color: var(--text-main); }
        .accent-dot { color: var(--brand-gold); }
        .nav-links { display: flex; list-style: none; gap: 2rem; align-items: center; }
        .nav-links a { color: var(--text-main); text-decoration: none; font-size: 0.8rem; font-weight: 500; text-transform: uppercase; letter-spacing: 1px; transition: color 0.3s; }
        .nav-links a:hover, .nav-links a.active { color: var(--brand-gold); }
        .mode-toggle { background: transparent; border: none; color: var(--text-main); font-size: 1.2rem; display: flex; align-items: center; justify-content: center; transition: transform 0.4s ease, color 0.3s; }
        .mode-toggle:hover { color: var(--brand-gold); transform: rotate(30deg); }
        @media(max-width: 768px) { .nav-links { display: none; } }
*/
       /* .btn-primary { background: var(--text-main); color: var(--bg-dark) !important; padding: 0.8rem 2rem; border-radius: 30px; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; text-decoration: none; border: none; transition: all 0.4s cubic-bezier(0.165,0.84,0.44,1); display: inline-block; font-size: 0.8rem; }
        .btn-primary:hover { background: var(--brand-gold); color: #fff !important; transform: scale(1.05); box-shadow: 0 10px 25px rgba(233,196,111,0.3); }
        .btn-outline { background: transparent; color: var(--brand-gold); padding: 0.9rem 2.2rem; border-radius: 30px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; text-decoration: none; border: 1px solid var(--border-light); transition: all 0.4s ease; display: inline-block; font-size: 0.78rem; }
        .btn-outline:hover { border-color: var(--brand-gold); background: rgba(233,196,111,0.05); }

        .ambient-glow { position: absolute; border-radius: 50%; filter: blur(140px); opacity: 0.15; z-index: 1; pointer-events: none; }
        .glow-top { width: 60vw; height: 60vw; background: radial-gradient(circle, var(--brand-gold) 0%, transparent 70%); top: -30vw; left: 20vw; }
        body.light-mode .ambient-glow { opacity: 0.08; }
*/
        /*.breadcrumb-nav { max-width: 1200px; margin: 6.5rem auto 0; padding: 0 5%; font-size: 0.78rem; color: var(--text-muted); display: flex; align-items: center; gap: 0.5rem; position: relative; z-index: 2; }
        .breadcrumb-nav a { color: var(--text-muted); text-decoration: none; }
        .breadcrumb-nav a:hover { color: var(--brand-gold); }
        .breadcrumb-nav .bc-sep { opacity: 0.4; }
        .breadcrumb-nav .bc-current { color: var(--brand-gold); }
*/
        .portfolio-hero { padding: 2rem 5% 3rem; text-align: center; position: relative; z-index: 2; margin-top: 10rem; }
        .portfolio-hero-inner { max-width: 780px; margin: 0 auto; }
        .subheading { font-size: 0.8rem; color: var(--brand-gold); text-transform: uppercase; letter-spacing: 4px; margin-bottom: 1.2rem; display: block; }
        .portfolio-hero h1 { font-size: clamp(2.2rem, 5vw, 4rem); font-weight: 200; line-height: 1.1; margin-bottom: 1.2rem; letter-spacing: -1px; }
        .portfolio-hero h1 strong { font-weight: 800; background:linear-gradient(to right,#ffffff,var(--brand-gold)); -webkit-background-clip:text; background-clip:text; -webkit-text-fill-color:transparent; color:var(--brand-gold); }
        .portfolio-hero p { color: var(--text-muted); font-size: 1.05rem; font-weight: 300; }

        .filter-container { display: flex; justify-content: center; gap: 1rem; flex-wrap: wrap; margin: 0 5% 3rem; position: relative; z-index: 2; }
        .filter-btn { background: transparent; border: 1px solid var(--border-light); color: var(--text-muted); padding: 0.7rem 1.6rem; border-radius: 30px; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 1px; font-weight: 600; transition: all 0.3s; }
        .filter-btn.active, .filter-btn:hover { border-color: var(--brand-gold); color: var(--brand-gold); background: rgba(233,196,111,0.06); }

        .portfolio-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(340px, 1fr)); gap: 2rem; max-width: 1200px; margin: 0 auto; padding: 0 5% 6rem; position: relative; z-index: 2; }
        .portfolio-item { border-radius: 24px; overflow: hidden; position: relative; height: 340px; border: 1px solid var(--border-light); transition: all 0.5s cubic-bezier(0.165,0.84,0.44,1); background: none; text-align: left; width: 100%; display: block; }
        .portfolio-item:hover { transform: translateY(-8px); border-color: var(--brand-gold); box-shadow: 0 20px 50px rgba(0,0,0,0.25); }
        .portfolio-item.hidden { display: none; }
        .portfolio-bg { width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; position: relative; overflow: hidden; }
        .portfolio-bg::before { content: ""; position: absolute; inset: 0; opacity: 0.5; background-image: radial-gradient(circle, rgba(255,255,255,0.06) 1px, transparent 1px); background-size: 18px 18px; }

        /* Browser-chrome mockup strip — shows the real domain, ties every card to an actual live site */
        .browser-chrome { position: absolute; top: 0; left: 0; right: 0; display: flex; align-items: center; gap: 6px; padding: 0.65rem 0.9rem; background: rgba(0,0,0,0.28); z-index: 2; }
        .browser-dots { display: flex; gap: 5px; flex-shrink: 0; }
        .browser-dot { width: 7px; height: 7px; border-radius: 50%; background: rgba(255,255,255,0.25); }
        .browser-url { flex: 1; background: rgba(255,255,255,0.08); border-radius: 20px; padding: 3px 12px; font-size: 0.62rem; color: rgba(255,255,255,0.6); text-align: center; font-family: 'Courier New', monospace; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

        /* Device badges — communicates the responsive desktop + mobile build on every card */
        .device-badges { position: absolute; bottom: 1rem; right: 1rem; display: flex; gap: 6px; z-index: 3; }
        .device-badge { width: 28px; height: 28px; border-radius: 8px; background: rgba(0,0,0,0.45); backdrop-filter: blur(4px); display: flex; align-items: center; justify-content: center; border: 1px solid rgba(255,255,255,0.14); }
        .device-badge svg { width: 13px; height: 13px; stroke: rgba(255,255,255,0.75); fill: none; stroke-width: 1.8; }
        .portfolio-bg-text { font-size: 5rem; font-weight: 800; letter-spacing: -2px; opacity: 0.9; position: relative; z-index: 1; }
        .cat-home-services .portfolio-bg { background: linear-gradient(135deg, #6b4a2c, #402a1a); }
        .cat-home-services .portfolio-bg-text { color: var(--brand-gold); }
        .cat-logistics .portfolio-bg { background: linear-gradient(135deg, #2c3e6b, #1a2540); }
        .cat-logistics .portfolio-bg-text { color: #7ea8e8; }
        .cat-real-estate-construction .portfolio-bg { background: linear-gradient(135deg, #2c6b52, #1a4033); }
        .cat-real-estate-construction .portfolio-bg-text { color: #6ee7a0; }
        .cat-care .portfolio-bg { background: linear-gradient(135deg, #5a2c6b, #33173d); }
        .cat-care .portfolio-bg-text { color: #d99ee8; }
        .cat-security-finance .portfolio-bg { background: linear-gradient(135deg, #4a2c2c, #2b1717); }
        .cat-security-finance .portfolio-bg-text { color: #e88a7e; }
        .portfolio-overlay { position: absolute; bottom: 0; left: 0; width: 100%; padding: 2rem; background: var(--overlay-gradient); }
        .portfolio-overlay h3 { color: var(--brand-gold); margin-bottom: 0.3rem; font-size: 1.2rem; }
        .portfolio-overlay p { color: var(--text-muted); font-size: 0.85rem; font-weight: 300; }
        .portfolio-cat-tag { position: absolute; top: 3.4rem; left: 1.2rem; font-size: 0.6rem; text-transform: uppercase; letter-spacing: 1px; font-weight: 700; padding: 4px 10px; border-radius: 20px; background: rgba(0,0,0,0.4); color: #fff; z-index: 2; }

        .portfolio-cta { max-width: 900px; margin: 0 auto; padding: 0 5% 8rem; text-align: center; position: relative; z-index: 2; }
        .portfolio-cta-inner { background: var(--card-bg); border: 1px solid var(--border-glow); border-radius: 28px; padding: 4rem 3rem; box-shadow: inset 0 0 30px var(--ai-glow); }
        .portfolio-cta-inner h2 { font-size: clamp(1.6rem, 3.5vw, 2.4rem); font-weight: 200; margin-bottom: 1rem; }
        .portfolio-cta-inner h2 strong { font-weight: 800; color: var(--brand-gold); }
        .portfolio-cta-inner p { color: var(--text-muted); margin-bottom: 2rem; font-weight: 300; }

        /* Modal */
        .modal-overlay { position: fixed; inset: 0; background: var(--modal-overlay); backdrop-filter: blur(6px); z-index: 99997; display: none; align-items: center; justify-content: center; padding: 2rem; }
        .modal-overlay.active { display: flex; }
        .modal-content { background: var(--bg-dark); border: 1px solid var(--border-glow); border-radius: 28px; max-width: 640px; width: 100%; max-height: 85vh; overflow: hidden; overflow-y: auto; padding: 0 0 3rem; position: relative; box-shadow: 0 30px 80px rgba(0,0,0,0.5); }
        .modal-chrome { display: flex; align-items: center; gap: 6px; padding: 0.9rem 3.2rem 0.9rem 1.2rem; background: rgba(0,0,0,0.25); border-bottom: 1px solid var(--border-light); position: sticky; top: 0; z-index: 5; }
        .modal-chrome .browser-dot { width: 9px; height: 9px; }
        .modal-chrome .browser-url { font-size: 0.72rem; padding: 5px 14px; }
        .modal-body-inner { padding: 2.5rem 3rem 0; }
        .modal-device-row { display: flex; gap: 0.6rem; margin: 1.2rem 0 1.8rem; }
        .modal-device-chip { display: flex; align-items: center; gap: 6px; font-size: 0.68rem; text-transform: uppercase; letter-spacing: 0.5px; color: var(--text-muted); border: 1px solid var(--border-light); border-radius: 20px; padding: 5px 12px 5px 8px; }
        .modal-device-chip svg { width: 13px; height: 13px; stroke: var(--brand-gold); fill: none; stroke-width: 1.8; }
        .close-modal { position: absolute; top: 0.6rem; right: 1rem; background: transparent; border: none; color: var(--text-muted); font-size: 1.8rem; line-height: 1; z-index: 6; }
        .close-modal:hover { color: var(--brand-gold); }
        .modal-project-meta { display: flex; gap: 2rem; margin: 1.5rem 0 2rem; flex-wrap: wrap; }
        .meta-label { display: block; font-size: 0.65rem; text-transform: uppercase; letter-spacing: 1px; color: var(--text-muted); margin-bottom: 0.3rem; }
        .meta-value { font-size: 0.95rem; color: var(--text-main); font-weight: 500; }
        .modal-content p { color: var(--text-muted); font-weight: 300; line-height: 1.8; margin-bottom: 1rem; }
        .modal-content h4 { color: var(--text-main); font-weight: 500; margin-top: 1.5rem; margin-bottom: 0.5rem; }
        .modal-tag-list { display: flex; flex-wrap: wrap; gap: 0.6rem; margin-top: 1.5rem; }
        .modal-tag { font-size: 0.68rem; text-transform: uppercase; letter-spacing: 1px; padding: 5px 12px; border: 1px solid var(--border-light); border-radius: 20px; color: var(--brand-gold); }

        .fade-in { opacity: 0; transform: translateY(40px); transition: opacity 1s cubic-bezier(0.165,0.84,0.44,1), transform 1s cubic-bezier(0.165,0.84,0.44,1); }
        .fade-in.visible { opacity: 1; transform: translateY(0); }

        /* Embed mode: compact proof-grid shown inside an iframe on service.html pricing cards */
        body.embed-mode .navbar, body.embed-mode .breadcrumb-nav, body.embed-mode .portfolio-hero,
        body.embed-mode .filter-container, body.embed-mode .portfolio-cta, body.embed-mode footer,
        body.embed-mode .whatsapp-float, body.embed-mode .cursor-dot, body.embed-mode .cursor-outline { display: none !important; }
        body.embed-mode, body.embed-mode * { cursor: auto !important; }
        body.embed-mode .portfolio-grid { padding: 1rem; margin: 0; max-width: 100%; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 1rem; }
        body.embed-mode .portfolio-item { height: 200px; }
        body.embed-mode .portfolio-bg-text { font-size: 3rem; }

        .whatsapp-float { position: fixed; right: 22px; bottom: 22px; z-index: 9995; width: 56px; height: 56px; border-radius: 50%; background: #25D366; color: #fff; display: flex; align-items: center; justify-content: center; box-shadow: 0 8px 24px rgba(37,211,102,0.45); text-decoration: none; }
        .whatsapp-float svg { width: 28px; height: 28px; fill: #fff; }

        footer { padding: 6rem 5% 4rem; text-align: center; border-top: 1px solid var(--border-light); position: relative; z-index: 2; }
        .footer-logo { font-size: clamp(2.5rem, 6vw, 6rem); font-weight: 800; letter-spacing: -2px; margin-bottom: 1rem; color: transparent; -webkit-text-stroke: 1px rgba(255,255,255,0.1); text-decoration: none; }
        body.light-mode .footer-logo { -webkit-text-stroke: 1px rgba(0,0,0,0.06); }
        .footer-logo:hover { color: var(--text-main); -webkit-text-stroke: 0; }
        .footer-bottom { margin-top: 2rem; color: var(--text-muted); font-size: 0.8rem; letter-spacing: 1px; text-transform: uppercase; }
    </style>

<!-- ===== ANALYTICS & CONVERSION TRACKING ===== -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-58PYC27MPE"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-58PYC27MPE');
</script>
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '2162187584315430');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=2162187584315430&ev=PageView&noscript=1" /></noscript>
<script>
  window.trackConversion = function(eventName, params) {
    params = params || {};
    try { if (typeof gtag === 'function') gtag('event', eventName, params); } catch(e) {}
    try { if (typeof fbq === 'function') fbq('trackCustom', eventName, params); } catch(e) {}
  };
  document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('a[href*="wa.me"]').forEach(function(el) {
      el.addEventListener('click', function() { window.trackConversion('whatsapp_click', { page: window.location.pathname }); });
    });
  });
</script>
<!-- ===== END ANALYTICS ===== -->
</head>
<body>
    <a href="#main-content" class="skip-link">Skip to main content</a>
  
         <?php include '../header.php';?>

    <header class="portfolio-hero fade-in" id="main-content">
        <div class="portfolio-hero-inner">
            <span class="subheading">Delivered Work</span>
            <h1>A Showcase of Delivered <strong>Excellence</strong></h1>
            <p>Real projects, real clients, real results — across web architecture, brand identity, and regional marketing.</p>
        </div>
    </header>

    <div class="filter-container fade-in">
        <button class="filter-btn active interactive-el" data-filter="all">All Work</button>
        <button class="filter-btn interactive-el" data-filter="home-services">Home Services</button>
        <button class="filter-btn interactive-el" data-filter="logistics">Transport &amp; Logistics</button>
        <button class="filter-btn interactive-el" data-filter="real-estate-construction">Real Estate &amp; Construction</button>
        <button class="filter-btn interactive-el" data-filter="care">Care &amp; Wellness</button>
        <button class="filter-btn interactive-el" data-filter="security-finance">Security &amp; Finance</button>
    </div>

    <div class="portfolio-grid" id="portfolio-grid"></div>

    <div class="portfolio-cta fade-in">
        <div class="portfolio-cta-inner">
            <h2>Want results like <strong>these</strong>?</h2>
            <p>Tell us about your project — we'll show you exactly how we'd approach it.</p>
            <a href="/#contact" class="btn-primary interactive-el">Start a Project →</a>
        </div>
    </div>

    <a href="https://wa.me/971564785139" target="_blank" class="whatsapp-float" aria-label="Chat on WhatsApp"><svg viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51l-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.247-.694.247-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg></a>

    <div class="modal-overlay" id="modal-overlay">
        <div class="modal-content" id="modal-content-inner">
            <div class="modal-chrome" id="modal-chrome">
                <span class="browser-dots"><span class="browser-dot"></span><span class="browser-dot"></span><span class="browser-dot"></span></span>
                <span class="browser-url" id="modal-domain"></span>
            </div>
            <button class="close-modal interactive-el" id="close-modal-btn" aria-label="Close">×</button>
            <div id="modal-body"></div>
        </div>
    </div>

    

    <script>
        const projectData = {
            'bros-cleaning': {
                name: 'Bros Cleaning Services', initials: 'BC', category: 'home-services',
                industry: 'Residential & Commercial Cleaning', client: 'Bros Cleaning Services', location: 'Edmonton, AB',
                description: 'A full service site for a residential and commercial cleaning company covering Edmonton and surrounding areas. Built around a multi-service booking flow (ongoing cleaning, deep & seasonal, move-in/out, post-renovation, office & warehouse), dedicated commercial and residential service pages, and direct WhatsApp click-to-chat.',
                tags: ['Service Booking Flow', 'Area-Served Pages', 'WhatsApp Integration'],
                liveUrl: 'https://broscleaning.ca/'
            },
            'golden-moves': {
                name: 'Golden Moves Logistics', initials: 'GM', category: 'logistics',
                industry: 'Freight & Trucking (FTL, LTL, Reefer)', client: 'Golden Moves Logistics Ltd', location: 'Mississauga, ON',
                description: 'A freight brokerage site covering five distinct transport services — Dry Van, Temperature Controlled, LTL & FTL, Flatbed, and Power Unit — each with its own dedicated page. Built to communicate cross-border Canada/USA capability and a clear needs-assessment-to-delivery process for prospective shippers.',
                tags: ['Multi-Service Architecture', 'Quote Request Flow', 'Cross-Border Positioning'],
                liveUrl: 'https://goldenmoveslogistics.ca/'
            },
            'jd-zon': {
                name: 'JD ZON Landscaping', initials: 'JZ', category: 'home-services',
                industry: 'Landscaping & Snow Removal', client: 'JD ZON Landscaping', location: 'Saskatoon, SK',
                description: 'A landscaping and snow removal site built around a large project image gallery, a 7-category service breakdown (hardscaping, lawn & turf, irrigation, planting, winter services, and more), and an FAQ addressing licensing, timelines, and sustainable landscaping options.',
                tags: ['Project Gallery', 'Service Categorization', 'FAQ & Trust Signals'],
                liveUrl: 'https://www.jdzonlandscaping.ca/'
            },
            'kindheart': {
                name: 'Kindheart Support', initials: 'KH', category: 'care',
                industry: 'In-Home Senior Care', client: 'Kindheart Support Limited', location: 'Waikato & Auckland, NZ',
                description: 'A private home care platform built around a 12-service, 17-location appointment booking widget, mission/vision/values sections, and a rotating testimonial carousel — designed to build the trust a family needs before booking in-home care for a loved one.',
                tags: ['Multi-Location Booking Widget', 'Testimonial Carousel', 'Trust-Focused Layout'],
                liveUrl: 'https://kindheartsupport.co.nz/'
            },
            'trusted-home-care': {
                name: 'Trusted Home Care', initials: 'TH', category: 'care',
                industry: 'In-Home Senior Care', client: 'Trusted Private Home Care', location: 'Auckland & Waikato, NZ',
                description: 'A companion home care site structured around four package tiers (Essential, Standard, Comprehensive, Bespoke), a four-step "how it works" process, and animated stat counters — built to make a sensitive, high-trust decision feel clear and approachable.',
                tags: ['Package Tier Structure', 'Animated Stats', 'Four-Step Process Explainer'],
                liveUrl: 'https://trustedhomecare.co.nz/'
            },
            'fibrepro': {
                name: 'FibrePro Carpet Cleaning', initials: 'FP', category: 'home-services',
                industry: 'Carpet Cleaning & Flood Restoration', client: 'FibrePro', location: 'Christchurch, NZ',
                description: 'A carpet cleaning and flood restoration site with a 16-option service booking dropdown, an integrated blog for ongoing local SEO, and IICRC certification prominently featured to establish technical credibility for a service where trust in expertise matters.',
                tags: ['Service Booking Dropdown', 'Built-In Blog for SEO', 'Certification Trust Signal'],
                liveUrl: 'https://fibreprocarpetcleaning.co.nz/'
            },
            'youngpros': {
                name: 'YoungPros Construction', initials: 'YP', category: 'real-estate-construction',
                industry: 'Residential Framing Contractor', client: 'YoungPros Construction Ltd', location: 'Vancouver Island & Lower Mainland, BC',
                description: 'A B2B-facing site for a residential framing contractor serving builders and developers, featuring animated project-count and experience stat counters, a categorized project showcase (garages, single-family homes, ADUs, decks, stairs), and a clear four-step delivery method.',
                tags: ['B2B-Focused Positioning', 'Project Type Showcase', 'Animated Stat Counters'],
                liveUrl: 'https://youngprosconstruction.ca/'
            },
            'realtor-jaskaur': {
                name: 'Realtor Jaskaur', initials: 'JK', category: 'real-estate-construction',
                industry: 'Real Estate — Buyer Specialist', client: 'Jas Kaur, REALTOR®', location: 'Brampton, ON',
                description: 'A personal brand site for a first-time-buyer specialist REALTOR®, anchored by a downloadable First-Time Home Buyer Guide as a lead magnet, an FAQ accordion walking through the Ontario buying process step by step, and a testimonial carousel from real closed clients.',
                tags: ['Lead Magnet (Downloadable Guide)', 'Educational FAQ Accordion', 'Personal Brand Positioning'],
                liveUrl: 'https://realtorjaskaur.com/'
            },
            'brothers-furnace': {
                name: 'Brothers Furnace & Duct Cleaning', initials: 'BF', category: 'home-services',
                industry: 'Furnace, Duct & Dryer Vent Cleaning', client: 'Brothers Furnace & Duct Cleaning', location: 'Calgary & Airdrie, AB',
                description: 'A furnace and duct cleaning site covering six Alberta service areas, with a clear three-step process (schedule, inspect, clean) and an extensive testimonial wall — built to convert a low-frequency, trust-dependent home service into repeat bookings.',
                tags: ['Multi-City Service Area Pages', 'Process Explainer', 'Testimonial Wall'],
                liveUrl: 'https://brothersfurnaceandductcleaning.ca/'
            },
            'elite-funding': {
                name: 'Elite Funding', initials: 'EF', category: 'security-finance',
                industry: 'Truck & Business Loan Brokerage', client: 'Elite Funding', location: 'Mississauga, ON',
                description: 'A commercial lending site structured around four distinct financing products — Truck Loan & Leasing, Business Loan, Equipment Financing, and Working Capital — each with its own page and mega-menu navigation, built for owner-operators and growing businesses across Canada.',
                tags: ['Mega-Menu Navigation', 'Multi-Product Architecture', 'Lead Quote Form'],
                liveUrl: 'https://elitefunding.ca/'
            },
            'openaer': {
                name: 'OpenAer Towing', initials: 'OA', category: 'logistics',
                industry: '24/7 Towing & Roadside Assistance', client: 'OpenAer', location: 'Surrey & Fraser Valley, BC',
                description: 'A 24/7 towing and roadside assistance site built heavily around local SEO — five core services, a five-city service area, and an extensive FAQ block addressing pricing, response time, and coverage, aimed squarely at high-urgency "near me" search intent.',
                tags: ['Local SEO Architecture', 'FAQ-Driven Content', 'Emergency-Intent Optimized'],
                liveUrl: 'https://openaer.ca/'
            },
            'blue-stallion': {
                name: 'Blue Stallion Logistics', initials: 'BS', category: 'logistics',
                industry: 'Refrigerated Trucking & 3PL', client: 'Blue Stallion Logistics', location: 'Winnipeg, MB',
                description: 'A 3PL and refrigerated trucking site explaining a four-stage fulfillment cycle (inbound logistics, order integration, fulfillment execution, tracking), with an expandable FAQ covering TDG certification and service area — built to make a technical B2B service legible to a non-logistics buyer.',
                tags: ['Process Visualization', 'Expandable FAQ', 'B2B Trust Signals'],
                liveUrl: 'https://bluestallionlogistics.com/'
            },
            'east-kootenay-security': {
                name: 'East Kootenay Security', initials: 'EK', category: 'security-finance',
                industry: 'Commercial Security Services', client: 'East Kootenay Security Group Ltd', location: 'Cranbrook, BC',
                description: 'A commercial security services site covering four distinct offerings — Mobile Patrols & Rapid Response, Commercial & Industrial Site Security, Advanced CCTV & Remote Monitoring, and Loss Prevention — each with its own page, built to serve clients across BC, Canada, and the USA.',
                tags: ['Multi-Service Pages', 'WhatsApp CTA', 'Cross-Border Positioning'],
                liveUrl: 'https://eastkootenaysecurity.com/'
            }
        };

        const grid = document.getElementById('portfolio-grid');
        const MONITOR_ICON = '<svg viewBox="0 0 24 24"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>';
        const PHONE_ICON = '<svg viewBox="0 0 24 24"><rect x="7" y="2" width="10" height="20" rx="2"/><line x1="11" y1="18" x2="13" y2="18"/></svg>';
        function domainOf(url) { try { return new URL(url).hostname.replace('www.', ''); } catch (e) { return url; } }
        function renderGrid() {
            grid.innerHTML = Object.entries(projectData).map(([id, p]) => `
                <button class="portfolio-item interactive-card cat-${p.category} fade-in visible" data-category="${p.category}" onclick="openModal('${id}')">
                    <div class="portfolio-bg">
                        <div class="browser-chrome">
                            <span class="browser-dots"><span class="browser-dot"></span><span class="browser-dot"></span><span class="browser-dot"></span></span>
                            <span class="browser-url">${domainOf(p.liveUrl)}</span>
                        </div>
                        <div class="portfolio-bg-text">${p.initials}</div>
                    </div>
                    <span class="portfolio-cat-tag">${p.industry}</span>
                    <div class="device-badges">
                        <span class="device-badge" title="Desktop-optimized">${MONITOR_ICON}</span>
                        <span class="device-badge" title="Mobile-optimized">${PHONE_ICON}</span>
                    </div>
                    <div class="portfolio-overlay">
                        <h3>${p.name}</h3>
                        <p>${p.location}</p>
                    </div>
                </button>
            `).join('');
            bindCursorElements();
        }
        renderGrid();

        const urlParams = new URLSearchParams(window.location.search);

        // Embed mode: used when this page is loaded inside an iframe on a service page's pricing card.
        // All 13 case studies are real website builds, so every service page shows the full set —
        // there's no meaningful per-service subset to pre-filter to.
        if (urlParams.get('embed') === '1') {
            document.body.classList.add('embed-mode');
        }

        const filterBtns = document.querySelectorAll('.filter-btn');
        function applyFilter(filter) {
            document.querySelectorAll('.portfolio-item').forEach(item => {
                item.classList.toggle('hidden', filter !== 'all' && item.getAttribute('data-category') !== filter);
            });
        }
        filterBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                filterBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                applyFilter(btn.getAttribute('data-filter'));
            });
        });

        // Modal
        const modalOverlay = document.getElementById('modal-overlay');
        const modalBody = document.getElementById('modal-body');
        window.openModal = function(id) {
            const p = projectData[id];
            if (!p) return;
            const domain = domainOf(p.liveUrl);
            modalBody.innerHTML = `
                <div class="modal-body-inner">
                    <h3>${p.name}</h3>
                    <p style="color: var(--brand-gold); font-size: 0.8rem; text-transform: uppercase; letter-spacing: 2px; margin-bottom: 0;">${p.industry}</p>
                    <div class="modal-device-row">
                        <span class="modal-device-chip">${MONITOR_ICON} Desktop-optimized</span>
                        <span class="modal-device-chip">${PHONE_ICON} Mobile-optimized</span>
                    </div>
                    <div class="modal-project-meta">
                        <div><span class="meta-label">Client</span><span class="meta-value">${p.client}</span></div>
                        <div><span class="meta-label">Location</span><span class="meta-value">${p.location}</span></div>
                    </div>
                    <p>${p.description}</p>
                    <div class="modal-tag-list">${p.tags.map(t => `<span class="modal-tag">${t}</span>`).join('')}</div>
                    <div style="margin-top: 2rem; display: flex; gap: 1rem; flex-wrap: wrap;">
                        <a href="${p.liveUrl}" target="_blank" rel="noopener" class="btn-outline interactive-el">Visit Live Site →</a>
                        <a href="/#contact" class="btn-primary interactive-el">Start a Similar Project</a>
                    </div>
                </div>
            `;
            document.getElementById('modal-domain').textContent = domain;
            modalOverlay.classList.add('active');
            document.body.style.overflow = 'hidden';
            window.trackConversion('portfolio_view', { project: id });
            bindCursorElements();
        };
        function closeModal() { modalOverlay.classList.remove('active'); document.body.style.overflow = ''; }
        document.getElementById('close-modal-btn').addEventListener('click', closeModal);
        modalOverlay.addEventListener('click', (e) => { if (e.target === modalOverlay) closeModal(); });
        document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });

        // Theme
        const themeToggleBtn = document.getElementById('theme-toggle');
        const currentTheme = localStorage.getItem('theme');
        if (currentTheme === 'light') { document.body.classList.add('light-mode'); if (themeToggleBtn) themeToggleBtn.innerText = '☾'; }
        if (themeToggleBtn) themeToggleBtn.addEventListener('click', () => {
            document.body.classList.toggle('light-mode');
            if (document.body.classList.contains('light-mode')) { themeToggleBtn.innerText = '☾'; localStorage.setItem('theme', 'light'); checkCanvas(); }
            else { themeToggleBtn.innerText = '☼'; localStorage.setItem('theme', 'dark'); checkCanvas(); }
        });

        // Cursor
        const cursorDot = document.querySelector('.cursor-dot');
        const cursorOutline = document.querySelector('.cursor-outline');
        window.addEventListener('mousemove', (e) => {
            document.documentElement.classList.add('cursor-ready');
            cursorDot.style.left = `${e.clientX}px`; cursorDot.style.top = `${e.clientY}px`;
            cursorOutline.animate({ left: `${e.clientX}px`, top: `${e.clientY}px` }, { duration: 300, fill: "forwards" });
        });
        function bindCursorElements() {
            document.querySelectorAll('a, button, .interactive-el, .interactive-card').forEach(el => {
                if (el._cursorBound) return;
                el._cursorBound = true;
                el.addEventListener('mouseenter', () => {
                    cursorOutline.style.transform = 'translate(-50%, -50%) scale(1.5)';
                    cursorOutline.style.backgroundColor = document.body.classList.contains('light-mode') ? 'rgba(0,0,0,0.05)' : 'rgba(255,255,255,0.05)';
                    cursorDot.style.opacity = '0';
                });
                el.addEventListener('mouseleave', () => {
                    cursorOutline.style.transform = 'translate(-50%, -50%) scale(1)';
                    cursorOutline.style.backgroundColor = 'transparent'; cursorDot.style.opacity = '1';
                });
            });
        }

        // Scroll + fade-in
        const navbar = document.querySelector('.navbar');
        window.addEventListener('scroll', () => {
            if (document.documentElement.scrollTop > 50) navbar.classList.add('scrolled');
            else navbar.classList.remove('scrolled');
            document.querySelectorAll('.fade-in').forEach(el => {
                if (el.getBoundingClientRect().top < window.innerHeight - 80) el.classList.add('visible');
            });
        });
        window.dispatchEvent(new Event('scroll'));

        // Animated background canvas (dark mode only)
        const canvas = document.getElementById('bg-canvas');
        const ctx = (canvas && canvas.getContext) ? canvas.getContext('2d') : null;
        let particles = [], w, h, animationId;
        function resize() { w = canvas.width = window.innerWidth; h = canvas.height = window.innerHeight; }
        resize(); window.addEventListener('resize', resize);
        function createParticles() {
            const count = Math.min(Math.floor(w / 18), 70);
            particles = [];
            for (let i = 0; i < count; i++) {
                particles.push({ x: Math.random()*w, y: Math.random()*h, r: Math.random()*1.8+0.4, vy: -(Math.random()*0.4+0.1), vx: (Math.random()-0.5)*0.2, alpha: Math.random()*0.5+0.1, pulse: Math.random()*Math.PI*2, pulseSpeed: Math.random()*0.02+0.005 });
            }
        }
        createParticles();
        function animate() {
            if (!ctx) return;
            ctx.clearRect(0,0,w,h);
            particles.forEach(p => {
                p.y += p.vy; p.x += p.vx; p.pulse += p.pulseSpeed;
                const pulseAlpha = p.alpha * (0.5 + 0.5 * Math.sin(p.pulse));
                if (p.y < -10) { p.y = h+10; p.x = Math.random()*w; }
                if (p.x < -10) p.x = w+10; if (p.x > w+10) p.x = -10;
                const gradient = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r*6);
                gradient.addColorStop(0, `rgba(233,196,111,${pulseAlpha})`);
                gradient.addColorStop(1, 'rgba(233,196,111,0)');
                ctx.fillStyle = gradient; ctx.beginPath(); ctx.arc(p.x, p.y, p.r*6, 0, Math.PI*2); ctx.fill();
                ctx.fillStyle = `rgba(233,196,111,${pulseAlpha*1.5})`; ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI*2); ctx.fill();
            });
            animationId = requestAnimationFrame(animate);
        }
        function checkCanvas() {
            if (document.body.classList.contains('light-mode')) { if (animationId) { cancelAnimationFrame(animationId); animationId = null; if (ctx) ctx.clearRect(0,0,w,h); } }
            else if (!animationId) animate();
        }
        if (ctx) checkCanvas();
    </script>

 <?php include '../footer.php';?>
       <script src="../assets/js/script.js"></script>

</body>
</html>
