<?php
// Contact form handler - Graphinxt
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: https://graphinxt.com/");
    exit;
}

$name    = strip_tags(trim($_POST["name"] ?? ""));
$email   = strip_tags(trim($_POST["email"] ?? ""));
$company = strip_tags(trim($_POST["company"] ?? ""));
$service = strip_tags(trim($_POST["service"] ?? ""));
$message = strip_tags(trim($_POST["message"] ?? ""));

// Basic header-injection protection
$name  = str_replace(array("\r", "\n"), " ", $name);
$email = str_replace(array("\r", "\n"), " ", $email);

$to      = "graphinxtmarketing@gmail.com, graphinxtwebdevelopments@gmail.com, reach@graphinxt.com, graphinxt@gmail.com";
$subject = "New Website Enquiry - Graphinxt";

$body  = "You have received a new enquiry from the website contact form.\n\n";
$body .= "Name: " . $name . "\n";
$body .= "Email: " . $email . "\n";
$body .= "Company: " . $company . "\n\n";
$body .= "service: " . $service . "\n\n";
$body .= "Message:\n" . $message . "\n";

$headers  = "From: Graphinxt <reach@graphinxt.com>\r\n";
if ($email !== "" && filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $headers .= "Reply-To: " . $email . "\r\n";
}
$headers .= "X-Mailer: PHP/" . phpversion();

mail($to, $subject, $body, $headers);

header("Location: /thank-you/");
exit;
