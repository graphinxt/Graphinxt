<?php
// Contact / Appointment form handler - Hoor Aesthetics
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: /");
    exit;
}

$name    = strip_tags(trim($_POST["name"] ?? ""));
$email   = strip_tags(trim($_POST["email"] ?? ""));
$company   = strip_tags(trim($_POST["company"] ?? ""));
$phone   = strip_tags(trim($_POST["phone-number"] ?? ""));
$service = strip_tags(trim($_POST["service"] ?? ""));
$message = strip_tags(trim($_POST["message"] ?? ""));

// Basic header-injection protection
$name  = str_replace(array("\r", "\n"), " ", $name);
$email = str_replace(array("\r", "\n"), " ", $email);

$to      = "graphinxt@gmail.com, reach@graphinxt.com";
$subject = "New Website Enquiry - Graphinxt";

$body  = "You have received a new enquiry from the website.\n\n";
$body .= "Full Name: " . $name . "\n";
$body .= "Email: " . $email . "\n";
$body .= "Company: " . $company . "\n\n";
$body .= "Phone: " . $phone . "\n";
$body .= "Service: " . $service . "\n\n";
$body .= "Message:\n" . $message . "\n";

$headers  = "From: Graphinxt <reach@graphinxt.com>\r\n";
if ($email !== "" && filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $headers .= "Reply-To: " . $email . "\r\n";
}
$headers .= "X-Mailer: PHP/" . phpversion();

mail($to, $subject, $body, $headers);

header("Location: /thank-you/");
exit;
