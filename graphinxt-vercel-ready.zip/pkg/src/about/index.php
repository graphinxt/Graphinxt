<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Graphinxt — Digital Growth Studio</title>
    <meta name="description" content="Graphinxt is an AI-powered business growth partner serving the UK, USA, Canada, Australia & New Zealand. Meet the studio behind the work.">
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="https://graphinxt.com/about">
    <meta property="og:site_name" content="Graphinxt">
    <meta property="og:type" content="website">
   <link rel="stylesheet" href="../assets/style.css">
  <link rel="stylesheet" href="../assets/header.css">
   <link rel="shortcut icon" href="../assets/favicon.ico" type="image/x-icon">
        <link rel="icon" href="../assets/favicon.ico" type="image/x-icon">

    <meta property="og:title" content="About Graphinxt — Digital Architecture Studio">
    <meta property="og:description" content="A distributed digital architecture studio serving enterprise clients across the UK, USA, Canada, Australia, and New Zealand.">
    <meta property="og:url" content="https://graphinxt.com/about">
    <meta property="og:image" content="https://graphinxt.com/assets/og-cover.jpg">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:image" content="https://graphinxt.com/assets/og-cover.jpg">
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='14' fill='%23363638'/%3E%3Ctext x='32' y='44' font-family='Georgia, serif' font-size='36' font-weight='800' fill='%23e9c46f' text-anchor='middle'%3EG%3C/text%3E%3C/svg%3E">
            <script src="https://cdn.jsdelivr.net/npm/@emailjs/browser@4/dist/email.min.js"></script>

    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@200;300;400;500;800&display=swap" rel="stylesheet">

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "AboutPage",
      "url": "https://graphinxt.com/about",
      "mainEntity": {
        "@type": "ProfessionalService",
        "name": "Graphinxt",
        "alternateName": "Graphinxt Digital Content Creator FZ LLC",
        "url": "https://graphinxt.com/",
        "description": "A digital architecture studio delivering web engineering, brand identity, AI solutions, and regional marketing for enterprise clients across the UK, USA, Canada, Australia, and New Zealand.",
        "address": { "@type": "PostalAddress", "addressLocality": "Ras Al Khaimah", "addressCountry": "AE" },
        "areaServed": [
          { "@type": "Country", "name": "United States" }, { "@type": "Country", "name": "United Kingdom" },
          { "@type": "Country", "name": "Canada" }, { "@type": "Country", "name": "Australia" }, { "@type": "Country", "name": "New Zealand" }
        ]
      }
    }
    </script>
      <!-- Structured Data: FAQPage (mirrors the visible FAQ section, for AI/answer-engine surfacing) -->
        <script type="application/ld+json">
        {
          "@context": "https://schema.org",
          "@type": "FAQPage",
          "mainEntity": [
            {
              "@type": "Question",
              "name": "What is the typical project timeline?",
              "acceptedAnswer": { "@type": "Answer", "text": "Project timelines vary based on scope and complexity. A standard web platform typically takes 4–8 weeks, while comprehensive enterprise systems with AI integration can span 12–20 weeks." }
            },
            {
              "@type": "Question",
              "name": "Do you work with clients internationally?",
              "acceptedAnswer": { "@type": "Answer", "text": "Yes. Graphinxt operates across the USA, Canada, the UK, New Zealand, and Australia, with active nodes in New York, Toronto, London, Auckland, and Sydney, supporting asynchronous collaboration across time zones." }
            },
            {
              "@type": "Question",
              "name": "How much does a website or digital marketing project cost in the UK, USA, Canada, Australia, or New Zealand?",
              "acceptedAnswer": { "@type": "Answer", "text": "Graphinxt prices in USD and converts to local currency, so quotes are consistent whether a client is based in the UK, USA, Canada, Australia, or New Zealand. Web platforms typically start around $1,500, enterprise systems with AI integration can exceed $10,000, and paid media management starts around $500/month. Every quote is scoped to the specific market and project." }
            },
            {
              "@type": "Question",
              "name": "How does the Marketing Architect engine work?",
              "acceptedAnswer": { "@type": "Answer", "text": "The Marketing Architect uses predictive modeling to simulate ad performance across Meta, Google, and TikTok. It factors in industry, location, keywords, and budget to project CPC, click volume, and acquisition curves in real time." }
            },
            {
              "@type": "Question",
              "name": "What happens after launch?",
              "acceptedAnswer": { "@type": "Answer", "text": "Launch is the beginning of an ongoing optimization retainer that includes performance monitoring, A/B testing, SEO refinement, and iterative feature development." }
            },
            {
              "@type": "Question",
              "name": "Can you integrate with our existing systems?",
              "acceptedAnswer": { "@type": "Answer", "text": "Yes. The engineering team specializes in API integrations, data migrations, and legacy system modernization across Shopify, Salesforce, custom ERPs, and proprietary platforms." }
            },
            {
              "@type": "Question",
              "name": "Do you offer AI-powered chatbots and assistants?",
              "acceptedAnswer": { "@type": "Answer", "text": "Yes. The Graphinxt AI service line delivers custom-trained LLM assistants for customer support, lead qualification, and internal knowledge retrieval, tailored to a client's brand voice and data." }
            }
          ]
        }
        </script>

      

<!-- ===== ANALYTICS & CONVERSION TRACKING ===== -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-58PYC27MPE"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-58PYC27MPE');
</script>
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '2162187584315430');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=2162187584315430&ev=PageView&noscript=1" /></noscript>
<script>
  window.trackConversion = function(eventName, params) {
    params = params || {};
    try { if (typeof gtag === 'function') gtag('event', eventName, params); } catch(e) {}
    try { if (typeof fbq === 'function') fbq('trackCustom', eventName, params); } catch(e) {}
  };
  document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('a[href*="wa.me"]').forEach(function(el) {
      el.addEventListener('click', function() { window.trackConversion('whatsapp_click', { page: window.location.pathname }); });
    });
  });
</script>
<!-- ===== END ANALYTICS ===== -->

    <style>
     /*   :root {
            --bg-dark: #363638; --bg-darker: #2a2a2c; --brand-gold: #e9c46f; --brand-gold-hover: #d4ae58;
            --text-main: #ffffff; --text-muted: #a1a1a5; --card-bg: rgba(255,255,255,0.02);
            --border-light: rgba(233,196,111,0.12); --border-glow: rgba(233,196,111,0.4);
            --nav-bg: rgba(42,42,44,0.4); --nav-bg-scrolled: rgba(30,30,32,0.8);
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Montserrat', sans-serif; scroll-behavior: smooth; }
        a:focus-visible, button:focus-visible, [tabindex]:focus-visible { outline: 2px solid var(--brand-gold); outline-offset: 3px; border-radius: 4px; }
        body { background: var(--bg-dark); color: var(--text-main); line-height: 1.6; overflow-x: hidden; }
        h1, h2, h3, .logo { font-weight: 800; }

        #bg-canvas { position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; z-index: 0; pointer-events: none; }
        body.light-mode #bg-canvas { display: none; }
        .ambient-glow { position: fixed; width: 60vw; height: 60vw; border-radius: 50%; background: radial-gradient(circle, var(--brand-gold) 0%, transparent 70%); top: -30vw; left: 20vw; opacity: 0.1; filter: blur(140px); pointer-events: none; z-index: 0; }
*/
     /*   .navbar { display: flex; justify-content: space-between; align-items: center; padding: 1rem 2rem; position: fixed; width: 90%; max-width: 1200px; top: 2rem; left: 50%; transform: translateX(-50%); z-index: 9990; background: var(--nav-bg); backdrop-filter: blur(24px); border: 1px solid var(--border-light); border-radius: 50px; box-shadow: 0 20px 40px rgba(0,0,0,0.1); }
        .navbar.scrolled { top: 1rem; width: 95%; background: var(--nav-bg-scrolled); border-color: var(--border-glow); }
        .logo { font-size: 1.4rem; text-decoration: none; color: var(--text-main); }
        .accent-dot { color: var(--brand-gold); }
        .nav-links { display: flex; gap: 2rem; list-style: none; }
        .nav-links a { text-decoration: none; font-size: 0.78rem; font-weight: 500; text-transform: uppercase; letter-spacing: 1px; color: var(--text-main); }
        .nav-links a:hover, .nav-links a.active { color: var(--brand-gold); }
        @media(max-width: 760px) { .nav-links { display: none; } }
*/
        .btn-primary { background: #fff; color: var(--bg-dark) !important; padding: 0.9rem 2.2rem; border-radius: 30px; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; text-decoration: none; display: inline-block; font-size: 0.78rem; border: none; transition: all .3s; }
        .btn-primary:hover { background: var(--brand-gold); color: #fff !important; transform: scale(1.05); }
        .btn-outline { background: transparent; color: var(--brand-gold); padding: 0.9rem 2.2rem; border-radius: 30px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; text-decoration: none; border: 1px solid var(--border-light); display: inline-block; font-size: 0.76rem; transition: all .3s; }
        .btn-outline:hover { border-color: var(--brand-gold); }

        section { padding: 5rem 5%; max-width: 1100px; margin: 0 auto; position: relative; z-index: 1; }
        .hero-sec { padding-top: 14rem; text-align: center; }
        .eyebrow { font-size: 0.75rem; color: var(--brand-gold); text-transform: uppercase; letter-spacing: 3px; margin-bottom: 1.2rem; display: inline-block; }
        .hero-sec h1 { font-size: clamp(2rem, 5vw, 3.4rem); font-weight: 200; line-height: 1.15; margin-bottom: 1.2rem; }
        .hero-sec h1 strong { font-weight:800; background:linear-gradient(to right,#ffffff,var(--brand-gold)); -webkit-background-clip:text; background-clip:text; -webkit-text-fill-color:transparent; color:var(--brand-gold); }
        .hero-sec p { color: var(--text-muted); max-width: 620px; margin: 0 auto; font-weight: 300; }

        .origin-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 4rem; align-items: start; }
        .origin-grid p { color: var(--text-muted); margin-bottom: 1.2rem; font-size: 0.92rem; font-weight: 300; }
        .origin-grid p strong { color: var(--text-main); font-weight: 600; }
        .coord-card { background: var(--card-bg); border: 1px solid var(--border-light); border-radius: 20px; padding: 2rem; font-family: monospace; font-size: 0.8rem; }
        .coord-card .row { display: flex; justify-content: space-between; padding: 0.7rem 0; border-bottom: 1px dashed var(--border-light); }
        .coord-card .row:last-child { border-bottom: none; }
        .coord-card .row span:first-child { color: var(--text-muted); }
        .coord-card .row span:last-child { color: var(--brand-gold); text-align: right; max-width: 60%; }
        @media(max-width: 860px) { .origin-grid { grid-template-columns: 1fr; gap: 2rem; } }

        .section-header { text-align: center; max-width: 620px; margin: 0 auto 3rem; }
        .section-header h2 { font-size: clamp(1.6rem, 3.5vw, 2.4rem); font-weight: 200; }
        .section-header h2 strong { color: var(--brand-gold); font-weight: 800; }
        .section-header p { color: var(--text-muted); margin-top: 0.6rem; font-weight: 300; }

        .values-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px,1fr)); gap: 1.2rem; }
        .value-card { background: var(--card-bg); border: 1px solid var(--border-light); border-radius: 18px; padding: 1.8rem; }
        .value-card .num { font-family: monospace; font-size: 0.72rem; color: var(--brand-gold); margin-bottom: 0.8rem; }
        .value-card h3 { font-size: 1.05rem; margin-bottom: 0.5rem; font-weight: 500; }
        .value-card p { color: var(--text-muted); font-size: 0.82rem; font-weight: 300; }

        .node-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(140px,1fr)); gap: 1rem; }
        .node-card { background: var(--card-bg); border: 1px solid var(--border-light); border-radius: 16px; padding: 1.4rem; text-align: center; }
        .node-card .city { font-weight: 700; }
        .node-card .region { font-size: 0.72rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1px; margin-top: 0.3rem; }

        .cta-final { text-align: center; background: linear-gradient(135deg, rgba(233,196,111,0.08), transparent); border: 1px solid var(--border-glow); border-radius: 24px; padding: 3.5rem 2rem; }
        .cta-final h2 { font-size: clamp(1.6rem, 3.5vw, 2.4rem); font-weight: 200; margin-bottom: 1rem; }
        .cta-final h2 strong { color: var(--brand-gold); font-weight: 800; }
        .cta-final p { color: var(--text-muted); margin-bottom: 1.8rem; font-weight: 300; }
        .cta-row { display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap; }

        footer { padding: 4rem 5%; text-align: center; border-top: 1px solid var(--border-light); color: var(--text-muted); font-size: 0.8rem; }
        footer a { color: var(--brand-gold); text-decoration: none; }
        /* ===== VISION & MISSION ===== */
        #vision-mission { padding-top: 2rem; }
        .slogan-block { text-align: center; max-width: 760px; margin: 0 auto 3.5rem; position: relative; }
        .slogan-mark { font-family: Georgia, serif; font-size: 6rem; line-height: 0.6; color: var(--brand-gold); opacity: 0.22; margin-bottom: 0.4rem; }
        .slogan { font-size: clamp(2rem, 5.5vw, 3.6rem); font-weight: 200; line-height: 1.1; letter-spacing: -1px; margin-bottom: 1.2rem; }
        .slogan span { display: inline-block; font-weight: 800; background: linear-gradient(to right, #ffffff, var(--brand-gold)); -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent; color: var(--brand-gold); }
        .slogan-sub { font-size: 0.9rem; color: var(--text-muted); font-weight: 300; font-style: italic; }
        .vm-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1.6rem; margin-bottom: 3rem; }
        @media (max-width: 860px) { .vm-grid { grid-template-columns: 1fr; } }
        .vm-card { background: rgba(255,255,255,0.02); border: 1px solid var(--border-light); border-radius: 24px; padding: 2.4rem; position: relative; transition: all 0.35s ease; }
        .vm-card:hover { border-color: var(--brand-gold); transform: translateY(-4px); }
        .vm-card-accent { background: linear-gradient(150deg, rgba(233,196,111,0.08), rgba(233,196,111,0.01)); border-color: var(--border-glow); }
        .vm-icon { font-size: 1.4rem; color: var(--brand-gold); margin-bottom: 1rem; opacity: 0.85; }
        .vm-label { font-size: 0.66rem; text-transform: uppercase; letter-spacing: 2.5px; color: var(--brand-gold); font-weight: 700; display: block; margin-bottom: 0.9rem; }
        .vm-card h3 { font-size: clamp(1.15rem, 2.2vw, 1.42rem); font-weight: 800; line-height: 1.32; margin-bottom: 1.1rem; }
        .vm-card p { font-size: 0.9rem; color: var(--text-muted); font-weight: 300; line-height: 1.75; margin-bottom: 0.9rem; }
        .vm-card p:last-child { margin-bottom: 0; }
        .values-strip { display: grid; grid-template-columns: repeat(auto-fit, minmax(215px, 1fr)); gap: 1.2rem; padding: 2.2rem 0; border-top: 1px solid var(--border-light); border-bottom: 1px solid var(--border-light); }
        .value-item { position: relative; padding-left: 2.6rem; }
        .value-num { position: absolute; left: 0; top: -2px; font-size: 0.86rem; font-weight: 800; color: var(--brand-gold); opacity: 0.55; letter-spacing: -0.5px; }
        .value-item h4 { font-size: 0.92rem; font-weight: 600; margin-bottom: 0.4rem; }
        .value-item p { font-size: 0.8rem; color: var(--text-muted); font-weight: 300; line-height: 1.6; }
        .vm-cta { text-align: center; margin-top: 2.6rem; }
        .vm-cta p { font-size: 1.02rem; color: var(--text-main); font-weight: 200; margin-bottom: 1.2rem; }
        .btn-vm { display: inline-block; background: var(--brand-gold); color: var(--bg-dark); padding: 0.95rem 2.3rem; border-radius: 30px; font-weight: 800; font-size: 0.78rem; text-transform: uppercase; letter-spacing: 1px; text-decoration: none; transition: all 0.3s; }
        .btn-vm:hover { background: #fff; transform: scale(1.04); }
    </style>
</head>
<body>
    <canvas id="bg-canvas"></canvas>
    <div class="ambient-glow"></div>
       <?php include '../header.php';?>

    <header class="hero-sec">
        <span class="eyebrow">About Graphinxt</span>
        <h1>A digital architecture studio, <strong>built distributed.</strong></h1>
        <p>Web engineering, brand identity, and regional marketing under one roof — headquartered in Ras Al Khaimah, with active nodes across North America, the UK, and Oceania.</p>
    </header>

    <!-- VISION & MISSION -->
    <section id="vision-mission">
        <div class="slogan-block">
            <div class="slogan-mark">&ldquo;</div>
            <h2 class="slogan">Fearless Creativity<br><span>for the Next ERA</span></h2>
            <p class="slogan-sub">Not a line we printed on a mug. It's the standard we hold every project to.</p>
        </div>

        <div class="vm-grid">
            <div class="vm-card">
                <div class="vm-icon">&#9670;</div>
                <span class="vm-label">Our Vision</span>
                <h3>A world where ambitious businesses aren't outgunned by bigger budgets.</h3>
                <p>The next era of business won't be won by whoever spends most — it'll be won by whoever moves with the most clarity and courage. We're building the studio that gives small and mid-sized companies the same calibre of creative thinking, engineering, and intelligence that used to be reserved for enterprise clients.</p>
                <p>Fearless creativity means we don't hand you a safer version of what your competitor already did. It means telling you the truth about what's holding you back, then building the thing that actually moves you forward.</p>
            </div>

            <div class="vm-card vm-card-accent">
                <div class="vm-icon">&#9671;</div>
                <span class="vm-label">Our Mission</span>
                <h3>When we shake hands on a deal, we don't deliver a project. We build a brand.</h3>
                <p>Anyone can deliver files. Our commitment is different: from the moment a deal is made, we treat your business as a brand in the making — not a ticket to close. The website, the identity, the campaigns, and the content all pull in one direction, because they're designed as one system.</p>
                <p>A logo isn't a brand. A website isn't a brand. A brand is what people believe about you before you've spoken. Our job is to make that belief unmistakable — and then make it profitable.</p>
            </div>
        </div>

        <div class="values-strip">
            <div class="value-item">
                <span class="value-num">01</span>
                <h4>Truth over comfort</h4>
                <p>We'll tell you if an idea won't work. A pleasant meeting that wastes your money isn't service.</p>
            </div>
            <div class="value-item">
                <span class="value-num">02</span>
                <h4>Systems, not deliverables</h4>
                <p>Every piece connects. Brand informs site, site informs campaigns, campaigns feed back into brand.</p>
            </div>
            <div class="value-item">
                <span class="value-num">03</span>
                <h4>Built to outlive the launch</h4>
                <p>We build what still works in year three, not what looks impressive in the handover meeting.</p>
            </div>
            <div class="value-item">
                <span class="value-num">04</span>
                <h4>Accountable to outcomes</h4>
                <p>Traffic, leads, revenue. We report the numbers that matter — including the uncomfortable ones.</p>
            </div>
        </div>

        <div class="vm-cta">
            <p>Ready to become a brand, not just a project?</p>
            <a href="/solutions" class="btn-vm">See How We Work Together →</a>
        </div>
    </section>

    <section>
        <div class="origin-grid">
            <div>
                <p>Graphinxt was built on a simple premise: most digital agencies hand off between disconnected specialists — a branding shop here, a dev shop there, a media buyer somewhere else. <strong>We built one studio that handles the whole system</strong>, from identity to infrastructure to acquisition.</p>
                <p>We operate as a distributed team, with people working across North America, the UK, and Oceania — meaning your project has real hands on it across most time zones, not just a single office's working hours.</p>
                <p>Today we build for home services companies, logistics operators, security firms, real estate agents, and healthcare providers across the UK, USA, Canada, Australia, and New Zealand — real client work you can see on our <a href="/portfolio" style="color:var(--brand-gold);">portfolio page</a>.</p>
            </div>
            <div class="coord-card">
                <div class="row"><span>Entity</span><span>Graphinxt Digital Content Creator FZ LLC</span></div>
                <div class="row"><span>HQ</span><span>Ras Al Khaimah, UAE</span></div>
                <div class="row"><span>Structure</span><span>Distributed / Async-first</span></div>
                <div class="row"><span>Regions Served</span><span>UK · USA · Canada · Australia · NZ</span></div>
                <div class="row"><span>Contact</span><span>reach@graphinxt.com</span></div>
            </div>
        </div>
    </section>

    <section>
        <div class="section-header">
            <span class="eyebrow">How We Work</span>
            <h2>Operating <strong>Principles</strong></h2>
        </div>
        <div class="values-grid">
            <div class="value-card">
                <div class="num">01 / DATA</div>
                <h3>Evidence over instinct</h3>
                <p>Recommendations are backed by real data — from real Core Web Vitals to live client performance — not house style.</p>
            </div>
            <div class="value-card">
                <div class="num">02 / SYSTEM</div>
                <h3>Built to extend</h3>
                <p>We design systems meant to grow with you, not get rebuilt every two years.</p>
            </div>
            <div class="value-card">
                <div class="num">03 / OWNERSHIP</div>
                <h3>One partner, no handoffs</h3>
                <p>Branding, engineering, and marketing sit inside the same studio — nothing gets lost in translation between vendors.</p>
            </div>
            <div class="value-card">
                <div class="num">04 / TRANSPARENCY</div>
                <h3>Plain-language reporting</h3>
                <p>No jargon-dense dashboards. Straight answers on what's working and what we're changing next.</p>
            </div>
            <div class="value-card">
                <div class="num">05 / HONESTY</div>
                <h3>We say what's real</h3>
                <p>If something's an estimate, we label it an estimate. If a feature needs infrastructure we don't have yet, we say so instead of faking it.</p>
            </div>
            <div class="value-card">
                <div class="num">06 / LONGEVITY</div>
                <h3>Built past launch</h3>
                <p>Launch is a milestone, not an ending — our work continues optimizing performance long after.</p>
            </div>
        </div>
    </section>

    <section>
        <div class="section-header">
            <span class="eyebrow">Global Network</span>
            <h2>Where We <strong>Work</strong></h2>
        </div>
        <div class="node-grid">
            <div class="node-card"><div class="city">New York</div><div class="region">USA</div></div>
            <div class="node-card"><div class="city">Toronto</div><div class="region">Canada</div></div>
            <div class="node-card"><div class="city">London</div><div class="region">UK</div></div>
            <div class="node-card"><div class="city">Auckland</div><div class="region">New Zealand</div></div>
            <div class="node-card"><div class="city">Sydney</div><div class="region">Australia</div></div>
        </div>
    </section>

    <section>
        <div class="cta-final">
            <h2>Want to see the <strong>real work</strong>?</h2>
            <p>13 real client sites, live and working — not mockups.</p>
            <div class="cta-row">
                <a href="/portfolio" class="btn-primary">View Portfolio</a>
                <a href="/#contact" class="btn-outline">Start a Project</a>
            </div>
        </div>
    </section>



<!-- Assistant Chatbot -->


 <?php include '../footer.php';?>
 <script src="../assets/js/script.js"></script>

</body>
</html>
