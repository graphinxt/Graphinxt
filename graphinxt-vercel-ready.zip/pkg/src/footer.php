
        <!-- Footer -->
        <footer>
        
        
                <!--<div class="newsletter-wrap fade-in">-->
                <!--        <h3 style="font-size: 1.5rem; font-weight: 300; margin-bottom: 0.5rem;">Stay Ahead of the Curve</h3>-->
                <!--        <p style="color: var(--text-muted); font-size: 0.9rem;">Get strategic insights and industry intelligence delivered monthly.</p>-->
                <!--        <form class="newsletter-form" id="newsletter-form">-->
                <!--                <input type="email" placeholder="Your email address" required class="interactive-el">-->
                <!--                <button type="submit" class="btn-primary interactive-el" style="font-size: 0.75rem; padding: 0.7rem 1.5rem;">Subscribe</button>-->
                <!--        </form>-->
                <!--        <div class="newsletter-success" id="newsletter-success">✓ You're subscribed. Welcome aboard.</div>-->
                <!--</div>-->

                <div class="footer-logo interactive-el">GRAPHINXT.</div>
                <p style="color: var(--text-muted); font-weight: 300;">Engineering digital excellence for visionary enterprises.</p>

                <div class="footer-social">
                        <a href="#" class="interactive-el" aria-label="LinkedIn"><svg viewBox="0 0 24 24"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg></a>
                        <a href="#" class="interactive-el" aria-label="Instagram"><svg viewBox="0 0 24 24"><rect x="2" y="2" width="20" height="20" rx="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg></a>
                        <a href="#" class="interactive-el" aria-label="Twitter"><svg viewBox="0 0 24 24"><path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"/></svg></a>
                        <a href="https://www.facebook.com/" target="_blank" class="interactive-el filled" aria-label="Facebook"><svg viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg></a>
                        <a href="https://wa.me/971564785139" target="_blank" class="interactive-el filled" aria-label="WhatsApp"><svg viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51l-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.247-.694.247-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg></a>
                </div>

                <div class="footer-links">
                        <a href="/services/" class="interactive-el">Services</a>
                        <a href="/portfolio/" class="interactive-el">Portfolio</a>
                        <a href="/about/" class="interactive-el">About</a>
                        <a href="/blog/" class="interactive-el">Insights</a>
                        <a href="/solutions/" class="interactive-el">Growth Solutions</a>
                        <a href="/tools/" class="interactive-el">Free AI Tools</a>
                        <a href="/startup-kit/" class="interactive-el">Startup Kit</a>
                        <a href="/website-check/" class="interactive-el">Website Check</a>
                        <a href="/uk-digital-agency/" class="interactive-el">UK Agency</a>
                        <a href="#contact" class="interactive-el">Contact</a>
                </div>

                <div class="footer-bottom">
                        <p>&copy; 2026 Graphinxt Digital Content Creator FZ LLC. All Rights Reserved.</p>
                        <p style="margin-top:0.6rem; font-size:0.72rem; opacity:0.7;">CWEP3588, Compass Building, Al Shohada Road, AL Hamra Industrial Zone-FZ, Ras Al Khaimah, UAE · reach@graphinxt.com · +971 56 478 5139</p>
                </div>
        
        <div style="margin-top:1rem;"><a href="/privacy/" style="color:var(--text-muted,#a1a1a5); font-size:0.72rem; text-transform:uppercase; letter-spacing:1px; text-decoration:none;">Privacy Policy</a></div>
    </footer>

        <!-- WhatsApp Floating Button -->
        <a href="https://wa.me/971564785139" target="_blank" class="whatsapp-float" aria-label="Chat on WhatsApp"><svg viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51l-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.247-.694.247-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg></a>
