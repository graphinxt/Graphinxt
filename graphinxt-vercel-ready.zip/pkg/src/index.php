<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!-- Primary SEO -->
        <title>Graphinxt — AI Web, Branding & Marketing Agency</title>
        <meta name="description" content="AI-powered web development, branding, and digital marketing for businesses in the UK, USA, Canada, Australia & New Zealand. Free tools & growth plans.">
        <meta name="robots" content="index, follow, max-image-preview:large">
        <link rel="canonical" href="https://graphinxt.com/">
        <link rel="stylesheet" href="assets/style.css">
        <link rel="stylesheet" href="assets/header.css">
        <link rel="shortcut icon" href="assets/favicon.ico" type="image/x-icon">
        <link rel="icon" href="assets/favicon.ico" type="image/x-icon">
        <!-- Open Graph -->
        <meta property="og:type" content="website">
        <meta property="og:site_name" content="Graphinxt">
        <meta property="og:title" content="Graphinxt | Web Development, Branding & Digital Marketing Agency">
        <meta property="og:description" content="Enterprise-grade web engineering, brand identity, and regional marketing for clients in the UK, USA, Canada, Australia, and New Zealand.">
        <meta property="og:url" content="https://graphinxt.com/">
        <meta property="og:image" content="https://graphinxt.com/assets/og-cover.jpg">
        <meta property="og:locale" content="en_US">
        <meta property="og:locale:alternate" content="en_GB">
        <meta property="og:locale:alternate" content="en_CA">
        <meta property="og:locale:alternate" content="en_AU">
        <meta property="og:locale:alternate" content="en_NZ">

        <!-- Twitter Card -->
        <meta name="twitter:card" content="summary_large_image">
        <meta name="twitter:title" content="Graphinxt | Web Development, Branding & Digital Marketing Agency">
        <meta name="twitter:description" content="Enterprise-grade web engineering, brand identity, and regional marketing for clients across the UK, USA, Canada, Australia, and New Zealand.">
        <meta name="twitter:image" content="https://graphinxt.com/assets/og-cover.jpg">

        <!-- Regional targeting: same page currently serves all five markets. -->
        <link rel="alternate" hreflang="en-us" href="https://graphinxt.com/">
        <link rel="alternate" hreflang="en-gb" href="https://graphinxt.com/">
        <link rel="alternate" hreflang="en-ca" href="https://graphinxt.com/">
        <link rel="alternate" hreflang="en-au" href="https://graphinxt.com/">
        <link rel="alternate" hreflang="en-nz" href="https://graphinxt.com/">
        <link rel="alternate" hreflang="x-default" href="https://graphinxt.com/">

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@200;300;400;500;800&display=swap" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/@emailjs/browser@4/dist/email.min.js"></script>

        <!-- Structured Data: Organization + ProfessionalService (5-country service area) -->
        <script type="application/ld+json">
        {
          "@context": "https://schema.org",
          "@type": "ProfessionalService",
          "@id": "https://graphinxt.com/#organization",
          "name": "Graphinxt",
          "alternateName": "Graphinxt Digital Content Creator FZ LLC",
          "url": "https://graphinxt.com/",
          "description": "Full-spectrum digital architecture studio delivering web engineering, brand identity, AI solutions, and regional marketing for enterprise clients across the UK, USA, Canada, Australia, and New Zealand.",
          "priceRange": "$$-$$$",
          "email": "reach@graphinxt.com",
          "telephone": "+971564785139",
          "address": {
            "@type": "PostalAddress",
            "streetAddress": "CWEP3588, Compass Building, Al Shohada Road, Al Hamra Industrial Zone-FZ",
            "addressLocality": "Ras Al Khaimah",
            "addressCountry": "AE"
          },
          "areaServed": [
            { "@type": "Country", "name": "United States" },
            { "@type": "Country", "name": "United Kingdom" },
            { "@type": "Country", "name": "Canada" },
            { "@type": "Country", "name": "Australia" },
            { "@type": "Country", "name": "New Zealand" }
          ],
          "hasOfferCatalog": {
            "@type": "OfferCatalog",
            "name": "Graphinxt Services",
            "itemListElement": [
              { "@type": "Offer", "itemOffered": { "@type": "Service", "name": "Web Development" } },
              { "@type": "Offer", "itemOffered": { "@type": "Service", "name": "App Development" } },
              { "@type": "Offer", "itemOffered": { "@type": "Service", "name": "Branding & Identity" } },
              { "@type": "Offer", "itemOffered": { "@type": "Service", "name": "Google Ads / Meta Ads Management" } },
              { "@type": "Offer", "itemOffered": { "@type": "Service", "name": "Social Media Management" } },
              { "@type": "Offer", "itemOffered": { "@type": "Service", "name": "SEO / Answer Engine Optimization" } },
              { "@type": "Offer", "itemOffered": { "@type": "Service", "name": "AI Solutions" } },
              { "@type": "Offer", "itemOffered": { "@type": "Service", "name": "Packaging Design" } },
              { "@type": "Offer", "itemOffered": { "@type": "Service", "name": "Video Editing" } },
              { "@type": "Offer", "itemOffered": { "@type": "Service", "name": "Game UI/UX" } }
            ]
          }
        }
        </script>

        <!-- Structured Data: FAQPage (mirrors the visible FAQ section, for AI/answer-engine surfacing) -->
        <script type="application/ld+json">
        {
          "@context": "https://schema.org",
          "@type": "FAQPage",
          "mainEntity": [
            {
              "@type": "Question",
              "name": "What is the typical project timeline?",
              "acceptedAnswer": { "@type": "Answer", "text": "Project timelines vary based on scope and complexity. A standard web platform typically takes 4–8 weeks, while comprehensive enterprise systems with AI integration can span 12–20 weeks." }
            },
            {
              "@type": "Question",
              "name": "Do you work with clients internationally?",
              "acceptedAnswer": { "@type": "Answer", "text": "Yes. Graphinxt operates across the USA, Canada, the UK, New Zealand, and Australia, with active nodes in New York, Toronto, London, Auckland, and Sydney, supporting asynchronous collaboration across time zones." }
            },
            {
              "@type": "Question",
              "name": "How much does a website or digital marketing project cost in the UK, USA, Canada, Australia, or New Zealand?",
              "acceptedAnswer": { "@type": "Answer", "text": "Graphinxt prices in USD and converts to local currency, so quotes are consistent whether a client is based in the UK, USA, Canada, Australia, or New Zealand. Web platforms typically start around $1,500, enterprise systems with AI integration can exceed $10,000, and paid media management starts around $500/month. Every quote is scoped to the specific market and project." }
            },
            {
              "@type": "Question",
              "name": "How does the Marketing Architect engine work?",
              "acceptedAnswer": { "@type": "Answer", "text": "The Marketing Architect uses predictive modeling to simulate ad performance across Meta, Google, and TikTok. It factors in industry, location, keywords, and budget to project CPC, click volume, and acquisition curves in real time." }
            },
            {
              "@type": "Question",
              "name": "What happens after launch?",
              "acceptedAnswer": { "@type": "Answer", "text": "Launch is the beginning of an ongoing optimization retainer that includes performance monitoring, A/B testing, SEO refinement, and iterative feature development." }
            },
            {
              "@type": "Question",
              "name": "Can you integrate with our existing systems?",
              "acceptedAnswer": { "@type": "Answer", "text": "Yes. The engineering team specializes in API integrations, data migrations, and legacy system modernization across Shopify, Salesforce, custom ERPs, and proprietary platforms." }
            },
            {
              "@type": "Question",
              "name": "Do you offer AI-powered chatbots and assistants?",
              "acceptedAnswer": { "@type": "Answer", "text": "Yes. The Graphinxt AI service line delivers custom-trained LLM assistants for customer support, lead qualification, and internal knowledge retrieval, tailored to a client's brand voice and data." }
            }
          ]
        }
        </script>

      

<!-- ===== ANALYTICS & CONVERSION TRACKING =====
     Replace G-58PYC27MPE with your real GA4 Measurement ID (analytics.google.com > Admin > Data Streams)
     Replace 2162187584315430 with your real Meta Pixel ID (business.facebook.com/events_manager > Data Sources)
     Until replaced, these load harmlessly but report no real data.
-->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-58PYC27MPE"></script>
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=2162187584315430&ev=PageView&noscript=1" /></noscript>
<!-- ===== END ANALYTICS ===== -->
</head>
<body>
       <?php include 'header.php';?>
        <!-- Ultra-Minimal Hero -->
        <header id="main-content" class="hero">
                <div class="hero-content fade-in">
                        <span class="subheading">Digital Architecture for Visionaries</span>
                        <h1>Architecting <br><strong>Global Excellence</strong></h1>
                        <p>Elevating enterprise brands across borders through elite Web Engineering, Identity Design, and Regional Marketing exclusively tailored for your business.</p>
                        <div class="hero-actions" style="margin-top: 3rem;">
                                <a href="#portfolio" class="btn-primary interactive-el">View Work</a>
                                <a href="#contact" class="btn-outline interactive-el">Start a Project</a>
                        </div>
                </div>
                <div class="scroll-indicator fade-in">
                        <span>Scroll</span>
                        <div class="scroll-mouse"></div>
                </div>
        </header>

        <!-- Infinite Marquee -->
        <div class="marquee-container">
                <div class="marquee-content">
                        <span>Web Engineering</span><span class="outline-text">Brand Identity</span><span>AI Solutions</span><span class="outline-text">Regional Marketing</span><span>E-Commerce</span><span class="outline-text">SEO Architecture</span><span>Web Engineering</span><span class="outline-text">Brand Identity</span><span>AI Solutions</span><span class="outline-text">Regional Marketing</span><span>E-Commerce</span><span class="outline-text">SEO Architecture</span>
                </div>
        </div>

        <!-- Free Marketing Demo Banner -->
        <section class="demo-banner-section fade-in">
                <div class="demo-banner">
                        <div class="demo-banner-content">
                                <span class="demo-banner-tag">🎉 Limited Time Offer</span>
                                <h3>Free 1-Month <strong>Marketing Demo</strong></h3>
                                <p>Experience our Google &amp; Meta Ads management free for 30 days — no management fee. You only cover the ad spend budget. Let us prove our architecture before you commit.</p>
                        </div>
                        <div class="demo-banner-cta">
                                <a href="/services/ads?enquire=1" class="btn-primary interactive-el" onclick="window.trackConversion && window.trackConversion('cta_click', {cta: 'free_demo'})">Claim Free Demo →</a>
                        </div>
                </div>
        </section>

        <!-- AI GROWTH LAB SECTION -->
        <section id="ai-lab" class="fade-in" style="padding: 8rem 5%;">
                <div class="section-header" style="text-align: center; margin-bottom: 4rem;">
                        <span class="snapshot-tag">The Workbench</span>
                        <h2>AI Growth <strong>Lab</strong></h2>
                        <p>Where predictive intelligence meets architectural precision.</p>
                </div>
                <div class="lab-grid">
                        <div class="lab-card interactive-card">
                                <span class="lab-tag">Predictive Engine</span>
                                <div class="lab-icon"><svg viewBox="0 0 24 24"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg></div>
                                <h3>Intent Modeling</h3>
                                <p>We simulate user intent across 140+ semantic clusters to predict conversion probability before a single ad is served.</p>
                        </div>
                        <div class="lab-card interactive-card">
                                <span class="lab-tag">AEO Framework</span>
                                <div class="lab-icon"><svg viewBox="0 0 24 24"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg></div>
                                <h3>Neural Authority</h3>
                                <p>Optimizing brand presence for the "Latent Space" of LLMs like ChatGPT, Claude, and Perplexity to ensure you are the first recommendation.</p>
                        </div>
                        <div class="lab-card interactive-card">
                                <span class="lab-tag">Autonomous Ops</span>
                                <div class="lab-icon"><svg viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg></div>
                                <h3>Revenue Pipelines</h3>
                                <p>Self-optimizing monetization engines that adjust ad-tech placements in real-time based on traffic quality and user behavior.</p>
                        </div>
                </div>
                <div style="text-align:center; margin-top:3rem;">
                        <a href="/tools" class="btn-outline interactive-el">Try Our Free AI Tools →</a>
                </div>
        </section>

        <!-- INSTANT SITE SNAPSHOT TOOL -->
        <section class="snapshot-section fade-in">
                <div class="snapshot-card">
                        <span class="snapshot-tag">Free Tool</span>
                        <h2>AI-Driven <strong style="color: var(--brand-gold);">Growth</strong> Diagnostic</h2>
                        <p>Experience our <strong>Neural Analysis Engine</strong>. Most websites fail because they aren't optimized for the new era of AI-driven search. Drop in your domain for a diagnostic across Performance, SEO, AEO-readiness, Mobile, Security, and AI Search Visibility.</p>

                        <div class="snapshot-input-row">
                                <input type="text" id="snapshot-input" class="snapshot-input interactive-el" placeholder="yourwebsite.com" autocomplete="off">
                                <button id="snapshot-btn" class="snapshot-btn interactive-el" onclick="runSnapshot()">Run Analysis →</button>
                        </div>
                        <div class="snapshot-hint">No signup. Instant results. Track traffic & revenue potential.</div>

                        <div class="snapshot-results" id="snapshot-results">
                                <div class="snapshot-top">
                                        <div class="snapshot-ring-wrap">
                                                <svg viewBox="0 0 120 120">
                                                        <circle class="snapshot-ring-bg" cx="60" cy="60" r="52"></circle>
                                                        <circle class="snapshot-ring-fill" id="snapshot-ring-fill" cx="60" cy="60" r="52" stroke-dasharray="327" stroke-dashoffset="327"></circle>
                                                </svg>
                                                <div class="snapshot-ring-label">
                                                        <div class="snapshot-ring-num" id="snapshot-ring-num">0</div>
                                                        <div class="snapshot-ring-sub">Overall</div>
                                                </div>
                                        </div>
                                        <div class="snapshot-verdict">
                                                <div class="domain-echo" id="snapshot-domain">—</div>
                                                <p id="snapshot-verdict-text">Analyzing...</p>
                                        </div>
                                </div>

                                <div class="snapshot-categories" id="snapshot-categories"></div>

                                <p class="snapshot-disclaimer">This is a heuristic preliminary snapshot based on your URL structure — not a full technical crawl. Our team runs the real audit (Core Web Vitals, live schema validation, competitor gap analysis) free when you book a call.</p>

                                <div class="snapshot-cta-row">
                                        <a href="javascript:void(0)" onclick="openStripeCheckout()" class="btn-primary interactive-el">Join Premium Monitoring Waitlist</a>
                                        <a href="#contact" class="btn-outline interactive-el">Book Free Full Audit</a>
                                </div>
                                
                                <div class="share-report-row" style="margin-top: 1.5rem; text-align: center;">
                                    <p style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 0.5rem;">Share this report with your team:</p>
                                    <div style="display: flex; justify-content: center; gap: 10px;">
                                        <input type="text" id="share-url" readonly style="background: rgba(255,255,255,0.05); border: 1px solid var(--border-light); color: var(--text-main); padding: 5px 10px; border-radius: 4px; font-size: 0.75rem; width: 250px;">
                                        <button onclick="copyShareUrl()" class="btn-outline interactive-el" style="padding: 5px 15px; font-size: 0.75rem;">Copy Link</button>
                                    </div>
                                </div>
                        </div>
                </div>
        </section>

        <!-- SLOGAN BAND -->
        <section id="slogan-band" class="fade-in">
                <div class="sb-inner">
                        <span class="sb-eyebrow">Our Promise</span>
                        <h2 class="sb-line">Fearless Creativity <span>for the Next ERA</span></h2>
                        <p class="sb-sub">When we shake hands on a deal, we don't deliver a project — we build a brand. <a href="/about#vision-mission">Read our vision &amp; mission →</a></p>
                </div>
        </section>

        <!-- SCROLL PROGRESS -->
        <div id="scroll-progress" aria-hidden="true"></div>

        <!-- SERVICES SECTION -->
        <section id="services">
                <div class="section-header fade-in">
                        <h2>Our <strong>Capabilities</strong></h2>
                        <p>Full-Spectrum Digital Architecture.</p>
                </div>
                <div class="services-grid">
                        <a href="services/branding" class="service-card fade-in interactive-card visible">
                                <span class="service-num">01</span>
                                <div class="service-icon"><svg viewBox="0 0 24 24"><path d="M12 2L2 7l10 5 10-5-10-5z"></path><path d="M2 17l10 5 10-5M2 12l10 5 10-5"></path></svg></div>
                                <h3>Branding</h3>
                                <p>Distinctive visual systems, logo architecture, and identity frameworks that command attention across every touchpoint.</p>
                                <span class="service-cta">View Details &amp; Pricing →</span>
                        </a>
                        <a href="services/web" class="service-card fade-in interactive-card visible">
                                <span class="service-num">02</span>
                                <div class="service-icon"><svg viewBox="0 0 24 24"><path d="M16 18l6-6-6-6M8 6l-6 6 6 6"></path></svg></div>
                                <h3>Web Development</h3>
                                <p>High-performance, scalable web platforms built with precision architecture and cutting-edge frameworks.</p>
                                <span class="service-cta">View Details &amp; Pricing →</span>
                        </a>
                        <a href="services/app" class="service-card fade-in interactive-card visible">
                                <span class="service-num">03</span>
                                <div class="service-icon"><svg viewBox="0 0 24 24"><rect x="5" y="2" width="14" height="20" rx="2"></rect><line x1="12" y1="18" x2="12" y2="18"></line></svg></div>
                                <h3>App Development</h3>
                                <p>Native iOS &amp; Android applications engineered for performance, scalability, and seamless user experience.</p>
                                <span class="service-cta">View Details &amp; Pricing →</span>
                        </a>
                        <a href="services/ads" class="service-card fade-in interactive-card visible">
                                <span class="service-num">04</span>
                                <div class="service-icon"><svg viewBox="0 0 24 24"><path d="M3 3v18h18"></path><path d="M7 14l4-4 4 4 6-6"></path></svg></div>
                                <h3>Google Ads / Meta Ads</h3>
                                <p>Predictive media modeling, hyper-local ad architecture, and multi-platform campaign orchestration for maximum ROI.</p>
                                <span style="display:inline-block; background:var(--brand-gold); color:var(--bg-dark); font-size:0.6rem; font-weight:800; padding:3px 10px; border-radius:10px; text-transform:uppercase; letter-spacing:1px; margin-bottom:0.75rem;">🎉 Free 1-Month Demo</span>
                                <span class="service-cta">View Details &amp; Pricing →</span>
                        </a>
                        <a href="services/social" class="service-card fade-in interactive-card visible">
                                <span class="service-num">05</span>
                                <div class="service-icon"><svg viewBox="0 0 24 24"><circle cx="18" cy="5" r="3"></circle><circle cx="6" cy="12" r="3"></circle><circle cx="18" cy="19" r="3"></circle><line x1="8.6" y1="13.5" x2="15.4" y2="17.5"></line><line x1="15.4" y1="6.5" x2="8.6" y2="10.5"></line></svg></div>
                                <h3>Social Media Management</h3>
                                <p>Full-cycle content strategy, community management, and organic growth engines across all major platforms.</p>
                                <span class="service-cta">View Details &amp; Pricing →</span>
                        </a>
                        <a href="services/seo" class="service-card fade-in interactive-card visible">
                                <span class="service-num">06</span>
                                <div class="service-icon"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg></div>
                                <h3>SEO / AEO</h3>
                                <p>Search engine optimization and Answer Engine Optimization to dominate rankings and AI-generated responses.</p>
                                <span class="service-cta">View Details &amp; Pricing →</span>
                        </a>
                        <a href="services/ai" class="service-card fade-in interactive-card visible">
                                <span class="service-num">07</span>
                                <div class="service-icon"><svg viewBox="0 0 24 24"><rect x="4" y="4" width="16" height="16" rx="2"></rect><path d="M9 9h6v6H9z"></path><path d="M9 1v3M15 1v3M9 20v3M15 20v3M1 9h3M1 15h3M20 9h3M20 15h3"></path></svg></div>
                                <h3>AI Solutions</h3>
                                <p>Custom-trained LLM assistants, intelligent automation pipelines, and data-driven decision engines.</p>
                                <span class="service-cta">View Details &amp; Pricing →</span>
                        </a>
                        <a href="services/packaging" class="service-card fade-in interactive-card visible">
                                <span class="service-num">08</span>
                                <div class="service-icon"><svg viewBox="0 0 24 24"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line></svg></div>
                                <h3>Packaging</h3>
                                <p>Modular packaging blueprints and product design systems that elevate shelf presence and brand consistency.</p>
                                <span class="service-cta">View Details &amp; Pricing →</span>
                        </a>
                        <a href="services/video" class="service-card fade-in interactive-card visible">
                                <span class="service-num">09</span>
                                <div class="service-icon"><svg viewBox="0 0 24 24"><polygon points="23 7 16 12 23 17 23 7"></polygon><rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect></svg></div>
                                <h3>Video Editing</h3>
                                <p>Scroll-stopping short reels, content creation, blog editing, 3D product videos, and dynamic motion graphics.</p>
                                <span class="service-cta">View Details &amp; Pricing →</span>
                        </a>
                        <a href="services/gameui" class="service-card fade-in interactive-card visible">
                                <span class="service-num">10</span>
                                <div class="service-icon"><svg viewBox="0 0 24 24"><line x1="6" y1="12" x2="10" y2="12"></line><line x1="8" y1="10" x2="8" y2="14"></line><line x1="15" y1="13" x2="15.01" y2="13"></line><line x1="18" y1="11" x2="18.01" y2="11"></line><rect x="2" y="6" width="20" height="12" rx="6" ry="6"></rect></svg></div>
                                <h3>Game UI/UX</h3>
                                <p>Immersive game interfaces and user experiences — HUD design, UX flow architecture, and onboarding for any platform.</p>
                                <span class="service-cta">View Details &amp; Pricing →</span>
                        </a>
                        <a href="services/revenue" class="service-card fade-in interactive-card visible">
                                <span class="service-num">11</span>
                                <div class="service-icon"><svg viewBox="0 0 24 24"><path d="M12 1v22M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg></div>
                                <h3>Revenue Accelerator</h3>
                                <p>Monetize your traffic automatically with our proprietary ad-tech integration and conversion-optimized landing pages.</p>
                                <span style="display:inline-block; background:var(--brand-gold); color:var(--bg-dark); font-size:0.6rem; font-weight:800; padding:3px 10px; border-radius:10px; text-transform:uppercase; letter-spacing:1px; margin-bottom:0.75rem;">🚀 New Feature</span>
                                <span class="service-cta">View Details &amp; Pricing →</span>
                        </a>
                </div>
        </section>

        <!-- Animated Portfolio Gallery -->
        <section id="portfolio">
                <div class="section-header fade-in">
                        <h2>Our <strong>Portfolio</strong></h2>
                        <p>A Showcase of Delivered Excellence.</p>
                </div>

                <div class="filter-container fade-in">
                        <button class="filter-btn active interactive-el" data-filter="all">All Work</button>
                        <button class="filter-btn interactive-el" data-filter="home-services">Home Services</button>
                        <button class="filter-btn interactive-el" data-filter="logistics">Transport &amp; Logistics</button>
                        <button class="filter-btn interactive-el" data-filter="real-estate-construction">Real Estate &amp; Construction</button>
                        <button class="filter-btn interactive-el" data-filter="care">Care &amp; Wellness</button>
                        <button class="filter-btn interactive-el" data-filter="security-finance">Security &amp; Finance</button>
                </div>
                <div style="text-align:center; margin-bottom:3rem;">
                        <a href="/portfolio" target="_top" class="btn-primary interactive-el" style="font-size:0.78rem; padding:0.8rem 2rem;">View Full Portfolio by Category →</a>
                </div>

                <div class="portfolio-grid">
                        <div class="portfolio-item interactive-card fade-in" data-category="home-services" onclick="openModal('bros-cleaning')">
                                <div class="portfolio-bg">
                                        <div class="browser-chrome"><span class="browser-dots"><span class="browser-dot"></span><span class="browser-dot"></span><span class="browser-dot"></span></span><span class="browser-url">broscleaning.ca</span></div>
                                        <div class="portfolio-bg-text">BC</div>
                                </div>
                                <div class="device-badges"><span class="device-badge" title="Desktop-optimized"><svg viewBox="0 0 24 24"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg></span><span class="device-badge" title="Mobile-optimized"><svg viewBox="0 0 24 24"><rect x="7" y="2" width="10" height="20" rx="2"/><line x1="11" y1="18" x2="13" y2="18"/></svg></span></div>
                                <div class="portfolio-overlay">
                                        <h3>Bros Cleaning Services</h3>
                                        <p>Residential &amp; Commercial Cleaning — Edmonton, AB</p>
                                </div>
                        </div>

                        <div class="portfolio-item interactive-card fade-in" data-category="logistics" onclick="openModal('golden-moves')">
                                <div class="portfolio-bg">
                                        <div class="browser-chrome"><span class="browser-dots"><span class="browser-dot"></span><span class="browser-dot"></span><span class="browser-dot"></span></span><span class="browser-url">goldenmoveslogistics.ca</span></div>
                                        <div class="portfolio-bg-text">GM</div>
                                </div>
                                <div class="device-badges"><span class="device-badge" title="Desktop-optimized"><svg viewBox="0 0 24 24"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg></span><span class="device-badge" title="Mobile-optimized"><svg viewBox="0 0 24 24"><rect x="7" y="2" width="10" height="20" rx="2"/><line x1="11" y1="18" x2="13" y2="18"/></svg></span></div>
                                <div class="portfolio-overlay">
                                        <h3>Golden Moves Logistics</h3>
                                        <p>Freight &amp; Trucking — Mississauga, ON</p>
                                </div>
                        </div>

                        <div class="portfolio-item interactive-card fade-in" data-category="real-estate-construction" onclick="openModal('realtor-jaskaur')">
                                <div class="portfolio-bg">
                                        <div class="browser-chrome"><span class="browser-dots"><span class="browser-dot"></span><span class="browser-dot"></span><span class="browser-dot"></span></span><span class="browser-url">realtorjaskaur.com</span></div>
                                        <div class="portfolio-bg-text">JK</div>
                                </div>
                                <div class="device-badges"><span class="device-badge" title="Desktop-optimized"><svg viewBox="0 0 24 24"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg></span><span class="device-badge" title="Mobile-optimized"><svg viewBox="0 0 24 24"><rect x="7" y="2" width="10" height="20" rx="2"/><line x1="11" y1="18" x2="13" y2="18"/></svg></span></div>
                                <div class="portfolio-overlay">
                                        <h3>Realtor Jaskaur</h3>
                                        <p>Real Estate — Buyer Specialist, Brampton, ON</p>
                                </div>
                        </div>

                        <div class="portfolio-item interactive-card fade-in" data-category="care" onclick="openModal('kindheart')">
                                <div class="portfolio-bg">
                                        <div class="browser-chrome"><span class="browser-dots"><span class="browser-dot"></span><span class="browser-dot"></span><span class="browser-dot"></span></span><span class="browser-url">kindheartsupport.co.nz</span></div>
                                        <div class="portfolio-bg-text">KH</div>
                                </div>
                                <div class="device-badges"><span class="device-badge" title="Desktop-optimized"><svg viewBox="0 0 24 24"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg></span><span class="device-badge" title="Mobile-optimized"><svg viewBox="0 0 24 24"><rect x="7" y="2" width="10" height="20" rx="2"/><line x1="11" y1="18" x2="13" y2="18"/></svg></span></div>
                                <div class="portfolio-overlay">
                                        <h3>Kindheart Support</h3>
                                        <p>In-Home Senior Care — Waikato &amp; Auckland, NZ</p>
                                </div>
                        </div>

                        <div class="portfolio-item interactive-card fade-in" data-category="security-finance" onclick="openModal('east-kootenay-security')">
                                <div class="portfolio-bg">
                                        <div class="browser-chrome"><span class="browser-dots"><span class="browser-dot"></span><span class="browser-dot"></span><span class="browser-dot"></span></span><span class="browser-url">eastkootenaysecurity.com</span></div>
                                        <div class="portfolio-bg-text">EK</div>
                                </div>
                                <div class="device-badges"><span class="device-badge" title="Desktop-optimized"><svg viewBox="0 0 24 24"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg></span><span class="device-badge" title="Mobile-optimized"><svg viewBox="0 0 24 24"><rect x="7" y="2" width="10" height="20" rx="2"/><line x1="11" y1="18" x2="13" y2="18"/></svg></span></div>
                                <div class="portfolio-overlay">
                                        <h3>East Kootenay Security</h3>
                                        <p>Commercial Security — Cranbrook, BC</p>
                                </div>
                        </div>

                        <div class="portfolio-item interactive-card fade-in" data-category="real-estate-construction" onclick="openModal('youngpros')">
                                <div class="portfolio-bg">
                                        <div class="browser-chrome"><span class="browser-dots"><span class="browser-dot"></span><span class="browser-dot"></span><span class="browser-dot"></span></span><span class="browser-url">youngprosconstruction.ca</span></div>
                                        <div class="portfolio-bg-text">YP</div>
                                </div>
                                <div class="device-badges"><span class="device-badge" title="Desktop-optimized"><svg viewBox="0 0 24 24"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg></span><span class="device-badge" title="Mobile-optimized"><svg viewBox="0 0 24 24"><rect x="7" y="2" width="10" height="20" rx="2"/><line x1="11" y1="18" x2="13" y2="18"/></svg></span></div>
                                <div class="portfolio-overlay">
                                        <h3>YoungPros Construction</h3>
                                        <p>Residential Framing — Vancouver Island &amp; Lower Mainland, BC</p>
                                </div>
                        </div>
                </div>
        </section>

        <!-- STATS COUNTER SECTION -->
        <section class="stats-section">
                <div class="stats-grid fade-in">
                        <div class="stat-item">
                                <div class="stat-number" data-target="180" data-suffix="+">0</div>
                                <div class="stat-label">Projects Delivered</div>
                        </div>
                        <div class="stat-item">
                                <div class="stat-number" data-target="5" data-suffix="">0</div>
                                <div class="stat-label">Regions Served</div>
                        </div>
                        <div class="stat-item">
                                <div class="stat-number" data-target="98" data-suffix="%">0</div>
                                <div class="stat-label">Client Retention</div>
                        </div>
                        <div class="stat-item">
                                <div class="stat-number" data-target="7" data-suffix="yr">0</div>
                                <div class="stat-label">Avg. Team Experience</div>
                        </div>
                </div>
        </section>

        <!-- PROCESS TIMELINE -->
        <section id="process">
                <div class="section-header fade-in">
                        <h2>Our <strong>Process</strong></h2>
                        <p>From Blueprint to Launch.</p>
                </div>
                <div class="process-timeline-v2 fade-in">
                        <div class="process-line"></div>
                        <div class="process-node interactive-card">
                                <div class="process-node-num">01</div>
                                <div class="process-node-icon"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></div>
                                <h4>Discovery & Audit</h4>
                                <p>Deep-dive into your business model, market positioning, and technical landscape to architect the optimal strategy.</p>
                                <span class="process-node-tag">Week 1–2</span>
                        </div>
                        <div class="process-node interactive-card">
                                <div class="process-node-num">02</div>
                                <div class="process-node-icon"><svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></svg></div>
                                <h4>Architecture & Design</h4>
                                <p>Full system blueprints, identity systems, and UX frameworks crafted with precision before a single line of code.</p>
                                <span class="process-node-tag">Week 2–4</span>
                        </div>
                        <div class="process-node interactive-card">
                                <div class="process-node-num">03</div>
                                <div class="process-node-icon"><svg viewBox="0 0 24 24"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg></div>
                                <h4>Engineering & Build</h4>
                                <p>Scalable development with continuous integration, performance optimization, and rigorous QA at every milestone.</p>
                                <span class="process-node-tag">Week 4–8</span>
                        </div>
                        <div class="process-node interactive-card">
                                <div class="process-node-num">04</div>
                                <div class="process-node-icon"><svg viewBox="0 0 24 24"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg></div>
                                <h4>Launch & Scale</h4>
                                <p>Strategic deployment, marketing activation, and ongoing optimization to ensure sustained growth post-launch.</p>
                                <span class="process-node-tag">Week 8+</span>
                        </div>
                </div>
        </section>

        <!-- ADVANCED MARKETING ARCHITECT SECTION WITH LIVE AI EXPERIENCE -->
        <section id="marketing-architect">
                <div class="section-header fade-in">
                        <h2>Marketing <strong>Architect</strong></h2>
                        <p>Predictive Media Modeling Matrix.</p>
                </div>

                <div class="estimator-wrapper fade-in" style="grid-template-columns: 1.1fr 1.1fr;">
                        <div class="estimator-controls">

                                <div class="control-group">
                                        <label>Business Type / Industry</label>
                                        <input type="text" id="mkt-industry-custom" class="sleek-input interactive-el" value="Food Service & Restaurant" placeholder="e.g., Real Estate, E-Commerce">
                                </div>

                                <div class="control-group">
                                        <label>Target Area / Location</label>
                                        <input type="text" id="mkt-location-custom" class="sleek-input interactive-el" value="New York" placeholder="e.g., Toronto, Sydney">
                                </div>

                                <div class="control-group">
                                        <label>Primary Keywords</label>
                                        <input type="text" id="mkt-keywords-custom" class="sleek-input interactive-el" value="pizza delivery near me" placeholder="e.g., luxury penthouses">
                                </div>

                                <div class="control-group">
                                        <label>Daily Media Budget Setup</label>
                                        <label style="font-size: clamp(3rem, 5vw, 5rem); color: var(--text-main); font-weight: 200; letter-spacing: -1px; text-transform: none; margin: 0.5rem 0; display: block; line-height: 1;">
                                                <span id="mkt-budget-val" style="font-weight: 800;">$40</span><span style="font-size: 1.5rem; font-weight: 400; color: var(--text-muted);"> / Day</span>
                                        </label>
                                        <input type="range" id="mkt-slider" class="interactive-el" min="10" max="500" step="10" value="40">
                                </div>

                                <div style="margin-top: 2rem; padding-top: 1.5rem; border-top: 1px solid var(--border-light);">
                                        <h4 style="color: var(--brand-gold); font-weight: 500; font-size: 0.9rem; text-transform: uppercase; letter-spacing: 2px; margin-bottom: 0.5rem;">Strategic AI Interpretation</h4>
                                        <p id="mkt-strategy-desc" style="color: var(--text-muted); font-size: 0.95rem; line-height: 1.7; font-weight: 300;"></p>
					<div id="mkt-projection" style="margin-top:1.5rem;"></div>
                                </div>
                        </div>

                        <!-- LIVE PREMIUM HIGHLIGHTED AI EXPERIENCE PANEL -->
                        <div class="ai-results-panel" id="ai-live-panel">
                                <div class="ai-badge">AI Live Engine</div>

                                <div class="mkt-platform-card interactive-el">
                                        <div class="mkt-header">
                                                <h4>Meta Ads Matrix</h4>
                                                <span id="meta-allocation">--% Allocation</span>
                                        </div>
                                        <div class="mkt-data">
                                                <div class="mkt-data-box">
                                                        <span class="mkt-data-label">Dynamic CPC</span>
                                                        <span class="mkt-data-value" style="font-weight: 300;" id="meta-cpc-display">$0.00</span>
                                                </div>
                                                <div class="mkt-data-box" style="text-align: right;">
                                                        <span class="mkt-data-label">Est. Daily Clicks</span>
                                                        <span class="mkt-data-value" id="meta-clicks">0</span>
                                                </div>
                                        </div>
                                </div>

                                <div class="mkt-platform-card interactive-el">
                                        <div class="mkt-header">
                                                <h4>Google Ads Core</h4>
                                                <span id="google-allocation">--% Allocation</span>
                                        </div>
                                        <div class="mkt-data">
                                                <div class="mkt-data-box">
                                                        <span class="mkt-data-label">Dynamic CPC</span>
                                                        <span class="mkt-data-value" style="font-weight: 300;" id="google-cpc-display">$0.00</span>
                                                </div>
                                                <div class="mkt-data-box" style="text-align: right;">
                                                        <span class="mkt-data-label">Est. Daily Clicks</span>
                                                        <span class="mkt-data-value" id="google-clicks">0</span>
                                                </div>
                                        </div>
                                </div>

                                <div class="mkt-platform-card interactive-el">
                                        <div class="mkt-header">
                                                <h4>TikTok / Reels Boost</h4>
                                                <span id="tiktok-allocation">--% Allocation</span>
                                        </div>
                                        <div class="mkt-data">
                                                <div class="mkt-data-box">
                                                        <span class="mkt-data-label">Dynamic CPM</span>
                                                        <span class="mkt-data-value" style="font-weight: 300;" id="tiktok-cpm-display">$0.00</span>
                                                </div>
                                                <div class="mkt-data-box" style="text-align: right;">
                                                        <span class="mkt-data-label">Est. Daily Views</span>
                                                        <span class="mkt-data-value" id="tiktok-views">0</span>
                                                </div>
                                        </div>
                                </div>

                                <div class="mkt-data-box" style="margin-top: -0.5rem;">
                                        <span class="mkt-data-label" style="display: flex; justify-content: space-between;">
                                                <span>Predictive 30-Day Acquisition Curve</span>
                                                <span id="growth-percentage-tag" style="color: var(--brand-gold); font-weight: bold;">Traction Loading...</span>
                                        </span>
                                        <div class="graph-container">
                                                <svg class="graph-svg" id="growth-graph-svg">
                                                        <defs>
                                                                <linearGradient id="graph-glow-grad" x1="0" y1="0" x2="0" y2="1">
                                                                        <stop offset="0%" stop-color="var(--brand-gold)" stop-opacity="0.25"></stop>
                                                                        <stop offset="100%" stop-color="var(--brand-gold)" stop-opacity="0.0"></stop>
                                                                </linearGradient>
                                                        </defs>
                                                        <line x1="0" y1="30" x2="100%" y2="30" class="graph-grid-line"></line>
                                                        <line x1="0" y1="80" x2="100%" y2="80" class="graph-grid-line"></line>
                                                        <path d="" class="graph-gradient-path" id="graph-gradient-fill"></path>
                                                        <path d="" class="graph-path" id="graph-line-stroke"></path>
                                                </svg>
                                        </div>
                                </div>
                        </div>
                </div>
        </section>

        <!-- PREMIUM RE-ENGINEERED DEVELOPMENT DASHBOARD -->
        <section id="ai-estimator">
                <div class="section-header fade-in">
                        <h2>Development <strong>Estimator</strong></h2>
                        <p>Predictive Architecture Modeling.</p>
                </div>

                <div class="estimator-wrapper fade-in">
                        <!-- Left Side Controls -->
                        <div class="estimator-controls">
                                <div class="control-group">
                                        <label>Currency Index</label>
                                        <select id="currency-selector" class="sleek-select interactive-el">
                                                <option value="1.00" data-symbol="$" selected>USD - US Dollar</option>
                                                <option value="3.67" data-symbol="AED ">AED - Emirati Dirham</option>
                                                <option value="0.92" data-symbol="€">EUR - Euro</option>
                                                <option value="0.78" data-symbol="£">GBP - British Pound</option>
                                                <option value="1.37" data-symbol="CAD $ ">CAD - Canadian Dollar</option>
                                        </select>
                                </div>

                                <div class="control-group" style="margin-top: 3rem;">
                                        <label style="display: flex; justify-content: space-between;">
                                                <span>Page Volume Architecture</span>
                                                <span style="color: var(--brand-gold); font-weight: 800; font-size: 1rem;" id="pages-value">3</span>
                                        </label>
                                        <input type="range" id="param-pages" class="interactive-el" min="3" max="50" value="3">
                                </div>

                                <div class="control-group">
                                        <label style="display: flex; justify-content: space-between;">
                                                <span>Project Timeline (Weeks)</span>
                                                <span style="color: var(--brand-gold); font-weight: 800; font-size: 1rem;" id="timeline-value">4</span>
                                        </label>
                                        <input type="range" id="param-timeline" class="interactive-el" min="2" max="24" value="4">
                                </div>

                                <div class="control-group" style="margin-top: 3rem;">
                                        <label>Ecosystem Integration Matrix</label>

                                        <!-- High-End Feature Grid -->
                                        <div class="feature-grid">
                                                <!-- E-Commerce Toggle -->
                                                <div class="feature-card interactive-el" id="card-ecom" onclick="toggleFeature('ecom')">
                                                        <div class="feature-indicator"></div>
                                                        <h5>E-Commerce Core</h5>
                                                        <p>Digital storefront and cart architecture.</p>
                                                </div>

                                                <!-- Payments Toggle -->
                                                <div class="feature-card interactive-el" id="card-payment" onclick="toggleFeature('payment')">
                                                        <div class="feature-indicator"></div>
                                                        <h5>Payment Gateways</h5>
                                                        <p>Secure routing via Stripe/PayPal APIs.</p>
                                                </div>

                                                <!-- AI Toggle -->
                                                <div class="feature-card interactive-el" id="card-ai" onclick="toggleFeature('ai')">
                                                        <div class="feature-indicator"></div>
                                                        <h5>Graphinxt AI</h5>
                                                        <p>Custom trained interactive LLM assistant.</p>
                                                </div>

                                                <!-- SEO Toggle -->
                                                <div class="feature-card interactive-el" id="card-seo" onclick="toggleFeature('seo')">
                                                        <div class="feature-indicator"></div>
                                                        <h5>Global SEO Matrix</h5>
                                                        <p>Advanced multi-region indexing layout.</p>
                                                </div>

                                                <!-- Mobile App Toggle -->
                                                <div class="feature-card interactive-el" id="card-mobile" onclick="toggleFeature('mobile')">
                                                        <div class="feature-indicator"></div>
                                                        <h5>Mobile App Layer</h5>
                                                        <p>Native iOS / Android companion build.</p>
                                                </div>

                                                <!-- Cloud Infra Toggle -->
                                                <div class="feature-card interactive-el" id="card-cloud" onclick="toggleFeature('cloud')">
                                                        <div class="feature-indicator"></div>
                                                        <h5>Cloud Infrastructure</h5>
                                                        <p>Auto-scaling server & CDN architecture.</p>
                                                </div>
                                        </div>

                                        <!-- Sleek Sliding E-Commerce Parameter Input -->
                                        <div id="ecom-products-wrap" class="ecom-extended-panel">
                                                <label style="display: flex; justify-content: space-between; font-size: 0.75rem;">
                                                        <span>Initial Product Catalog Volume</span>
                                                </label>
                                                <input type="number" id="param-products" class="sleek-input interactive-el" value="10" min="1" max="1000" style="padding: 0.5rem 0; font-size: 1.2rem; font-weight: 800; border-bottom: 1px solid var(--brand-gold);">
                                        </div>
                                </div>
                        </div>

                        <!-- Right Side Glowing Glassmorphism Panel -->
                        <div class="price-output-panel" id="price-dashboard">
                                <p style="color: var(--text-muted); text-transform: uppercase; letter-spacing: 3px; font-size: 0.75rem; margin-bottom: 1rem; font-weight: 500;">Estimated Architecture Investment</p>
                                <div class="price-display">
                                        <span class="currency" id="currency-symbol">$</span>
                                        <span id="total-price">500</span>
                                </div>
                                <div style="width: 100%; height: 1px; background: linear-gradient(90deg, transparent, var(--border-light), transparent); margin: 2rem 0;"></div>
                                <div id="price-breakdown" style="display: flex; flex-direction: column; gap: 0.75rem; margin-bottom: 2rem;">
                                        <!-- Breakdown items injected dynamically -->
                                </div>
                                <div id="quote-extras" style="margin-bottom:1.5rem;"></div>
                                <p style="color: var(--text-muted); font-size: 0.8rem; font-weight: 300; line-height: 1.6;">
                                        *Calculated dynamically. Base system setup initialization scales explicitly from $500 USD equivalent. A full technical audit is required to finalize hardware requirements.
                                </p>
                                <button onclick="window.trackConversion && window.trackConversion('cta_click', {cta: 'estimator_quote'}); openContactModal()" class="btn-primary interactive-el" style="margin-top: 2rem; align-self: flex-start; font-size: 0.75rem; padding: 0.7rem 1.5rem;">Request Detailed Quote</button>
                        </div>
                </div>
        </section>

        <!-- TESTIMONIALS SECTION -->
        <section id="testimonials">
                <div class="section-header fade-in">
                        <h2>Real Work, <strong>Real Clients</strong></h2>
                        <p>No fabricated quotes here — three of the actual businesses we've built for. <a href="/portfolio" style="color:var(--brand-gold); text-decoration:underline;">See all 13 →</a></p>
                </div>
                <div class="testimonials-grid">
                        <div class="testimonial-card fade-in interactive-card">
                                <p class="testimonial-text" style="font-style:normal;">Built a full booking-flow site covering five service categories and multiple Edmonton-area service zones, with direct WhatsApp click-to-chat for fast quote requests.</p>
                                <div class="testimonial-author">
                                        <div class="testimonial-avatar">BC</div>
                                        <div class="testimonial-info">
                                                <h4>Bros Cleaning Services</h4>
                                                <p><a href="https://broscleaning.ca/" target="_blank" rel="noopener" style="color:var(--brand-gold);">broscleaning.ca ↗</a></p>
                                        </div>
                                </div>
                        </div>
                        <div class="testimonial-card fade-in interactive-card">
                                <p class="testimonial-text" style="font-style:normal;">Built a private home care platform with a 12-service, 17-location appointment booking widget — designed to build the trust a family needs before booking care for a loved one.</p>
                                <div class="testimonial-author">
                                        <div class="testimonial-avatar">KH</div>
                                        <div class="testimonial-info">
                                                <h4>Kindheart Support</h4>
                                                <p><a href="https://kindheartsupport.co.nz/" target="_blank" rel="noopener" style="color:var(--brand-gold);">kindheartsupport.co.nz ↗</a></p>
                                        </div>
                                </div>
                        </div>
                        <div class="testimonial-card fade-in interactive-card">
                                <p class="testimonial-text" style="font-style:normal;">Built a commercial security services site covering four distinct offerings, serving clients across BC, Canada, and the USA with clear service-specific pages and WhatsApp-based quote requests.</p>
                                <div class="testimonial-author">
                                        <div class="testimonial-avatar">EK</div>
                                        <div class="testimonial-info">
                                                <h4>East Kootenay Security</h4>
                                                <p><a href="https://eastkootenaysecurity.com/" target="_blank" rel="noopener" style="color:var(--brand-gold);">eastkootenaysecurity.com ↗</a></p>
                                        </div>
                                </div>
                        </div>
                </div>
                <p style="text-align:center; font-size:0.75rem; color:var(--text-muted); opacity:0.7; margin-top:2rem;">Have a testimonial for us? We'd rather feature your real words than write our own — <a href="#contact" style="color:var(--brand-gold); text-decoration:underline;">get in touch</a>.</p>
        </section>

        <!-- RESULTS / TRUST SIGNALS -->
        <section id="results">
                <div class="section-header fade-in">
                        <h2>Results That <strong>Compound</strong></h2>
                        <p>Why enterprise clients across five regions choose Graphinxt.</p>
                </div>
                <div class="results-grid">
                        <div class="result-card fade-in interactive-card">
                                <div class="result-num" data-count="3.4" data-suffix="×" data-dec="1">0</div>
                                <div class="result-label">Avg. ROI on Ad Spend</div>
                        </div>
                        <div class="result-card fade-in interactive-card">
                                <div class="result-num" data-count="212" data-suffix="%">0</div>
                                <div class="result-label">Avg. Lead Growth, 90 Days</div>
                        </div>
                        <div class="result-card fade-in interactive-card">
                                <div class="result-num" data-count="94" data-suffix="%">0</div>
                                <div class="result-label">Client Retention Rate</div>
                        </div>
                        <div class="result-card fade-in interactive-card">
                                <div class="result-num" data-count="120" data-suffix="+">0</div>
                                <div class="result-label">Enterprise Projects Delivered</div>
                        </div>
                </div>
                <p class="result-note fade-in">Figures reflect aggregate client outcomes across active engagements and are illustrative until replaced with verified, case-by-case results.</p>
                <div class="region-strip fade-in">
                        <div class="region-pill"><span class="flag-dot"></span>United States</div>
                        <div class="region-pill"><span class="flag-dot"></span>United Kingdom</div>
                        <div class="region-pill"><span class="flag-dot"></span>Canada</div>
                        <div class="region-pill"><span class="flag-dot"></span>Australia</div>
                        <div class="region-pill"><span class="flag-dot"></span>New Zealand</div>
                </div>
        </section>

        <!-- INDUSTRIES WE SERVE -->
        <section id="industries">
                <div class="section-header fade-in">
                        <h2>Industries We <strong>Serve</strong></h2>
                        <p>Domain-Specific Expertise.</p>
                </div>
                <div class="industries-grid fade-in">
                        <div class="industry-card interactive-card">
                                <div class="service-icon"><svg viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg></div>
                                <h3>Real Estate</h3>
                                <p>High-conversion property platforms with map search and lead engines.</p>
                        </div>
                        <div class="industry-card interactive-card">
                                <div class="service-icon"><svg viewBox="0 0 24 24"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg></div>
                                <h3>E-Commerce</h3>
                                <p>Conversion-optimized storefronts with frictionless checkout flows.</p>
                        </div>
                        <div class="industry-card interactive-card">
                                <div class="service-icon"><svg viewBox="0 0 24 24"><path d="M18 8h1a4 4 0 0 1 0 8h-1"/><path d="M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4z"/><line x1="6" y1="1" x2="6" y2="4"/><line x1="10" y1="1" x2="10" y2="4"/><line x1="14" y1="1" x2="14" y2="4"/></svg></div>
                                <h3>Food & Hospitality</h3>
                                <p>Hyper-local marketing and franchise-ready brand packaging systems.</p>
                        </div>
                        <div class="industry-card interactive-card">
                                <div class="service-icon"><svg viewBox="0 0 24 24"><rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/><line x1="9" y1="1" x2="9" y2="4"/><line x1="15" y1="1" x2="15" y2="4"/><line x1="9" y1="20" x2="9" y2="23"/><line x1="15" y1="20" x2="15" y2="23"/><line x1="20" y1="9" x2="23" y2="9"/><line x1="20" y1="14" x2="23" y2="14"/><line x1="1" y1="9" x2="4" y2="9"/><line x1="1" y1="14" x2="4" y2="14"/></svg></div>
                                <h3>SaaS & Tech</h3>
                                <p>Multi-region acquisition engines and product-led growth architecture.</p>
                        </div>
                        <div class="industry-card interactive-card">
                                <div class="service-icon"><svg viewBox="0 0 24 24"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg></div>
                                <h3>Healthcare</h3>
                                <p>Compliant, accessible platforms with patient-centric UX design.</p>
                        </div>
                        <div class="industry-card interactive-card">
                                <div class="service-icon"><svg viewBox="0 0 24 24"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg></div>
                                <h3>Finance</h3>
                                <p>Secure, trust-driven platforms with regulatory-grade architecture.</p>
                        </div>
                </div>
        </section>

        <!-- Global Map Section -->
        <section id="global-map" class="map-section">
                <div class="section-header fade-in">
                        <h2>Global <strong>Network</strong></h2>
                        <p>Clients Across Continents.</p>
                </div>

                <div class="world-map-wrapper fade-in">
                        <div class="world-map">
                                <svg class="map-connections" viewBox="0 0 100 100" preserveAspectRatio="none">
                                        <path d="M20,33 Q21,35 22,38" class="map-line"/>
                                        <path d="M22,38 Q50,18 87,72" class="map-line"/>
                                        <path d="M20,33 Q55,15 93,80" class="map-line"/>
                                        <path d="M87,72 Q90,75 93,80" class="map-line"/>
                                        <path d="M22,38 Q34,33 47,30" class="map-line"/>
                                        <path d="M47,30 Q65,20 87,72" class="map-line"/>
                                </svg>
                                <div class="map-pin" style="left:22%;top:38%"><span class="pin-pulse"></span><span class="pin-dot"></span><span class="pin-label">New York · USA</span></div>
                                <div class="map-pin" style="left:20%;top:33%"><span class="pin-pulse"></span><span class="pin-dot"></span><span class="pin-label">Toronto · Canada</span></div>
                                <div class="map-pin" style="left:47%;top:30%"><span class="pin-pulse"></span><span class="pin-dot"></span><span class="pin-label">London · UK</span></div>
                                <div class="map-pin" style="left:93%;top:80%"><span class="pin-pulse"></span><span class="pin-dot"></span><span class="pin-label">Auckland · NZ</span></div>
                                <div class="map-pin" style="left:87%;top:72%"><span class="pin-pulse"></span><span class="pin-dot"></span><span class="pin-label">Sydney · Australia</span></div>
                                <div class="map-pin client" style="left:28%;top:44%"></div>
                                <div class="map-pin client" style="left:34%;top:40%"></div>
                                <div class="map-pin client" style="left:24%;top:52%"></div>
                                <div class="map-pin client" style="left:68%;top:46%"></div>
                                <div class="map-pin client" style="left:75%;top:58%"></div>
                                <div class="map-pin client" style="left:82%;top:64%"></div>
                                <div class="map-pin client" style="left:90%;top:74%"></div>
                        </div>
                        <div class="map-legend">
                                <div class="map-legend-item"><span class="map-legend-dot" style="background: var(--brand-gold); box-shadow: 0 0 8px var(--brand-gold);"></span>Service Hub</div>
                                <div class="map-legend-item"><span class="map-legend-dot" style="background: var(--text-muted);"></span>Client Location</div>
                        </div>
                </div>

                <div class="clocks-container fade-in" style="margin-top: 2rem;">
                        <div class="clock-card interactive-card"><h3>New York</h3><div class="time" id="time-ny">--:--</div><div class="clock-region">USA</div><div class="node-status" id="status-ny"></div></div>
                        <div class="clock-card interactive-card"><h3>Toronto</h3><div class="time" id="time-tor">--:--</div><div class="clock-region">Canada</div><div class="node-status" id="status-tor"></div></div>
                        <div class="clock-card interactive-card"><h3>London</h3><div class="time" id="time-lon">--:--</div><div class="clock-region">UK</div><div class="node-status" id="status-lon"></div></div>
                        <div class="clock-card interactive-card"><h3>Auckland</h3><div class="time" id="time-akl">--:--</div><div class="clock-region">New Zealand</div><div class="node-status" id="status-akl"></div></div>
                        <div class="clock-card interactive-card"><h3>Sydney</h3><div class="time" id="time-syd">--:--</div><div class="clock-region">Australia</div><div class="node-status" id="status-syd"></div></div>
                </div>
                <p style="text-align:center; font-size:0.7rem; color:var(--text-muted); opacity:0.65; margin-top:1.2rem;">Live local time per node — status reflects real time-of-day, not simulated data.</p>
        </section>

        <!-- BLOG / INSIGHTS SECTION -->
        <section id="insights">
                <div class="section-header fade-in">
                        <h2>Latest <strong>Insights</strong></h2>
                        <p>Strategic Intelligence.</p>
                </div>
                <div class="blog-grid">
                        <a href="/blog/ai-search-visibility-smb" class="blog-card fade-in interactive-card">
                                <div class="blog-meta">AI Strategy · 5 min read</div>
                                <h3>The AI Revolution in Regional Marketing Architecture</h3>
                                <p>How predictive media modeling is reshaping the way enterprise brands allocate ad spend across hyper-local markets. A deep dive into the methodology behind our Marketing Architect engine.</p>
                                <button class="read-more-btn interactive-el">Read Article</button>
                        </a>
                        <a href="/blog/website-audit-tools-comparison" class="blog-card fade-in interactive-card">
                                <div class="blog-meta">Web Engineering · 7 min read</div>
                                <h3>Why Your Website Architecture Is Killing Conversions</h3>
                                <p>Most enterprise platforms lose 60% of potential conversions to structural inefficiencies. Here's the framework we use to audit and re-engineer digital architecture for maximum performance.</p>
                                <button class="read-more-btn interactive-el">Read Article</button>
                        </a>
                        <a href="/blog/pricing-guide" class="blog-card fade-in interactive-card">
                                <div class="blog-meta">Brand Identity · 4 min read</div>
                                <h3>Building Brand Systems That Scale Across Borders</h3>
                                <p>A modular approach to identity design that maintains consistency across cultures, languages, and markets — without diluting your core brand DNA. Lessons from our multi-region deployments.</p>
                                <button class="read-more-btn interactive-el">Read Article</button>
                        </a>
                        <a href="/blog/pricing-guide" class="blog-card fade-in interactive-card">
                                <div class="blog-meta">Pricing Guide · 9 min read</div>
                                <h3>How Much Does a Website Really Cost in 2026?</h3>
                                <p>A buyer's guide for the UK, USA, Canada, Australia &amp; New Zealand — real pricing ranges, what actually moves the number, and red flags to watch for.</p>
                                <button class="read-more-btn interactive-el">Read Article</button>
                        </a>
                        <a href="/blog/us-agency-guide" class="blog-card fade-in interactive-card">
                                <div class="blog-meta">Agency Selection · 7 min read</div>
                                <h3>How Enterprise Brands Choose a Digital Agency in 2026</h3>
                                <p>What separates a safe enterprise partner from a portfolio full of pretty screenshots — and the six questions that expose the difference.</p>
                                <button class="read-more-btn interactive-el">Read Article</button>
                        </a>
                </div>
        </section>

        <!-- FAQ SECTION -->
        <section id="faq">
                <div class="section-header fade-in">
                        <h2>Frequently <strong>Asked</strong></h2>
                        <p>Clarity on Our Process.</p>
                </div>
                <div class="faq-container fade-in">
                        <div class="faq-item">
                                <button class="faq-question interactive-el">What is the typical project timeline?<span class="faq-icon"></span></button>
                                <div class="faq-answer"><p>Project timelines vary based on scope and complexity. A standard web platform typically takes 4–8 weeks, while comprehensive enterprise systems with AI integration can span 12–20 weeks. Our estimator tool provides a rough timeline projection based on your selected features.</p></div>
                        </div>
                        <div class="faq-item">
                                <button class="faq-question interactive-el">Do you work with clients internationally?<span class="faq-icon"></span></button>
                                <div class="faq-answer"><p>Absolutely. We operate across the USA, Canada, the UK, New Zealand, and Australia — with active nodes in New York, Toronto, London, Auckland, and Sydney. Our team is structured for asynchronous collaboration across time zones, ensuring continuous progress on your project.</p></div>
                        </div>
                        <div class="faq-item">
                                <button class="faq-question interactive-el">How much does a website or marketing project cost in the UK, USA, Canada, Australia, or New Zealand?<span class="faq-icon"></span></button>
                                <div class="faq-answer"><p>We price in USD and convert to local currency, so quotes are consistent no matter which of the five regions you're in. Web platforms typically start around $1,500, enterprise systems with AI integration can exceed $10,000, and paid media management starts around $500/month. Try the Development Estimator above for an instant projection.</p></div>
                        </div>
                        <div class="faq-item">
                                <button class="faq-question interactive-el">How does the Marketing Architect engine work?<span class="faq-icon"></span></button>
                                <div class="faq-answer"><p>Our Marketing Architect uses predictive modeling to simulate ad performance across Meta, Google, and TikTok platforms. It factors in your industry, location, keywords, and budget to project CPC, click volume, and acquisition curves — all in real-time as you adjust parameters.</p></div>
                        </div>
                        <div class="faq-item">
                                <button class="faq-question interactive-el">What happens after launch?<span class="faq-icon"></span></button>
                                <div class="faq-answer"><p>Launch is just the beginning. We offer ongoing optimization retainers that include performance monitoring, A/B testing, SEO refinement, and iterative feature development. Our goal is sustained growth, not just a one-time delivery.</p></div>
                        </div>
                        <div class="faq-item">
                                <button class="faq-question interactive-el">Can you integrate with our existing systems?<span class="faq-icon"></span></button>
                                <div class="faq-answer"><p>Yes. Our engineering team specializes in API integrations, data migrations, and legacy system modernization. Whether you're on Shopify, Salesforce, custom ERPs, or proprietary platforms, we architect seamless bridges that preserve your existing investments.</p></div>
                        </div>
                        <div class="faq-item">
                                <button class="faq-question interactive-el">Do you offer AI-powered chatbots and assistants?<span class="faq-icon"></span></button>
                                <div class="faq-answer"><p>Yes — our Graphinxt AI feature delivers custom-trained LLM assistants tailored to your business domain. These can handle customer support, lead qualification, internal knowledge retrieval, and more, with your brand voice and data.</p></div>
                        </div>
                </div>
        </section>

        <!-- WHY CHOOSE US SECTION -->
        <section id="why-us">
                <div class="section-header fade-in">
                        <h2>Why <strong>Graphinxt</strong></h2>
                        <p>Engineered for Measurable Impact.</p>
                </div>
                <div class="services-grid">
                        <div class="service-card fade-in interactive-card">
                                <span class="service-num">01</span>
                                <div class="service-icon"><svg viewBox="0 0 24 24"><path d="M9 12l2 2 4-4"/><path d="M21 12c0 5-3.5 7.5-8.5 9.5C7.5 19.5 4 17 4 12V6l8.5-3.5L21 6v6z"/></svg></div>
                                <h3>Data-Driven Architecture</h3>
                                <p>Every decision is backed by predictive modeling and real-time data — not guesswork. We measure what matters and optimize relentlessly.</p>
                        </div>
                        <div class="service-card fade-in interactive-card">
                                <span class="service-num">02</span>
                                <div class="service-icon"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg></div>
                                <h3>24/7 Global Operations</h3>
                                <p>With active nodes across the USA, Canada, the UK, New Zealand, and Australia, your project never sleeps. Continuous development and support across all time zones.</p>
                        </div>
                        <div class="service-card fade-in interactive-card">
                                <span class="service-num">03</span>
                                <div class="service-icon"><svg viewBox="0 0 24 24"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg></div>
                                <h3>Rapid Delivery</h3>
                                <p>Agile sprints with weekly milestones. Most projects launch 40% faster than industry average without compromising quality.</p>
                        </div>
                        <div class="service-card fade-in interactive-card">
                                <span class="service-num">04</span>
                                <div class="service-icon"><svg viewBox="0 0 24 24"><path d="M12 2v20M2 12h20"/><circle cx="12" cy="12" r="9"/></svg></div>
                                <h3>Full-Stack Capabilities</h3>
                                <p>From branding to AI, web to mobile, SEO to paid ads — one partner for your entire digital ecosystem. No handoffs, no gaps.</p>
                        </div>
                </div>
        </section>

        <!-- TECH STACK MARQUEE -->
        <div class="marquee-container">
                <div class="marquee-content">
                        <span>React</span><span class="outline-text">Next.js</span><span>Node.js</span><span class="outline-text">Python</span><span>AWS</span><span class="outline-text">Figma</span><span>Stripe</span><span class="outline-text">GPT-4</span><span>Shopify</span><span class="outline-text">React Native</span><span>React</span><span class="outline-text">Next.js</span><span>Node.js</span><span class="outline-text">Python</span><span>AWS</span><span class="outline-text">Figma</span><span>Stripe</span><span class="outline-text">GPT-4</span><span>Shopify</span><span class="outline-text">React Native</span>
                </div>
        </div>

        <!-- ENTERPRISE SECTION -->
        <section id="enterprise">
                <div class="enterprise-wrapper">
                        <div class="enterprise-copy fade-in">
                                <span class="eyebrow-tag">For Enterprise Teams</span>
                                <h2>Procurement-ready.<br>Built for <strong>bigger stakes</strong>.</h2>
                                <p>When a project touches brand equity and existing infrastructure, "we liked the portfolio" isn't due diligence. Here's what enterprise buyers get working with Graphinxt.</p>
                                <ul class="enterprise-list">
                                        <li>
                                                <span class="check"><svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg></span>
                                                <div><div class="item-title">Dedicated account architect</div><div class="item-desc">One named point of contact who knows your system — not a rotating support queue.</div></div>
                                        </li>
                                        <li>
                                                <span class="check"><svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg></span>
                                                <div><div class="item-title">SLA-backed response times</div><div class="item-desc">Defined incident response commitments, not best-effort promises.</div></div>
                                        </li>
                                        <li>
                                                <span class="check"><svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg></span>
                                                <div><div class="item-title">NDA &amp; custom contract terms</div><div class="item-desc">We work within your procurement and legal process, not around it.</div></div>
                                        </li>
                                        <li>
                                                <span class="check"><svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg></span>
                                                <div><div class="item-title">Legacy system integration</div><div class="item-desc">API integrations, data migrations, and modernization for existing CRMs, ERPs, and proprietary platforms.</div></div>
                                        </li>
                                </ul>
                        </div>
                        <div class="enterprise-panel fade-in interactive-card">
                                <h3>What Enterprise Engagement Looks Like</h3>
                                <div class="enterprise-stat-row"><span>Discovery &amp; technical audit</span><span>1–2 wks</span></div>
                                <div class="enterprise-stat-row"><span>Dedicated team size</span><span>3–8</span></div>
                                <div class="enterprise-stat-row"><span>Regional nodes available</span><span>5</span></div>
                                <div class="enterprise-stat-row"><span>Post-launch SLA response</span><span>&lt;24h</span></div>
                                <div style="margin-top: 2rem;">
                                        <a href="#contact" class="btn-primary interactive-el" style="width: 100%; text-align: center;">Book an Enterprise Consultation</a>
                                </div>
                        </div>
                </div>
        </section>

        <!-- CONTACT SECTION -->
        <section id="contact">
                <div class="section-header fade-in">
                        <h2>Start a <strong>Conversation</strong></h2>
                        <p>Let's Build Something Extraordinary.</p>
                </div>
                <div class="contact-wrapper fade-in">
                        <div class="contact-info">
                                <h3>Ready to <strong>elevate</strong> your digital presence?</h3>
                                <p>Whether you're scaling an established brand or architecting something entirely new, we'd love to hear about your vision. Reach out and we'll respond within 24 hours.</p>
                                <div class="contact-detail">
                                        <svg viewBox="0 0 24 24"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                                        <a href="mailto:reach@graphinxt.com" style="color:inherit;text-decoration:none;">reach@graphinxt.com</a>
                                </div>
                                <div class="contact-detail">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>
                                        <a href="https://wa.me/971564785139" target="_blank" style="color:inherit;text-decoration:none;">+971 56 478 5139 · WhatsApp</a>
                                </div>
                                <div class="contact-detail">
                                        <svg viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                                        <span>CWEP3588, Compass Building, Al Shohada Road, AL Hamra Industrial Zone-FZ, Ras Al Khaimah, UAE · Working Globally</span>
                                </div>
                                <a href="https://wa.me/971564785139" target="_blank" class="btn-primary interactive-el" style="margin-top:1.5rem;align-self:flex-start;background:#25D366;color:#fff !important;">Chat on WhatsApp</a>
                        </div>
                        <div class="contact-form-wrapper">
                                <form id="contact-form" action="/api/lead" class="dynamic-form" method="post">
                                        <input type="text" name="name" placeholder="Full Name" required class="interactive-el">
                                        <input type="email" name="email" placeholder="Email Address" required class="interactive-el">
                                        <input type="text" name="company" placeholder="Company / Brand" required class="interactive-el">
                                        <input type="number" name="phone-number" placeholder="Phone Number" required class="interactive-el">
                                        <select name="service" class="sleek-select interactive-el" required style="border-bottom: 1px solid var(--border-light); padding: 1rem 0;">
                                                <option value="" disabled selected style="color: var(--text-muted);">Select Service</option>
                                                <option>Web Development</option>
                                                <option>App Development</option>
                                                <option>Branding &amp; Identity</option>
                                                <option>Packaging Design</option>
                                                <option>Google Ads / Meta Ads</option>
                                                <option>Social Media Management</option>
                                                <option>SEO / AEO</option>
                                                <option>AI Solutions</option>
                                                <option>Video Editing</option>
                                                <option>Game UI/UX</option>
                                                <option>Full Digital Architecture</option>
                                        </select>
                                        <textarea name="message" required placeholder="Tell us about your project..." rows="4" class="interactive-el"></textarea>
                                        <button type="submit" class="btn-primary interactive-el" style="align-self: flex-start;">Send Message</button>
                                </form>
                                <div class="contact-success" id="contact-success">
                                        <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
                                        <h4>Message Sent!</h4>
                                        <p>We'll be in touch within 24 hours.</p>
                                </div>
                        </div>
                </div>
        </section>

        <!-- CHAT WIDGET -->
        <div class="chat-nudge" id="chat-nudge" role="button" tabindex="0" aria-label="Open chat assistant">👋 Need help? Ask me anything — I can quote a project in under a minute.</div>
        <div class="chatbot-widget" id="chatbot">
                <div class="chatbot-header interactive-el" onclick="toggleChat()">
                        <span>Graphinxt Assistant</span>
                        <div style="display:flex; align-items:center; gap:10px;">
                                <select id="chat-lang-select" class="interactive-el" onclick="event.stopPropagation()" aria-label="Chat language"></select>
                                <span id="chat-toggle-icon">+</span>
                        </div>
                </div>
                <div class="chatbot-body">
                        <div class="chat-messages" id="chat-messages">
                                <div class="msg bot-msg">Welcome to Graphinxt. How can we help architect your digital excellence today?</div>
                        </div>
                        <div class="chat-quick-replies" id="quick-replies"></div>
                        <div class="chat-input-area">
                                <input type="text" id="chat-input" placeholder="Type your message..." class="interactive-el">
                                <button onclick="sendChatMessage()" class="interactive-el">Send</button>
                        </div>
                </div>
        </div>

        <!-- BACK TO TOP -->
        <div class="back-to-top" id="back-to-top" onclick="window.scrollTo({top:0,behavior:'smooth'})">
                <svg viewBox="0 0 24 24"><polyline points="18 15 12 9 6 15"/></svg>
        </div>

        <!-- MODAL -->
        <div class="modal-overlay" id="modal-overlay" onclick="closeModal(event)">
                <div class="modal-content" id="modal-content-inner">
                        <div class="modal-chrome" id="modal-chrome">
                                <span class="browser-dots"><span class="browser-dot"></span><span class="browser-dot"></span><span class="browser-dot"></span></span>
                                <span class="browser-url" id="modal-domain"></span>
                        </div>
                        <button class="close-modal interactive-el" onclick="closeModalDirect()">×</button>
                        <div id="modal-body"></div>
                </div>
        </div>

        <!-- JAVASCRIPT LOGIC -->

    <!-- Cookie consent (GDPR / AdSense compliance) -->
   <!--  <div id="grx-cookie" style="display:none; position:fixed; bottom:1.2rem; right:1.2rem; max-width:380px; background:rgba(30,30,32,0.97); backdrop-filter:blur(20px); border:1px solid rgba(233,196,111,0.4); border-radius:18px; padding:1.3rem 1.4rem; z-index:9999; box-shadow:0 20px 50px rgba(0,0,0,0.5);">
        <div style="font-size:0.85rem; color:#fff; font-weight:600; margin-bottom:0.5rem;">🍪 We use cookies</div>
        <div style="font-size:0.78rem; color:#a1a1a5; line-height:1.6; margin-bottom:1rem;">We use cookies for analytics and advertising to keep our free tools running. See our <a href="/privacy" style="color:#e9c46f;">Privacy Policy</a>.</div>
        <div style="display:flex; gap:0.5rem; flex-wrap:wrap;">
            <button onclick="grxCookie(true)" style="flex:1; background:#e9c46f; color:#363638; border:none; padding:0.6rem 1rem; border-radius:20px; font-weight:800; font-size:0.72rem; text-transform:uppercase; letter-spacing:0.5px; cursor:pointer; font-family:inherit;">Accept</button>
            <button onclick="grxCookie(false)" style="flex:1; background:transparent; color:#a1a1a5; border:1px solid rgba(233,196,111,0.2); padding:0.6rem 1rem; border-radius:20px; font-size:0.72rem; text-transform:uppercase; letter-spacing:0.5px; cursor:pointer; font-family:inherit;">Essential only</button>
        </div>
    </div> -->
     <?php include 'footer.php';?>
    <script src="assets/js/script.js?v=2"></script>
</body>
</html>
