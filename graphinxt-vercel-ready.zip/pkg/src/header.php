 <div class="faith-banner" role="note" aria-label="Ek Onkar invocation">
                <div class="symbol"><img src="/assets/ekonkar.png" width="125"></div>
                <div class="translation">Ek Onkaar: There is only One Creator, realized by the Grace of the True Guru.</div>
        </div>
        <div class="ambient-glow glow-top"></div>
        <canvas id="bg-canvas"></canvas>
        <div class="cursor-dot"></div>
        <div class="cursor-outline"></div>

        <!-- Floating Navbar -->
        <nav class="navbar">
               <a href="/" style="color:white; text-decoration: none;"> <div class="logo interactive-el">Graphinxt<span class="accent-dot">.</span></div></a>
                <ul class="nav-links">
                        <li><a href="/about/" class="interactive-el">About</a></li>
                        <li><a href="/portfolio/" class="interactive-el">Portfolio</a></li>
                        <li><a href="/#services" class="interactive-el">Services</a></li>
                        <li class="nav-dropdown">
                                <a href="/solutions/" class="interactive-el nav-dropdown-toggle">AI Growth <span class="nav-caret">▾</span></a>
                                <ul class="nav-dropdown-menu">
                                        <li><a href="/solutions/" class="interactive-el">Growth Solutions</a></li>
                                        <li><a href="/growth-planner/" class="interactive-el">Growth Planner</a></li>
                                </ul>
                        </li>
                        <li><a href="/tools/" class="interactive-el">AI Free Tools</a></li>
                        <li><a href="/blog/" class="interactive-el">Insights</a></li>
                        <li><a href="/services/ads?enquire=1" class="interactive-el" style="cursur: pointer !important">Request a Quote</a></li>
                        <li><button id="theme-toggle" class="interactive-el mode-toggle" aria-label="Toggle Theme">☼</button></li>
                </ul>
                <button id="theme-toggle-mobile-header" class="interactive-el mode-toggle mode-toggle-mobile" aria-label="Toggle Theme">☼</button>
                <button class="nav-toggle interactive-el" id="nav-toggle" aria-label="Menu"><span></span><span></span><span></span></button>
        </nav>
        <div class="mobile-menu" id="mobile-menu">
                <a href="/about/" class="interactive-el">About</a>
                <a href="/portfolio/" class="interactive-el">Portfolio</a>
                <a href="/services/" class="interactive-el">Services</a>
                <a href="/solutions" class="interactive-el">Growth Solutions</a>
                <a href="/growth-planner/" class="interactive-el">Growth Planner</a>
                <a href="/tools/" class="interactive-el">AI Free Tools</a>
                <a href="/blog/" class="interactive-el">Insights</a>
                <a href="/#contact" class="interactive-el">Contact</a>
                <button id="theme-toggle-mobile" class="interactive-el mobile-theme-btn" aria-label="Toggle Theme"><span id="mobile-theme-icon">☼</span> Toggle Theme</button>
        </div>