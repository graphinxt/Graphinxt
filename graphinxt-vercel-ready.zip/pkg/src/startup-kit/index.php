<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Free Startup Launch Kit Generator | Graphinxt</title>
    <meta name="description" content="Free AI startup kit: business name ideas, taglines, brand colour palette, logo concepts, and domain checks — plus a downloadable branded PDF.">
    <meta name="robots" content="index, follow">
           <link rel="stylesheet" href="../assets/style.css">
  <link rel="stylesheet" href="../assets/header.css">
        <link rel="shortcut icon" href="../assets/favicon.ico" type="image/x-icon">
        <link rel="icon" href="../assets/favicon.ico" type="image/x-icon">
    <link rel="canonical" href="https://graphinxt.com/startup-kit">
    <meta property="og:site_name" content="Graphinxt">
    <meta property="og:type" content="website">
    <meta property="og:title" content="Free Startup Launch Kit Generator | Graphinxt">
    <meta property="og:description" content="Business name ideas, taglines, and a brand color palette — free, instant, shareable.">
    <meta property="og:url" content="https://graphinxt.com/startup-kit">
    <meta property="og:image" content="https://graphinxt.com/assets/og-cover.jpg">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:image" content="https://graphinxt.com/assets/og-cover.jpg">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@200;300;400;500;800&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "WebApplication",
      "name": "Graphinxt Startup Launch Kit Generator",
      "url": "https://graphinxt.com/startup-kit",
      "applicationCategory": "BusinessApplication",
      "offers": { "@type": "Offer", "price": "0", "priceCurrency": "USD" },
      "description": "Free instant startup launch kit generator: business names, taglines, and brand color palette."
    }
    </script>

<!-- ===== ANALYTICS & CONVERSION TRACKING ===== -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-58PYC27MPE"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-58PYC27MPE');
</script>
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '2162187584315430');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=2162187584315430&ev=PageView&noscript=1" /></noscript>
<script>
  window.trackConversion = function(eventName, params) {
    params = params || {};
    try { if (typeof gtag === 'function') gtag('event', eventName, params); } catch(e) {}
    try { if (typeof fbq === 'function') fbq('trackCustom', eventName, params); } catch(e) {}
  };
  document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('a[href*="wa.me"]').forEach(function(el) {
      el.addEventListener('click', function() { window.trackConversion('whatsapp_click', { page: window.location.pathname }); });
    });
  });
</script>
<!-- ===== END ANALYTICS ===== -->

    <style>
        :root {
            --bg-dark: #363638; --bg-darker: #2a2a2c; --brand-gold: #e9c46f; --brand-gold-hover: #d4ae58;
            --text-main: #ffffff; --text-muted: #a1a1a5; --card-bg: rgba(255,255,255,0.02);
            --border-light: rgba(233,196,111,0.12); --border-glow: rgba(233,196,111,0.4);
            --nav-bg: rgba(42,42,44,0.4); --nav-bg-scrolled: rgba(30,30,32,0.8);
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Montserrat', sans-serif; scroll-behavior: smooth; }
        section { padding: 7rem 5%; max-width: 1100px; margin: 0 auto; position: relative; z-index: 1; }
        .hero-sec { padding-top: 14rem; text-align: center; }
        .eyebrow { font-size: 0.75rem; color: var(--brand-gold); text-transform: uppercase; letter-spacing: 3px; margin-bottom: 1.2rem; display: inline-block; }
        .hero-sec h1 { font-size: clamp(2rem, 5vw, 3.4rem); font-weight: 200; line-height: 1.15; margin-bottom: 1.2rem; }
        .hero-sec h1 strong { font-weight:800; background:linear-gradient(to right,#ffffff,var(--brand-gold)); -webkit-background-clip:text; background-clip:text; -webkit-text-fill-color:transparent; color:var(--brand-gold); }
        .hero-sec p { color: var(--text-muted); max-width: 580px; margin: 0 auto 2.5rem; font-weight: 300; }

        .kit-card { background: var(--card-bg); border: 1px solid var(--border-light); border-radius: 28px; padding: 3rem; max-width: 820px; margin: 0 auto; }
        .kit-form-row { display: flex; gap: 1rem; flex-wrap: wrap; margin-bottom: 1rem; }
        .kit-input, .kit-select { flex: 1; min-width: 200px; background: var(--bg-darker); border: 1px solid var(--border-light); color: var(--text-main); padding: 1rem 1.4rem; border-radius: 30px; font-size: 0.9rem; outline: none; font-family: inherit; }
        .kit-input:focus, .kit-select:focus { border-color: var(--brand-gold); }
        .kit-select { cursor: pointer; }
        .kit-run-btn { background: var(--brand-gold); color: var(--bg-dark) !important; padding: 1rem 2.4rem; border-radius: 30px; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; border: none; font-size: 0.78rem; cursor: pointer; transition: all .3s; width: 100%; margin-top: 0.5rem; }
        .kit-run-btn:hover { transform: scale(1.02); }
        .kit-hint { text-align: center; font-size: 0.7rem; color: var(--text-muted); opacity: 0.7; margin-top: 1rem; }

        .kit-results { display: none; margin-top: 2.5rem; }
        .kit-results.show { display: block; animation: kitFadeIn .5s ease; }
        @keyframes kitFadeIn { from { opacity:0; transform: translateY(12px);} to { opacity:1; transform: translateY(0);} }
        .kit-section-title { font-size: 0.95rem; font-weight: 500; margin: 0 0 1rem; color: var(--brand-gold); display: flex; align-items: center; justify-content: space-between; }
        .kit-regen-btn { background: transparent; border: 1px solid var(--border-light); color: var(--text-muted); font-size: 0.65rem; text-transform: uppercase; letter-spacing: 0.5px; padding: 4px 12px; border-radius: 20px; cursor: pointer; }
        .kit-regen-btn:hover { color: var(--brand-gold); border-color: var(--brand-gold); }

        .kit-names-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px,1fr)); gap: 0.8rem; margin-bottom: 2rem; }
        .kit-name-card { background: var(--bg-darker); border: 1px solid var(--border-light); border-radius: 14px; padding: 1rem 1.2rem; }
        .kit-name-card .name { font-size: 1.05rem; font-weight: 700; margin-bottom: 0.5rem; }
        .kit-name-card .domain-links { display: flex; gap: 0.5rem; flex-wrap: wrap; }
        .kit-name-card .domain-links a { font-size: 0.65rem; color: var(--brand-gold); text-decoration: none; border: 1px solid var(--border-light); padding: 2px 8px; border-radius: 10px; }
        .kit-name-card .domain-links a:hover { border-color: var(--brand-gold); }

        .kit-taglines { list-style: none; margin-bottom: 2rem; }
        .kit-taglines li { font-size: 0.9rem; color: var(--text-muted); font-weight: 300; padding: 0.8rem 0; border-bottom: 1px solid var(--border-light); font-style: italic; }
        .kit-taglines li:last-child { border-bottom: none; }

        .kit-palette-row { display: flex; gap: 0; border-radius: 14px; overflow: hidden; margin-bottom: 0.8rem; height: 90px; }
        .kit-swatch { flex: 1; display: flex; align-items: flex-end; padding: 0.5rem; }
        .kit-swatch span { font-size: 0.6rem; font-family: monospace; background: rgba(0,0,0,0.4); color: #fff; padding: 2px 6px; border-radius: 4px; }
        .kit-palette-name { text-align: center; font-size: 0.78rem; color: var(--text-muted); margin-bottom: 2rem; }

        .kit-cta-row { display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap; margin-top: 2rem; }
        .kit-disclaimer { font-size: 0.68rem; color: var(--text-muted); opacity: 0.65; text-align: center; max-width: 600px; margin: 1.5rem auto 0; }

        .ai-sim-card { background: var(--bg-darker); border: 1px solid var(--border-light); border-radius: 16px; padding: 1.4rem 1.6rem; }
        .ai-sim-label { display: inline-flex; align-items: center; gap: 6px; font-size: 0.62rem; text-transform: uppercase; letter-spacing: 1px; font-weight: 700; color: var(--text-muted); margin-bottom: 0.8rem; }
        .ai-sim-label .dot { width: 6px; height: 6px; border-radius: 50%; background: var(--brand-gold); }
        .ai-sim-text { font-size: 0.85rem; color: var(--text-muted); font-weight: 300; line-height: 1.6; }
        .ai-sim-text strong { color: var(--brand-gold); font-weight: 600; }

        .kit-select { max-width: 100%; }
        @media(max-width: 700px) { .kit-form-row .kit-select { flex: 1 1 100%; } }

        .funnel-card { max-width: 820px; margin: 3rem auto 0; background: linear-gradient(135deg, rgba(233,196,111,0.08), transparent); border: 1px solid var(--border-glow); border-radius: 24px; padding: 2.5rem; text-align: center; }
        .funnel-card h3 { font-size: 1.3rem; font-weight: 200; margin-bottom: 0.8rem; }
        .funnel-card h3 strong { color: var(--brand-gold); font-weight: 800; }
        .funnel-card p { color: var(--text-muted); font-size: 0.85rem; margin-bottom: 1.5rem; font-weight: 300; }

        footer { padding: 4rem 5%; text-align: center; border-top: 1px solid var(--border-light); color: var(--text-muted); font-size: 0.8rem; }
        footer a { color: var(--brand-gold); text-decoration: none; }
    </style>
</head>
<body>
    <canvas id="bg-canvas"></canvas>
    <div class="ambient-glow"></div>

          <?php include '../header.php';?>

    <header class="hero-sec">
        <span class="eyebrow">Free Tool · No Signup</span>
        <h1>Startup Launch Kit <strong>Generator</strong></h1>
        <p>Business name ideas, taglines, and a brand color palette — tailored to your industry, generated instantly. A real starting point, not a finished brand.</p>
    </header>

    <section style="padding-top:0;">
        <div class="kit-card">
            <div class="kit-form-row">
                <input type="text" id="kit-idea" class="kit-input" placeholder="What's your business idea? (e.g. organic dog treats)" autocomplete="off">
            </div>
            <div class="kit-form-row">
                <input type="text" id="kit-audience" class="kit-input" placeholder="Who's it for? (optional — e.g. busy pet owners)" autocomplete="off">
            </div>
            <div class="kit-form-row">
                <select id="kit-industry" class="kit-select">
                    <option value="tech">Tech &amp; SaaS</option>
                    <option value="wellness">Wellness &amp; Health</option>
                    <option value="food">Food &amp; Beverage</option>
                    <option value="fashion">Fashion &amp; Retail</option>
                    <option value="professional">Professional Services</option>
                    <option value="creative">Creative &amp; Design</option>
                </select>
                <select id="kit-tone" class="kit-select">
                    <option value="professional">Tone: Professional</option>
                    <option value="playful">Tone: Playful</option>
                    <option value="luxury">Tone: Luxury</option>
                    <option value="minimal">Tone: Minimal</option>
                    <option value="bold">Tone: Bold</option>
                </select>
                <select id="kit-namestyle" class="kit-select">
                    <option value="blended">Names: Blended (default)</option>
                    <option value="short">Names: Short &amp; Punchy</option>
                    <option value="descriptive">Names: Descriptive</option>
                    <option value="invented">Names: Invented Word</option>
                </select>
            </div>
            <button id="kit-run-btn" class="kit-run-btn" onclick="runKitGenerator()">Generate My Launch Kit →</button>
            <div class="kit-hint">Instant, deterministic generation — same input always gives the same kit, so you can bookmark a result you like.</div>

            <div class="kit-results" id="kit-results">
                <div class="ai-sim-card" id="kit-reasoning-card" style="margin-bottom:2rem;"></div>

                <div class="kit-section-title">Name Ideas <button class="kit-regen-btn" onclick="regenSection('names')">Shuffle ↻</button></div>
                <div class="kit-names-grid" id="kit-names-grid"></div>

                <div class="kit-section-title">Elevator Pitch <button class="kit-regen-btn" onclick="regenSection('pitch')">Shuffle ↻</button></div>
                <p id="kit-pitch" style="font-size:0.9rem; color:var(--text-muted); font-weight:300; font-style:italic; margin-bottom:2rem; padding:1rem 1.2rem; background:var(--bg-darker); border-radius:14px; border:1px solid var(--border-light);"></p>

                <div class="kit-section-title">Tagline Ideas <button class="kit-regen-btn" onclick="regenSection('taglines')">Shuffle ↻</button></div>
                <ul class="kit-taglines" id="kit-taglines"></ul>

                <div class="kit-section-title">Mission Statement <button class="kit-regen-btn" onclick="regenSection('mission')">Shuffle ↻</button></div>
                <p id="kit-mission" style="font-size:0.9rem; color:var(--text-muted); font-weight:300; margin-bottom:2rem;"></p>

                <div class="kit-section-title">Social Handle Ideas</div>
                <div class="kit-names-grid" id="kit-handles" style="margin-bottom:2rem;"></div>

                <div class="kit-section-title">Brand Color Palette <button class="kit-regen-btn" onclick="regenSection('palette')">Shuffle ↻</button></div>
                <div class="kit-palette-row" id="kit-palette-row"></div>
                <div class="kit-sec-label" style="margin-top:2rem; font-size:0.8rem; color:var(--brand-gold); font-weight:600;">Advanced: Logo Mark Concepts</div>
                <div id="kit-logos" style="display:flex; gap:1.5rem; flex-wrap:wrap; margin-top:0.8rem;"></div>
                <div class="kit-sec-label" style="margin-top:2rem; font-size:0.8rem; color:var(--brand-gold); font-weight:600;">Advanced: Domain Ideas</div>
                <div id="kit-domains" style="display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:0.8rem; margin-top:0.8rem;"></div>
                <div class="kit-palette-name" id="kit-palette-name"></div>

                <p class="kit-disclaimer">Generated algorithmically from your input and industry — not a live domain availability check (use the links provided to confirm) and not a substitute for real brand strategy or trademark search. Think of this as a fast starting point for brainstorming, not a finished brand.</p>

                <div class="kit-cta-row">
                    <button class="btn-primary" onclick="downloadKitPDF()">Download Branded PDF</button>
                    <a href="/services/branding" class="btn-outline">See Branding Services</a>
                </div>
            </div>
        </div>

        <div class="funnel-card" id="funnel-card" style="display:none;">
            <h3>Like what you see? We can build the <strong>real thing</strong>.</h3>
            <p>This kit is a 30-second starting point. A real brand identity, logo, and launch-ready website is what we actually do — and your first strategy call is free.</p>
            <div class="kit-cta-row">
                <a href="/#contact" class="btn-primary">Book a Free Strategy Call</a>
                <a href="https://wa.me/971564785139" target="_blank" class="btn-outline">Ask on WhatsApp</a>
            </div>
        </div>
    </section>


    <script>
        window.addEventListener('scroll', () => {
            document.getElementById('navbar').classList.toggle('scrolled', document.documentElement.scrollTop > 30);
        });

        function hashString(str) { let h = 5381; for (let i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) >>> 0; return h; }
        function seededPick(seed, salt, arr) { return arr[hashString(seed + '::' + salt) % arr.length]; }
        function seededShuffle(seed, salt, arr) {
            const out = arr.slice();
            for (let i = out.length - 1; i > 0; i--) {
                const j = hashString(seed + '::' + salt + '::' + i) % (i + 1);
                const tmp = out[i]; out[i] = out[j]; out[j] = tmp;
            }
            return out;
        }
        function cap(s) { return s.charAt(0).toUpperCase() + s.slice(1); }

        const INDUSTRY_DATA = {
            tech: {
                label: 'Tech & SaaS',
                prefixes: ['Nova', 'Apex', 'Pulse', 'Grid', 'Loop', 'Nex', 'Byte', 'Core'],
                suffixes: ['ly', 'io', 'Hub', 'Base', 'Stack', 'Flow', 'Labs', 'OS'],
                taglineTemplates: [
                    'Built for how {idea} actually works.',
                    'The smarter way to {idea}.',
                    '{idea}, without the friction.',
                    'Where {idea} meets real intelligence.',
                    'Your {idea}, automated.'
                ],
                palettes: [
                    { name: 'Electric Signal', colors: ['#4F46E5', '#7C3AED', '#111827', '#F9FAFB'] },
                    { name: 'Midnight Grid', colors: ['#0EA5E9', '#1E293B', '#0F172A', '#E2E8F0'] },
                    { name: 'Neon Circuit', colors: ['#22D3EE', '#A78BFA', '#18181B', '#FAFAFA'] }
                ]
            },
            wellness: {
                label: 'Wellness & Health',
                prefixes: ['Pure', 'Root', 'Calm', 'Vital', 'Bloom', 'Zen', 'Even', 'Whole'],
                suffixes: ['ly', 'Well', 'Care', 'Vita', 'Glow', 'Balance', 'Roots', 'Space'],
                taglineTemplates: [
                    '{idea}, the way nature intended.',
                    'Rooted in real {idea}.',
                    'A calmer approach to {idea}.',
                    '{idea} that actually feels good.',
                    'Wellness starts with real {idea}.'
                ],
                palettes: [
                    { name: 'Sage & Cream', colors: ['#87A96B', '#E8DCC8', '#4A5D4E', '#FAF7F2'] },
                    { name: 'Warm Earth', colors: ['#C08552', '#F1E3D3', '#5C4033', '#FDFBF7'] },
                    { name: 'Soft Bloom', colors: ['#D8A7B1', '#F4E9E7', '#6B4C57', '#FFFFFF'] }
                ]
            },
            food: {
                label: 'Food & Beverage',
                prefixes: ['Toast', 'Hearth', 'Crave', 'Kettle', 'Golden', 'Rustic', 'Wild', 'Corner'],
                suffixes: ['ery', 'Kitchen', 'Table', 'Fare', 'Pantry', 'Co', 'House', 'Bites'],
                taglineTemplates: [
                    '{idea}, made fresh, made simple.',
                    'Real {idea}, real ingredients.',
                    'Small batch {idea}, big flavor.',
                    '{idea} worth coming back for.',
                    'Honest {idea}, every time.'
                ],
                palettes: [
                    { name: 'Warm Toast', colors: ['#E8622C', '#FFF4E0', '#2B1810', '#F4A261'] },
                    { name: 'Harvest', colors: ['#D4A24E', '#3D2B1F', '#F7EDE2', '#8B5E34'] },
                    { name: 'Fresh Market', colors: ['#6B8E4E', '#FDF6E3', '#2D3B1F', '#E9C46A'] }
                ]
            },
            fashion: {
                label: 'Fashion & Retail',
                prefixes: ['Muse', 'Atelier', 'Thread', 'Noir', 'Studio', 'Form', 'Edit', 'Wear'],
                suffixes: ['Co', 'House', 'Studio', 'Label', 'Collective', 'Atelier', 'Row', 'Edit'],
                taglineTemplates: [
                    '{idea}, designed to last.',
                    'Wear your {idea} well.',
                    '{idea} for the way you actually live.',
                    'Quiet confidence, curated {idea}.',
                    '{idea} that speaks for itself.'
                ],
                palettes: [
                    { name: 'Noir & Gold', colors: ['#1A1A1A', '#D4AF37', '#F5E6E0', '#FFFFFF'] },
                    { name: 'Blush Studio', colors: ['#E8B4B8', '#2D2A2E', '#F7F3F0', '#C9A992'] },
                    { name: 'Modern Mono', colors: ['#000000', '#FFFFFF', '#9B9B9B', '#E5E5E5'] }
                ]
            },
            professional: {
                label: 'Professional Services',
                prefixes: ['Meridian', 'Sterling', 'Anchor', 'Summit', 'Beacon', 'North', 'Ledger', 'Trust'],
                suffixes: ['Partners', 'Group', 'Advisory', 'Consulting', 'Associates', 'Co', 'Collective', 'Firm'],
                taglineTemplates: [
                    'Clear {idea}, backed by real expertise.',
                    '{idea} you can actually trust.',
                    'Straightforward {idea}, no jargon.',
                    'Your {idea}, handled properly.',
                    '{idea} built on real relationships.'
                ],
                palettes: [
                    { name: 'Navy & Gold', colors: ['#1E3A5F', '#E9C46F', '#F5F5F5', '#FFFFFF'] },
                    { name: 'Slate Trust', colors: ['#334155', '#94A3B8', '#F1F5F9', '#0F172A'] },
                    { name: 'Deep Forest', colors: ['#1B4332', '#95D5B2', '#F0FDF4', '#081C15'] }
                ]
            },
            creative: {
                label: 'Creative & Design',
                prefixes: ['Prism', 'Canvas', 'Spark', 'Frame', 'Ink', 'Vivid', 'Motif', 'Palette'],
                suffixes: ['Studio', 'Collective', 'Co', 'Works', 'Lab', 'House', 'Design', 'Atelier'],
                taglineTemplates: [
                    '{idea}, with a point of view.',
                    'Bold {idea}, made memorable.',
                    '{idea} that does not look like everyone else\'s.',
                    'Creative {idea}, no templates.',
                    '{idea} designed to be noticed.'
                ],
                palettes: [
                    { name: 'Vivid Play', colors: ['#FF6B6B', '#4ECDC4', '#FFE66D', '#1A1A2E'] },
                    { name: 'Ink & Paper', colors: ['#2B2B2B', '#F4F1EA', '#C0392B', '#FFFFFF'] },
                    { name: 'Sunset Studio', colors: ['#F72585', '#7209B7', '#3A0CA3', '#FFF3F0'] }
                ]
            }
        };

        const TONE_DATA = {
            professional: { adjective: 'reliable', verb: 'simplify', taglines: ['The trusted choice for {idea}.', 'Serious {idea}, straightforward results.', '{idea}, done right.'] },
            playful: { adjective: 'fun', verb: 'reinvent', taglines: ['{idea} that does not take itself too seriously.', 'Say hello to better {idea}.', '{idea}, but make it fun.'] },
            luxury: { adjective: 'refined', verb: 'elevate', taglines: ['An elevated take on {idea}.', '{idea}, crafted without compromise.', 'The art of {idea}.'] },
            minimal: { adjective: 'effortless', verb: 'simplify', taglines: ['{idea}. Simplified.', 'Just better {idea}.', '{idea} -- nothing extra.'] },
            bold: { adjective: 'unforgettable', verb: 'redefine', taglines: ['{idea} that refuses to blend in.', 'Unapologetic {idea}.', '{idea}, on your terms.'] }
        };

        let lastKit = null;
        let shuffleSalts = { names: 0, taglines: 0, palette: 0, pitch: 0, mission: 0 };

        function cleanIdea(raw) {
            return raw.trim().toLowerCase().replace(/[^a-z0-9\s-]/gi, '').split(/\s+/).slice(0, 3).join(' ') || 'startup';
        }
        function coreWord(idea) {
            const words = idea.split(' ').filter(function(w) { return w.length > 2; });
            return words.length ? words[words.length - 1] : idea;
        }

        function generateNames(idea, industry, shuffleSalt, nameStyle) {
            nameStyle = nameStyle || 'blended';
            const data = INDUSTRY_DATA[industry];
            const core = coreWord(idea);
            const coreCap = cap(core);
            const names = [];
            const seen = {};
            function addName(n) { if (!seen[n]) { seen[n] = true; names.push(n); } }
            const prefixes = seededShuffle(idea, 'prefix' + shuffleSalt, data.prefixes);
            const suffixes = seededShuffle(idea, 'suffix' + shuffleSalt, data.suffixes);
            const trimmed = core.length > 4 ? cap(core.slice(0, Math.ceil(core.length * 0.55))) : coreCap;

            if (nameStyle === 'short') {
                // Prioritize compact, punchy combos — prefix alone, or trimmed core + short suffix
                for (let i = 0; i < prefixes.length && names.length < 9; i++) addName(prefixes[i]);
                for (let i = 0; i < suffixes.length && names.length < 9; i++) addName(trimmed + suffixes[i]);
            } else if (nameStyle === 'descriptive') {
                // Prioritize keyword-forward combos that describe what the business does
                for (let i = 0; i < suffixes.length && names.length < 9; i++) addName(coreCap + suffixes[i]);
                for (let i = 0; i < prefixes.length && names.length < 9; i++) addName(prefixes[i] + coreCap);
            } else if (nameStyle === 'invented') {
                // Prioritize portmanteau-style blends of prefix + trimmed core
                for (let i = 0; i < prefixes.length && names.length < 9; i++) addName(prefixes[i].slice(0, 4) + trimmed.toLowerCase());
                for (let i = 0; i < suffixes.length && names.length < 9; i++) addName(trimmed + suffixes[i]);
            } else {
                // Blended (default): the original balanced mix
                for (let i = 0; i < prefixes.length && names.length < 5; i++) addName(prefixes[i] + coreCap);
                for (let i = 0; i < suffixes.length && names.length < 9; i++) addName(coreCap + suffixes[i]);
                if (core.length > 4) addName(trimmed + seededPick(idea, 'trim' + shuffleSalt, data.suffixes));
            }
            return names.slice(0, 9);
        }

        function generateTaglines(idea, industry, tone, shuffleSalt) {
            const data = INDUSTRY_DATA[industry];
            const toneData = TONE_DATA[tone];
            const industryShuffled = seededShuffle(idea, 'tag' + shuffleSalt, data.taglineTemplates);
            const toneShuffled = seededShuffle(idea, 'tonetag' + shuffleSalt, toneData.taglines);
            const combined = industryShuffled.slice(0, 3).concat(toneShuffled.slice(0, 3));
            return combined.map(function(t) { return t.replace(/\{idea\}/g, idea); });
        }

        function pickPalette(idea, industry, shuffleSalt) {
            const data = INDUSTRY_DATA[industry];
            return seededPick(idea, 'pal' + shuffleSalt, data.palettes);
        }

        function generatePitch(idea, industry, audience, tone, shuffleSalt) {
            const data = INDUSTRY_DATA[industry];
            const toneData = TONE_DATA[tone];
            const who = audience && audience.trim() ? audience.trim() : 'people who need it most';
            const templates = [
                'We help ' + who + ' ' + toneData.verb + ' ' + idea + ' — ' + toneData.adjective + ', and built to actually work.',
                'For ' + who + ', ' + idea + ' should feel ' + toneData.adjective + '. That is exactly what we built.',
                'A ' + toneData.adjective + ' approach to ' + idea + ', made for ' + who + '.'
            ];
            return seededPick(idea, 'pitch' + shuffleSalt, templates);
        }

        function generateMission(idea, industry, audience, shuffleSalt) {
            const who = audience && audience.trim() ? audience.trim() : 'our customers';
            const templates = [
                'Our mission is to make ' + idea + ' genuinely better for ' + who + ' — no shortcuts, no gimmicks.',
                'We exist to bring honest, well-made ' + idea + ' to ' + who + '.',
                'We believe ' + who + ' deserve ' + idea + ' that actually delivers on its promise.'
            ];
            return seededPick(idea, 'mission' + shuffleSalt, templates);
        }

        function generateHandles(names) {
            return names.slice(0, 4).map(function(n) {
                const handle = n.toLowerCase().replace(/[^a-z0-9]/g, '');
                return { name: n, handle: handle };
            });
        }

        function generateReasoning(idea, industryLabel, audience, tone, nameStyle) {
            const toneData = TONE_DATA[tone];
            const nameStyleText = {
                blended: 'a balanced mix of prefix- and suffix-based combinations',
                short: 'compact, punchy combinations prioritized for memorability',
                descriptive: 'keyword-forward combinations that describe what the business does',
                invented: 'portmanteau-style blends for a more distinctive, ownable name'
            }[nameStyle];
            const audienceText = audience && audience.trim() ? ('targeting ' + audience.trim()) : 'without a specified audience, so kept broad';
            return 'Built from <strong>"' + idea + '"</strong> in the <strong>' + industryLabel + '</strong> space, ' + audienceText + ', with a <strong>' + tone + '</strong> tone. Names lean on ' + nameStyleText + '; taglines blend ' + industryLabel.toLowerCase() + '-specific phrasing with ' + toneData.adjective + ' language; the palette draws from color associations common in ' + industryLabel.toLowerCase() + ' branding.';
        }

        function renderNames(idea, industry, salt, nameStyle) {
            const names = generateNames(idea, industry, salt, nameStyle);
            document.getElementById('kit-names-grid').innerHTML = names.map(function(n) {
                const domain = n.toLowerCase().replace(/[^a-z0-9]/g, '');
                return '<div class="kit-name-card"><div class="name">' + n + '</div><div class="domain-links"><a href="https://www.namecheap.com/domains/registration/results/?domain=' + domain + '" target="_blank" rel="noopener">' + domain + '.com →</a></div></div>';
            }).join('');
            return names;
        }
        function renderTaglines(idea, industry, tone, salt) {
            const taglines = generateTaglines(idea, industry, tone, salt);
            document.getElementById('kit-taglines').innerHTML = taglines.map(function(t) { return '<li>"' + t + '"</li>'; }).join('');
        }
        function renderPalette(idea, industry, salt) {
            const palette = pickPalette(idea, industry, salt);
            document.getElementById('kit-palette-row').innerHTML = palette.colors.map(function(c) {
                return '<div class="kit-swatch" style="background:' + c + ';"><span>' + c + '</span></div>';
            }).join('');
            document.getElementById('kit-palette-name').innerText = palette.name;
            window._kitPalette = palette;
        }
        function renderKitExtras(names, idea) {
            const p = window._kitPalette || { colors: ['#e9c46f','#363638','#ffffff'] };
            const c1 = p.colors[0], c2 = p.colors[1] || '#363638';
            const name = names[0] || 'Brand';
            const letter = name.charAt(0).toUpperCase();
            const marks = [
                '<svg viewBox="0 0 90 90" width="90" height="90"><circle cx="45" cy="45" r="42" fill="' + c2 + '"/><text x="45" y="60" font-family="Georgia,serif" font-size="44" font-weight="800" fill="' + c1 + '" text-anchor="middle">' + letter + '</text></svg>',
                '<svg viewBox="0 0 90 90" width="90" height="90"><rect x="4" y="4" width="82" height="82" rx="18" fill="' + c1 + '"/><text x="45" y="60" font-family="Montserrat,sans-serif" font-size="42" font-weight="800" fill="' + c2 + '" text-anchor="middle">' + letter + '</text></svg>',
                '<svg viewBox="0 0 90 90" width="90" height="90"><rect x="4" y="4" width="82" height="82" rx="45" fill="none" stroke="' + c1 + '" stroke-width="4"/><text x="45" y="58" font-family="Montserrat,sans-serif" font-size="34" font-weight="300" fill="' + c1 + '" text-anchor="middle">' + letter + '</text></svg>'
            ];
            document.getElementById('kit-logos').innerHTML = marks.map(m => '<div style="display:flex; flex-direction:column; align-items:center; gap:0.5rem;">' + m + '</div>').join('');
            const doms = names.slice(0, 3).map(n => {
                const base = n.toLowerCase().replace(/[^a-z0-9]/g, '');
                return '<div class="kit-name-card"><div class="name" style="font-size:0.9rem;">' + base + '.com \u00b7 .co \u00b7 .io</div><div class="domain-links"><a href="https://www.namecheap.com/domains/registration/results/?domain=' + base + '" target="_blank" rel="noopener">Check availability \u2192</a></div></div>';
            }).join('');
            document.getElementById('kit-domains').innerHTML = doms;
        }
        function renderPitch(idea, industry, audience, tone, salt) {
            document.getElementById('kit-pitch').innerText = generatePitch(idea, industry, audience, tone, salt);
        }
        function renderMission(idea, industry, audience, salt) {
            document.getElementById('kit-mission').innerText = generateMission(idea, industry, audience, salt);
        }
        function renderHandles(names) {
            const handles = generateHandles(names);
            document.getElementById('kit-handles').innerHTML = handles.map(function(h) {
                return '<div class="kit-name-card"><div class="name" style="font-size:0.9rem;">@' + h.handle + '</div><div class="domain-links"><a href="https://instagram.com/' + h.handle + '" target="_blank" rel="noopener">Check Instagram →</a></div></div>';
            }).join('');
        }
        function renderReasoning(idea, industryLabel, audience, tone, nameStyle) {
            document.getElementById('kit-reasoning-card').innerHTML =
                '<span class="ai-sim-label"><span class="dot"></span>How This Kit Was Generated</span>' +
                '<p class="ai-sim-text">' + generateReasoning(idea, industryLabel, audience, tone, nameStyle) + '</p>';
        }

        window.runKitGenerator = function() {
            const ideaRaw = document.getElementById('kit-idea').value.trim();
            const idea = cleanIdea(ideaRaw || 'your business');
            const audience = document.getElementById('kit-audience').value.trim();
            const industry = document.getElementById('kit-industry').value;
            const tone = document.getElementById('kit-tone').value;
            const nameStyle = document.getElementById('kit-namestyle').value;
            shuffleSalts = { names: 0, taglines: 0, palette: 0, pitch: 0, mission: 0 };

            const names = renderNames(idea, industry, shuffleSalts.names, nameStyle);
            renderTaglines(idea, industry, tone, shuffleSalts.taglines);
            renderPalette(idea, industry, shuffleSalts.palette);
            renderPitch(idea, industry, audience, tone, shuffleSalts.pitch);
            renderMission(idea, industry, audience, shuffleSalts.mission);
            renderHandles(names);
            renderReasoning(idea, INDUSTRY_DATA[industry].label, audience, tone, nameStyle);
            renderKitExtras(names, idea);

            lastKit = { idea: idea, industry: industry, audience: audience, tone: tone, nameStyle: nameStyle };
            document.getElementById('kit-results').classList.add('show');
            document.getElementById('funnel-card').style.display = 'block';
            document.getElementById('kit-results').scrollIntoView({ behavior: 'smooth', block: 'start' });
            if (window.trackConversion) window.trackConversion('tool_engagement', { tool: 'startup_kit', industry: industry, tone: tone });
        };

        window.regenSection = function(section) {
            if (!lastKit) return;
            shuffleSalts[section]++;
            if (section === 'names') {
                const names = renderNames(lastKit.idea, lastKit.industry, shuffleSalts.names, lastKit.nameStyle);
                renderHandles(names);
            }
            if (section === 'taglines') renderTaglines(lastKit.idea, lastKit.industry, lastKit.tone, shuffleSalts.taglines);
            if (section === 'palette') renderPalette(lastKit.idea, lastKit.industry, shuffleSalts.palette);
            if (section === 'pitch') renderPitch(lastKit.idea, lastKit.industry, lastKit.audience, lastKit.tone, shuffleSalts.pitch);
            if (section === 'mission') renderMission(lastKit.idea, lastKit.industry, lastKit.audience, shuffleSalts.mission);
        };

        document.getElementById('kit-idea').addEventListener('keypress', function(e) { if (e.key === 'Enter') runKitGenerator(); });

        window.downloadKitPDF = function() {
            if (!lastKit || !window.jspdf) return;
            const jsPDF = window.jspdf.jsPDF;
            const doc = new jsPDF();
            const data = INDUSTRY_DATA[lastKit.industry];
            const names = generateNames(lastKit.idea, lastKit.industry, shuffleSalts.names, lastKit.nameStyle);
            const taglines = generateTaglines(lastKit.idea, lastKit.industry, lastKit.tone, shuffleSalts.taglines);
            const palette = pickPalette(lastKit.idea, lastKit.industry, shuffleSalts.palette);
            const pitch = generatePitch(lastKit.idea, lastKit.industry, lastKit.audience, lastKit.tone, shuffleSalts.pitch);
            const mission = generateMission(lastKit.idea, lastKit.industry, lastKit.audience, shuffleSalts.mission);

            doc.setFillColor(54, 54, 56); doc.rect(0, 0, 210, 32, 'F');
            doc.setTextColor(233, 196, 111); doc.setFontSize(20); doc.setFont(undefined, 'bold');
            doc.text('GRAPHINXT.', 15, 20);
            doc.setTextColor(255,255,255); doc.setFontSize(10); doc.setFont(undefined, 'normal');
            doc.text('Startup Launch Kit', 15, 27);

            doc.setTextColor(20,20,20); doc.setFontSize(11);
            doc.text('For: ' + lastKit.idea + ' (' + data.label + ', ' + lastKit.tone + ' tone)', 15, 42);
            doc.setFontSize(9); doc.setTextColor(120,120,120);
            doc.text('Generated ' + new Date().toLocaleDateString(), 15, 48);

            let y = 60;
            doc.setTextColor(20,20,20); doc.setFontSize(13); doc.setFont(undefined, 'bold');
            doc.text('Elevator Pitch', 15, y); y += 8;
            doc.setFont(undefined, 'italic'); doc.setFontSize(10);
            let lines = doc.splitTextToSize(pitch, 180);
            doc.text(lines, 15, y); y += lines.length * 6 + 8;

            doc.setFont(undefined, 'bold'); doc.setFontSize(13); doc.text('Name Ideas', 15, y); y += 8;
            doc.setFont(undefined, 'normal'); doc.setFontSize(10);
            names.forEach(function(n) { doc.text('- ' + n, 15, y); y += 6; });

            y += 6; doc.setFontSize(13); doc.setFont(undefined, 'bold'); doc.text('Tagline Ideas', 15, y); y += 8;
            doc.setFont(undefined, 'normal'); doc.setFontSize(10);
            taglines.forEach(function(t) {
                const tLines = doc.splitTextToSize('"' + t + '"', 180);
                doc.text(tLines, 15, y); y += tLines.length * 6;
            });

            y += 6; doc.setFontSize(13); doc.setFont(undefined, 'bold'); doc.text('Mission Statement', 15, y); y += 8;
            doc.setFont(undefined, 'normal'); doc.setFontSize(10);
            lines = doc.splitTextToSize(mission, 180);
            doc.text(lines, 15, y); y += lines.length * 6 + 6;

            if (y > 230) { doc.addPage(); y = 20; }
            doc.setFontSize(13); doc.setFont(undefined, 'bold'); doc.text('Brand Palette: ' + palette.name, 15, y); y += 10;
            palette.colors.forEach(function(c, i) {
                const rgb = [parseInt(c.slice(1,3),16), parseInt(c.slice(3,5),16), parseInt(c.slice(5,7),16)];
                doc.setFillColor(rgb[0], rgb[1], rgb[2]);
                doc.rect(15 + i * 30, y, 25, 25, 'F');
                doc.setFontSize(8); doc.setTextColor(80,80,80);
                doc.text(c, 15 + i * 30, y + 32);
            });
            y += 45;

            doc.setFontSize(9); doc.setTextColor(120,120,120);
            const disclaimerLines = doc.splitTextToSize('Generated algorithmically as a brainstorming starting point -- not a live domain check, trademark search, or finished brand. Graphinxt Digital Content Creator FZ LLC.', 180);
            doc.text(disclaimerLines, 15, y);

            doc.save('graphinxt-startup-kit-' + lastKit.idea.replace(/[^a-z0-9]/gi,'-') + '.pdf');
            if (window.trackConversion) window.trackConversion('pdf_download', { tool: 'startup_kit' });
        };
    </script>

    <script>
    // Animated gold-particle background — matches Graphinxt homepage
    (function() {
        var canvas = document.getElementById('bg-canvas');
        if (!canvas) return;
        var ctx = (canvas.getContext) ? canvas.getContext('2d') : null;
        if (!ctx) return;
        if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
        var particles = [], w, h, animationId;
        function resize(){ w = canvas.width = window.innerWidth; h = canvas.height = window.innerHeight; }
        resize(); window.addEventListener('resize', resize);
        function create(){
            var count = Math.min(Math.floor(w / 18), 70); particles = [];
            for (var i=0;i<count;i++){ particles.push({ x:Math.random()*w, y:Math.random()*h, r:Math.random()*1.8+0.4, vy:-(Math.random()*0.4+0.1), vx:(Math.random()-0.5)*0.2, alpha:Math.random()*0.5+0.1, pulse:Math.random()*Math.PI*2, pulseSpeed:Math.random()*0.02+0.005 }); }
        }
        create();
        function animate(){
            if (!ctx) return;
            ctx.clearRect(0,0,w,h);
            particles.forEach(function(p){
                p.y+=p.vy; p.x+=p.vx; p.pulse+=p.pulseSpeed;
                var a = p.alpha*(0.5+0.5*Math.sin(p.pulse));
                if (p.y<-10){ p.y=h+10; p.x=Math.random()*w; }
                if (p.x<-10) p.x=w+10; if (p.x>w+10) p.x=-10;
                var g = ctx.createRadialGradient(p.x,p.y,0,p.x,p.y,p.r*6);
                g.addColorStop(0,'rgba(233,196,111,'+a+')'); g.addColorStop(1,'rgba(233,196,111,0)');
                ctx.fillStyle=g; ctx.beginPath(); ctx.arc(p.x,p.y,p.r*6,0,Math.PI*2); ctx.fill();
                ctx.fillStyle='rgba(233,196,111,'+(a*1.5)+')'; ctx.beginPath(); ctx.arc(p.x,p.y,p.r,0,Math.PI*2); ctx.fill();
            });
            animationId = requestAnimationFrame(animate);
        }
        function start(){ if(!animationId) animate(); }
        function stop(){ if(animationId){ cancelAnimationFrame(animationId); animationId=null; if(ctx) ctx.clearRect(0,0,w,h);} }
        function checkTheme(){ if(document.body.classList.contains('light-mode')) stop(); else start(); }
        checkTheme();
        var tt = document.getElementById('theme-toggle') || document.getElementById('theme-toggle-btn');
        if (tt) tt.addEventListener('click', function(){ setTimeout(checkTheme, 60); });
    })();
    </script>

    
 <?php include '../footer.php';?>
 <script src="../assets/js/script.js"></script>

</body>
</html>
