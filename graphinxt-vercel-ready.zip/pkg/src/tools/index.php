<!DOCTYPE html>
<!--
  ============================================================
  Graphinxt AI Marketing Toolbox
  © 2026 Graphinxt Digital Content Creator FZ LLC. All rights reserved.
  Proprietary software. Unauthorised copying, modification, distribution,
  or reverse engineering of this file or its logic is prohibited.
  Licensing enquiries: reach@graphinxt.com
  ============================================================
-->

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Free AI Marketing Tools (No Signup) | Graphinxt</title>
    <meta name="description" content="12 free AI marketing tools: SEO meta tags, ad copy, captions, content analyzer, website diagnostic, branding kit, budget & cost planners. No signup.">
    <meta name="robots" content="index, follow, max-image-preview:large">
    <link rel="canonical" href="https://graphinxt.com/tools">
    <meta property="og:site_name" content="Graphinxt">
    <meta property="og:type" content="website">
    <meta property="og:title" content="12 Free AI Marketing Tools — UK, USA, Canada, Australia & NZ | Graphinxt">
    <meta property="og:description" content="SEO meta tags, ad copy, captions, content analysis, website diagnostic, branding kit, budget planner & cost estimator — all free, instant, no signup.">
    <meta property="og:url" content="https://graphinxt.com/tools">
    <meta property="og:image" content="https://graphinxt.com/assets/og-cover.jpg">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:image" content="https://graphinxt.com/assets/og-cover.jpg">
     <link rel="stylesheet" href="../assets/style.css">
     <link rel="stylesheet" href="../assets/header.css">
     
   <link rel="shortcut icon" href="../assets/favicon.ico" type="image/x-icon">
        <link rel="icon" href="../assets/favicon.ico" type="image/x-icon">

    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@200;300;400;500;800&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@graph": [
        {
          "@type": "BreadcrumbList",
          "itemListElement": [
            { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://graphinxt.com/" },
            { "@type": "ListItem", "position": 2, "name": "Free AI Tools", "item": "https://graphinxt.com/tools" }
          ]
        },
        {
          "@type": "ItemList",
          "name": "Graphinxt Free AI Marketing Tools",
          "itemListElement": [
            { "@type": "WebApplication", "position": 1, "name": "SEO Title & Meta Description Generator", "url": "https://graphinxt.com/tools#meta-generator", "applicationCategory": "BusinessApplication", "operatingSystem": "Any", "offers": { "@type": "Offer", "price": "0", "priceCurrency": "USD" }, "description": "Generate SEO-optimized title tags and meta descriptions with a live Google search preview and character counters." },
            { "@type": "WebApplication", "position": 2, "name": "Google & Meta Ad Copy Generator", "url": "https://graphinxt.com/tools#ad-copy", "applicationCategory": "BusinessApplication", "operatingSystem": "Any", "offers": { "@type": "Offer", "price": "0", "priceCurrency": "USD" }, "description": "Generate Google responsive search ad headlines and descriptions, plus Meta ad texts, within platform character limits." },
            { "@type": "WebApplication", "position": 3, "name": "Social Caption & Hashtag Generator", "url": "https://graphinxt.com/tools#caption-generator", "applicationCategory": "BusinessApplication", "operatingSystem": "Any", "offers": { "@type": "Offer", "price": "0", "priceCurrency": "USD" }, "description": "Platform-matched captions and tiered hashtag sets for Instagram, LinkedIn, TikTok, and X." },
            { "@type": "WebApplication", "position": 4, "name": "Content SEO Analyzer", "url": "https://graphinxt.com/tools#content-analyzer", "applicationCategory": "BusinessApplication", "operatingSystem": "Any", "offers": { "@type": "Offer", "price": "0", "priceCurrency": "USD" }, "description": "Analyze any text for readability, keyword density, and on-page SEO improvements with an instant score." },
            { "@type": "WebApplication", "position": 5, "name": "Website Growth Diagnostic", "url": "https://graphinxt.com/tools#web-diagnostic", "applicationCategory": "BusinessApplication", "operatingSystem": "Any", "offers": { "@type": "Offer", "price": "0", "priceCurrency": "USD" }, "description": "Instant 5-category website snapshot with a prioritized action plan." },
            { "@type": "WebApplication", "position": 6, "name": "Startup Launch Kit", "url": "https://graphinxt.com/tools#startup-kit-tool", "applicationCategory": "BusinessApplication", "operatingSystem": "Any", "offers": { "@type": "Offer", "price": "0", "priceCurrency": "USD" }, "description": "Business name ideas, taglines, brand palette, logo mark concepts, and domain checks." },
            { "@type": "WebApplication", "position": 7, "name": "Marketing Budget Architect", "url": "https://graphinxt.com/tools#budget-architect", "applicationCategory": "BusinessApplication", "operatingSystem": "Any", "offers": { "@type": "Offer", "price": "0", "priceCurrency": "USD" }, "description": "Ad budget split across Google and Meta with projected clicks, leads, and cost per lead." },
            { "@type": "WebApplication", "position": 8, "name": "Project Cost Estimator", "url": "https://graphinxt.com/tools#cost-estimator", "applicationCategory": "BusinessApplication", "operatingSystem": "Any", "offers": { "@type": "Offer", "price": "0", "priceCurrency": "USD" }, "description": "Itemized project quotes in USD, GBP, CAD, AUD, and NZD with delivery estimates." },
            { "@type": "WebApplication", "position": 9, "name": "Marketing ROI & Revenue Calculator", "url": "https://graphinxt.com/tools#roi-calculator", "applicationCategory": "BusinessApplication", "operatingSystem": "Any", "offers": { "@type": "Offer", "price": "0", "priceCurrency": "USD" }, "description": "Project revenue, ROI, and payback from your marketing budget using industry benchmark cost-per-lead." },
            { "@type": "WebApplication", "position": 10, "name": "Keyword & Competitor Research", "url": "https://graphinxt.com/tools#keyword-research", "applicationCategory": "BusinessApplication", "operatingSystem": "Any", "offers": { "@type": "Offer", "price": "0", "priceCurrency": "USD" }, "description": "Discover keyword families with search intent, difficulty, content angles, and questions people ask." },
            { "@type": "WebApplication", "position": 11, "name": "AI Content Writer", "url": "https://graphinxt.com/tools#content-writer", "applicationCategory": "BusinessApplication", "operatingSystem": "Any", "offers": { "@type": "Offer", "price": "0", "priceCurrency": "USD" }, "description": "Draft marketing emails, blog outlines, video scripts, and Google Business posts in seconds." },
            { "@type": "WebApplication", "position": 12, "name": "Local SEO & Reputation Checklist", "url": "https://graphinxt.com/tools#local-seo", "applicationCategory": "BusinessApplication", "operatingSystem": "Any", "offers": { "@type": "Offer", "price": "0", "priceCurrency": "USD" }, "description": "Score your local search readiness and get a Google review growth plan for your city." },
            { "@type": "WebApplication", "position": 9, "name": "Real SEO & AEO Audit", "url": "https://graphinxt.com/services?id=seo", "applicationCategory": "BusinessApplication", "operatingSystem": "Any", "offers": { "@type": "Offer", "price": "0", "priceCurrency": "USD" }, "description": "Live Google Lighthouse audit with an AEO readiness checklist." }
          ]
        },
        {
          "@type": "FAQPage",
          "mainEntity": [
            { "@type": "Question", "name": "Are these AI marketing tools really free?", "acceptedAnswer": { "@type": "Answer", "text": "Yes. Every tool on this page is completely free, runs instantly in your browser, and requires no signup, no email, and no credit card." } },
            { "@type": "Question", "name": "How long should a title tag and meta description be?", "acceptedAnswer": { "@type": "Answer", "text": "Keep title tags under roughly 60 characters and meta descriptions under roughly 155 characters so Google displays them without truncation. The generator on this page counts characters for you and shows a live Google preview." } },
            { "@type": "Question", "name": "What are the character limits for Google and Meta ads?", "acceptedAnswer": { "@type": "Answer", "text": "Google responsive search ads allow headlines up to 30 characters and descriptions up to 90 characters. Meta (Facebook and Instagram) ads work best with headlines under 40 characters and primary text with the key message in the first 125 characters. Our ad copy generator enforces these limits automatically." } },
            { "@type": "Question", "name": "Is my text or data stored when I use these tools?", "acceptedAnswer": { "@type": "Answer", "text": "No. Everything runs locally in your browser. Nothing you type into the generators or the analyzer is uploaded or stored." } },
            { "@type": "Question", "name": "Do these AI marketing tools work for businesses in the UK, USA, Canada, Australia and New Zealand?", "acceptedAnswer": { "@type": "Answer", "text": "Yes. The cost estimator quotes in GBP, USD, CAD, AUD and NZD, the budget planner uses benchmarks for English-speaking markets, and the SEO generators follow the Google guidelines that apply in all five countries. Graphinxt serves clients across the UK, USA, Canada, Australia and New Zealand." } },
            { "@type": "Question", "name": "Can Graphinxt do this work for me?", "acceptedAnswer": { "@type": "Answer", "text": "Yes — these tools are fast starting points. Graphinxt provides full SEO, paid advertising, content, and web development services for clients across the UK, USA, Canada, Australia, and New Zealand. The first strategy call is free." } }
          ]
        }
      ]
    }
    </script>

<!-- ===== ANALYTICS & CONVERSION TRACKING ===== -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-58PYC27MPE"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-58PYC27MPE');
</script>
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '2162187584315430');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=2162187584315430&ev=PageView&noscript=1" /></noscript>
<script>
  window.trackConversion = function(eventName, params) {
    params = params || {};
    try { if (typeof gtag === 'function') gtag('event', eventName, params); } catch(e) {}
    try { if (typeof fbq === 'function') fbq('trackCustom', eventName, params); } catch(e) {}
  };
  document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('a[href*="wa.me"]').forEach(function(el) {
      el.addEventListener('click', function() { window.trackConversion('whatsapp_click', { page: window.location.pathname }); });
    });
  });
</script>
<!-- ===== END ANALYTICS ===== -->

    <style>
        :root {
            --bg-dark: #363638; --bg-darker: #2a2a2c; --brand-gold: #e9c46f; --brand-gold-hover: #d4ae58;
            --text-main: #ffffff; --text-muted: #a1a1a5; --card-bg: rgba(255,255,255,0.02);
            --border-light: rgba(233,196,111,0.12); --border-glow: rgba(233,196,111,0.4);
            --nav-bg: rgba(42,42,44,0.4); --nav-bg-scrolled: rgba(30,30,32,0.8);
            --ok: #7ec97e; --warn: #e9a25f; --bad: #e05f5f;
        }
      
        section { padding: 5rem 5%; max-width: 1100px; margin: 0 auto; position: relative; z-index: 1; }
        .hero-sec { padding-top: 12rem; padding-bottom: 2rem; text-align: center; }
        .eyebrow { font-size: 0.75rem; color: var(--brand-gold); text-transform: uppercase; letter-spacing: 3px; margin-bottom: 1.2rem; display: inline-block; }
        .hero-sec h1 { font-size: clamp(2rem, 5vw, 3.4rem); font-weight: 200; line-height: 1.15; margin-bottom: 1.2rem; }
        .hero-sec h1 strong { font-weight:800; background:linear-gradient(to right,#ffffff,var(--brand-gold)); -webkit-background-clip:text; background-clip:text; -webkit-text-fill-color:transparent; color:var(--brand-gold); }
        .hero-sec p { color: var(--text-muted); max-width: 620px; margin: 0 auto 2.5rem; font-weight: 300; }

        .tool-jump-row { display: flex; gap: 0.8rem; justify-content: center; flex-wrap: wrap; }
        .tool-jump { font-size: 0.72rem; text-transform: uppercase; letter-spacing: 1px; color: var(--text-muted); text-decoration: none; border: 1px solid var(--border-light); padding: 0.6rem 1.4rem; border-radius: 30px; transition: all .3s; }
        .tool-jump:hover { color: var(--brand-gold); border-color: var(--brand-gold); }

        .tool-card { background: var(--card-bg); border: 1px solid var(--border-light); border-radius: 28px; padding: 3rem; max-width: 900px; margin: 0 auto; }
        @media(max-width: 700px) { .tool-card { padding: 2rem 1.4rem; } }
        .tool-head { text-align: center; margin-bottom: 2.2rem; }
        .tool-head h2 { font-size: clamp(1.5rem, 3.5vw, 2.1rem); font-weight: 200; margin-bottom: 0.6rem; }
        .tool-head h2 strong { font-weight: 800; color: var(--brand-gold); }
        .tool-head p { color: var(--text-muted); font-weight: 300; font-size: 0.92rem; max-width: 560px; margin: 0 auto; }

        .form-row { display: flex; gap: 1rem; flex-wrap: wrap; margin-bottom: 1rem; }
        .t-input, .t-select, .t-area { flex: 1; min-width: 200px; background: var(--bg-darker); border: 1px solid var(--border-light); color: var(--text-main); padding: 1rem 1.4rem; border-radius: 30px; font-size: 0.9rem; outline: none; font-family: inherit; }
        .t-select { -webkit-appearance: none; -moz-appearance: none; appearance: none; background-image: url("data:image/svg+xml;charset=UTF-8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 8'%3E%3Cpath fill='none' stroke='%23e9c46f' stroke-width='1.6' d='M1 1.5l5 5 5-5'/%3E%3C/svg%3E"); background-repeat: no-repeat; background-position: right 1.3rem center; background-size: 11px; padding-right: 3rem; cursor: pointer; }
        .t-select option { background: var(--bg-darker); color: var(--text-main); }
        .t-input:focus, .t-select:focus, .t-area:focus { border-color: var(--brand-gold); }
        /* Inputs already show a gold border on focus — suppress the extra offset outline */
        .t-input:focus-visible, .t-select:focus-visible, .t-area:focus-visible { outline: none; box-shadow: 0 0 0 3px rgba(233,196,111,0.15); }
        .t-select { cursor: pointer; }
        .t-area { border-radius: 20px; min-height: 200px; resize: vertical; line-height: 1.7; width: 100%; }
        .run-btn { background: var(--brand-gold); color: var(--bg-dark) !important; padding: 1rem 2.4rem; border-radius: 30px; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; border: none; font-size: 0.78rem; cursor: pointer; transition: all .3s; width: 100%; margin-top: 0.5rem; }
        .run-btn:hover { transform: scale(1.02); }
        .tool-hint { text-align: center; font-size: 0.7rem; color: var(--text-muted); opacity: 0.7; margin-top: 1rem; }

        .results { display: none; margin-top: 2.5rem; }
        .results.show { display: block; animation: fadeUp .5s ease; }
        @keyframes fadeUp { from { opacity:0; transform: translateY(12px);} to { opacity:1; transform: translateY(0);} }
        @media (prefers-reduced-motion: reduce) { *, *::before, *::after { animation-duration: 0.01ms !important; transition-duration: 0.01ms !important; } }

        .sec-title { font-size: 0.95rem; font-weight: 500; margin: 0 0 1rem; color: var(--brand-gold); display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 0.5rem; }
        .regen-btn { background: transparent; border: 1px solid var(--border-light); color: var(--text-muted); font-size: 0.65rem; text-transform: uppercase; letter-spacing: 0.5px; padding: 4px 12px; border-radius: 20px; cursor: pointer; font-family: inherit; }
        .results-toolbar { display: flex; gap: 0.6rem; justify-content: flex-end; margin-bottom: 1.2rem; flex-wrap: wrap; }
        .tb-btn { background: rgba(233,196,111,0.08); border: 1px solid var(--border-light); color: var(--brand-gold); font-size: 0.7rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; padding: 0.5rem 1rem; border-radius: 20px; cursor: pointer; font-family: inherit; transition: all 0.2s; }
        .tb-btn:hover { border-color: var(--brand-gold); background: rgba(233,196,111,0.15); }
        .tb-btn.tb-primary { background: var(--brand-gold); color: var(--bg-dark); border-color: var(--brand-gold); }
        .tb-btn.tb-primary:hover { background: #fff; }
        .next-tool { margin-top: 1.4rem; padding: 0.9rem 1.2rem; background: linear-gradient(135deg, rgba(233,196,111,0.1), transparent); border: 1px dashed var(--border-glow); border-radius: 12px; font-size: 0.82rem; color: var(--text-muted); }
        .next-tool span { color: var(--brand-gold); font-weight: 600; }
        .next-tool a { color: var(--brand-gold); text-decoration: none; font-weight: 600; margin-left: 0.3rem; }
        .next-tool a:hover { text-decoration: underline; }
        .toolkit-tray { position: fixed; bottom: 1.5rem; left: 1.5rem; z-index: 9500; display: none; }
        .toolkit-tray.show { display: block; }
        .toolkit-tray.pulse .tk-toggle { animation: tkpulse 0.8s ease; }
        @keyframes tkpulse { 0%,100%{transform:scale(1);} 40%{transform:scale(1.08);} }
        .tk-toggle { display: flex; align-items: center; gap: 0.5rem; background: rgba(30,30,32,0.95); backdrop-filter: blur(20px); border: 1px solid var(--border-glow); color: var(--text-main); padding: 0.7rem 1.2rem; border-radius: 30px; cursor: pointer; font-family: inherit; font-size: 0.8rem; font-weight: 600; box-shadow: 0 10px 30px rgba(0,0,0,0.4); }
        .tk-star { color: var(--brand-gold); }
        .tk-badge { background: var(--brand-gold); color: var(--bg-dark); font-weight: 800; border-radius: 20px; padding: 1px 9px; font-size: 0.72rem; }
        .tk-panel { position: absolute; bottom: calc(100% + 10px); left: 0; width: 300px; max-width: 82vw; background: rgba(30,30,32,0.97); backdrop-filter: blur(24px); border: 1px solid var(--border-glow); border-radius: 18px; padding: 1.2rem; box-shadow: 0 20px 50px rgba(0,0,0,0.5); opacity: 0; visibility: hidden; transform: translateY(10px); transition: all 0.25s; }
        .toolkit-tray.open .tk-panel { opacity: 1; visibility: visible; transform: translateY(0); }
        .tk-panel-head { font-size: 0.7rem; text-transform: uppercase; letter-spacing: 1.5px; color: var(--brand-gold); margin-bottom: 0.8rem; }
        .tk-list { max-height: 200px; overflow-y: auto; margin-bottom: 1rem; }
        .tk-item { display: flex; justify-content: space-between; align-items: center; gap: 0.5rem; padding: 0.5rem 0; border-bottom: 1px solid var(--border-light); font-size: 0.8rem; color: var(--text-muted); }
        .tk-item button { background: none; border: none; color: var(--text-muted); cursor: pointer; font-size: 0.9rem; opacity: 0.6; }
        .tk-item button:hover { opacity: 1; color: var(--brand-gold); }
        .tk-actions { display: flex; flex-direction: column; gap: 0.5rem; }
        .tk-clear { background: none; border: none; color: var(--text-muted); font-size: 0.7rem; cursor: pointer; font-family: inherit; text-decoration: underline; opacity: 0.6; }
        .tk-clear:hover { opacity: 1; }
        .preset-row { display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap; margin: -0.4rem 0 1rem; }
        .preset-label { font-size: 0.66rem; text-transform: uppercase; letter-spacing: 1px; color: var(--text-muted); opacity: 0.7; }
        .preset-chip { background: transparent; border: 1px dashed var(--border-light); color: var(--text-muted); font-size: 0.72rem; padding: 0.35rem 0.9rem; border-radius: 20px; cursor: pointer; font-family: inherit; transition: all 0.2s; }
        .preset-chip:hover { border-style: solid; border-color: var(--brand-gold); color: var(--brand-gold); }
        .regen-btn:hover { color: var(--brand-gold); border-color: var(--brand-gold); }

        .copy-item { background: var(--bg-darker); border: 1px solid var(--border-light); border-radius: 14px; padding: 0.9rem 1.1rem; margin-bottom: 0.7rem; display: flex; align-items: center; justify-content: space-between; gap: 1rem; }
        .copy-item .txt { font-size: 0.9rem; font-weight: 300; flex: 1; word-break: break-word; }
        .copy-item .meta-r { display: flex; align-items: center; gap: 0.6rem; flex-shrink: 0; }
        .char-badge { font-size: 0.62rem; font-family: monospace; padding: 2px 8px; border-radius: 10px; border: 1px solid var(--border-light); color: var(--text-muted); }
        .char-badge.ok { color: var(--ok); border-color: rgba(126,201,126,0.4); }
        .char-badge.warn { color: var(--warn); border-color: rgba(233,162,95,0.4); }
        .copy-btn { background: transparent; border: 1px solid var(--border-light); color: var(--text-muted); font-size: 0.62rem; text-transform: uppercase; letter-spacing: 0.5px; padding: 4px 12px; border-radius: 20px; cursor: pointer; font-family: inherit; transition: all .2s; }
        .copy-btn:hover { color: var(--brand-gold); border-color: var(--brand-gold); }

        /* Google SERP preview */
        .serp-preview { background: #fff; border-radius: 16px; padding: 1.4rem 1.6rem; margin-bottom: 1.8rem; font-family: arial, sans-serif; }
        .serp-url { color: #202124; font-size: 0.78rem; display: flex; align-items: center; gap: 8px; margin-bottom: 4px; }
        .serp-favicon { width: 22px; height: 22px; border-radius: 50%; background: #363638; color: #e9c46f; display: inline-flex; align-items: center; justify-content: center; font-size: 12px; font-weight: bold; font-family: Georgia, serif; flex-shrink: 0; }
        .serp-title { color: #1a0dab; font-size: 1.15rem; line-height: 1.3; margin-bottom: 3px; cursor: pointer; }
        .serp-title:hover { text-decoration: underline; }
        .serp-desc { color: #4d5156; font-size: 0.85rem; line-height: 1.5; }

        /* Analyzer */
        .score-wrap { display: flex; gap: 2rem; align-items: center; flex-wrap: wrap; margin-bottom: 2rem; }
        .score-ring-box { position: relative; width: 130px; height: 130px; flex-shrink: 0; }
        .score-ring-box svg { transform: rotate(-90deg); }
        .ring-bg { fill: none; stroke: var(--border-light); stroke-width: 8; }
        .ring-fill { fill: none; stroke: var(--brand-gold); stroke-width: 8; stroke-linecap: round; transition: stroke-dashoffset 1s ease; }
        .ring-label { position: absolute; inset: 0; display: flex; flex-direction: column; align-items: center; justify-content: center; }
        .ring-num { font-size: 2rem; font-weight: 800; }
        .ring-sub { font-size: 0.6rem; text-transform: uppercase; letter-spacing: 1px; color: var(--text-muted); }
        .stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 0.8rem; flex: 1; min-width: 260px; }
        .stat-box { background: var(--bg-darker); border: 1px solid var(--border-light); border-radius: 14px; padding: 0.9rem 1rem; }
        .stat-box .v { font-size: 1.25rem; font-weight: 800; }
        .stat-box .k { font-size: 0.62rem; text-transform: uppercase; letter-spacing: 1px; color: var(--text-muted); margin-top: 2px; }
        .term-chips { display: flex; gap: 0.5rem; flex-wrap: wrap; margin-bottom: 2rem; }
        .term-chip { font-size: 0.72rem; border: 1px solid var(--border-light); color: var(--text-muted); padding: 4px 12px; border-radius: 16px; }
        .term-chip strong { color: var(--brand-gold); font-weight: 600; }
        .suggest-list { list-style: none; margin-bottom: 1rem; }
        .suggest-list li { font-size: 0.85rem; color: var(--text-muted); font-weight: 300; padding: 0.7rem 0 0.7rem 1.8rem; border-bottom: 1px solid var(--border-light); position: relative; }
        .suggest-list li:last-child { border-bottom: none; }
        .suggest-list li::before { position: absolute; left: 0; font-weight: 700; }
        .suggest-list li.good::before { content: '✓'; color: var(--ok); }
        .suggest-list li.fix::before { content: '→'; color: var(--warn); }

        .ai-sim-card { background: var(--bg-darker); border: 1px solid var(--border-light); border-radius: 16px; padding: 1.4rem 1.6rem; margin-bottom: 1.8rem; display: none; }
        .ai-sim-card.show { display: block; }
        .ai-sim-label { display: inline-flex; align-items: center; gap: 6px; font-size: 0.62rem; text-transform: uppercase; letter-spacing: 1px; font-weight: 700; color: var(--text-muted); margin-bottom: 0.6rem; }
        .ai-sim-label .dot { width: 6px; height: 6px; border-radius: 50%; background: var(--brand-gold); animation: blink 1s infinite; }
        @keyframes blink { 50% { opacity: 0.2; } }
        .ai-sim-text { font-size: 0.85rem; color: var(--text-muted); font-weight: 300; }

        .disclaimer { font-size: 0.68rem; color: var(--text-muted); opacity: 0.65; text-align: center; max-width: 620px; margin: 1.5rem auto 0; }

        /* More tools grid */
        .more-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 1.4rem; }
        .more-card { background: var(--card-bg); border: 1px solid var(--border-light); border-radius: 20px; padding: 1.8rem; text-decoration: none; color: var(--text-main); transition: all .3s; display: block; }
        .more-card:hover { border-color: var(--brand-gold); transform: translateY(-4px); }
        .more-card .tag { font-size: 0.6rem; text-transform: uppercase; letter-spacing: 1px; color: var(--brand-gold); font-weight: 700; }
        .more-card h3 { font-size: 1.05rem; margin: 0.6rem 0 0.4rem; }
        .more-card p { font-size: 0.8rem; color: var(--text-muted); font-weight: 300; }

        .funnel-card { max-width: 900px; margin: 0 auto; background: linear-gradient(135deg, rgba(233,196,111,0.08), transparent); border: 1px solid var(--border-glow); border-radius: 24px; padding: 2.5rem; text-align: center; }
        .funnel-card h3 { font-size: 1.3rem; font-weight: 200; margin-bottom: 0.8rem; }
        .funnel-card h3 strong { color: var(--brand-gold); font-weight: 800; }
        .funnel-card p { color: var(--text-muted); font-size: 0.85rem; margin-bottom: 1.5rem; font-weight: 300; }
        .cta-row { display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap; align-items:center;}
        input[type="checkbox"] {
    appearance: none;
    -webkit-appearance: none;
    width: 12px;
    height: 12px;
    border: 2px solid #e8c471;
    border-radius: 10px;
    background:#39393b;
    cursor: pointer;
    position: relative;
    transition: all 0.2s ease;
}

input[type="checkbox"]:checked {
    background: #e9c46f;
    border-color: #39393b;
}

input[type="checkbox"]:checked::after {
    content: "";
    position: absolute;
    left: 5px;
    top: 1px;
    width: 5px;
    height: 10px;
    border: solid #39393b;
    border-width: 0 2px 2px 0;
    transform: rotate(45deg);
}
        .faq-item { border-bottom: 1px solid var(--border-light); padding: 1.4rem 0; max-width: 800px; margin: 0 auto; }
        .faq-item h3 { font-size: 1rem; font-weight: 600; margin-bottom: 0.5rem; }
        .faq-item p { font-size: 0.88rem; color: var(--text-muted); font-weight: 300; }

        .section-head { text-align: center; margin-bottom: 3rem; }
        .section-head h2 { font-size: clamp(1.6rem, 4vw, 2.4rem); font-weight: 200; }
        .section-head h2 strong { font-weight:800; background:linear-gradient(to right,#ffffff,var(--brand-gold)); -webkit-background-clip:text; background-clip:text; -webkit-text-fill-color:transparent; color:var(--brand-gold); }
        .section-head p { color: var(--text-muted); font-weight: 300; font-size: 0.92rem; max-width: 560px; margin: 0.8rem auto 0; }

        /* ===== PRO LAYER ===== */
        .pro-zone { margin-top: 2rem; }
        .pro-teaser { border: 1px solid var(--border-glow); background: linear-gradient(135deg, rgba(233,196,111,0.07), transparent); border-radius: 20px; padding: 2rem; position: relative; overflow: hidden; }
        .pro-badge { display: inline-flex; align-items: center; gap: 6px; font-size: 0.6rem; font-weight: 800; text-transform: uppercase; letter-spacing: 1.5px; color: var(--bg-dark); background: var(--brand-gold); padding: 4px 12px; border-radius: 12px; margin-bottom: 1rem; }
        .pro-teaser h3 { font-size: 1.1rem; margin-bottom: 0.8rem; font-weight: 800; }
        .pro-bullets { list-style: none; margin-bottom: 1.4rem; }
        .pro-bullets li { font-size: 0.82rem; color: var(--text-muted); font-weight: 300; padding: 0.35rem 0 0.35rem 1.6rem; position: relative; }
        .pro-bullets li::before { content: '\2605'; color: var(--brand-gold); position: absolute; left: 0; font-size: 0.7rem; top: 0.5rem; }
        .pro-blur { filter: blur(5px); user-select: none; pointer-events: none; opacity: 0.55; margin-bottom: 1.2rem; }
        .pro-cta-row { display: flex; gap: 0.8rem; flex-wrap: wrap; align-items: center; }
        .pro-code-row { display: flex; gap: 0.6rem; margin-top: 1rem; flex-wrap: wrap; }
        .pro-code-input { background: var(--bg-darker); border: 1px solid var(--border-light); color: var(--text-main); padding: 0.7rem 1.2rem; border-radius: 30px; font-size: 0.8rem; outline: none; font-family: inherit; flex: 1; min-width: 160px; }
        .pro-code-input:focus { border-color: var(--brand-gold); }
        .pro-code-btn { background: transparent; border: 1px solid var(--border-light); color: var(--text-muted); padding: 0.7rem 1.4rem; border-radius: 30px; font-size: 0.68rem; text-transform: uppercase; letter-spacing: 1px; cursor: pointer; font-family: inherit; }
        .pro-code-btn:hover { color: var(--brand-gold); border-color: var(--brand-gold); }
        .pro-note { font-size: 0.65rem; color: var(--text-muted); opacity: 0.7; margin-top: 0.8rem; }
        .pro-content { -webkit-user-select: none; -moz-user-select: none; user-select: none; border: 1px solid var(--border-glow); border-radius: 20px; padding: 2rem; background: rgba(233,196,111,0.03); }
        .pro-sec { margin-top: 1.6rem; }
        .pro-sec h4 { font-size: 0.92rem; color: var(--brand-gold); margin-bottom: 0.7rem; font-weight: 600; }
        .pro-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 0.8rem; }
        .pro-metric { background: var(--bg-darker); border: 1px solid var(--border-light); border-radius: 12px; padding: 1rem; text-align: center; }
        .pro-metric .v { display: block; font-size: 1.3rem; font-weight: 800; color: var(--brand-gold); }
        .pro-metric .k { display: block; font-size: 0.68rem; color: var(--text-muted); margin-top: 0.25rem; }
        .pro-code { background: var(--bg-darker); border: 1px solid var(--border-light); border-left: 3px solid var(--brand-gold); border-radius: 0 10px 10px 0; padding: 1rem 1.2rem; font-family: 'Courier New', monospace; font-size: 0.8rem; line-height: 1.7; color: var(--text-muted); white-space: normal; }
        .pro-note { font-size: 0.74rem; color: var(--text-muted); opacity: 0.85; margin-top: 0.6rem; font-style: italic; }
        .fb-label { font-size: 0.72rem; text-transform: uppercase; letter-spacing: 1.5px; color: var(--text-muted); margin-bottom: 0.7rem; }
        .chip-row { display: flex; flex-wrap: wrap; gap: 0.6rem; margin-bottom: 1.4rem; }
        .chip { border: 1px solid var(--border-light); color: var(--text-muted); background: transparent; padding: 0.55rem 1.2rem; border-radius: 30px; font-size: 0.8rem; cursor: pointer; transition: all 0.2s; font-family: inherit; line-height: 1.3; }
        .chip:hover { border-color: var(--brand-gold); color: var(--brand-gold); }
        .chip.sel { border-color: var(--brand-gold); color: var(--brand-gold); background: rgba(233,196,111,0.08); }
        .fb-optional { text-transform: none; letter-spacing: 0; opacity: 0.6; }
        .fb-stars { display: flex; align-items: center; gap: 0.3rem; }
        .fb-star { background: none; border: none; font-size: 1.8rem; color: var(--border-light); cursor: pointer; padding: 0 2px; transition: color 0.15s, transform 0.15s; line-height: 1; }
        .fb-star:hover { transform: scale(1.15); }
        .fb-star.on { color: var(--brand-gold); }
        .fb-rating-text { font-size: 0.8rem; color: var(--brand-gold); margin-left: 0.8rem; font-weight: 500; }
        .t-area { width: 100%; background: var(--bg-darker); border: 1px solid var(--border-light); color: var(--text-main); padding: 1rem 1.2rem; border-radius: 14px; font-size: 0.9rem; outline: none; font-family: inherit; resize: vertical; line-height: 1.6; }
        .t-area:focus { border-color: var(--brand-gold); }
        .fb-thanks { display: none; text-align: center; padding: 2.5rem 1rem; }
        .fb-thanks.show { display: block; animation: fadeUp 0.4s ease; }
        .fb-step.hide { display: none; }
        .fb-thanks-icon { width: 56px; height: 56px; border-radius: 50%; background: rgba(126,201,126,0.15); border: 1px solid var(--ok, #7ec97e); color: var(--ok, #7ec97e); font-size: 1.6rem; display: flex; align-items: center; justify-content: center; margin: 0 auto 1.2rem; }
        .fb-thanks h3 { font-size: 1.15rem; margin-bottom: 0.5rem; }
        .fb-thanks p { font-size: 0.87rem; color: var(--text-muted); font-weight: 300; max-width: 420px; margin: 0 auto; }
        .fb-thanks-actions { display: flex; gap: 0.7rem; justify-content: center; flex-wrap: wrap; margin-top: 1.4rem; }
        .code-block { background: var(--bg-darker); border: 1px solid var(--border-light); border-radius: 14px; padding: 1rem 1.2rem; font-family: monospace; font-size: 0.72rem; color: var(--text-muted); white-space: pre-wrap; word-break: break-all; margin-bottom: 0.8rem; line-height: 1.7; max-height: 260px; overflow-y: auto; }
        .mini-table { width: 100%; border-collapse: collapse; margin-bottom: 1rem; font-size: 0.78rem; }
        .mini-table td, .mini-table th { padding: 0.55rem 0.7rem; border-bottom: 1px solid var(--border-light); text-align: left; font-weight: 300; color: var(--text-muted); }
        .mini-table th { font-weight: 700; color: var(--text-main); font-size: 0.65rem; text-transform: uppercase; letter-spacing: 1px; }
        .mini-table .v-ok { color: var(--ok); } .mini-table .v-warn { color: var(--warn); }
        .pro-toast { position: fixed; bottom: 24px; left: 50%; transform: translateX(-50%); background: var(--brand-gold); color: var(--bg-dark); font-weight: 800; font-size: 0.78rem; padding: 0.9rem 2rem; border-radius: 30px; z-index: 99999; box-shadow: 0 10px 30px rgba(0,0,0,0.4); animation: fadeUp .4s ease; }
        .ad-slot { max-width: 900px; margin: 0 auto; text-align: center; display: none; }
        .ad-slot.on { display: block; }
        .ad-slot .ad-label { font-size: 0.58rem; text-transform: uppercase; letter-spacing: 1.5px; color: var(--text-muted); opacity: 0.5; margin-bottom: 0.4rem; }

    </style>
</head>
<body>
    <canvas id="bg-canvas"></canvas>
    <div class="ambient-glow"></div>

            <?php include '../header.php';?>

    <header class="hero-sec">
        <span class="eyebrow">Free AI Marketing tools · No Signup · Runs In Your Browser</span>
        <h1> <strong>Free AI Marketing tools </strong> <br/> Graphinxt</h1>
        <p>Twelve working marketing tools, free forever — built for businesses in the <strong style="font-weight:500; color:var(--text-main);">UK, USA, Canada, Australia, and New Zealand</strong>. Generate SEO meta tags, ad copy, and captions; analyze content; diagnose your website; brand a startup; plan an ad budget; and price a project — instantly, with nothing uploaded and nothing stored. Every result now copies or downloads as a branded file, and one-tap examples get you started instantly.</p>
        <div class="tool-jump-row">
            <a href="#meta-generator" class="tool-jump">Meta Tag Generator</a>
            <a href="#ad-copy" class="tool-jump">Ad Copy Generator</a>
            <a href="#caption-generator" class="tool-jump">Caption &amp; Hashtags</a>
            <a href="#content-analyzer" class="tool-jump">Content Analyzer</a>
            <a href="#web-diagnostic" class="tool-jump">Website Diagnostic</a>
            <a href="#startup-kit-tool" class="tool-jump">Startup Kit</a>
            <a href="#budget-architect" class="tool-jump">Budget Architect</a>
            <a href="#cost-estimator" class="tool-jump">Cost Estimator</a>
            <a href="#roi-calculator" class="tool-jump">ROI Calculator</a>
            <a href="#keyword-research" class="tool-jump">Keyword Research</a>
            <a href="#content-writer" class="tool-jump">AI Content Writer</a>
            <a href="#local-seo" class="tool-jump">Local SEO Check</a>
            <a href="/growth-planner" class="tool-jump" style="border-color:var(--brand-gold); color:var(--brand-gold);">★ 1-Year Growth Planner</a>
            <a href="#feedback" class="tool-jump">💬 Suggest a Tool</a>
        </div>
        <div style="margin-top:1.6rem; font-size:0.68rem; color:var(--text-muted); display:flex; gap:0.8rem; justify-content:center; align-items:center; flex-wrap:wrap;">
            <span style="text-transform:uppercase; letter-spacing:1.5px;">Share these tools:</span>
            <a class="tool-jump" style="padding:0.4rem 1rem;" target="_blank" rel="noopener" onclick="trackConversion('share_click',{net:'whatsapp'})" href="https://wa.me/?text=Free%20AI%20marketing%20tools%20%E2%80%94%20SEO%20meta%20generator%2C%20ad%20copy%2C%20captions%20%2B%20hashtags%2C%20content%20analyzer.%20No%20signup%3A%20https%3A%2F%2Fgraphinxt.com%2Ftools.html">WhatsApp</a>
            <a class="tool-jump" style="padding:0.4rem 1rem;" target="_blank" rel="noopener" onclick="trackConversion('share_click',{net:'x'})" href="https://twitter.com/intent/tweet?text=Free%20AI%20marketing%20tools%20(no%20signup)%3A%20SEO%20meta%20generator%2C%20ad%20copy%2C%20captions%20%2B%20hashtags%2C%20content%20analyzer&url=https%3A%2F%2Fgraphinxt.com%2Ftools.html">X</a>
            <a class="tool-jump" style="padding:0.4rem 1rem;" target="_blank" rel="noopener" onclick="trackConversion('share_click',{net:'linkedin'})" href="https://www.linkedin.com/sharing/share-offsite/?url=https%3A%2F%2Fgraphinxt.com%2Ftools.html">LinkedIn</a>
        </div>
    </header>

    <!-- ============ TOOL 1: META TAG GENERATOR ============ -->
    <section id="meta-generator" style="padding-top:3rem;">
        <div class="tool-card">
            <div class="tool-head">
                <span class="eyebrow">Tool 01</span>
                <h2>SEO Title & Meta <strong>Generator</strong></h2>
                <p>Title tags and meta descriptions built around your keyword — with live character counts and a real Google search preview.</p>
            </div>
            <div class="form-row">
                <input type="text" id="mg-brand" class="t-input" placeholder="Brand name (e.g. Graphinxt)" autocomplete="off">
                <input type="text" id="mg-topic" class="t-input" placeholder="Page topic / service (e.g. web design)" autocomplete="off">
            </div>
            <div class="form-row">
                <input type="text" id="mg-keyword" class="t-input" placeholder="Primary keyword (e.g. web design agency)" autocomplete="off">
                <input type="text" id="mg-location" class="t-input" placeholder="Location — optional (e.g. London)" autocomplete="off">
            </div>
            <div class="form-row">
                <select id="mg-type" class="t-select" aria-label="Page type">
                    <option value="home">Homepage</option>
                    <option value="service">Service page</option>
                    <option value="product">Product page</option>
                    <option value="blog">Blog article</option>
                    <option value="local">Local landing page</option>
                </select>
            </div>
            <button class="run-btn" id="mg-run" onclick="runMetaGen()">Generate Meta Tags →</button>
            <div class="tool-hint">Free · instant · nothing you type leaves this page</div>

            <div class="ai-sim-card" id="mg-sim">
                <div class="ai-sim-label"><span class="dot"></span> Generating</div>
                <div class="ai-sim-text" id="mg-sim-text">Mapping keyword intent…</div>
            </div>

            <div class="results" id="mg-results">
                <div class="sec-title">Google Preview <span style="font-size:0.65rem; color:var(--text-muted); font-weight:400;">click a title below to preview it</span></div>
                <div class="serp-preview">
                    <div class="serp-url"><span class="serp-favicon">G</span><span id="serp-url-text">yoursite.com</span></div>
                    <div class="serp-title" id="serp-title">Your title will appear here</div>
                    <div class="serp-desc" id="serp-desc">Your meta description will appear here.</div>
                </div>
                <div class="sec-title">Title Tags <button class="regen-btn" onclick="runMetaGen(true)">Regenerate ↻</button></div>
                <div id="mg-titles"></div>
                <div class="sec-title" style="margin-top:1.6rem;">Meta Descriptions</div>
                <div id="mg-descs"></div>
                <div style="text-align:center; margin-top:1.5rem;">
                    <button class="btn-outline" id="mg-copy-all" onclick="copyAllMeta()">Copy All Tags</button>
                </div>
                <div class="pro-zone" id="mg-pro"></div>
                <p class="disclaimer">Generated algorithmically from your input on this page — a fast, best-practice starting point, not a full keyword research project. Aim for titles under 60 characters and descriptions under 155.</p>
            </div>
        </div>
    </section>

    <div class="ad-slot" id="ad-slot-top"><div class="ad-label">Advertisement</div></div>

    <!-- ============ TOOL 2: AD COPY GENERATOR ============ -->
    <section id="ad-copy" style="padding-top:2rem;">
        <div class="tool-card">
            <div class="tool-head">
                <span class="eyebrow">Tool 02</span>
                <h2>Google & Meta <strong>Ad Copy Generator</strong></h2>
                <p>Headlines and descriptions that fit platform character limits on the first paste — no more "your headline is too long" errors.</p>
            </div>
            <div class="form-row">
                <input type="text" id="ac-product" class="t-input" placeholder="Product / service (e.g. house cleaning)" autocomplete="off">
                <input type="text" id="ac-benefit" class="t-input" placeholder="Key benefit (e.g. same-day booking)" autocomplete="off">
            </div>
            <div class="form-row">
                <input type="text" id="ac-audience" class="t-input" placeholder="Audience — optional (e.g. busy families)" autocomplete="off">
                <select id="ac-tone" class="t-select" aria-label="Tone">
                    <option value="professional">Professional tone</option>
                    <option value="bold">Bold tone</option>
                    <option value="friendly">Friendly tone</option>
                    <option value="urgent">Urgent tone</option>
                </select>
                <select id="ac-platform" class="t-select" aria-label="Platform">
                    <option value="google">Google Ads (RSA)</option>
                    <option value="meta">Meta (Facebook / Instagram)</option>
                </select>
            </div>
            <button class="run-btn" id="ac-run" onclick="runAdCopy()">Generate Ad Copy →</button>
            <div class="tool-hint">Google limits: 30-char headlines, 90-char descriptions · Meta: 40-char headlines enforced automatically</div>

            <div class="ai-sim-card" id="ac-sim">
                <div class="ai-sim-label"><span class="dot"></span> Generating</div>
                <div class="ai-sim-text" id="ac-sim-text">Studying your offer…</div>
            </div>

            <div class="results" id="ac-results">
                <div class="sec-title"><span id="ac-h-label">Headlines</span> <button class="regen-btn" onclick="runAdCopy(true)">Regenerate ↻</button></div>
                <div id="ac-headlines"></div>
                <div class="sec-title" style="margin-top:1.6rem;" id="ac-d-label">Descriptions</div>
                <div id="ac-descs"></div>
                <div class="sec-title" style="margin-top:1.6rem;">Live Ad Preview</div>
                <div id="ac-preview"></div>
                <div style="text-align:center; margin-top:1.5rem;">
                    <button class="btn-outline" onclick="copyAllAds()" id="ac-copy-all">Copy Everything</button>
                </div>
                <div class="pro-zone" id="ac-pro"></div>
                <p class="disclaimer">Template-driven generation from your inputs, tuned to each platform's published limits. Always A/B test copy — even great copy — before scaling spend.</p>
            </div>
        </div>
    </section>

    <!-- ============ TOOL 4 (position 3 on page): CAPTION & HASHTAG GENERATOR ============ -->
    <section id="caption-generator" style="padding-top:2rem;">
        <div class="tool-card">
            <div class="tool-head">
                <span class="eyebrow">Tool 03</span>
                <h2>Social Caption & <strong>Hashtag Generator</strong></h2>
                <p>Scroll-stopping captions and layered hashtag sets for Instagram, LinkedIn, TikTok, and X — matched to your vibe.</p>
            </div>
            <div class="form-row">
                <input type="text" id="cg-topic" class="t-input" placeholder="What's the post about? (e.g. new website launch)" autocomplete="off">
                <input type="text" id="cg-audience" class="t-input" placeholder="Audience — optional (e.g. small business owners)" autocomplete="off">
            </div>
            <div class="form-row">
                <select id="cg-platform" class="t-select" aria-label="Platform">
                    <option value="instagram">Instagram</option>
                    <option value="linkedin">LinkedIn</option>
                    <option value="tiktok">TikTok</option>
                    <option value="x">X (Twitter)</option>
                </select>
                <select id="cg-vibe" class="t-select" aria-label="Vibe">
                    <option value="fun">Fun & playful</option>
                    <option value="professional">Professional</option>
                    <option value="inspirational">Inspirational</option>
                    <option value="salesy">Direct & salesy</option>
                </select>
            </div>
            <button class="run-btn" id="cg-run" onclick="runCaptions()">Generate Captions →</button>
            <div class="tool-hint">Instagram shows the first 125 characters before "…more" — the counter tracks it for you</div>

            <div class="ai-sim-card" id="cg-sim">
                <div class="ai-sim-label"><span class="dot"></span> Generating</div>
                <div class="ai-sim-text" id="cg-sim-text">Reading the room…</div>
            </div>

            <div class="results" id="cg-results">
                <div class="sec-title">Captions <button class="regen-btn" onclick="runCaptions(true)">Regenerate ↻</button></div>
                <div id="cg-captions"></div>
                <div class="sec-title" style="margin-top:1.6rem;">Hashtag Sets <span style="font-size:0.62rem; color:var(--text-muted); font-weight:400;">mix one row from each tier</span></div>
                <div id="cg-hashtags"></div>
                <div style="text-align:center; margin-top:1.5rem;">
                    <button class="btn-outline" id="cg-copy-all" onclick="copyAllCaptions()">Copy Caption + Hashtags</button>
                </div>
                <div class="pro-zone" id="cg-pro"></div>
                <p class="disclaimer">Captions and tag sets are generated from your inputs using proven post structures. Swap in your own voice before posting — authenticity always outperforms templates.</p>
            </div>
        </div>
    </section>

    <!-- ============ TOOL 3: CONTENT ANALYZER ============ -->
    <section id="content-analyzer" style="padding-top:2rem;">
        <div class="tool-card">
            <div class="tool-head">
                <span class="eyebrow">Tool 04</span>
                <h2>Content SEO <strong>Analyzer</strong></h2>
                <p>Paste any article, page copy, or draft. Get an instant score across readability, structure, and keyword usage — with specific fixes.</p>
            </div>
            <div class="form-row">
                <input type="text" id="ca-keyword" class="t-input" placeholder="Target keyword — optional (e.g. digital marketing agency)" autocomplete="off">
            </div>
            <div class="form-row">
                <textarea id="ca-text" class="t-area" placeholder="Paste your content here (at least 50 words for a meaningful analysis)…"></textarea>
            </div>
            <button class="run-btn" id="ca-run" onclick="runAnalyzer()">Analyze Content →</button>
            <div class="tool-hint">Analysis runs locally in your browser — your text is never uploaded or stored · <a href="#" onclick="loadSampleText(); return false;" style="color:var(--brand-gold);">try it with sample text</a></div>

            <div class="results" id="ca-results">
                <div class="score-wrap">
                    <div class="score-ring-box">
                        <svg viewBox="0 0 130 130" width="130" height="130">
                            <circle class="ring-bg" cx="65" cy="65" r="56"></circle>
                            <circle class="ring-fill" id="ca-ring" cx="65" cy="65" r="56" stroke-dasharray="352" stroke-dashoffset="352"></circle>
                        </svg>
                        <div class="ring-label">
                            <div class="ring-num" id="ca-score">0</div>
                            <div class="ring-sub">Content Score</div>
                        </div>
                    </div>
                    <div class="stat-grid">
                        <div class="stat-box"><div class="v" id="ca-words">0</div><div class="k">Words</div></div>
                        <div class="stat-box"><div class="v" id="ca-read-time">0 min</div><div class="k">Reading Time</div></div>
                        <div class="stat-box"><div class="v" id="ca-flesch">0</div><div class="k">Readability</div></div>
                        <div class="stat-box"><div class="v" id="ca-avg-sent">0</div><div class="k">Avg Sentence</div></div>
                        <div class="stat-box"><div class="v" id="ca-kw-count">—</div><div class="k">Keyword Uses</div></div>
                        <div class="stat-box"><div class="v" id="ca-kw-density">—</div><div class="k">Keyword Density</div></div>
                    </div>
                </div>
                <div class="sec-title">Most Used Terms</div>
                <div class="term-chips" id="ca-terms"></div>
                <div class="sec-title">Recommendations</div>
                <ul class="suggest-list" id="ca-suggests"></ul>
                <div class="pro-zone" id="ca-pro"></div>
                <p class="disclaimer">Heuristic on-page analysis (Flesch reading ease, density, and structure rules) — not a full crawl or ranking prediction. For a technical audit of your live site, try the <a href="/website-check" style="color:var(--brand-gold);">Website Growth Diagnostic</a>.</p>
            </div>
        </div>
    </section>

    <!-- ============ TOOL 5: WEBSITE DIAGNOSTIC ============ -->
    <section id="web-diagnostic" style="padding-top:2rem;">
        <div class="tool-card">
            <div class="tool-head">
                <span class="eyebrow">Tool 05</span>
                <h2>Website Growth <strong>Diagnostic</strong></h2>
                <p>Enter your domain for an instant 5-category snapshot with a prioritized action plan.</p>
            </div>
            <div class="form-row">
                <input type="text" id="wd-domain" class="t-input" placeholder="yourwebsite.com" autocomplete="off">
            </div>
            <button class="run-btn" onclick="runDiagnostic()">Run Diagnostic →</button>
            <div class="tool-hint">Heuristic snapshot from your URL structure — the <a href="/services/seo" style="color:var(--brand-gold);">real Lighthouse audit</a> runs live checks</div>
            <div class="results" id="wd-results">
                <div class="score-wrap">
                    <div class="score-ring-box">
                        <svg viewBox="0 0 130 130" width="130" height="130">
                            <circle class="ring-bg" cx="65" cy="65" r="56"></circle>
                            <circle class="ring-fill" id="wd-ring" cx="65" cy="65" r="56" stroke-dasharray="352" stroke-dashoffset="352"></circle>
                        </svg>
                        <div class="ring-label"><div class="ring-num" id="wd-score">0</div><div class="ring-sub">Site Score</div></div>
                    </div>
                    <div class="stat-grid" id="wd-cats" style="grid-template-columns:1fr;"></div>
                </div>
                <div class="sec-title">Priority Action Plan</div>
                <ul class="suggest-list" id="wd-plan"></ul>
                <p class="disclaimer">Heuristic estimate based on domain signals — not a crawl. Book the free full audit for real Core Web Vitals and schema validation.</p>
                <div class="pro-zone" id="wd-pro"></div>
            </div>
        </div>
    </section>

    <!-- ============ TOOL 6: STARTUP KIT ============ -->
    <section id="startup-kit-tool" style="padding-top:2rem;">
        <div class="tool-card">
            <div class="tool-head">
                <span class="eyebrow">Tool 06</span>
                <h2>Startup Launch <strong>Kit</strong></h2>
                <p>Name ideas, taglines, a brand palette, logo mark concepts, and domain checks — from one sentence.</p>
            </div>
            <div class="form-row">
                <input type="text" id="sk-idea" class="t-input" placeholder="Your idea (e.g. organic coffee roastery)" autocomplete="off">
                <select id="sk-industry" class="t-select" aria-label="Industry">
                    <option value="tech">Tech / SaaS</option><option value="food">Food &amp; Drink</option>
                    <option value="retail">Retail / E-commerce</option><option value="services">Local Services</option>
                    <option value="creative">Creative / Agency</option><option value="health">Health &amp; Wellness</option>
                </select>
            </div>
            <button class="run-btn" onclick="runMiniKit()">Generate Kit →</button>
            <div class="tool-hint">Want the full kit with pitch, mission &amp; branded PDF? <a href="/startup-kit" style="color:var(--brand-gold);">Open the full generator</a></div>
            <div class="results" id="sk-results">
                <div class="sec-title">Name Ideas <button class="regen-btn" onclick="runMiniKit(true)">Regenerate ↻</button></div>
                <div id="sk-names"></div>
                <div class="sec-title" style="margin-top:1.4rem;">Taglines</div>
                <div id="sk-taglines"></div>
                <div class="sec-title" style="margin-top:1.4rem;">Brand Palette</div>
                <div id="sk-palette" style="display:flex; gap:0.6rem; flex-wrap:wrap;"></div>
                <div class="sec-title" style="margin-top:1.4rem;">Logo Mark Concepts</div>
                <div id="sk-logos" style="display:flex; gap:1.4rem; flex-wrap:wrap;"></div>
                <div class="sec-title" style="margin-top:1.4rem;">Domain Ideas</div>
                <div id="sk-domains"></div>
            
                <div class="pro-zone" id="sk-pro"></div></div>
        </div>
    </section>

    <!-- ============ TOOL 7: BUDGET ARCHITECT ============ -->
    <section id="budget-architect" style="padding-top:2rem;">
        <div class="tool-card">
            <div class="tool-head">
                <span class="eyebrow">Tool 07</span>
                <h2>Marketing Budget <strong>Architect</strong></h2>
                <p>See how your ad budget should split across Google and Meta — with projected clicks, leads, and cost per lead.</p>
            </div>
            <div class="form-row">
                <input type="text" id="ba-industry" class="t-input" placeholder="Industry (e.g. real estate, restaurant)" autocomplete="off">
                <input type="text" id="ba-location" class="t-input" placeholder="Market (e.g. London, Toronto, Sydney)" autocomplete="off">
            </div>
            <div class="form-row" style="align-items:center;">
                <label style="font-size:0.72rem; color:var(--text-muted); text-transform:uppercase; letter-spacing:1px; white-space:nowrap;">Daily budget: $<span id="ba-budget-val" style="color:var(--brand-gold); font-weight:800;">40</span></label>
                <input type="range" id="ba-budget" min="10" max="500" step="10" value="40" style="flex:1; accent-color:var(--brand-gold);">
            </div>
            <button class="run-btn" onclick="runBudget()">Build My Plan →</button>
            <div class="tool-hint">Benchmark estimates for planning — exact CPCs confirmed in your free strategy call  <a href="/services/ads#mkt-architect-embed" style="color:var(--brand-gold);">Open the full generator</a></div>
            <div class="results" id="ba-results">
                <div class="sec-title">Recommended Split</div>
                <div id="ba-split"></div>
                <div class="sec-title" style="margin-top:1.4rem;">Projected Performance (monthly)</div>
                <div id="ba-projection"></div>
            </div>
        </div>
    </section>

    <!-- ============ TOOL 8: COST ESTIMATOR ============ -->
    <section id="cost-estimator" style="padding-top:2rem;">
        <div class="tool-card">
            <div class="tool-head">
                <span class="eyebrow">Tool 08</span>
                <h2>Project Cost <strong>Estimator</strong></h2>
                <p>Itemized quote in your currency, with a delivery estimate and one-tap send to WhatsApp.</p>
                <div class="pro-zone" id="ba-pro"></div>
            </div>
            <div class="form-row">
                <select id="ce-type" class="t-select" aria-label="Project type">
                    <option value="500">Business Website — from $500</option>
                    <option value="750">E-Commerce Store — from $750</option>
                    <option value="1200">Web App / Platform — from $1,200</option>
                    <option value="350">Branding Package — from $350</option>
                </select>
                <select id="ce-currency" class="t-select" aria-label="Currency">
                    <option value="1" data-sym="$">USD — US Dollar</option>
                    <option value="0.78" data-sym="£">GBP — British Pound</option>
                    <option value="1.37" data-sym="CA$">CAD — Canadian Dollar</option>
                    <option value="1.52" data-sym="A$">AUD — Australian Dollar</option>
                    <option value="1.66" data-sym="NZ$">NZD — NZ Dollar</option>
                    <option value="3.67" data-sym="AED ">AED — Dirham</option>
                </select>
            </div>
            <div class="form-row" style="align-items:center;">
                <label style="font-size:0.72rem; color:var(--text-muted); text-transform:uppercase; letter-spacing:1px; white-space:nowrap;">Pages: <span id="ce-pages-val" style="color:var(--brand-gold); font-weight:800;">5</span></label>
                <input type="range" id="ce-pages" min="1" max="30" value="5" style="flex:1; accent-color:var(--brand-gold);">
            </div>
            <div class="form-row" id="ce-feats" style="gap:0.6rem;">
                <label class="tool-jump" style="cursor:pointer;"><input type="checkbox" value="100" data-label="SEO Setup"> SEO Setup +$100</label>
                <label class="tool-jump" style="cursor:pointer;"><input type="checkbox" value="200" data-label="AI Chatbot"> AI Chatbot +$200</label>
                <label class="tool-jump" style="cursor:pointer;"><input type="checkbox" value="150" data-label="Payment Gateway"> Payments +$150</label>
                <label class="tool-jump" style="cursor:pointer;"><input type="checkbox" value="120" data-label="Booking System"> Booking +$120</label>
            </div>
            <button class="run-btn" onclick="runEstimate()">Calculate My Quote →</button>
                                    <div class="tool-hint"> <a href="/services/web#webEstimator" style="color:var(--brand-gold);">Open the full generator</a></div>

            <div class="results" id="ce-results">
                <div class="sec-title">Your Itemized Quote</div>
                <div id="ce-breakdown"></div>
                <div style="text-align:center; margin:1.4rem 0 0.6rem; font-size:2.2rem; font-weight:800;"><span id="ce-sym">$</span><span id="ce-total">0</span></div>
                <div style="text-align:center; font-size:0.75rem; color:var(--text-muted);" id="ce-meta"></div>
                <div style="text-align:center; margin-top:1.4rem;">
                    <a id="ce-wa" href="#" target="_blank" rel="noopener" class="btn-primary">Send This Quote to WhatsApp →</a>
                </div>
                <p class="disclaimer">Indicative estimate — final quotes confirmed after a free scoping call.</p>
                <div class="pro-zone" id="ce-pro"></div>
            </div>
        </div>
    </section>

    <!-- ============ TOOL 9: ROI / REVENUE CALCULATOR ============ -->
    <section id="roi-calculator" style="padding-top:2rem;">
        <div class="tool-card">
            <div class="tool-head">
                <span class="eyebrow">Tool 09 · New</span>
                <h2>Marketing ROI &amp; Revenue <strong>Calculator</strong></h2>
                <p>See the real money impact before you spend a cent — projected revenue, ROI, and payback from your marketing investment.</p>
            </div>
            <div class="form-row">
                <input type="text" id="roi-avg-sale" class="t-input" placeholder="Average sale value (e.g. 500)" inputmode="numeric" autocomplete="off">
                <input type="text" id="roi-close-rate" class="t-input" placeholder="Lead-to-sale close rate % (e.g. 30)" inputmode="numeric" autocomplete="off">
            </div>
            <div class="form-row">
                <input type="text" id="roi-repeat" class="t-input" placeholder="Repeat purchases per year (e.g. 2)" inputmode="numeric" autocomplete="off">
                <input type="text" id="roi-spend" class="t-input" placeholder="Monthly marketing budget (e.g. 1000)" inputmode="numeric" autocomplete="off">
            </div>
            <div class="form-row">
                <select id="roi-currency" class="t-select" aria-label="Currency">
                    <option value="$">USD ($)</option><option value="£">GBP (£)</option>
                    <option value="CA$">CAD (CA$)</option><option value="A$">AUD (A$)</option>
                    <option value="NZ$">NZD (NZ$)</option>
                </select>
                <select id="roi-industry" class="t-select" aria-label="Industry (sets typical cost-per-lead)">
                    <option value="2.6">Home &amp; Trade Services</option>
                    <option value="4.5">Professional / Legal / Finance</option>
                    <option value="1.1">E-commerce / Retail</option>
                    <option value="1.3">Restaurant / Hospitality</option>
                    <option value="3.4">B2B / SaaS / Tech</option>
                    <option value="1.6">Other / General</option>
                </select>
            </div>
            <div class="preset-row"><span class="preset-label">Try an example:</span>
                <button class="preset-chip" onclick="applyPreset({'roi-avg-sale':'500','roi-close-rate':'30','roi-repeat':'2','roi-spend':'1000','roi-industry':'2.6'});runROI();">🔧 Home services</button>
                <button class="preset-chip" onclick="applyPreset({'roi-avg-sale':'3000','roi-close-rate':'20','roi-repeat':'1','roi-spend':'2000','roi-industry':'4.5'});runROI();">⚖️ Professional</button>
                <button class="preset-chip" onclick="applyPreset({'roi-avg-sale':'60','roi-close-rate':'3','roi-repeat':'4','roi-spend':'800','roi-industry':'1.1'});runROI();">🛍️ E-commerce</button>
            </div>
            <button class="run-btn" onclick="runROI()">Calculate My ROI →</button>
            <div class="tool-hint">Uses benchmark cost-per-lead by industry — real numbers confirmed in a free strategy call</div>
            <div class="results" id="roi-results">
                <div class="score-wrap" style="justify-content:center;">
                    <div style="text-align:center;">
                        <div style="font-size:0.65rem; text-transform:uppercase; letter-spacing:1.5px; color:var(--text-muted);">Projected Annual Revenue</div>
                        <div id="roi-revenue" style="font-size:2.6rem; font-weight:800; color:var(--brand-gold);">—</div>
                        <div id="roi-verdict" style="font-size:0.85rem; color:var(--text-muted); font-weight:300; margin-top:0.4rem;"></div>
                    </div>
                </div>
                <div class="stat-grid" id="roi-stats" style="margin-top:1rem;"></div>
                <div class="sec-title" style="margin-top:1.6rem;">The Math, Step by Step</div>
                <div id="roi-breakdown"></div>
                <div class="sec-title" style="margin-top:1.6rem;">Your 12-Month Growth Curve</div>
                <div id="roi-chart" style="display:flex; align-items:flex-end; gap:3px; height:120px; padding:0.5rem 0; margin-bottom:0.3rem;"></div>
                <div style="display:flex; justify-content:space-between; font-size:0.6rem; color:var(--text-muted); text-transform:uppercase; letter-spacing:1px;"><span>Month 1</span><span>Month 6</span><span>Month 12</span></div>
                <div style="text-align:center; margin-top:1.4rem;">
                    <a id="roi-wa" href="#" target="_blank" rel="noopener" class="btn-primary">Get This Growth Plan Built →</a>
                </div>
                <p class="disclaimer">Projection based on your inputs and industry-benchmark cost-per-lead. Actual results vary with offer, targeting, and landing page quality.</p>
                <div class="pro-zone" id="roi-pro"></div>
            </div>
        </div>
    </section>

    <!-- ============ TOOL 10: COMPETITOR & KEYWORD RESEARCH ============ -->
    <section id="keyword-research" style="padding-top:2rem;">
        <div class="tool-card">
            <div class="tool-head">
                <span class="eyebrow">Tool 10 · New</span>
                <h2>Keyword &amp; Competitor <strong>Research</strong></h2>
                <p>Discover the exact search terms your customers use — with intent, difficulty, and content angles you can rank for.</p>
            </div>
            <div class="form-row">
                <input type="text" id="kw-seed" class="t-input" placeholder="Your service or product (e.g. emergency plumber)" autocomplete="off">
                <input type="text" id="kw-location" class="t-input" placeholder="Location — optional (e.g. Leeds)" autocomplete="off">
            </div>
            <div class="preset-row"><span class="preset-label">Try an example:</span>
                <button class="preset-chip" onclick="applyPreset({'kw-seed':'emergency plumber','kw-location':'Leeds'});runKeywords();">Plumber · Leeds</button>
                <button class="preset-chip" onclick="applyPreset({'kw-seed':'dentist','kw-location':'Toronto'});runKeywords();">Dentist · Toronto</button>
                <button class="preset-chip" onclick="applyPreset({'kw-seed':'wedding photographer','kw-location':'Sydney'});runKeywords();">Photographer · Sydney</button>
            </div>
            <button class="run-btn" onclick="runKeywords()">Find Keywords →</button>
            <div class="tool-hint">Generates keyword families with search-intent &amp; difficulty estimates — no login, instant</div>
            <div class="results" id="kw-results">
                <div class="sec-title">Keyword Opportunities <button class="regen-btn" onclick="runKeywords(true)">Regenerate ↻</button></div>
                <div style="overflow-x:auto;"><table class="mini-table" id="kw-table"></table></div>
                <div class="sec-title" style="margin-top:1.6rem;">Content Angles That Rank</div>
                <ul class="suggest-list" id="kw-angles"></ul>
                <div class="sec-title" style="margin-top:1.6rem;">Questions People Ask (great for AEO &amp; FAQs)</div>
                <div class="term-chips" id="kw-questions"></div>
                <p class="disclaimer">Keyword families and difficulty are heuristic estimates for planning. For live search volumes, we run professional keyword tools in our SEO service.</p>
                <div class="pro-zone" id="kw-pro"></div>
            </div>
        </div>
    </section>

    <!-- ============ TOOL 11: AI CONTENT WRITER ============ -->
    <section id="content-writer" style="padding-top:2rem;">
        <div class="tool-card">
            <div class="tool-head">
                <span class="eyebrow">Tool 11 · New</span>
                <h2>AI Content <strong>Writer</strong></h2>
                <p>Draft a marketing email, a blog outline, or a video script in seconds — structured, on-brand, ready to edit.</p>
            </div>
            <div class="form-row">
                <select id="cw-type" class="t-select" aria-label="Content type">
                    <option value="email">Marketing Email</option>
                    <option value="blog">Blog Post Outline</option>
                    <option value="video">Reels / Video Script</option>
                    <option value="gbp">Google Business Post</option>
                </select>
                <input type="text" id="cw-topic" class="t-input" placeholder="Topic / offer (e.g. 20% off first clean)" autocomplete="off">
            </div>
            <div class="form-row">
                <input type="text" id="cw-business" class="t-input" placeholder="Business name" autocomplete="off">
                <select id="cw-tone" class="t-select" aria-label="Tone">
                    <option value="professional">Professional</option>
                    <option value="friendly">Friendly</option>
                    <option value="urgent">Urgent / promo</option>
                    <option value="premium">Premium / luxury</option>
                </select>
            </div>
            <div class="preset-row"><span class="preset-label">Try an example:</span>
                <button class="preset-chip" onclick="applyPreset({'cw-type':'email','cw-topic':'20% off first order','cw-business':'Bloom Co','cw-tone':'friendly'});runWriter();">Promo email</button>
                <button class="preset-chip" onclick="applyPreset({'cw-type':'blog','cw-topic':'how to choose a contractor','cw-business':'BuildRight','cw-tone':'professional'});runWriter();">Blog outline</button>
                <button class="preset-chip" onclick="applyPreset({'cw-type':'video','cw-topic':'new autumn menu','cw-business':'Cafe Nord','cw-tone':'friendly'});runWriter();">Reel script</button>
            </div>
            <button class="run-btn" onclick="runWriter()">Write It For Me →</button>
            <div class="tool-hint">Generates an editable draft — always add your own voice before publishing</div>
            <div class="results" id="cw-results">
                <div class="sec-title"><span id="cw-out-label">Your Draft</span> <button class="regen-btn" onclick="runWriter(true)">Regenerate ↻</button></div>
                <div id="cw-output" style="background:var(--bg-darker); border:1px solid var(--border-light); border-radius:14px; padding:1.4rem 1.6rem; font-size:0.88rem; line-height:1.7; color:var(--text-muted); white-space:pre-wrap;"></div>
                <div style="text-align:center; margin-top:1.4rem;">
                    <button class="btn-outline" id="cw-copy" onclick="copyWriter()">Copy Draft</button>
                </div>
                <p class="disclaimer">Template-driven draft from your inputs. For a full done-for-you content engine, see our <a href="/solutions#monthly" style="color:var(--brand-gold);">monthly plans</a>.</p>
                <div class="pro-zone" id="cw-pro"></div>
            </div>
        </div>
    </section>

    <!-- ============ TOOL 12: LOCAL SEO & REVIEW CHECKER ============ -->
    <section id="local-seo" style="padding-top:2rem;">
        <div class="tool-card">
            <div class="tool-head">
                <span class="eyebrow">Tool 12 · New</span>
                <h2>Local SEO &amp; Reputation <strong>Checklist</strong></h2>
                <p>See how findable you are on Google Maps &amp; local search — and get a review-generation game plan.</p>
            </div>
            <div class="form-row">
                <input type="text" id="ls-business" class="t-input" placeholder="Business name" autocomplete="off">
                <input type="text" id="ls-city" class="t-input" placeholder="City you serve (e.g. Toronto)" autocomplete="off">
            </div>
            <div class="form-row" style="align-items:center;">
                <label style="font-size:0.72rem; color:var(--text-muted); text-transform:uppercase; letter-spacing:1px; white-space:nowrap;">Google reviews you have: <span id="ls-rev-val" style="color:var(--brand-gold); font-weight:800;">10</span></label>
                <input type="range" id="ls-reviews" min="0" max="200" value="10" style="flex:1; accent-color:var(--brand-gold);">
            </div>
            <button class="run-btn" onclick="runLocalSEO()">Check My Local Presence →</button>
            <div class="tool-hint">Heuristic local-SEO readiness score + a review growth plan for your city</div>
            <div class="results" id="ls-results">
                <div class="score-wrap">
                    <div class="score-ring-box">
                        <svg viewBox="0 0 130 130" width="130" height="130">
                            <circle class="ring-bg" cx="65" cy="65" r="56"></circle>
                            <circle class="ring-fill" id="ls-ring" cx="65" cy="65" r="56" stroke-dasharray="352" stroke-dashoffset="352"></circle>
                        </svg>
                        <div class="ring-label"><div class="ring-num" id="ls-score">0</div><div class="ring-sub">Local Score</div></div>
                    </div>
                    <div class="stat-grid" id="ls-stats" style="min-width:240px;"></div>
                </div>
                <div class="sec-title">Your Local SEO Checklist</div>
                <ul class="suggest-list" id="ls-checklist"></ul>
                <div class="sec-title" style="margin-top:1.4rem;">Review Growth Plan</div>
                <div id="ls-reviews-plan"></div>
                <p class="disclaimer">Heuristic estimate based on your inputs. A full local audit checks your live Google Business Profile, citations, and competitor rankings.</p>
                <div class="pro-zone" id="ls-pro"></div>
            </div>
        </div>
    </section>

    <div class="ad-slot" id="ad-slot-mid" style="margin-top:3rem;"><div class="ad-label">Advertisement</div></div>

    <!-- ============ MORE TOOLS ============ -->
    <section id="more-tools">
        <div class="section-head">
            <h2>More Free <strong>Tools</strong></h2>
            <p>The rest of the Graphinxt toolbox — each one instant, each one free.</p>
        </div>
        <div class="more-grid">
            <a href="/growth-planner" class="more-card" style="border-color:var(--border-glow);">
                <span class="tag">★ Flagship</span>
                <h3>AI Business Growth Planner</h3>
                <p>Share your business, services, location &amp; audience — get a personalized 1-year plan with online + offline marketing and a PDF. Save it and return anytime.</p>
            </a>
            <a href="/services/seo" class="more-card">
                <span class="tag">Live Audit</span>
                <h3>Real SEO &amp; AEO Audit</h3>
                <p>A genuine Google Lighthouse audit of your live site — real scores, plus an AEO readiness checklist.</p>
            </a>
            <a href="/website-check" class="more-card">
                <span class="tag">Diagnostic</span>
                <h3>Website Growth Diagnostic</h3>
                <p>Full version: adds competitor comparison, score history, and a downloadable PDF report.</p>
            </a>
            <a href="/startup-kit" class="more-card">
                <span class="tag">Branding</span>
                <h3>Startup Launch Kit</h3>
                <p>Full version: adds elevator pitch, mission statement, social handles, and a branded PDF download.</p>
            </a>
            <a href="/#marketing-architect" class="more-card">
                <span class="tag">Strategy</span>
                <h3>Marketing Budget Architect</h3>
                <p>Budget split modeling plus projected clicks, leads, and cost-per-lead for your industry.</p>
            </a>
            <a href="/#ai-estimator" class="more-card">
                <span class="tag">Pricing</span>
                <h3>Project Cost Estimator</h3>
                <p>Itemized multi-currency quote with delivery date, installment split, and one-tap WhatsApp send.</p>
            </a>
        </div>
    </section>

    <!-- ============ FUNNEL ============ -->
    <section style="padding-top:0;">
        <div class="funnel-card">
            <h3>Tools are the starting point. <strong>Results are the service.</strong></h3>
            <p>Graphinxt builds websites, brands, and ad campaigns for clients across the UK, USA, Canada, Australia, and New Zealand. If a tool on this page showed you a gap, we can close it — and the first strategy call is free.</p>
            <div class="cta-row">
                <a href="/solutions" class="btn-primary">See Growth Packages — from $300</a>
                <a href="/#contact" class="btn-outline">Book a Free Strategy Call</a>
                <a href="https://wa.me/971564785139" target="_blank" rel="noopener" class="btn-outline">Ask on WhatsApp</a>
            </div>
        </div>
    </section>

    <!-- ============ FAQ ============ -->
    <section style="padding-top:1rem;">
        <div class="section-head">
            <h2>Questions, <strong>Answered</strong></h2>
        </div>
        <div class="faq-item">
            <h3>Are these AI marketing tools really free?</h3>
            <p>Yes. Every tool on this page is completely free, runs instantly in your browser, and requires no signup, no email, and no credit card.</p>
        </div>
        <div class="faq-item">
            <h3>How long should a title tag and meta description be?</h3>
            <p>Keep title tags under roughly 60 characters and meta descriptions under roughly 155 characters so Google displays them without truncation. The generator above counts characters for you and shows a live Google preview.</p>
        </div>
        <div class="faq-item">
            <h3>What are the character limits for Google and Meta ads?</h3>
            <p>Google responsive search ads allow headlines up to 30 characters and descriptions up to 90 characters. Meta ads work best with headlines under 40 characters and the key message in the first 125 characters of primary text. The generator enforces these limits automatically.</p>
        </div>
        <div class="faq-item">
            <h3>Is my text or data stored when I use these tools?</h3>
            <p>No. Everything runs locally in your browser. Nothing you type into the generators or the analyzer is uploaded or stored anywhere.</p>
        </div>
        <div class="faq-item">
            <h3>Do these tools work for businesses in the UK, USA, Canada, Australia and New Zealand?</h3>
            <p>Yes — they were built for exactly those markets. The cost estimator quotes in GBP, USD, CAD, AUD and NZD; the budget architect uses benchmark ad costs typical of English-speaking markets; and the SEO generators follow the same Google guidelines that apply in London, New York, Toronto, Sydney and Auckland alike. Graphinxt serves clients across all five countries.</p>
        </div>
        <div class="faq-item">
            <h3>Can Graphinxt do this work for me?</h3>
            <p>Yes — these tools are fast starting points. We provide full <a href="/services/seo" style="color:var(--brand-gold);">SEO</a>, <a href="/services/ads" style="color:var(--brand-gold);">paid advertising</a>, and <a href="/services/web" style="color:var(--brand-gold);">web development</a> services, and the first strategy call is free.</p>
        </div>
    </section>

    <!-- ============ FEEDBACK & SUGGESTIONS ============ -->
    <section id="feedback" style="padding-top:1rem;">
        <div class="tool-card" style="max-width:820px; margin:0 auto;">
            <div class="tool-head">
                <span class="eyebrow">Help Us Improve</span>
                <h2>Tell Us What to <strong>Build Next</strong></h2>
                <p>These tools are free and always will be — and they get better because business owners like you tell us what's missing. Rate what you used, suggest a tool, or report something that didn't work.</p>
            </div>

            <div class="fb-step" id="fb-form">
                <div class="fb-label">How useful were the tools today?</div>
                <div class="fb-stars" id="fb-stars" role="radiogroup" aria-label="Rating">
                    <button type="button" class="fb-star" data-v="1" aria-label="1 star">★</button>
                    <button type="button" class="fb-star" data-v="2" aria-label="2 stars">★</button>
                    <button type="button" class="fb-star" data-v="3" aria-label="3 stars">★</button>
                    <button type="button" class="fb-star" data-v="4" aria-label="4 stars">★</button>
                    <button type="button" class="fb-star" data-v="5" aria-label="5 stars">★</button>
                    <span class="fb-rating-text" id="fb-rating-text"></span>
                </div>

                <div class="fb-label" style="margin-top:1.6rem;">What's this about?</div>
                <div class="chip-row" id="fb-type-chips" style="justify-content:flex-start;">
                    <button type="button" class="chip sel" data-type="idea">💡 Suggest a new tool</button>
                    <button type="button" class="chip" data-type="improve">⚡ Improve an existing tool</button>
                    <button type="button" class="chip" data-type="bug">🐞 Something didn't work</button>
                    <button type="button" class="chip" data-type="praise">👏 Just saying thanks</button>
                </div>

                <div class="fb-label" style="margin-top:1.4rem;">Which tool? <span class="fb-optional">(optional)</span></div>
                <select id="fb-tool" class="t-select" aria-label="Which tool">
                    <option value="">— Select a tool (or leave blank) —</option>
                    <option>SEO Meta Tag Generator</option>
                    <option>Ad Copy Generator</option>
                    <option>Caption &amp; Hashtag Generator</option>
                    <option>Content SEO Analyzer</option>
                    <option>Website Growth Diagnostic</option>
                    <option>Startup Launch Kit</option>
                    <option>Marketing Budget Architect</option>
                    <option>Project Cost Estimator</option>
                    <option>Marketing ROI Calculator</option>
                    <option>Keyword &amp; Competitor Research</option>
                    <option>AI Content Writer</option>
                    <option>Local SEO &amp; Reputation</option>
                    <option>1-Year Growth Planner</option>
                    <option>A tool that doesn't exist yet</option>
                </select>

                <div class="fb-label" style="margin-top:1.4rem;">Your suggestion</div>
                <textarea id="fb-message" class="t-area" rows="4" placeholder="What would make these tools more useful for your business? Be as specific as you like — we read every message."></textarea>

                <div class="form-row" style="margin-top:0.4rem;">
                    <input type="text" id="fb-name" class="t-input" placeholder="Your name (optional)" autocomplete="name">
                    <input type="email" id="fb-email" class="t-input" placeholder="Email — only if you want a reply (optional)" autocomplete="email">
                </div>

                <button class="run-btn" onclick="submitFeedback()" style="margin-top:0.6rem;">Send My Feedback →</button>
                <div class="tool-hint">We read everything. Good ideas get built — and we'll tell you when yours ships.</div>
            </div>

            <div class="fb-thanks" id="fb-thanks">
                <div class="fb-thanks-icon">✓</div>
                <h3>Thank you — that genuinely helps.</h3>
                <p id="fb-thanks-msg">Your feedback is on its way to our team.</p>
                <div class="fb-thanks-actions" id="fb-thanks-actions"></div>
                <button class="ghost-btn" onclick="resetFeedback()" style="margin-top:1rem;">Send another</button>
            </div>
        </div>

        <p class="disclaimer" style="max-width:640px; margin:1.2rem auto 0;">Feedback opens WhatsApp so it reaches our team directly — nothing is stored on this page. Prefer email? Write to <a href="mailto:reach@graphinxt.com" style="color:var(--brand-gold);">reach@graphinxt.com</a>.</p>
    </section>

    <!-- MY TOOLKIT TRAY -->
    <div class="toolkit-tray" id="toolkit-tray" aria-live="polite">
        <button class="tk-toggle" onclick="document.getElementById('toolkit-tray').classList.toggle('open')" aria-label="Toggle toolkit">
            <span class="tk-star">★</span> My Toolkit <span class="tk-badge" id="toolkit-count">0</span>
        </button>
        <div class="tk-panel">
            <div class="tk-panel-head">Your saved results</div>
            <div class="tk-list" id="toolkit-list"></div>
            <div class="tk-actions">
                <button class="tb-btn" onclick="downloadToolkit()">⬇ Download all (PDF)</button>
                <button class="tb-btn tb-primary" onclick="sendToolkitToGraphinxt()">✈ Send to Graphinxt</button>
                <button class="tk-clear" onclick="clearToolkit()">Clear</button>
            </div>
        </div>
    </div>

   
    <script>
        window.addEventListener('scroll', () => {
            document.getElementById('navbar').classList.toggle('scrolled', document.documentElement.scrollTop > 30);
        });

        // ---------- shared helpers ----------
        function cap(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : s; }
        function esc(s) { const d = document.createElement('div'); d.textContent = s; return d.innerHTML; }
        function shuffle(arr) { const a = arr.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
        function copyText(btn, text) {
            const done = () => { const t = btn.textContent; btn.textContent = 'Copied ✓'; setTimeout(() => btn.textContent = t, 1400); };
            if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(text).then(done).catch(done); }
            else { const ta = document.createElement('textarea'); ta.value = text; document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); } catch(e) {} document.body.removeChild(ta); done(); }
        }

        // ============================================================
        // UNIVERSAL MINI-APP ENGINE — export, download, presets
        // (applies to every tool via a shared results toolbar)
        // ============================================================
        function extractResultsText(container) {
            // Pull readable text from a results block: headings, list items, table rows, key stats
            const lines = [];
            container.querySelectorAll('.sec-title, h3, h4, .copy-item .txt, .suggest-list li, .fix, .good, .stat-box, #kw-table tr, #roi-breakdown > div, [data-export]').forEach(function(el){
                if (el.closest('.results-toolbar')) return;
                let t = (el.innerText || el.textContent || '').replace(/\s+/g,' ').trim();
                if (el.classList && el.classList.contains('sec-title')) t = '\n== ' + t.replace(/↻.*$/,'').trim() + ' ==';
                if (el.tagName === 'TR') t = [].slice.call(el.children).map(function(c){ return ((c.innerText || c.textContent || '')).trim(); }).join('  |  ');
                if (t && t.length > 1) lines.push(t);
            });
            return lines.join('\n');
        }
        function toolExport(toolKey, title) {
            const container = document.getElementById(toolKey + '-results');
            if (!container) return '';
            var header = 'GRAPHINXT — ' + (title || 'Free Tool Result') + '\n' + new Date().toLocaleString() + '\ngraphinxt.com/tools\n' + '─'.repeat(40) + '\n\n';
            return header + extractResultsText(container) + '\n\n' + '─'.repeat(40) + '\nBuilt with Graphinxt free tools · Ready to grow? graphinxt.com/solutions';
        }
        function copyToolResults(toolKey, title, btn) {
            window.trackConversion('tool_export',{tool:toolKey,action:'copy',page:'/tools'});
            copyText(btn, toolExport(toolKey, title));
        }
        function downloadToolPDF(toolKey, title, btn) {
            window.trackConversion('tool_export',{tool:toolKey,action:'pdf',page:'/tools'});
            var text = toolExport(toolKey, title);
            if (window.jspdf && window.jspdf.jsPDF) {
                try {
                    var doc = new window.jspdf.jsPDF(); var M=16, y=0, W=210;
                    doc.setFillColor(54,54,56); doc.rect(0,0,W,26,'F');
                    doc.setTextColor(233,196,111); doc.setFontSize(16); doc.setFont(undefined,'bold'); doc.text('GRAPHINXT.', M, 12);
                    doc.setTextColor(255,255,255); doc.setFontSize(9); doc.setFont(undefined,'normal'); doc.text(title || 'Free Tool Result', M, 20);
                    y = 36; doc.setTextColor(50,50,50); doc.setFontSize(10);
                    var body = text.split('\n').slice(4); // skip header we redrew
                    body.forEach(function(line){
                        if (y > 280) { doc.addPage(); y = 20; }
                        if (line.startsWith('== ')) { doc.setFont(undefined,'bold'); doc.setTextColor(214,175,55); line = line.replace(/=/g,'').trim(); }
                        else { doc.setFont(undefined,'normal'); doc.setTextColor(60,60,60); }
                        var wrapped = doc.splitTextToSize(line, W - M*2);
                        doc.text(wrapped, M, y); y += wrapped.length * 5 + 1.5;
                    });
                    doc.save('graphinxt-' + toolKey + '.pdf');
                    if (btn) { var o=btn.textContent; btn.textContent='Downloaded ✓'; setTimeout(()=>btn.textContent=o,1400); }
                    return;
                } catch(e) {}
            }
            // fallback: download as .txt
            var blob = new Blob([text], {type:'text/plain'});
            var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'graphinxt-'+toolKey+'.txt';
            document.body.appendChild(a); a.click(); document.body.removeChild(a);
            if (btn) { var o2=btn.textContent; btn.textContent='Downloaded ✓'; setTimeout(()=>btn.textContent=o2,1400); }
        }
        // Inject a toolbar (Copy All + Download) at the top of a results block, once
        function ensureToolbar(toolKey, title) {
            var container = document.getElementById(toolKey + '-results');
            if (!container || container.querySelector('.results-toolbar')) return;
            var bar = document.createElement('div');
            bar.className = 'results-toolbar';
            var safe = title.replace(/'/g,"");
            bar.innerHTML =
                '<button class="tb-btn" onclick="copyToolResults(\'' + toolKey + '\',\'' + safe + '\',this)">⧉ Copy</button>' +
                '<button class="tb-btn" onclick="downloadToolPDF(\'' + toolKey + '\',\'' + safe + '\',this)">⬇ PDF</button>' +
                '<button class="tb-btn" onclick="saveToToolkit(\'' + toolKey + '\',\'' + safe + '\',this)">★ Save to Toolkit</button>' +
                '<button class="tb-btn tb-primary" onclick="sendToGraphinxt(\'' + toolKey + '\',\'' + safe + '\')">✈ Send to Graphinxt</button>';
            container.insertBefore(bar, container.firstChild);
            maybeSuggestNext(toolKey, container);
        }

        // ===== MY TOOLKIT — collect results across tools =====
        var toolkit = [];
        try { toolkit = JSON.parse(localStorage.getItem('grx_toolkit') || '[]'); } catch(e) { toolkit = []; }
        function saveToolkit(){ try { localStorage.setItem('grx_toolkit', JSON.stringify(toolkit.slice(-12))); } catch(e){} }
        function saveToToolkit(toolKey, title, btn) {
            var text = toolExport(toolKey, title);
            toolkit = toolkit.filter(function(i){ return i.key !== toolKey; });
            toolkit.push({ key: toolKey, title: title, text: text, at: Date.now() });
            saveToolkit(); renderToolkit();
            window.trackConversion('toolkit_save', { tool: toolKey, page: '/tools' });
            if (btn) { var o = btn.textContent; btn.textContent = 'Saved \u2605'; setTimeout(function(){ btn.textContent = o; }, 1400); }
            var tray = document.getElementById('toolkit-tray'); if (tray) { tray.classList.add('pulse'); setTimeout(function(){ tray.classList.remove('pulse'); }, 800); }
        }
        function renderToolkit() {
            var tray = document.getElementById('toolkit-tray'); if (!tray) return;
            if (toolkit.length === 0) { tray.classList.remove('show'); return; }
            tray.classList.add('show');
            document.getElementById('toolkit-count').textContent = toolkit.length;
            document.getElementById('toolkit-list').innerHTML = toolkit.map(function(i, idx){
                return '<div class="tk-item"><span>' + esc(i.title) + '</span><button aria-label="Remove" onclick="removeFromToolkit(' + idx + ')">\u2715</button></div>';
            }).join('');
        }
        function removeFromToolkit(idx) { toolkit.splice(idx, 1); saveToolkit(); renderToolkit(); }
        function clearToolkit() { toolkit = []; saveToolkit(); renderToolkit(); }
        function toolkitCombinedText() {
            var head = 'GRAPHINXT \u2014 MY MARKETING TOOLKIT\n' + new Date().toLocaleString() + '\ngraphinxt.com/tools\n' + '='.repeat(44) + '\n\n';
            return head + toolkit.map(function(i){ return i.text; }).join('\n\n' + '\u00b7'.repeat(44) + '\n\n');
        }
        function downloadToolkit() {
            window.trackConversion('toolkit_download', { count: toolkit.length, page: '/tools' });
            var text = toolkitCombinedText();
            if (window.jspdf && window.jspdf.jsPDF) {
                try {
                    var doc = new window.jspdf.jsPDF(), M=16, y=0, W=210;
                    doc.setFillColor(54,54,56); doc.rect(0,0,W,26,'F');
                    doc.setTextColor(233,196,111); doc.setFontSize(16); doc.setFont(undefined,'bold'); doc.text('GRAPHINXT.', M, 12);
                    doc.setTextColor(255,255,255); doc.setFontSize(9); doc.setFont(undefined,'normal'); doc.text('My Marketing Toolkit', M, 20);
                    y = 36;
                    text.split('\n').slice(4).forEach(function(line){
                        if (y > 280) { doc.addPage(); y = 20; }
                        if (line.startsWith('== ')) { doc.setFont(undefined,'bold'); doc.setTextColor(214,175,55); line = line.replace(/=/g,'').trim(); }
                        else { doc.setFont(undefined,'normal'); doc.setTextColor(60,60,60); }
                        var wr = doc.splitTextToSize(line, W - M*2); doc.text(wr, M, y); y += wr.length*5 + 1.5;
                    });
                    doc.save('graphinxt-my-toolkit.pdf'); return;
                } catch(e) {}
            }
            var blob = new Blob([text], {type:'text/plain'}); var a = document.createElement('a');
            a.href = URL.createObjectURL(blob); a.download = 'graphinxt-my-toolkit.txt';
            document.body.appendChild(a); a.click(); document.body.removeChild(a);
        }
        function sendToolkitToGraphinxt() {
            window.trackConversion('toolkit_send', { count: toolkit.length, page: '/tools' });
            var summary = toolkit.map(function(i){ return '\u2022 ' + i.title; }).join('\n');
            var msg = 'Hi Graphinxt! I used your free tools and built a toolkit with:\n' + summary + '\n\nI\u2019d like to discuss turning these into a real plan.';
            window.open('https://wa.me/971564785139?text=' + encodeURIComponent(msg), '_blank', 'noopener');
        }
        // ===== SEND TO GRAPHINXT — per-tool lead capture =====
        function sendToGraphinxt(toolKey, title) {
            window.trackConversion('tool_send_lead', { tool: toolKey, page: '/tools' });
            var msg = 'Hi Graphinxt! I just used your free ' + title + ' tool and would like help acting on the results. Can we talk?';
            window.open('https://wa.me/971564785139?text=' + encodeURIComponent(msg), '_blank', 'noopener');
        }
        // ===== SMART CROSS-TOOL SUGGESTIONS =====
        var NEXT_TOOL = {
            'kw': ['content-writer', 'Now write content for these keywords \u2192'],
            'cw': ['caption-generator', 'Turn this into social captions \u2192'],
            'mg': ['content-analyzer', 'Now check your page content \u2192'],
            'ca': ['keyword-research', 'Find keywords to target \u2192'],
            'wd': ['local-seo', 'Now check your local presence \u2192'],
            'ls': ['keyword-research', 'Find local keywords to rank for \u2192'],
            'ba': ['roi-calculator', 'See the revenue this could produce \u2192'],
            'roi': ['budget-architect', 'Plan how to split this budget \u2192'],
            'ce': ['roi-calculator', 'Project the ROI of this project \u2192'],
            'sk': ['meta-generator', 'Now create your SEO tags \u2192'],
            'ac': ['caption-generator', 'Now write matching social posts \u2192'],
            'cg': ['content-writer', 'Draft a full post or email \u2192']
        };
        function maybeSuggestNext(toolKey, container) {
            var map = NEXT_TOOL[toolKey]; if (!map || container.querySelector('.next-tool')) return;
            var d = document.createElement('div');
            d.className = 'next-tool';
            d.innerHTML = '<span>\uD83D\uDCA1 Next step:</span> <a href="#' + map[0] + '">' + map[1] + '</a>';
            container.appendChild(d);
        }
        // Preset chips: fill inputs with one tap
        function applyPreset(map) {
            Object.keys(map).forEach(function(id){
                var el = document.getElementById(id); if (!el) return;
                el.value = map[id];
                el.dispatchEvent(new Event('input', {bubbles:true}));
                el.dispatchEvent(new Event('change', {bubbles:true}));
            });
        }
        // Auto-attach export toolbar to every tool result when it becomes visible
        var TOOL_TITLES = {
            'mg':'SEO Meta Tags','ac':'Ad Copy','ca':'Content Analysis','cg':'Captions & Hashtags',
            'wd':'Website Diagnostic','sk':'Startup Kit','ba':'Budget Plan','ce':'Project Estimate',
            'roi':'ROI Projection','kw':'Keyword Research','cw':'Content Draft','ls':'Local SEO Report'
        };
        (function attachToolbars(){
            Object.keys(TOOL_TITLES).forEach(function(key){
                var el = document.getElementById(key + '-results');
                if (!el) return;
                var obs = new MutationObserver(function(){
                    if (el.classList.contains('show')) {
                        ensureToolbar(key, TOOL_TITLES[key]);
                        if (['wd','sk','ba','ce','roi','kw','cw','ls'].indexOf(key) !== -1 && window.renderProZone) window.renderProZone(key);
                    }
                });
                obs.observe(el, { attributes:true, attributeFilter:['class'] });
            });
            renderToolkit(); // restore saved toolkit for returning visitors
        })();
        function badge(len, limit) {
            const cls = len <= limit ? 'ok' : 'warn';
            return `<span class="char-badge ${cls}">${len}/${limit}</span>`;
        }
        function renderCopyList(container, items, limit) {
            container.innerHTML = items.map(t => `
                <div class="copy-item">
                    <span class="txt">${esc(t)}</span>
                    <span class="meta-r">${limit ? badge(t.length, limit) : ''}<button class="copy-btn" onclick="copyText(this, ${JSON.stringify(t).replace(/"/g, '&quot;')})">Copy</button></span>
                </div>`).join('');
        }
        function simulate(simId, textId, phrases, then) {
            const sim = document.getElementById(simId), txt = document.getElementById(textId);
            sim.classList.add('show');
            let i = 0;
            txt.textContent = phrases[0];
            const iv = setInterval(() => { i++; if (i < phrases.length) txt.textContent = phrases[i]; }, 420);
            setTimeout(() => { clearInterval(iv); sim.classList.remove('show'); then(); }, phrases.length * 420 + 200);
        }

        // ============================================================
        // TOOL 1 — META TAG GENERATOR
        // ============================================================
        let mgState = null;
        function runMetaGen(regen) {
            const brand = document.getElementById('mg-brand').value.trim();
            const topic = document.getElementById('mg-topic').value.trim();
            const keyword = document.getElementById('mg-keyword').value.trim() || topic;
            const location = document.getElementById('mg-location').value.trim();
            const type = document.getElementById('mg-type').value;
            if (!topic && !keyword) { document.getElementById('mg-topic').focus(); document.getElementById('mg-topic').placeholder = 'Enter a topic first — e.g. web design'; return; }
            window.trackConversion('tool_used', { tool: 'meta_generator', page: '/tools' });

            const go = () => {
                const kw = cap(keyword);
                const b = brand || 'Your Brand';
                const loc = location ? ` in ${cap(location)}` : '';
                const locBare = location ? ` ${cap(location)}` : '';
                const year = new Date().getFullYear();

                let titlePool = {
                    home: [
                        `${kw}${loc} | ${b}`,
                        `${b} — ${kw} That Delivers Results`,
                        `${kw}${loc} — Trusted Experts | ${b}`,
                        `${b} | Award-Level ${kw}${locBare}`,
                        `${kw} Done Right${loc} | ${b}`,
                        `Top-Rated ${kw}${loc} | ${b}`
                    ],
                    service: [
                        `${kw} Services${loc} | ${b}`,
                        `Professional ${kw}${loc} — Get a Free Quote | ${b}`,
                        `${kw}${loc}: Pricing & Packages | ${b}`,
                        `Expert ${kw} Services${loc} | ${b}`,
                        `${kw}${loc} — Fast Turnaround | ${b}`,
                        `Affordable ${kw} Services${loc} | ${b}`
                    ],
                    product: [
                        `${kw} — Buy Online | ${b}`,
                        `${kw}: Features, Pricing & Reviews | ${b}`,
                        `Shop ${kw}${loc} | Free Shipping | ${b}`,
                        `${kw} — Best Price Guaranteed | ${b}`,
                        `${kw} | In Stock & Ready to Ship | ${b}`
                    ],
                    blog: [
                        `${kw}: The Complete ${year} Guide | ${b}`,
                        `${kw} Explained — What You Need to Know | ${b}`,
                        `How ${kw} Works (+ Expert Tips) | ${b}`,
                        `${kw}: 7 Things to Know in ${year} | ${b}`,
                        `The Truth About ${kw} | ${b}`,
                        `${kw} — A Practical Guide | ${b}`
                    ],
                    local: [
                        `${kw}${loc} | Local Experts | ${b}`,
                        `#1 ${kw}${loc} — Free Quotes | ${b}`,
                        `${kw}${loc} — Serving Your Area | ${b}`,
                        `Trusted ${kw}${loc} Since Day One | ${b}`,
                        `${kw}${loc} | Same-Week Availability | ${b}`
                    ]
                }[type];

                let descPool = {
                    home: [
                        `${b} delivers ${keyword}${loc} with measurable results. Explore our work, see transparent pricing, and get a free consultation today.`,
                        `Looking for ${keyword}${loc}? ${b} combines strategy, design, and performance to grow your business. Book a free strategy call — no obligation.`,
                        `${cap(keyword)}${loc} built for results, not just looks. See why clients choose ${b} — portfolio, pricing, and a free first consultation inside.`,
                        `From first brief to final launch, ${b} handles ${keyword}${loc} end to end. Get a free quote in under 24 hours.`
                    ],
                    service: [
                        `Professional ${keyword} services${loc} from ${b}. Transparent pricing, fast turnaround, and real results. Request your free quote today.`,
                        `${b} offers expert ${keyword}${loc} — see packages, pricing, and past work. Free consultation, no pressure, quick response guaranteed.`,
                        `Need ${keyword}${loc}? ${b} delivers on time and on budget, with clear pricing published upfront. Get started with a free quote.`,
                        `${cap(keyword)} services${loc} that pay for themselves. ${b} — proven process, published pricing, free first consultation.`
                    ],
                    product: [
                        `Shop ${keyword} at ${b}. Honest pricing, fast delivery${loc}, and real customer support. See full details, specs, and reviews.`,
                        `${cap(keyword)} — everything you need to know before you buy: features, pricing, and comparisons. Order today from ${b}.`,
                        `Get ${keyword} from ${b} with fast shipping and easy returns. Check current pricing and availability now.`
                    ],
                    blog: [
                        `Everything you need to know about ${keyword} in ${year} — clear explanations, expert tips, and practical next steps from the ${b} team.`,
                        `${cap(keyword)} explained without the jargon. What it is, why it matters, and exactly what to do next. A practical guide by ${b}.`,
                        `We break down ${keyword} step by step — with real examples and mistakes to avoid. Read the full guide from ${b}.`
                    ],
                    local: [
                        `Trusted ${keyword}${loc}. ${b} serves local businesses with fast response times and transparent pricing. Call or message for a free quote today.`,
                        `Searching for ${keyword}${loc}? ${b} is rated for reliability, quality, and honest pricing. Free quotes, same-week availability.`,
                        `${cap(keyword)}${loc} from a team that actually shows up. ${b} — local, responsive, and upfront about pricing. Get your free quote.`
                    ]
                }[type];

                let titles = shuffle(titlePool).slice(0, 5);
                let descs = shuffle(descPool).slice(0, 3);

                mgState = { brand: b, brandRaw: brand, topic, keyword, location, type, titles, descs };
                renderCopyList(document.getElementById('mg-titles'), titles, 60);
                renderCopyList(document.getElementById('mg-descs'), descs, 155);

                // SERP preview: first title/desc; clicking a title updates preview
                const domain = (brand ? brand.toLowerCase().replace(/[^a-z0-9]/g, '') : 'yoursite') + '.com';
                document.getElementById('serp-url-text').textContent = 'https://' + domain + (type === 'home' ? '' : '/' + keyword.toLowerCase().replace(/[^a-z0-9]+/g, '-'));
                document.getElementById('serp-title').textContent = titles[0];
                document.getElementById('serp-desc').textContent = descs[0];
                document.querySelectorAll('#mg-titles .copy-item .txt').forEach(el => {
                    el.style.cursor = 'pointer';
                    el.title = 'Click to preview in Google result';
                    el.addEventListener('click', () => { document.getElementById('serp-title').textContent = el.textContent; });
                });
                document.querySelectorAll('#mg-descs .copy-item .txt').forEach(el => {
                    el.style.cursor = 'pointer';
                    el.title = 'Click to preview in Google result';
                    el.addEventListener('click', () => { document.getElementById('serp-desc').textContent = el.textContent; });
                });

                const res = document.getElementById('mg-results');
                res.classList.add('show');
                if (window.renderProZone) renderProZone('mg');
                if (!regen) if (res.scrollIntoView) res.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            };

            if (regen) { go(); }
            else simulate('mg-sim', 'mg-sim-text', ['Mapping keyword intent…', 'Checking pixel widths & character limits…', 'Writing title variants…', 'Polishing descriptions…'], go);
        }

        // ============================================================
        // TOOL 2 — AD COPY GENERATOR
        // ============================================================
        let acState = null;
        function fitLimit(candidates, limit, count) {
            const seen = new Set(), out = [];
            for (const c of candidates) {
                const t = c.trim();
                if (t.length <= limit && t.length > 4 && !seen.has(t.toLowerCase())) { seen.add(t.toLowerCase()); out.push(t); }
                if (out.length >= count) break;
            }
            return out;
        }
        function runAdCopy(regen) {
            const product = document.getElementById('ac-product').value.trim();
            const benefit = document.getElementById('ac-benefit').value.trim();
            const audience = document.getElementById('ac-audience').value.trim();
            const tone = document.getElementById('ac-tone').value;
            const platform = document.getElementById('ac-platform').value;
            if (!product) { document.getElementById('ac-product').focus(); document.getElementById('ac-product').placeholder = 'Enter your product or service first'; return; }
            window.trackConversion('tool_used', { tool: 'ad_copy_generator', page: '/tools' });

            const go = () => {
                const P = cap(product), pl = product.toLowerCase();
                const B = benefit ? cap(benefit) : '', bl = benefit ? benefit.toLowerCase() : '';
                const aud = audience ? audience.toLowerCase() : '';

                const toneWords = {
                    professional: { open: 'Expert', cta: 'Get a Free Quote', power: 'Trusted', urgency: 'Book Your Consultation' },
                    bold: { open: 'Best-in-Class', cta: 'Start Now', power: '#1 Rated', urgency: 'Claim Your Spot' },
                    friendly: { open: 'Hassle-Free', cta: 'Say Hello', power: 'Loved by Clients', urgency: 'Let\u2019s Talk Today' },
                    urgent: { open: 'Limited Availability', cta: 'Act Now', power: 'Don\u2019t Wait', urgency: 'Spots Filling Fast' }
                }[tone];

                let headlineCands = [
                    `${toneWords.open} ${P}`,
                    `${P} — ${toneWords.cta}`,
                    B ? `${P} — ${B}` : `${P} Made Simple`,
                    B ? `${B}, Guaranteed` : `${toneWords.power} ${P}`,
                    `${toneWords.power} ${P}`,
                    aud ? `${P} for ${cap(aud)}` : `Your ${P} Partner`,
                    `Top-Rated ${P}`,
                    `${P}? Sorted.`,
                    `${toneWords.urgency}`,
                    `Get ${P} Today`,
                    B ? `${B} — Free Quote` : `${P} — Free Quote`,
                    `${P} Near You`,
                    `Affordable ${P}`,
                    `${P} That Works`,
                    `Try ${P} Risk-Free`
                ];

                let descCands = [
                    `${toneWords.open} ${pl}${aud ? ' for ' + aud : ''}${bl ? ' with ' + bl : ''}. ${toneWords.cta} today.`,
                    `${toneWords.power.replace('#1 Rated', 'Rated #1')} for ${pl}. Transparent pricing, fast response, real results. ${toneWords.cta}.`,
                    B ? `${B} on every project. Get ${pl} from a team that delivers. ${toneWords.cta} — it takes 60 seconds.` : `Get ${pl} from a team that delivers on time and on budget. ${toneWords.cta} in 60 seconds.`,
                    aud ? `Built for ${aud}: ${pl}${bl ? ', ' + bl : ''}, and support that answers. ${toneWords.urgency}.` : `${cap(pl)} with honest pricing and support that actually answers. ${toneWords.urgency}.`,
                    `Stop overpaying for ${pl}. Compare our pricing, see the reviews, and ${toneWords.cta.toLowerCase()}.`,
                    `${cap(pl)}${bl ? ' + ' + bl : ''} — everything handled by one team. Free consultation, no obligation.`
                ];

                let headlines, descs, hLimit, dLimit, hLabel, dLabel;
                if (platform === 'google') {
                    hLimit = 30; dLimit = 90; hLabel = 'Headlines (max 30 chars — Google RSA)'; dLabel = 'Descriptions (max 90 chars)';
                    headlines = fitLimit(shuffle(headlineCands), 30, 8);
                    descs = fitLimit(shuffle(descCands), 90, 4);
                    if (descs.length < 4) descs = descs.concat(fitLimit(shuffle(descCands).map(d => d.length > 90 ? d.slice(0, 87).replace(/\s+\S*$/, '') + '…' : d), 90, 4 - descs.length));
                } else {
                    hLimit = 40; dLimit = 125; hLabel = 'Headlines (max 40 chars — Meta)'; dLabel = 'Primary Text (key message in first 125 chars)';
                    headlines = fitLimit(shuffle(headlineCands), 40, 5);
                    descs = shuffle(descCands).slice(0, 4).map(d => d + (aud ? '' : ' 👋'));
                }

                acState = { headlines, descs, product, benefit, audience, tone, platform };
                document.getElementById('ac-h-label').textContent = hLabel;
                document.getElementById('ac-d-label').textContent = dLabel;
                renderCopyList(document.getElementById('ac-headlines'), headlines, hLimit);
                renderCopyList(document.getElementById('ac-descs'), descs, dLimit);

                const res = document.getElementById('ac-results');
                res.classList.add('show');
                renderAdPreview();
                if (window.renderProZone) renderProZone('ac');
                if (!regen) if (res.scrollIntoView) res.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            };

            if (regen) { go(); }
            else simulate('ac-sim', 'ac-sim-text', ['Studying your offer…', 'Matching tone & platform limits…', 'Writing headline variants…', 'Trimming to character limits…'], go);
        }
        function copyAllAds() {
            if (!acState) return;
            const text = 'HEADLINES:\n' + acState.headlines.map(h => '- ' + h).join('\n') + '\n\nDESCRIPTIONS:\n' + acState.descs.map(d => '- ' + d).join('\n');
            copyText(document.getElementById('ac-copy-all'), text);
        }

        // ============================================================
        // TOOL 3 — CONTENT ANALYZER
        // ============================================================
        function countSyllables(word) {
            word = word.toLowerCase().replace(/[^a-z]/g, '');
            if (word.length <= 3) return 1;
            word = word.replace(/(?:[^laeiouy]es|ed|[^laeiouy]e)$/, '').replace(/^y/, '');
            const m = word.match(/[aeiouy]{1,2}/g);
            return m ? m.length : 1;
        }
        let caState = null;
        function runAnalyzer() {
            const text = document.getElementById('ca-text').value.trim();
            const keyword = document.getElementById('ca-keyword').value.trim().toLowerCase();
            if (!text) { document.getElementById('ca-text').focus(); return; }
            window.trackConversion('tool_used', { tool: 'content_analyzer', page: '/tools' });

            const words = text.split(/\s+/).filter(Boolean);
            const wordCount = words.length;
            const sentences = text.split(/[.!?]+/).map(s => s.trim()).filter(s => s.length > 2);
            const sentCount = Math.max(sentences.length, 1);
            const avgSent = wordCount / sentCount;
            const syllables = words.reduce((a, w) => a + countSyllables(w), 0);
            let flesch = 206.835 - 1.015 * avgSent - 84.6 * (syllables / Math.max(wordCount, 1));
            flesch = Math.max(0, Math.min(100, Math.round(flesch)));
            const readTime = Math.max(1, Math.round(wordCount / 220));
            const longSents = sentences.filter(s => s.split(/\s+/).length > 28).length;

            // keyword stats
            let kwCount = 0, kwDensity = 0;
            if (keyword) {
                const rx = new RegExp(keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
                kwCount = (text.match(rx) || []).length;
                const kwWords = keyword.split(/\s+/).length;
                kwDensity = wordCount ? (kwCount * kwWords / wordCount) * 100 : 0;
            }

            // top terms (ignore stopwords)
            const stop = new Set('the a an and or but of to in on for with at by from is are was were be been it its this that these those as your you we our they their i my he she his her not no so if then than can will just do does did have has had what which who whom about into over under more most some any all each very'.split(' '));
            const freq = {};
            words.forEach(w => {
                const c = w.toLowerCase().replace(/[^a-z0-9'-]/g, '');
                if (c.length > 3 && !stop.has(c)) freq[c] = (freq[c] || 0) + 1;
            });
            const top = Object.entries(freq).sort((a, b) => b[1] - a[1]).slice(0, 8);

            // suggestions & score
            const suggests = [];
            let score = 50;
            if (wordCount >= 600) { score += 12; suggests.push(['good', `Solid length (${wordCount} words) — enough depth for Google to understand the topic.`]); }
            else if (wordCount >= 300) { score += 6; suggests.push(['fix', `${wordCount} words is workable, but top-ranking pages usually run 600+ — consider expanding with examples or FAQs.`]); }
            else { score -= 8; suggests.push(['fix', `Only ${wordCount} words — thin content rarely ranks. Aim for at least 300, ideally 600+.`]); }

            if (flesch >= 60) { score += 10; suggests.push(['good', `Readability is strong (Flesch ${flesch}) — easy for most readers to follow.`]); }
            else if (flesch >= 40) { score += 4; suggests.push(['fix', `Readability is moderate (Flesch ${flesch}). Shorter sentences and simpler words would widen your audience.`]); }
            else { score -= 6; suggests.push(['fix', `Readability is difficult (Flesch ${flesch}). Break up long sentences and swap jargon for plain language.`]); }

            if (avgSent <= 20) { score += 8; suggests.push(['good', `Average sentence length is ${avgSent.toFixed(1)} words — comfortably scannable.`]); }
            else { score -= 4; suggests.push(['fix', `Sentences average ${avgSent.toFixed(1)} words — aim under 20 for web reading.`]); }
            if (longSents > 0) suggests.push(['fix', `${longSents} sentence${longSents > 1 ? 's run' : ' runs'} past 28 words — split ${longSents > 1 ? 'them' : 'it'} for easier scanning.`]);

            if (keyword) {
                if (kwCount === 0) { score -= 10; suggests.push(['fix', `Your target keyword "${keyword}" never appears — work it naturally into the opening, one subheading, and the close.`]); }
                else if (kwDensity > 3.5) { score -= 6; suggests.push(['fix', `Keyword density is ${kwDensity.toFixed(1)}% — that risks reading as keyword stuffing. Keep it between 0.5% and 2.5%.`]); }
                else { score += 12; suggests.push(['good', `Keyword "${keyword}" used ${kwCount}× (${kwDensity.toFixed(1)}% density) — within the healthy range.`]); }
            } else {
                suggests.push(['fix', 'No target keyword entered — add one above to check placement and density.']);
            }

            const hasQuestion = /\?/.test(text);
            if (hasQuestion) { score += 4; suggests.push(['good', 'Contains questions — good for featured snippets and AI answer engines (AEO).']); }
            else suggests.push(['fix', 'No questions found — adding a question-and-answer block improves featured snippet and AI search visibility.']);

            const hasNumbers = /\b\d/.test(text);
            if (hasNumbers) { score += 4; suggests.push(['good', 'Uses concrete numbers — specificity builds trust and improves click-through.']); }

            score = Math.max(5, Math.min(98, Math.round(score)));

            // render
            document.getElementById('ca-words').textContent = wordCount.toLocaleString();
            document.getElementById('ca-read-time').textContent = readTime + ' min';
            document.getElementById('ca-flesch').textContent = flesch;
            document.getElementById('ca-avg-sent').textContent = avgSent.toFixed(1);
            document.getElementById('ca-kw-count').textContent = keyword ? kwCount + '×' : '—';
            document.getElementById('ca-kw-density').textContent = keyword ? kwDensity.toFixed(1) + '%' : '—';
            document.getElementById('ca-terms').innerHTML = top.length
                ? top.map(([w, n]) => `<span class="term-chip">${esc(w)} <strong>×${n}</strong></span>`).join('')
                : '<span class="term-chip">Not enough text for term analysis</span>';
            document.getElementById('ca-suggests').innerHTML = suggests.map(([cls, t]) => `<li class="${cls}">${esc(t)}</li>`).join('');

            caState = { text, keyword, wordCount, sentences, avgSent, flesch, readTime, longSents, kwCount, kwDensity, top, score, suggestsText: suggests.map(x => x[1]) };
            const res = document.getElementById('ca-results');
            res.classList.add('show');
            if (window.renderProZone) renderProZone('ca');
            // animate ring + number
            const ring = document.getElementById('ca-ring');
            const circ = 352;
            requestAnimationFrame(() => { ring.style.strokeDashoffset = String(circ - (circ * score / 100)); });
            const numEl = document.getElementById('ca-score');
            let cur = 0;
            const step = Math.max(1, Math.round(score / 30));
            const iv = setInterval(() => { cur += step; if (cur >= score) { cur = score; clearInterval(iv); } numEl.textContent = cur; }, 25);
            if (res.scrollIntoView) res.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }


        // ============================================================
        // TOOL 4 — SOCIAL CAPTION & HASHTAG GENERATOR
        // ============================================================
        let cgState = null;
        function hashify(t) { return t.toLowerCase().replace(/[^a-z0-9\s]/g, '').trim().split(/\s+/).map((w,i) => i === 0 ? w : cap(w)).join(''); }
        function runCaptions(regen) {
            const topic = document.getElementById('cg-topic').value.trim();
            const audience = document.getElementById('cg-audience').value.trim();
            const platform = document.getElementById('cg-platform').value;
            const vibe = document.getElementById('cg-vibe').value;
            if (!topic) { const el = document.getElementById('cg-topic'); el.focus(); el.placeholder = 'Tell me what the post is about first'; return; }
            window.trackConversion('tool_used', { tool: 'caption_generator', page: '/tools' });

            const go = () => {
                const T = cap(topic), tl = topic.toLowerCase();
                const aud = audience ? audience.toLowerCase() : (platform === 'linkedin' ? 'professionals' : 'you');
                const em = {
                    fun: ['🎉','😄','✨','🙌','🔥'],
                    professional: ['📌','✅','📈','💼','🔍'],
                    inspirational: ['🌱','💡','🚀','⭐','🙏'],
                    salesy: ['🔥','⏰','💰','👉','✅']
                }[vibe];
                const hooks = {
                    fun: ['Okay, this is exciting…', 'Plot twist:', 'We did a thing ' + em[0], 'Real talk:'],
                    professional: ['Quick update:', 'Here\u2019s something worth your attention:', 'A milestone worth sharing:', 'Insight of the week:'],
                    inspirational: ['Every big result starts small.', 'Here\u2019s your reminder:', 'It started with one decision.', 'Growth looks like this:'],
                    salesy: ['Stop scrolling ' + em[3], 'This is for ' + aud + ':', 'Last chance energy:', 'You asked, we delivered:']
                }[vibe];
                const bodies = [
                    hooks[0] + ' ' + T + '! ' + em[1] + ' We\u2019ve poured real work into this and it\u2019s finally ready for ' + aud + '. ' + em[2],
                    hooks[1] + ' ' + T + '. Here\u2019s why it matters for ' + aud + ' \u2014 and what changes from today. ' + em[0],
                    hooks[2] + ' ' + T + ' is here. ' + em[4] + ' Tap the link, take a look, and tell us what you think ' + em[3],
                    hooks[3] + ' ' + tl + ' \u2014 done properly. No fluff, just the result. ' + em[1],
                    T + ' ' + em[0] + em[2] + ' Built for ' + aud + ', live now. Save this post for later ' + em[3],
                    'Three things about ' + tl + ':\n1) It\u2019s live ' + em[1] + '\n2) It\u2019s built for ' + aud + '\n3) The link is waiting ' + em[3]
                ];
                const ctas = {
                    instagram: 'Link in bio ' + em[3], linkedin: 'Thoughts? Drop them in the comments \u2b07\ufe0f',
                    tiktok: 'Follow for part 2 ' + em[3], x: 'RT if this helps someone \u267b\ufe0f'
                };
                const captions = shuffle(bodies).slice(0, 4).map(b => b + '\n\n' + ctas[platform]);

                const tag = hashify(topic);
                const audTag = audience ? hashify(audience) : '';
                const popular = { instagram: ['instagood','explorepage','reels','viral','trending'], linkedin: ['business','growth','innovation','leadership','marketing'], tiktok: ['fyp','foryou','viral','trending','learnontiktok'], x: ['trending','news','tips','growth','business'] }[platform];
                const medium = [tag + 'Tips', tag + 'Life', 'best' + cap(tag), tag + 'Daily', tag + 'Community'].map(x => x.slice(0, 28));
                const niche = [tag, tag + 'Expert', audTag || (tag + 'Journey'), tag + 'BehindTheScenes', tag + '2026'].filter(Boolean).map(x => x.slice(0, 28));
                const tiers = [
                    ['Popular (high reach, high competition)', popular],
                    ['Medium (your discovery sweet spot)', medium],
                    ['Niche (your exact people)', niche]
                ];
                cgState = { topic, audience, platform, vibe, captions, tiers };

                const capLimit = platform === 'x' ? 280 : 125;
                document.getElementById('cg-captions').innerHTML = captions.map(t => `
                    <div class="copy-item">
                        <span class="txt" style="white-space:pre-line;">${esc(t)}</span>
                        <span class="meta-r">${badge(platform === 'x' ? t.length : Math.min(t.length, 999), capLimit)}<button class="copy-btn" onclick='copyText(this, ${JSON.stringify(t).replace(/'/g, "&#39;")})'>Copy</button></span>
                    </div>`).join('');
                document.getElementById('cg-hashtags').innerHTML = tiers.map(([label, tags]) => {
                    const line = tags.map(x => '#' + x).join(' ');
                    return `<div class="copy-item"><span class="txt"><span style="display:block; font-size:0.6rem; text-transform:uppercase; letter-spacing:1px; color:var(--brand-gold); margin-bottom:4px;">${label}</span>${esc(line)}</span><span class="meta-r"><button class="copy-btn" onclick='copyText(this, ${JSON.stringify(line).replace(/'/g, "&#39;")})'>Copy</button></span></div>`;
                }).join('');

                if (window.renderProZone) renderProZone('cg');
                const res = document.getElementById('cg-results');
                res.classList.add('show');
                if (!regen && res.scrollIntoView) res.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            };
            if (regen) go();
            else simulate('cg-sim', 'cg-sim-text', ['Reading the room\u2026', 'Matching platform culture\u2026', 'Writing caption variants\u2026', 'Layering hashtag tiers\u2026'], go);
        }
        function copyAllCaptions() {
            if (!cgState) return;
            const text = cgState.captions[0] + '\n\n' + cgState.tiers.map(t => t[1].map(x => '#' + x).join(' ')).join(' ');
            copyText(document.getElementById('cg-copy-all'), text);
        }
        function copyAllMeta() {
            if (!mgState) return;
            const text = 'TITLE TAGS:\n' + mgState.titles.map(t => '- ' + t).join('\n') + '\n\nMETA DESCRIPTIONS:\n' + mgState.descs.map(d => '- ' + d).join('\n');
            copyText(document.getElementById('mg-copy-all'), text);
        }
        function loadSampleText() {
            document.getElementById('ca-keyword').value = 'web design agency';
            document.getElementById('ca-text').value = 'Choosing a web design agency is one of the biggest decisions a small business makes online. A good web design agency does more than make things look nice. It structures your pages around what customers actually search for, which is why the best results were achieved by teams that combine design with SEO.\n\nHow do you compare agencies? Start with three questions. First, can they show live client sites, not just mockups? Second, do they publish pricing, or does every answer require a sales call? Third, who owns the website when the project ends?\n\nFor example, a local bakery increased enquiries by 60% after restructuring its homepage around one clear action. As a result, visitors knew exactly what to do next. However, many businesses still treat their website as a brochure instead of a salesperson. In 2026, that gap is expensive.';
            runAnalyzer();
        }

        // ============================================================
        // LIVE AD PREVIEWS (Google + Meta mockups)
        // ============================================================
        function renderAdPreview() {
            const box = document.getElementById('ac-preview');
            if (!box || !acState) return;
            const h = acState.headlines, ds = acState.descs;
            if (acState.platform === 'google') {
                box.innerHTML = `
                <div class="serp-preview">
                    <div style="font-size:0.72rem; font-weight:bold; color:#202124; margin-bottom:2px;">Sponsored</div>
                    <div class="serp-url"><span class="serp-favicon">G</span><span>https://yoursite.com</span></div>
                    <div class="serp-title">${esc([h[0], h[1], h[2]].filter(Boolean).join(' | '))}</div>
                    <div class="serp-desc">${esc(ds[0] || '')} ${esc(ds[1] || '')}</div>
                </div>`;
            } else {
                box.innerHTML = `
                <div style="background:#fff; border-radius:16px; overflow:hidden; max-width:420px; font-family:Helvetica,Arial,sans-serif;">
                    <div style="padding:0.9rem 1rem; display:flex; align-items:center; gap:10px;">
                        <span class="serp-favicon" style="width:34px; height:34px; font-size:16px;">G</span>
                        <div><div style="color:#050505; font-size:0.85rem; font-weight:bold;">Your Business</div><div style="color:#65676b; font-size:0.7rem;">Sponsored · </div></div>
                    </div>
                    <div style="padding:0 1rem 0.8rem; color:#050505; font-size:0.85rem; line-height:1.45;">${esc(ds[0] || '')}</div>
                    <div style="background:#e4e6eb; height:150px; display:flex; align-items:center; justify-content:center; color:#65676b; font-size:0.75rem;">Your ad image / video</div>
                    <div style="padding:0.8rem 1rem; background:#f0f2f5; display:flex; justify-content:space-between; align-items:center; gap:1rem;">
                        <div style="min-width:0;"><div style="color:#65676b; font-size:0.65rem; text-transform:uppercase;">yoursite.com</div><div style="color:#050505; font-size:0.85rem; font-weight:bold; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${esc(h[0] || '')}</div></div>
                        <button style="background:#e4e6eb; border:none; color:#050505; font-weight:bold; font-size:0.78rem; padding:0.5rem 1rem; border-radius:6px; flex-shrink:0;">Learn More</button>
                    </div>
                </div>`;
            }
        }

        // ============================================================
        // INPUT MEMORY — restore a returning visitor's last inputs
        // ============================================================
        const PERSIST_IDS = ['mg-brand','mg-topic','mg-keyword','mg-location','mg-type','ac-product','ac-benefit','ac-audience','ac-tone','ac-platform','cg-topic','cg-audience','cg-platform','cg-vibe','ca-keyword'];
        (function() {
            try {
                const saved = JSON.parse(window.localStorage.getItem('grx_tool_inputs') || '{}');
                PERSIST_IDS.forEach(id => { const el = document.getElementById(id); if (el && saved[id]) el.value = saved[id]; });
            } catch(e) {}
            PERSIST_IDS.forEach(id => {
                const el = document.getElementById(id);
                if (!el) return;
                el.addEventListener('change', () => {
                    try {
                        const cur = JSON.parse(window.localStorage.getItem('grx_tool_inputs') || '{}');
                        cur[id] = el.value;
                        window.localStorage.setItem('grx_tool_inputs', JSON.stringify(cur));
                    } catch(e) {}
                });
            });
        })();

        // Enter-to-run for caption inputs
        ['cg-topic','cg-audience'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.addEventListener('keypress', e => { if (e.key === 'Enter') runCaptions(); });
        });


        // ============================================================
        // TOOL 5 — WEBSITE DIAGNOSTIC (embedded)
        // ============================================================
        function hashStr(str) { let h = 5381; for (let i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) >>> 0; return h; }
        function sRange(seed, min, max, salt) { return min + (hashStr(seed + '::' + salt) % (max - min + 1)); }
        const WD_FIXES = {
            Security: 'Install free SSL (Let\u2019s Encrypt) and force HTTPS site-wide \u2014 a hard trust and ranking factor.',
            SEO: 'Write unique title tags (<60 chars) and meta descriptions (<155) for every page \u2014 use Tool 01 above.',
            'AEO Readiness': 'Add FAQPage + Organization schema and rewrite key H2s as questions \u2014 AI engines quote Q&A pages.',
            Performance: 'Compress images to WebP, lazy-load below the fold, and aim for LCP under 2.5s on mobile.',
            Mobile: 'Check tap targets are 44px+ and test every form on a real phone \u2014 mobile forms lose the most leads.'
        };
        function runDiagnostic() {
            const raw = document.getElementById('wd-domain').value.trim();
            if (!raw) { document.getElementById('wd-domain').focus(); return; }
            window.trackConversion('tool_used', { tool: 'web_diagnostic', page: '/tools' });
            const hadHttps = /^https:\/\//i.test(raw);
            const domain = raw.toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').split('/')[0];
            const sld = domain.split('.')[0] || domain;
            const cats = {
                Security: hadHttps ? sRange(domain, 82, 98, 'sec') : sRange(domain, 35, 55, 'sec'),
                SEO: Math.min(97, sRange(domain, 55, 80, 'seo') + (sld.includes('-') ? 0 : 4) + (/\d/.test(sld) ? 0 : 3) + (sld.length <= 12 ? 5 : 0)),
                'AEO Readiness': sRange(domain, 28, 58, 'aeo'),
                Performance: sRange(domain, 48, 82, 'perf'),
                Mobile: sRange(domain, 55, 88, 'mob')
            };
            const keys = Object.keys(cats);
            const overall = Math.round(keys.reduce((a, k) => a + cats[k], 0) / keys.length);
            document.getElementById('wd-cats').innerHTML = keys.map(k =>
                '<div class="stat-box"><div style="display:flex; justify-content:space-between; font-size:0.75rem; margin-bottom:6px;"><span style="color:var(--text-muted);">' + k + '</span><strong>' + cats[k] + '</strong></div>' +
                '<div style="height:6px; background:var(--border-light); border-radius:4px; overflow:hidden;"><div style="height:100%; width:' + cats[k] + '%; background:var(--brand-gold); border-radius:4px;"></div></div></div>').join('');
            document.getElementById('wd-plan').innerHTML = keys.sort((a, b) => cats[a] - cats[b]).slice(0, 3)
                .map((k, i) => '<li class="fix"><strong>' + (i + 1) + '. ' + k + ' (' + cats[k] + '/100):</strong> ' + WD_FIXES[k] + '</li>').join('');
            const res = document.getElementById('wd-results');
            res.classList.add('show');
            const ring = document.getElementById('wd-ring');
            requestAnimationFrame(() => { ring.style.strokeDashoffset = String(352 - (352 * overall / 100)); });
            let cur = 0; const step = Math.max(1, Math.round(overall / 30));
            const iv = setInterval(() => { cur += step; if (cur >= overall) { cur = overall; clearInterval(iv); } document.getElementById('wd-score').textContent = cur; }, 25);
            if (res.scrollIntoView) res.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }

        // ============================================================
        // TOOL 6 — MINI STARTUP KIT (embedded)
        // ============================================================
        const SK_DATA = {
            tech: { pre: ['Nova', 'Flux', 'Apex', 'Zen', 'Bolt'], suf: ['ly', 'Labs', 'Hub', 'Stack', 'HQ'], colors: [['#0F172A','#38BDF8','#F8FAFC','#818CF8','#22D3EE'], ['#111827','#10B981','#F9FAFB','#6EE7B7','#374151']], tag: ['Built to scale from day one.', 'The smarter way to WORD.', 'WORD, without the busywork.'] },
            food: { pre: ['Fresh', 'Wild', 'Golden', 'Urban', 'Pure'], suf: ['Kitchen', 'Table', 'Co', 'House', 'Roots'], colors: [['#7C2D12','#FBBF24','#FFFBEB','#EA580C','#292524'], ['#14532D','#FDE68A','#F0FDF4','#65A30D','#1C1917']], tag: ['Made fresh. Made right.', 'Real WORD, no shortcuts.', 'Taste the difference care makes.'] },
            retail: { pre: ['Prime', 'Luxe', 'True', 'Ever', 'Nord'], suf: ['Store', 'Goods', 'Supply', 'Market', '&Co'], colors: [['#18181B','#E9C46F','#FAFAFA','#A16207','#3F3F46'], ['#1E1B4B','#F472B6','#FDF4FF','#8B5CF6','#312E81']], tag: ['Curated for people who notice.', 'Everyday WORD, elevated.', 'Quality you can keep.'] },
            services: { pre: ['Swift', 'Trust', 'Prime', 'Metro', 'Handy'], suf: ['Pros', 'Works', 'Crew', 'Solutions', 'Group'], colors: [['#0C4A6E','#F59E0B','#F0F9FF','#0284C7','#1E293B'], ['#134E4A','#FACC15','#F0FDFA','#2DD4BF','#115E59']], tag: ['On time. Done right.', 'The WORD team your neighbours recommend.', 'Book today, sorted tomorrow.'] },
            creative: { pre: ['Studio', 'Bold', 'Pixel', 'Muse', 'Form'], suf: ['Studio', 'Collective', 'Works', 'Craft', 'Lab'], colors: [['#1C1917','#F43F5E','#FAFAF9','#FB923C','#44403C'], ['#312E81','#FDE047','#EEF2FF','#A78BFA','#1E1B4B']], tag: ['Ideas that refuse to be ignored.', 'WORD with a point of view.', 'Make it unforgettable.'] },
            health: { pre: ['Vital', 'Pure', 'Bloom', 'Thrive', 'Calm'], suf: ['Wellness', 'Health', 'Life', 'Studio', 'Clinic'], colors: [['#064E3B','#A7F3D0','#F0FDF4','#34D399','#1F2937'], ['#4C1D95','#C4B5FD','#FAF5FF','#A78BFA','#2E1065']], tag: ['Feel like yourself again.', 'WORD, from the inside out.', 'Small habits. Big change.'] }
        };
        function runMiniKit(regen) {
            const idea = document.getElementById('sk-idea').value.trim();
            if (!idea) { document.getElementById('sk-idea').focus(); return; }
            window.trackConversion('tool_used', { tool: 'mini_startup_kit', page: '/tools' });
            const d = SK_DATA[document.getElementById('sk-industry').value];
            const words = idea.toLowerCase().replace(/[^a-z\s]/g, '').split(/\s+/).filter(w => w.length > 3);
            const core = cap(words[0] || idea.slice(0, 6));
            const names = [];
            shuffle(d.pre).forEach(p => { if (names.length < 3) names.push(p + core); });
            shuffle(d.suf).forEach(sf => { if (names.length < 6) names.push(core + (sf === '&Co' ? ' & Co' : sf)); });
            renderCopyList(document.getElementById('sk-names'), names, 0);
            const tags = shuffle(d.tag).slice(0, 3).map(t => t.replace('WORD', idea.toLowerCase()));
            renderCopyList(document.getElementById('sk-taglines'), tags, 0);
            const pal = d.colors[Math.floor(Math.random() * d.colors.length)];
            document.getElementById('sk-palette').innerHTML = pal.map(c =>
                '<div style="width:64px; height:64px; border-radius:12px; background:' + c + '; display:flex; align-items:flex-end; justify-content:center; padding-bottom:4px;"><span style="font-size:0.55rem; font-family:monospace; background:rgba(0,0,0,0.5); color:#fff; padding:1px 5px; border-radius:6px;">' + c + '</span></div>').join('');
            const L = names[0].charAt(0).toUpperCase();
            document.getElementById('sk-logos').innerHTML = [
                '<svg viewBox="0 0 80 80" width="80" height="80"><circle cx="40" cy="40" r="38" fill="' + pal[0] + '"/><text x="40" y="54" font-family="Georgia,serif" font-size="38" font-weight="800" fill="' + pal[1] + '" text-anchor="middle">' + L + '</text></svg>',
                '<svg viewBox="0 0 80 80" width="80" height="80"><rect x="3" y="3" width="74" height="74" rx="16" fill="' + pal[1] + '"/><text x="40" y="54" font-family="Montserrat,sans-serif" font-size="36" font-weight="800" fill="' + pal[0] + '" text-anchor="middle">' + L + '</text></svg>',
                '<svg viewBox="0 0 80 80" width="80" height="80"><rect x="3" y="3" width="74" height="74" rx="40" fill="none" stroke="' + pal[1] + '" stroke-width="3.5"/><text x="40" y="52" font-family="Montserrat,sans-serif" font-size="30" font-weight="300" fill="' + pal[1] + '" text-anchor="middle">' + L + '</text></svg>'
            ].join('');
            document.getElementById('sk-domains').innerHTML = names.slice(0, 3).map(n => {
                const base = n.toLowerCase().replace(/[^a-z0-9]/g, '');
                return '<div class="copy-item"><span class="txt">' + esc(base) + '.com \u00b7 .co \u00b7 .io</span><span class="meta-r"><a class="copy-btn" style="text-decoration:none;" target="_blank" rel="noopener" href="https://www.namecheap.com/domains/registration/results/?domain=' + base + '">Check \u2192</a></span></div>';
            }).join('');
            const res = document.getElementById('sk-results');
            res.classList.add('show');
            if (!regen && res.scrollIntoView) res.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }

        // ============================================================
        // TOOL 7 — BUDGET ARCHITECT (embedded)
        // ============================================================
        function baCpc(ind) {
            ind = (ind || '').toLowerCase();
            if (/real estate|property|law|legal|insurance|finance|dental|medical|clinic/.test(ind)) return 4.5;
            if (/ecommerce|e-commerce|shop|store|fashion|retail/.test(ind)) return 1.1;
            if (/restaurant|food|cafe|pizza|delivery/.test(ind)) return 1.3;
            if (/saas|software|tech|app|b2b/.test(ind)) return 3.4;
            if (/clean|plumb|hvac|roof|landscap|moving|repair|salon|gym|fitness/.test(ind)) return 2.6;
            return 1.6;
        }
        document.getElementById('ba-budget').addEventListener('input', function() { document.getElementById('ba-budget-val').textContent = this.value; });
        function runBudget() {
            const ind = document.getElementById('ba-industry').value.trim();
            const loc = document.getElementById('ba-location').value.trim();
            if (!ind) { document.getElementById('ba-industry').focus(); return; }
            window.trackConversion('tool_used', { tool: 'budget_architect', page: '/tools' });
            const daily = parseInt(document.getElementById('ba-budget').value) || 40;
            const monthly = daily * 30;
            const cpc = baCpc(ind);
            const il = ind.toLowerCase();
            let g = 60; // google share
            if (/ecommerce|fashion|retail|restaurant|cafe|beauty|salon|fitness|creative|events/.test(il)) g = 40;
            if (/law|legal|plumb|hvac|roof|repair|emergency|dental|clinic|real estate/.test(il)) g = 75;
            const rows = [['Google Search Ads', g, 'High-intent \u2014 people already searching for ' + esc(il)], ['Meta (FB/IG) Ads', 100 - g, 'Demand creation + retargeting' + (loc ? ' in ' + esc(cap(loc)) : '')]];
            document.getElementById('ba-split').innerHTML = rows.map(r =>
                '<div style="margin-bottom:0.9rem;"><div style="display:flex; justify-content:space-between; font-size:0.8rem; margin-bottom:5px;"><span>' + r[0] + ' \u2014 $' + Math.round(monthly * r[1] / 100).toLocaleString() + '/mo</span><strong style="color:var(--brand-gold);">' + r[1] + '%</strong></div>' +
                '<div style="height:8px; background:var(--border-light); border-radius:4px; overflow:hidden;"><div style="height:100%; width:' + r[1] + '%; background:var(--brand-gold);"></div></div>' +
                '<div style="font-size:0.68rem; color:var(--text-muted); margin-top:4px;">' + r[2] + '</div></div>').join('');
            const clicks = monthly / cpc;
            document.getElementById('ba-projection').innerHTML =
                '<div style="font-size:0.8rem; color:var(--text-muted); margin-bottom:0.8rem;">$' + monthly.toLocaleString() + '/mo \u00f7 ~$' + cpc.toFixed(2) + ' est. CPC \u2248 <strong style="color:var(--text-main);">' + Math.round(clicks).toLocaleString() + ' clicks</strong></div>' +
                [['Conservative', 0.02], ['Expected', 0.035], ['Optimized', 0.055]].map(sc => {
                    const leads = clicks * sc[1];
                    return '<div class="copy-item"><span class="txt">' + sc[0] + ' (' + (sc[1] * 100).toFixed(1) + '% conv.)</span><span class="meta-r" style="gap:1rem;"><strong>~' + Math.round(leads) + ' leads</strong><span style="color:var(--brand-gold); font-weight:700;">$' + Math.round(monthly / leads) + ' CPL</span></span></div>';
                }).join('');
            const res = document.getElementById('ba-results');
            res.classList.add('show');
            if (res.scrollIntoView) res.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }

        // ============================================================
        // TOOL 8 — COST ESTIMATOR (embedded)
        // ============================================================
        document.getElementById('ce-pages').addEventListener('input', function() { document.getElementById('ce-pages-val').textContent = this.value; });
        function runEstimate() {
            window.trackConversion('tool_used', { tool: 'cost_estimator', page: '/tools' });
            const typeEl = document.getElementById('ce-type');
            const base = parseInt(typeEl.value);
            const typeName = typeEl.options[typeEl.selectedIndex].text.split(' \u2014 ')[0];
            const pages = parseInt(document.getElementById('ce-pages').value);
            const items = [[typeName + ' \u2014 base build', base]];
            if (pages > 5) items.push([pages + ' pages architecture', (pages - 5) * 40]);
            document.querySelectorAll('#ce-feats input:checked').forEach(cb => items.push([cb.getAttribute('data-label'), parseInt(cb.value)]));
            const curEl = document.getElementById('ce-currency');
            const rate = parseFloat(curEl.value);
            const sym = curEl.options[curEl.selectedIndex].getAttribute('data-sym');
            const totalUSD = items.reduce((a, i) => a + i[1], 0);
            const total = Math.round(totalUSD * rate);
            document.getElementById('ce-breakdown').innerHTML = items.map(i =>
                '<div style="display:flex; justify-content:space-between; font-size:0.82rem; color:var(--text-muted); padding:0.45rem 0; border-bottom:1px solid var(--border-light);"><span>' + esc(i[0]) + '</span><strong style="color:var(--text-main);">' + sym + Math.round(i[1] * rate).toLocaleString() + '</strong></div>').join('');
            document.getElementById('ce-sym').textContent = sym;
            document.getElementById('ce-total').textContent = total.toLocaleString();
            const weeks = Math.max(2, Math.ceil(pages / 5) + (items.length > 3 ? 2 : 1));
            const dd = new Date(); dd.setDate(dd.getDate() + weeks * 7);
            const delivery = dd.toLocaleDateString(undefined, { day: 'numeric', month: 'long', year: 'numeric' });
            document.getElementById('ce-meta').textContent = 'Est. delivery ' + delivery + ' (' + weeks + ' weeks) \u00b7 or 3 installments of ' + sym + Math.ceil(total / 3).toLocaleString();
            const msg = 'Hi Graphinxt! My estimate from your free tools page:\n' + items.map(i => '\u2022 ' + i[0] + ' \u2014 ' + sym + Math.round(i[1] * rate).toLocaleString()).join('\n') + '\nTotal: ' + sym + total.toLocaleString() + '\nTarget delivery: ' + delivery + '\nPlease send me a formal quote.';
            document.getElementById('ce-wa').href = 'https://wa.me/971564785139?text=' + encodeURIComponent(msg);
            const res = document.getElementById('ce-results');
            res.classList.add('show');
            if (res.scrollIntoView) res.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }

        // ============================================================
        // TOOL 9 — ROI / REVENUE CALCULATOR
        // ============================================================
        function num(id){ return parseFloat((document.getElementById(id).value||'').replace(/[^0-9.]/g,''))||0; }
        function fmtMoney(sym,n){ return sym + Math.round(n).toLocaleString(); }
        function runROI(){
            const sale=num('roi-avg-sale'), close=num('roi-close-rate'), repeat=num('roi-repeat')||1, spend=num('roi-spend');
            const sym=document.getElementById('roi-currency').value;
            const cpl=parseFloat(document.getElementById('roi-industry').value);
            if(!sale||!close||!spend){ document.getElementById(!sale?'roi-avg-sale':(!close?'roi-close-rate':'roi-spend')).focus(); return; }
            window.trackConversion('tool_used',{tool:'roi_calculator',page:'/tools'});
            const annualSpend=spend*12;
            // Realistic: raw budget/CPC gives clicks, not leads; apply a click-to-lead factor (~8%)
            const clicks=annualSpend/cpl;
            const leads=clicks*0.08;
            const customers=leads*(close/100);
            const revenue=customers*sale*repeat;
            const roi=annualSpend>0?((revenue-annualSpend)/annualSpend*100):0;
            const payback=revenue>0?(annualSpend/(revenue/12)):0;
            document.getElementById('roi-revenue').textContent=fmtMoney(sym,revenue);
            const good=roi>=200;
            document.getElementById('roi-verdict').innerHTML = good?'Strong projected return \u2014 every '+sym+'1 could return '+sym+(revenue/annualSpend).toFixed(2):(roi>0?'Profitable, with room to optimize your funnel':'Tight \u2014 improving close rate or offer would lift this fast');
            document.getElementById('roi-stats').innerHTML=[
                ['~'+Math.round(leads).toLocaleString(),'Leads / year'],
                ['~'+Math.round(customers).toLocaleString(),'New customers'],
                [Math.round(roi).toLocaleString()+'%','Projected ROI'],
                [payback>0?payback.toFixed(1)+' mo':'—','Payback period']
            ].map(s=>'<div class="stat-box"><div class="v">'+s[0]+'</div><div class="k">'+s[1]+'</div></div>').join('');
            document.getElementById('roi-breakdown').innerHTML=[
                [sym+annualSpend.toLocaleString()+' annual budget','\u00f7 '+sym+cpl.toFixed(2)+' cost per click'],
                ['= '+Math.round(clicks).toLocaleString()+' clicks','\u00d7 ~8% become leads'],
                ['= '+Math.round(leads).toLocaleString()+' leads','\u00d7 '+close+'% close rate'],
                ['= '+Math.round(customers).toLocaleString()+' customers','\u00d7 '+sym+sale.toLocaleString()+' \u00d7 '+repeat+'/yr'],
                ['= '+fmtMoney(sym,revenue)+' revenue','from '+fmtMoney(sym,annualSpend)+' invested']
            ].map(r=>'<div style="display:flex; justify-content:space-between; gap:1rem; font-size:0.82rem; color:var(--text-muted); padding:0.5rem 0; border-bottom:1px solid var(--border-light);"><span style="color:var(--text-main); font-weight:500;">'+r[0]+'</span><span>'+r[1]+'</span></div>').join('');
            const msg='Hi Graphinxt! Your ROI calculator projects '+fmtMoney(sym,revenue)+'/yr revenue from '+fmtMoney(sym,annualSpend)+' marketing spend ('+Math.round(roi)+'% ROI). I\u2019d like help making this real.';
            document.getElementById('roi-wa').href='https://wa.me/971564785139?text='+encodeURIComponent(msg);
            // 12-month cumulative growth curve (ramp: ads take a few months to hit full stride)
            const ramp=[0.35,0.5,0.65,0.78,0.88,0.95,1,1.05,1.1,1.12,1.15,1.18];
            const monthlyBase=revenue/12;
            let cum=0; const monthly=ramp.map(r=>{cum+=monthlyBase*r; return cum;});
            const maxCum=monthly[monthly.length-1]||1;
            document.getElementById('roi-chart').innerHTML=monthly.map((v,i)=>{
                const pct=Math.max(4,(v/maxCum*100));
                return '<div title="Month '+(i+1)+': '+fmtMoney(sym,v)+' cumulative" style="flex:1; height:'+pct+'%; background:linear-gradient(to top,var(--brand-gold),rgba(233,196,111,0.35)); border-radius:3px 3px 0 0; transition:height .5s ease '+(i*0.04)+'s;"></div>';
            }).join('');
            const res=document.getElementById('roi-results'); res.classList.add('show'); if(res.scrollIntoView) res.scrollIntoView({behavior:'smooth',block:'nearest'});
        }

        // ============================================================
        // TOOL 10 — KEYWORD & COMPETITOR RESEARCH
        // ============================================================
        function runKeywords(regen){
            const seed=document.getElementById('kw-seed').value.trim();
            const loc=document.getElementById('kw-location').value.trim();
            if(!seed){ document.getElementById('kw-seed').focus(); return; }
            window.trackConversion('tool_used',{tool:'keyword_research',page:'/tools'});
            const s=seed.toLowerCase(), L=loc?(' '+loc.toLowerCase()):'';
            const Lc=loc?(' '+cap(loc)):'';
            function diff(k){ const base=(k.length+(k.split(' ').length*4)); return base<14?['Easy','var(--ok)']:(base<22?['Medium','var(--warn)']:['Hard','var(--bad)']); }
            const kws=[
                ['best '+s+Lc,'Commercial'],
                [s+Lc,'Commercial'],
                [s+' near me','Local · High intent'],
                ['affordable '+s+Lc,'Commercial'],
                [s+' cost'+(loc?Lc:''),'Research'],
                [s+' prices','Research'],
                [(loc?cap(loc)+' ':'')+s+' company','Commercial'],
                ['top '+s+Lc,'Commercial'],
                ['emergency '+s+Lc,'Local · High intent'],
                [s+' reviews','Research'],
                ['professional '+s+Lc,'Commercial'],
                ['24 hour '+s+Lc,'Local · High intent']
            ];
            const rows=shuffle(kws).slice(0,8).map(function(k){ const d=diff(k[0]); const vol=['High','Medium','Medium','Low','Medium','Low','Low','Medium'][Math.floor(Math.random()*8)]; return '<tr><td>'+esc(k[0])+'</td><td style="white-space:nowrap;">'+k[1]+'</td><td style="color:'+d[1]+'; font-weight:600;">'+d[0]+'</td></tr>'; }).join('');
            document.getElementById('kw-table').innerHTML='<tr><th>Keyword</th><th>Intent</th><th>Difficulty</th></tr>'+rows;
            const angles=[
                'How much does '+s+(loc?' in '+cap(loc):'')+' cost? ['+new Date().getFullYear()+' guide]',
                'Best '+s+Lc+': how to choose the right one',
                s+' vs DIY: which is right for you?',
                '7 questions to ask before hiring '+(loc?'a '+s+' in '+cap(loc):'a '+s),
                'Signs you need '+s+' now (and what to expect)'
            ];
            document.getElementById('kw-angles').innerHTML=angles.map(a=>'<li class="fix">'+esc(a)+'</li>').join('');
            const qs=['How much does '+s+' cost?','Is '+s+' worth it?','How to choose a '+s+'?','What does '+s+' include?','How long does '+s+' take?','Best '+s+' near me?'];
            document.getElementById('kw-questions').innerHTML=qs.map(q=>'<span class="term-chip">'+esc(q)+'</span>').join('');
            const res=document.getElementById('kw-results'); res.classList.add('show'); if(!regen&&res.scrollIntoView) res.scrollIntoView({behavior:'smooth',block:'nearest'});
        }

        // ============================================================
        // TOOL 11 — AI CONTENT WRITER
        // ============================================================
        let cwText='';
        function runWriter(regen){
            const type=document.getElementById('cw-type').value;
            const topic=document.getElementById('cw-topic').value.trim();
            const biz=document.getElementById('cw-business').value.trim()||'Your Business';
            const tone=document.getElementById('cw-tone').value;
            if(!topic){ document.getElementById('cw-topic').focus(); return; }
            window.trackConversion('tool_used',{tool:'content_writer',ctype:type,page:'/tools'});
            const T=cap(topic);
            const openers={professional:['We\u2019re pleased to share','Here\u2019s something worth your attention:','A quick update from '+biz+':'],friendly:['Hey there! ','Good news ','We\u2019ve got something for you '],urgent:['Don\u2019t miss this ','Limited time: ','Last chance \u2014 '],premium:['An exclusive invitation from '+biz+'. ','Introducing something special. ','For those who expect more: ']}[tone];
            const cta={professional:'Get in touch to learn more.',friendly:'Reply or message us \u2014 we\u2019d love to help!',urgent:'Act now \u2014 offer ends soon.',premium:'Enquire today to reserve yours.'}[tone];
            const op=shuffle(openers)[0];
            let out='', label='Your Draft';
            if(type==='email'){
                label='Marketing Email';
                out='Subject: '+T+' \u2014 from '+biz+'\n\nHi [First Name],\n\n'+op+T+'.\n\nAt '+biz+', we know you want results without the hassle. That\u2019s exactly what this is about \u2014 '+topic.toLowerCase()+', done right.\n\nHere\u2019s why it matters for you:\n\u2022 Save time and get it done properly the first time\n\u2022 Transparent pricing, no surprises\n\u2022 Backed by a team that actually answers\n\n'+cta+'\n\nWarm regards,\nThe '+biz+' Team';
            } else if(type==='blog'){
                label='Blog Post Outline';
                out='TITLE: '+T+': The Complete Guide ('+new Date().getFullYear()+')\n\nMETA DESCRIPTION: Everything you need to know about '+topic.toLowerCase()+' \u2014 practical, clear, and up to date. By '+biz+'.\n\n1. INTRODUCTION\n   \u2022 Hook: the common problem readers face\n   \u2022 Promise: what they\u2019ll learn\n\n2. WHAT IS '+T.toUpperCase()+'?\n   \u2022 Plain-language explanation\n   \u2022 Why it matters now\n\n3. KEY BENEFITS / HOW IT WORKS\n   \u2022 Point 1 with a real example\n   \u2022 Point 2 with data or a stat\n   \u2022 Point 3 addressing a common objection\n\n4. HOW TO CHOOSE / GET STARTED\n   \u2022 Step-by-step or checklist\n   \u2022 Mistakes to avoid\n\n5. FAQ (great for AEO)\n   \u2022 How much does it cost?\n   \u2022 How long does it take?\n\n6. CONCLUSION + CTA\n   \u2022 Recap the promise\n   \u2022 Invite them to contact '+biz;
            } else if(type==='video'){
                label='Reels / Video Script (30\u201345s)';
                out='HOOK (0\u20133s): '+op+T+'? Watch this.\n\nPROBLEM (3\u20138s): Most people struggle with '+topic.toLowerCase()+' because nobody explains it simply.\n\nVALUE (8\u201325s):\n\u2022 Point 1 \u2014 the thing they didn\u2019t know\n\u2022 Point 2 \u2014 the quick win\n\u2022 Point 3 \u2014 the proof it works\n\nCTA (25\u201330s): Follow '+biz+' for more, or tap the link to get started.\n\n[ON-SCREEN TEXT: keep captions bold & short]\n[MUSIC: upbeat, trending audio]';
            } else {
                label='Google Business Post';
                out=op+T+'! \uD83C\uDF1F\n\nAt '+biz+', '+topic.toLowerCase()+' is what we do best. '+cta+'\n\n\uD83D\uDCCD Serving your local area\n\uD83D\uDCF2 Message us to book\n\n#localbusiness #'+biz.toLowerCase().replace(/[^a-z0-9]/g,'');
            }
            cwText=out;
            document.getElementById('cw-out-label').textContent=label;
            document.getElementById('cw-output').textContent=out;
            const res=document.getElementById('cw-results'); res.classList.add('show'); if(!regen&&res.scrollIntoView) res.scrollIntoView({behavior:'smooth',block:'nearest'});
        }
        function copyWriter(){ if(cwText) copyText(document.getElementById('cw-copy'), cwText); }

        // ============================================================
        // TOOL 12 — LOCAL SEO & REPUTATION
        // ============================================================
        document.getElementById('ls-reviews').addEventListener('input',function(){ document.getElementById('ls-rev-val').textContent=this.value; });
        function runLocalSEO(){
            const biz=document.getElementById('ls-business').value.trim();
            const city=document.getElementById('ls-city').value.trim();
            const reviews=parseInt(document.getElementById('ls-reviews').value)||0;
            if(!biz||!city){ document.getElementById(!biz?'ls-business':'ls-city').focus(); return; }
            window.trackConversion('tool_used',{tool:'local_seo',page:'/tools'});
            // heuristic score from review count + name/city signals
            let revScore = reviews>=100?100:(reviews>=50?85:(reviews>=25?70:(reviews>=10?55:(reviews>=1?35:10))));
            const overall = Math.round(revScore*0.55 + 65*0.25 + 70*0.20);
            document.getElementById('ls-stats').innerHTML=[
                [reviews, 'Your reviews'],
                [reviews>=50?'Strong':(reviews>=10?'Building':'Low'),'Review strength'],
                [cap(city),'Target market'],
                [reviews<25?'+'+(25-reviews):'\u2713','Reviews to "trusted"']
            ].map(s=>'<div class="stat-box"><div class="v" style="font-size:1.1rem;">'+s[0]+'</div><div class="k">'+s[1]+'</div></div>').join('');
            const checklist=[
                ['good','Claim &amp; fully complete your Google Business Profile for '+esc(biz)],
                [reviews>=25?'good':'fix','Reviews: you have '+reviews+(reviews>=25?' \u2014 great social proof':' \u2014 aim for 25+ to build trust in '+esc(city))],
                ['fix','Add your city name to your website title tags: "'+esc(biz)+' '+esc(city)+'"'],
                ['fix','Create a location page targeting "[service] in '+esc(city)+'"'],
                ['fix','Keep name, address &amp; phone identical everywhere (site, GBP, directories)'],
                ['fix','Post to your Google Business Profile weekly \u2014 it boosts map ranking'],
                ['fix','Add FAQ &amp; LocalBusiness schema so AI search can recommend you']
            ];
            document.getElementById('ls-checklist').innerHTML=checklist.map(c=>'<li class="'+c[0]+'">'+c[1]+'</li>').join('');
            const target=Math.max(reviews+20, 30);
            document.getElementById('ls-reviews-plan').innerHTML=
                '<div style="font-size:0.83rem; color:var(--text-muted); font-weight:300; line-height:1.7;">'+
                '<strong style="color:var(--text-main);">Goal: reach '+target+' reviews.</strong> At 3 review requests/week (asking happy customers right after the job), that\u2019s about '+Math.ceil((target-reviews)/3*(1/0.4))+' weeks assuming 40% respond.<br><br>'+
                '\u2192 Ask in person right after delivering great work<br>'+
                '\u2192 Send a follow-up text with your direct Google review link<br>'+
                '\u2192 Reply to every review (Google rewards this)<br>'+
                '\u2192 Never buy reviews \u2014 it gets you penalized</div>';
            const res=document.getElementById('ls-results'); res.classList.add('show');
            const ring=document.getElementById('ls-ring');
            requestAnimationFrame(()=>{ ring.style.strokeDashoffset=String(352-(352*overall/100)); });
            let cur=0; const step=Math.max(1,Math.round(overall/30));
            const iv=setInterval(()=>{ cur+=step; if(cur>=overall){cur=overall;clearInterval(iv);} document.getElementById('ls-score').textContent=cur; },25);
            if(res.scrollIntoView) res.scrollIntoView({behavior:'smooth',block:'nearest'});
        }

        // ============================================================
        // FEEDBACK & SUGGESTIONS
        // ============================================================
        var fbRating = 0, fbType = 'idea';
        var FB_RATING_WORDS = { 1:'We can do better — tell us how', 2:'Thanks — what would help?', 3:'Good — what\u2019s missing?', 4:'Great! Any ideas to add?', 5:'Brilliant, thank you!' };
        (function initFeedback(){
            var stars = document.getElementById('fb-stars');
            if (!stars) return;
            stars.querySelectorAll('.fb-star').forEach(function(btn){
                btn.addEventListener('click', function(){
                    fbRating = parseInt(btn.getAttribute('data-v'));
                    stars.querySelectorAll('.fb-star').forEach(function(b){
                        b.classList.toggle('on', parseInt(b.getAttribute('data-v')) <= fbRating);
                    });
                    document.getElementById('fb-rating-text').textContent = FB_RATING_WORDS[fbRating] || '';
                    window.trackConversion('feedback_rating', { rating: fbRating, page: '/tools' });
                });
            });
            var chips = document.getElementById('fb-type-chips');
            if (chips) chips.querySelectorAll('.chip').forEach(function(c){
                c.addEventListener('click', function(){
                    chips.querySelectorAll('.chip').forEach(function(x){ x.classList.remove('sel'); });
                    c.classList.add('sel');
                    fbType = c.getAttribute('data-type');
                });
            });
        })();
        function submitFeedback() {
            var msg = (document.getElementById('fb-message').value || '').trim();
            var tool = document.getElementById('fb-tool').value;
            var name = (document.getElementById('fb-name').value || '').trim();
            var email = (document.getElementById('fb-email').value || '').trim();
            if (!msg && !fbRating) { document.getElementById('fb-message').focus(); return; }
            var typeLabel = { idea:'New tool suggestion', improve:'Tool improvement', bug:'Bug report', praise:'Feedback' }[fbType] || 'Feedback';
            window.trackConversion('feedback_submit', { type: fbType, rating: fbRating, tool: tool || 'none', page: '/tools' });
            var lines = ['Hi Graphinxt! Feedback on your free AI tools:', '', 'Type: ' + typeLabel];
            if (fbRating) lines.push('Rating: ' + fbRating + '/5');
            if (tool) lines.push('Tool: ' + tool);
            if (msg) lines.push('', 'Message:', msg);
            if (name) lines.push('', 'From: ' + name);
            if (email) lines.push('Email: ' + email);
            var waUrl = 'https://wa.me/971564785139?text=' + encodeURIComponent(lines.join('\n'));
            var mailUrl = 'mailto:reach@graphinxt.com?subject=' + encodeURIComponent('Tools feedback: ' + typeLabel) + '&body=' + encodeURIComponent(lines.slice(2).join('\n'));
            try { window.open(waUrl, '_blank', 'noopener'); } catch(e) {}
            document.getElementById('fb-form').classList.add('hide');
            var thanks = document.getElementById('fb-thanks');
            thanks.classList.add('show');
            document.getElementById('fb-thanks-msg').textContent = fbType === 'bug'
                ? 'Thanks for flagging that — we\u2019ll investigate and fix it.'
                : (fbType === 'idea' ? 'If we build your idea, we\u2019ll let you know it shipped.' : 'Your feedback is on its way to our team.');
            document.getElementById('fb-thanks-actions').innerHTML =
                '<a class="btn-outline" href="' + waUrl + '" target="_blank" rel="noopener">Open WhatsApp again</a>' +
                '<a class="btn-outline" href="' + mailUrl + '">Send by email instead</a>';
            if (thanks.scrollIntoView) thanks.scrollIntoView({ behavior:'smooth', block:'center' });
        }
        function resetFeedback() {
            document.getElementById('fb-thanks').classList.remove('show');
            document.getElementById('fb-form').classList.remove('hide');
            document.getElementById('fb-message').value = '';
            document.getElementById('fb-tool').value = '';
            fbRating = 0;
            var stars = document.getElementById('fb-stars');
            if (stars) stars.querySelectorAll('.fb-star').forEach(function(b){ b.classList.remove('on'); });
            document.getElementById('fb-rating-text').textContent = '';
        }

        // Enter-to-run for single-line inputs
        [['mg-brand','mg-topic','mg-keyword','mg-location'], ['ac-product','ac-benefit','ac-audience']].forEach((ids, i) => {
            ids.forEach(id => {
                const el = document.getElementById(id);
                if (el) el.addEventListener('keypress', e => { if (e.key === 'Enter') (i === 0 ? runMetaGen : runAdCopy)(); });
            });
        });
    </script>

    <script>
        // ============================================================
        // GRAPHINXT PRO LAYER — $2 unlock + ad revenue
        // Full setup instructions: MONETIZATION_SETUP.md
        // ============================================================
        const PRO_CONFIG = {
            // ================= DIRECT PAYMENT SETUP =================
            // Create THREE Payment Links in Stripe Dashboard > Payment Links (one per price)
            // and paste each URL below. The instant a link is pasted, that tier's button
            // becomes a direct card-payment gateway popup. No other change needed.
            //
            // For each Payment Link set "After payment" -> redirect to the matching URL:
            //   $2  link -> https://graphinxt.com/tools?unlock=GRX-DAY-7342
            //   $10 link -> https://graphinxt.com/tools?unlock=GRX-WEEK-8151
            //   $25 link -> https://graphinxt.com/tools?unlock=GRX-MONTH-9260
            //
            // SECURITY: NEVER paste your Stripe SECRET key (sk_live_...) anywhere in this
            // website's code. Payment LINKS are designed to be public; the secret key is not.
            plans: {
                day:   { label: '24-Hour Pass', price: '$2',  hours: 24,  paymentLink: 'https://buy.stripe.com/4gM9ASaEvanY44lbgjgA80C', redirectCode: 'GRX-DAY-7342' },
                week:  { label: '7-Day Pass',   price: '$10', hours: 168, paymentLink: 'https://buy.stripe.com/eVqcN46of67I1Wd98bgA80D', redirectCode: 'GRX-WEEK-8151' },
                month: { label: '30-Day Pass',  price: '$25', hours: 720, paymentLink: 'https://buy.stripe.com/9B64gyfYPbs28kB703gA80E', redirectCode: 'GRX-MONTH-9260' }
            },
            salt: 'grx-pass-salt-x91',
            whatsapp: 'https://wa.me/971564785139?text='
        };
        const AD_CONFIG = {
            // Paste your AdSense publisher ID (e.g. 'ca-pub-1234567890123456') AFTER Google approves your site.
            adsensePublisherId: '',
            slots: { 'ad-slot-top': '', 'ad-slot-mid': '' }  // paste each ad unit's slot ID
        };

        // ---- storage helpers ----
        let _memPass = null;
        function lsGetRaw(k) { try { return window.localStorage.getItem(k); } catch(e) { return k === 'grx_pro_pass' ? _memPass : null; } }
        function lsSetRaw(k, v) { try { window.localStorage.setItem(k, v); } catch(e) { if (k === 'grx_pro_pass') _memPass = v; } }
        function lsDel(k) { try { window.localStorage.removeItem(k); } catch(e) { if (k === 'grx_pro_pass') _memPass = null; } }

        // ---- self-validating pass codes ----
        // Format: GRX-{D|W|M}-{EXP36}-{RAND}-{CHK}
        // EXP36 = expiry time (epoch minutes, base36). CHK = checksum so any device can verify.
        function chk(str) {
            let h = 5381;
            const x = str + '|' + PRO_CONFIG.salt;
            for (let i = 0; i < x.length; i++) { h = ((h << 5) + h + x.charCodeAt(i)) & 0xffffffff; }
            return Math.abs(h).toString(36).toUpperCase().slice(0, 4).padStart(4, 'Z');
        }
        function planLetter(k) { return { day: 'D', week: 'W', month: 'M' }[k]; }
        function letterPlan(l) { return { D: 'day', W: 'week', M: 'month' }[l]; }
        function makePassCode(planKey, expiryMs) {
            const exp36 = Math.floor(expiryMs / 60000).toString(36).toUpperCase();
            const rand = Math.random().toString(36).toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 4).padEnd(4, 'X');
            const L = planLetter(planKey);
            return 'GRX-' + L + '-' + exp36 + '-' + rand + '-' + chk(L + exp36 + rand);
        }
        function parsePassCode(code) {
            const m = /^GRX-([DWM])-([A-Z0-9]+)-([A-Z0-9]{4})-([A-Z0-9]{4})$/.exec((code || '').trim().toUpperCase());
            if (!m) return null;
            if (chk(m[1] + m[2] + m[3]) !== m[4]) return null;
            const expiryMs = parseInt(m[2], 36) * 60000;
            if (!expiryMs || isNaN(expiryMs)) return null;
            return { planKey: letterPlan(m[1]), expiryMs, code: m[0] };
        }

        // ---- active pass state ----
        function getPass() {
            try {
                const p = JSON.parse(lsGetRaw('grx_pro_pass') || 'null');
                if (p && p.expiryMs && Date.now() < p.expiryMs) return p;
                if (p) lsDel('grx_pro_pass'); // expired -> clean up
            } catch(e) {}
            return null;
        }
        function isPro() { return !!getPass(); }
        function savePass(p, src) {
            lsSetRaw('grx_pro_pass', JSON.stringify(p));
            window.trackConversion('pro_unlocked', { source: src, plan: p.planKey, page: '/tools' });
            showToast(PRO_CONFIG.plans[p.planKey].label + ' active until ' + fmtDate(p.expiryMs) + ' \u2713');
            if (window.renderProZone) ['mg','ac','ca','cg','wd','sk','ba','ce','roi','kw','cw','ls'].forEach(window.renderProZone);
        }
        function activatePlan(planKey, src) {
            const plan = PRO_CONFIG.plans[planKey];
            const expiryMs = Math.floor((Date.now() + plan.hours * 3600000) / 60000) * 60000; // minute precision matches the code format
            const code = makePassCode(planKey, expiryMs);
            savePass({ planKey, expiryMs, code }, src);
        }
        function fmtDate(ms) {
            try { return new Date(ms).toLocaleString(undefined, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }); }
            catch(e) { return new Date(ms).toString().slice(0, 21); }
        }
        function showToast(msg) {
            const t = document.createElement('div');
            t.className = 'pro-toast'; t.textContent = msg;
            document.body.appendChild(t);
            setTimeout(() => t.remove(), 4200);
        }
        function tryCode(inputEl) {
            const v = (inputEl.value || '').trim().toUpperCase();
            // personal pass code from another device
            const parsed = parsePassCode(v);
            if (parsed) {
                if (Date.now() >= parsed.expiryMs) { inputEl.value = ''; inputEl.placeholder = 'That pass expired on ' + fmtDate(parsed.expiryMs); return; }
                savePass(parsed, 'code_entry');
                return;
            }
            // plan redirect codes (used by Stripe redirects; also lets you sell manually)
            for (const k of Object.keys(PRO_CONFIG.plans)) {
                if (v === PRO_CONFIG.plans[k].redirectCode.toUpperCase()) { activatePlan(k, 'code_entry'); return; }
            }
            inputEl.value = ''; inputEl.placeholder = 'Code not recognized \u2014 check your pass PDF or receipt';
        }
        function buyPro(planKey) {
            const plan = PRO_CONFIG.plans[planKey] || PRO_CONFIG.plans.day;
            window.trackConversion('pro_unlock_click', { plan: planKey, page: '/tools' });
            if (plan.paymentLink) {
                // Direct payment gateway popup (centered); new tab if the browser blocks popups
                const pw = 520, ph = Math.min(780, (window.screen && screen.height ? screen.height - 80 : 780));
                const px = Math.max(0, ((window.screen && screen.width ? screen.width : 1200) - pw) / 2);
                const py = Math.max(0, ((window.screen && screen.height ? screen.height : 800) - ph) / 2);
                let win = null;
                try { win = window.open(plan.paymentLink, 'grx_checkout', 'width=' + pw + ',height=' + ph + ',left=' + px + ',top=' + py + ',resizable=yes,scrollbars=yes'); } catch(e) {}
                if (!win) { window.open(plan.paymentLink, '_blank', 'noopener'); }
                else { showToast('Secure Stripe checkout opened \u2014 this page unlocks automatically after payment'); }
            } else {
                // Payment link not pasted yet for this tier (see PRO_CONFIG above) \u2014 temporary manual fallback
                window.open(PRO_CONFIG.whatsapp + encodeURIComponent('Hi! I want the ' + plan.label + ' (' + plan.price + ') for the Pro tools on graphinxt.com. How do I pay?'), '_blank', 'noopener');
            }
        }
        // Live unlock across windows: checkout popup stores the pass, main window hears it instantly
        window.addEventListener('storage', function(e) {
            if (e && e.key === 'grx_pro_pass' && e.newValue) {
                try {
                    const p = JSON.parse(e.newValue);
                    if (p && Date.now() < p.expiryMs) {
                        showToast('Payment received \u2014 ' + PRO_CONFIG.plans[p.planKey].label + ' unlocked \u2713');
                        window.trackConversion('pro_unlocked', { source: 'popup_storage', plan: p.planKey, page: '/tools' });
                        if (window.renderProZone) ['mg','ac','ca','cg','wd','sk','ba','ce','roi','kw','cw','ls'].forEach(window.renderProZone);
                    }
                } catch(err) {}
            }
        });
        // Stripe redirect handler: tools.html?unlock=GRX-DAY-7342 (or WEEK / MONTH)
        (function() {
            try {
                const q = new URLSearchParams(window.location.search);
                const u = (q.get('unlock') || '').toUpperCase();
                if (!u) return;
                let matched = null;
                for (const k of Object.keys(PRO_CONFIG.plans)) {
                    if (u === PRO_CONFIG.plans[k].redirectCode.toUpperCase()) { matched = k; break; }
                }
                const parsed = !matched && parsePassCode(u);
                if (matched) activatePlan(matched, 'stripe_redirect');
                else if (parsed && Date.now() < parsed.expiryMs) savePass(parsed, 'link_redeem');
                else return;
                if (window.history && history.replaceState) history.replaceState({}, '', window.location.pathname + window.location.hash);
                // If this page is the checkout popup, hand back to the main window and close
                try {
                    if (window.opener && !window.opener.closed) {
                        showToast('Payment complete \u2014 returning you to the tools\u2026');
                        setTimeout(function() { try { window.close(); } catch(e) {} }, 1600);
                    }
                } catch(e) {}
            } catch(e) {}
        })();

        // ---- shared pro UI ----
        function teaserHTML(tool, bullets) {
            const P = PRO_CONFIG.plans;
            return '<div class="pro-teaser">' +
                '<span class="pro-badge">Pro Deep Report \u00b7 from ' + P.day.price + '</span>' +
                '<h3>There\u2019s a deeper report waiting under this one.</h3>' +
                '<div class="pro-blur">' +
                    '<div class="copy-item"><span class="txt">\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588 \u2588\u2588\u2588\u2588\u2588\u2588 \u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588 \u2014 \u2588\u2588 \u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588</span></div>' +
                    '<div class="copy-item"><span class="txt">\u2588\u2588\u2588\u2588\u2588\u2588 \u2588\u2588\u2588 \u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588 \u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588 \u2588\u2588\u2588\u2588</span></div>' +
                '</div>' +
                '<ul class="pro-bullets">' + bullets.map(b => '<li>' + b + '</li>').join('') + '</ul>' +
                '<div class="pro-cta-row">' +
                    '<button class="btn-primary" onclick="buyPro(\'day\')">' + P.day.label + ' \u2014 ' + P.day.price + '</button>' +
                    '<button class="btn-outline" onclick="buyPro(\'week\')">' + P.week.label + ' \u2014 ' + P.week.price + '</button>' +
                    '<button class="btn-outline" onclick="buyPro(\'month\')">' + P.month.label + ' \u2014 ' + P.month.price + '</button>' +
                '</div>' +
                '<div class="pro-code-row">' +
                    '<input type="text" class="pro-code-input" id="' + tool + '-code" placeholder="Have a pass code? Enter it here">' +
                    '<button class="pro-code-btn" onclick="tryCode(document.getElementById(\'' + tool + '-code\'))">Unlock</button>' +
                '</div>' +
                '<p class="pro-note">Pay by card on Stripe\u2019s secure checkout \u2014 we never see your card. Your pass unlocks all four tools and comes with a personal code (downloadable as PDF) that works on any device until it expires.</p>' +
            '</div>';
        }
        function passBarHTML() {
            const p = getPass();
            if (!p) return '';
            return '<div style="display:flex; align-items:center; justify-content:space-between; gap:1rem; flex-wrap:wrap; margin-bottom:1.4rem; padding-bottom:1.2rem; border-bottom:1px solid var(--border-light);">' +
                '<div><span class="pro-badge" style="margin-bottom:0.4rem;">' + PRO_CONFIG.plans[p.planKey].label + ' \u00b7 Active</span>' +
                '<div style="font-size:0.72rem; color:var(--text-muted);">Expires ' + fmtDate(p.expiryMs) + ' \u00b7 Code: <span style="font-family:monospace; color:var(--brand-gold);">' + esc(p.code) + '</span></div></div>' +
                '<button class="pro-code-btn" onclick="downloadPassPDF()">Download Pass PDF</button>' +
            '</div>';
        }
        function downloadPassPDF() {
            const p = getPass();
            if (!p) return;
            if (!(window.jspdf && window.jspdf.jsPDF)) { showToast('PDF library still loading \u2014 try again in a second'); return; }
            window.trackConversion('pass_pdf_download', { plan: p.planKey, page: '/tools' });
            const doc = new window.jspdf.jsPDF();
            doc.setFillColor(54, 54, 56); doc.rect(0, 0, 210, 297, 'F');
            doc.setFillColor(42, 42, 44); doc.roundedRect(20, 40, 170, 130, 6, 6, 'F');
            doc.setDrawColor(233, 196, 111); doc.setLineWidth(0.8); doc.roundedRect(20, 40, 170, 130, 6, 6, 'S');
            doc.setTextColor(233, 196, 111); doc.setFontSize(20); doc.setFont(undefined, 'bold');
            doc.text('GRAPHINXT.', 30, 58);
            doc.setTextColor(255, 255, 255); doc.setFontSize(14);
            doc.text('Pro Tools Access Pass', 30, 70);
            doc.setFontSize(10); doc.setFont(undefined, 'normal'); doc.setTextColor(190, 190, 195);
            doc.text('Plan:', 30, 90); doc.text('Valid until:', 30, 100); doc.text('Your pass code:', 30, 116);
            doc.setTextColor(255, 255, 255); doc.setFont(undefined, 'bold');
            doc.text(PRO_CONFIG.plans[p.planKey].label + '  (' + PRO_CONFIG.plans[p.planKey].price + ')', 60, 90);
            doc.text(fmtDate(p.expiryMs), 60, 100);
            doc.setFontSize(15); doc.setTextColor(233, 196, 111); doc.setFont('courier', 'bold');
            doc.text(p.code, 30, 127);
            doc.setFont(undefined, 'normal'); doc.setFontSize(9); doc.setTextColor(160, 160, 165);
            doc.text('To use on another device: open graphinxt.com/tools, run any tool,', 30, 145);
            doc.text('and enter this code in the "Have a pass code?" box. Valid until expiry.', 30, 151);
            doc.setFontSize(9); doc.setTextColor(120, 120, 125);
            doc.text('graphinxt.com  \u00b7  reach@graphinxt.com  \u00b7  Keep this PDF \u2014 it is your receipt of access.', 20, 200);
            doc.save('graphinxt-pro-pass.pdf');
        }
        function copyBlockBtn(text) {
            return '<button class="copy-btn" style="margin-bottom:1rem;" onclick=\'copyText(this, ' + JSON.stringify(text).replace(/'/g, "&#39;") + ')\'>Copy Block</button>';
        }

        // ---- pixel width estimation for SERP titles ----
        function pxWidth(text, fontPx) {
            try {
                const c = document.createElement('canvas');
                const ctx = c.getContext && c.getContext('2d');
                if (ctx) { ctx.font = fontPx + 'px arial'; return Math.round(ctx.measureText(text).width); }
            } catch(e) {}
            return Math.round(text.length * fontPx * 0.48); // fallback approximation
        }

        // ============================================================
        // PRO GENERATORS
        // ============================================================
        function mgProHTML(st) {
            const kw = st.keyword || st.topic, KW = cap(kw), b = st.brand;
            const loc = st.location ? ' in ' + cap(st.location) : '';
            const year = new Date().getFullYear();
            // 1. pixel width audit
            let rows = st.titles.map(t => {
                const w = pxWidth(t, 20);
                const ok = w <= 580;
                return '<tr><td>' + esc(t) + '</td><td class="' + (ok ? 'v-ok' : 'v-warn') + '">' + w + 'px ' + (ok ? '\u2713 fits' : '\u26a0 may truncate') + '</td></tr>';
            }).join('');
            // 2. long-tail angles
            const angles = [
                'How Much Does ' + KW + ' Cost' + loc + '? [' + year + ' Prices]',
                KW + ' vs DIY: Which Is Right for You?',
                '7 Questions to Ask Before Hiring ' + (st.type === 'product' ? 'a Seller of ' + KW : KW + ' Experts'),
                'Best ' + KW + loc + ': How to Choose in ' + year,
                KW + ' Checklist: What to Look For' + loc,
                'Is ' + KW + ' Worth It? An Honest Breakdown',
                KW + ' Mistakes That Cost You Money (And Fixes)',
                'The Beginner\u2019s Guide to ' + KW + loc
            ];
            // 3. paste-ready head block
            const slug = kw.toLowerCase().replace(/[^a-z0-9]+/g, '-');
            const domain = (st.brandRaw ? st.brandRaw.toLowerCase().replace(/[^a-z0-9]/g, '') : 'yoursite') + '.com';
            const url = 'https://' + domain + (st.type === 'home' ? '/' : '/' + slug);
            const headBlock = '<title>' + st.titles[0] + '</title>\n' +
                '<meta name="description" content="' + st.descs[0].replace(/"/g, '&quot;') + '">\n' +
                '<link rel="canonical" href="' + url + '">\n' +
                '<meta property="og:title" content="' + st.titles[0] + '">\n' +
                '<meta property="og:description" content="' + st.descs[0].replace(/"/g, '&quot;') + '">\n' +
                '<meta property="og:url" content="' + url + '">\n' +
                '<meta property="og:type" content="' + (st.type === 'blog' ? 'article' : 'website') + '">\n' +
                '<meta name="twitter:card" content="summary_large_image">';
            // 4. schema snippet
            let schema;
            if (st.type === 'blog') {
                schema = { '@context': 'https://schema.org', '@type': 'Article', headline: st.titles[0].slice(0, 110), description: st.descs[0], author: { '@type': 'Organization', name: b }, publisher: { '@type': 'Organization', name: b }, mainEntityOfPage: url };
            } else if (st.type === 'local') {
                schema = { '@context': 'https://schema.org', '@type': 'LocalBusiness', name: b, description: st.descs[0], url: url, areaServed: st.location ? cap(st.location) : 'Your service area' };
            } else {
                schema = { '@context': 'https://schema.org', '@type': st.type === 'product' ? 'Product' : 'ProfessionalService', name: (st.type === 'product' ? KW : b), description: st.descs[0], url: url };
            }
            const schemaBlock = '<scr' + 'ipt type="application/ld+json">\n' + JSON.stringify(schema, null, 2) + '\n</scr' + 'ipt>';
            // 5. placement checklist
            const checklist = [
                'Put "' + kw + '" in the first 60 characters of your page H1',
                'Use the keyword once in the first 100 words of body copy',
                'Add it to one H2 subheading, phrased as a question if possible',
                'Include it in the image alt text of your hero image',
                'Use it in the URL slug: /' + slug,
                'Link to this page from at least 2 other pages on your site using the keyword as anchor text'
            ];
            return '<div class="pro-content">' +
                '<span class="pro-badge">Pro Report · Unlocked</span>' +
                '<div class="sec-title">Pixel-Width Audit (Google truncates titles \u2248 580px on desktop)</div>' +
                '<table class="mini-table"><tr><th>Title</th><th>Width</th></tr>' + rows + '</table>' +
                '<div class="sec-title">8 Long-Tail Title Angles (lower competition, higher intent)</div>' +
                '<div id="mg-pro-angles"></div>' +
                '<div class="sec-title">Paste-Ready &lt;head&gt; Block</div>' + copyBlockBtn(headBlock) +
                '<div class="code-block">' + esc(headBlock) + '</div>' +
                '<div class="sec-title">Structured Data (JSON-LD) for Rich Results</div>' + copyBlockBtn(schemaBlock) +
                '<div class="code-block">' + esc(schemaBlock) + '</div>' +
                '<div class="sec-title">Keyword Placement Checklist</div>' +
                '<ul class="suggest-list">' + checklist.map(c => '<li class="fix">' + esc(c) + '</li>').join('') + '</ul>' +
            '</div>';
        }
        function mgProAfterRender() {
            const el = document.getElementById('mg-pro-angles');
            if (!el || !mgState) return;
            const kw = mgState.keyword || mgState.topic, KW = cap(kw);
            const loc = mgState.location ? ' in ' + cap(mgState.location) : '';
            const year = new Date().getFullYear();
            const angles = [
                'How Much Does ' + KW + ' Cost' + loc + '? [' + year + ' Prices]',
                KW + ' vs DIY: Which Is Right for You?',
                '7 Questions to Ask Before Hiring ' + KW + ' Experts',
                'Best ' + KW + loc + ': How to Choose in ' + year,
                KW + ' Checklist: What to Look For' + loc,
                'Is ' + KW + ' Worth It? An Honest Breakdown',
                KW + ' Mistakes That Cost You Money (And Fixes)',
                'The Beginner\u2019s Guide to ' + KW + loc
            ];
            renderCopyList(el, angles, 60);
        }

        function acProHTML(st) {
            const P = cap(st.product), pl = st.product.toLowerCase();
            const loc = '';
            // keywords
            const kwList = [
                [pl, 'exact'], ['"' + pl + ' services"', 'phrase'], ['best ' + pl, 'phrase'],
                [pl + ' near me', 'phrase'], [pl + ' cost', 'phrase'], [pl + ' quotes', 'phrase'],
                ['affordable ' + pl, 'phrase'], [pl + ' company', 'broad'], ['professional ' + pl, 'broad'],
                (st.audience ? [pl + ' for ' + st.audience.toLowerCase(), 'phrase'] : ['top rated ' + pl, 'phrase'])
            ];
            const negs = ['free', 'diy', 'jobs', 'salary', 'course', 'training', 'how to become', 'wiki', 'meaning', 'reddit'];
            const sitelinks = [
                { t: 'Pricing & Packages', d: 'Transparent pricing published upfront. No surprises, no pressure.' },
                { t: 'See Our Work', d: 'Real projects, real results. Browse the portfolio before you decide.' },
                { t: 'Free Quote in 24h', d: 'Tell us what you need \u2014 get a clear quote within one business day.' },
                { t: 'Why Choose Us', d: 'Fast response, honest pricing, and work that speaks for itself.' }
            ];
            const callouts = ['Free Consultation', 'Fast Turnaround', 'Transparent Pricing', '5-Star Rated', 'No Hidden Fees', 'Satisfaction First', 'Quick Response', 'Flexible Packages'];
            const structured = 'Services: ' + P + ', Consultation, Custom Quotes, Ongoing Support';
            const blueprint =
                'CAMPAIGN BLUEPRINT \u2014 ' + P + '\n\n' +
                'KEYWORDS:\n' + kwList.map(k => '  [' + k[1] + '] ' + k[0]).join('\n') + '\n\n' +
                'NEGATIVE KEYWORDS:\n' + negs.map(n => '  -' + n).join('\n') + '\n\n' +
                'SITELINKS:\n' + sitelinks.map(x => '  ' + x.t + ' \u2014 ' + x.d).join('\n') + '\n\n' +
                'CALLOUTS:\n  ' + callouts.join(' \u00b7 ') + '\n\n' +
                'STRUCTURED SNIPPET:\n  ' + structured + '\n\n' +
                'HEADLINES:\n' + (acState ? acState.headlines.map(h => '  - ' + h).join('\n') : '') + '\n\n' +
                'DESCRIPTIONS:\n' + (acState ? acState.descs.map(d => '  - ' + d).join('\n') : '');
            return '<div class="pro-content">' +
                '<span class="pro-badge">Pro Report · Unlocked</span>' +
                '<div class="sec-title">Keyword Targeting Plan</div>' +
                '<table class="mini-table"><tr><th>Keyword</th><th>Match Type</th></tr>' +
                kwList.map(k => '<tr><td>' + esc(k[0]) + '</td><td>' + k[1] + '</td></tr>').join('') + '</table>' +
                '<div class="sec-title">Negative Keywords (stop paying for junk clicks)</div>' +
                '<div class="term-chips">' + negs.map(n => '<span class="term-chip">\u2212 ' + esc(n) + '</span>').join('') + '</div>' +
                '<div class="sec-title">Sitelink Extensions</div>' +
                '<table class="mini-table"><tr><th>Sitelink</th><th>Description</th></tr>' +
                sitelinks.map(x => '<tr><td>' + x.t + '</td><td>' + x.d + '</td></tr>').join('') + '</table>' +
                '<div class="sec-title">Callout Extensions</div>' +
                '<div class="term-chips">' + callouts.map(c => '<span class="term-chip">' + c + '</span>').join('') + '</div>' +
                '<div class="sec-title">Full Campaign Blueprint</div>' + copyBlockBtn(blueprint) +
                '<div class="code-block">' + esc(blueprint) + '</div>' +
            '</div>';
        }

        function caProHTML(st) {
            // longest sentences
            const ranked = st.sentences.map(x => ({ s: x, n: x.split(/\s+/).length })).sort((a, b) => b.n - a.n).slice(0, 5);
            const longRows = ranked.map(r => '<tr><td>' + esc(r.s.length > 140 ? r.s.slice(0, 137) + '\u2026' : r.s) + '</td><td class="' + (r.n > 28 ? 'v-warn' : 'v-ok') + '">' + r.n + ' words</td></tr>').join('');
            // passive voice (heuristic)
            const passiveRx = /\b(am|is|are|was|were|be|been|being)\s+\w+(ed|en)\b/gi;
            const passives = [];
            st.sentences.forEach(x => { if (passiveRx.test(x)) passives.push(x); passiveRx.lastIndex = 0; });
            // transition words
            const transitions = ['however', 'therefore', 'meanwhile', 'moreover', 'instead', 'because', 'although', 'finally', 'first', 'second', 'next', 'also', 'in addition', 'as a result', 'for example', 'in fact', 'on the other hand'];
            const tl = st.text.toLowerCase();
            const transCount = transitions.reduce((a, t) => a + (tl.split(t).length - 1), 0);
            const transRatio = st.sentences.length ? (transCount / st.sentences.length * 100) : 0;
            // paragraphs
            const paras = st.text.split(/\n\s*\n/).map(p => p.trim()).filter(Boolean);
            const longParas = paras.filter(p => p.split(/\s+/).length > 150).length;
            // related terms
            const kw = st.keyword;
            const related = kw ? ['best ' + kw, kw + ' cost', kw + ' benefits', kw + ' examples', 'how ' + kw + ' works', kw + ' vs alternatives', kw + ' checklist', kw + ' for beginners'] : st.top.slice(0, 4).map(t => t[0] + ' guide');
            return '<div class="pro-content">' +
                '<span class="pro-badge">Pro Report · Unlocked</span>' +
                '<div class="sec-title">Longest Sentences (your biggest readability wins)</div>' +
                '<table class="mini-table"><tr><th>Sentence</th><th>Length</th></tr>' + longRows + '</table>' +
                '<div class="sec-title">Passive Voice</div>' +
                '<p style="font-size:0.82rem; color:var(--text-muted); font-weight:300; margin-bottom:0.8rem;">' + passives.length + ' likely passive sentence' + (passives.length === 1 ? '' : 's') + ' detected' + (passives.length ? ' \u2014 rewriting these in active voice usually tightens the copy:' : ' \u2014 nice, your copy is direct.') + '</p>' +
                (passives.length ? '<ul class="suggest-list">' + passives.slice(0, 4).map(p => '<li class="fix">' + esc(p.length > 120 ? p.slice(0, 117) + '\u2026' : p) + '</li>').join('') + '</ul>' : '') +
                '<div class="sec-title">Flow &amp; Structure</div>' +
                '<div class="stat-grid" style="margin-bottom:1.4rem;">' +
                    '<div class="stat-box"><div class="v">' + transRatio.toFixed(0) + '%</div><div class="k">Transition Ratio</div></div>' +
                    '<div class="stat-box"><div class="v">' + paras.length + '</div><div class="k">Paragraphs</div></div>' +
                    '<div class="stat-box"><div class="v">' + longParas + '</div><div class="k">Overlong Paras</div></div>' +
                '</div>' +
                (transRatio < 20 ? '<p style="font-size:0.8rem; color:var(--text-muted); font-weight:300; margin-bottom:1.2rem;">\u2192 Under 20% of sentences use a transition word \u2014 sprinkling in words like \u201chowever\u201d, \u201cfor example\u201d, and \u201cas a result\u201d makes long copy feel guided instead of listy.</p>' : '') +
                '<div class="sec-title">Related Terms to Weave In (topical depth for SEO &amp; AI search)</div>' +
                '<div class="term-chips">' + related.map(r => '<span class="term-chip">' + esc(r) + '</span>').join('') + '</div>' +
                '<div style="text-align:center; margin-top:1.6rem;"><button class="btn-primary" onclick="downloadCaPDF()">Download PDF Report</button></div>' +
            '</div>';
        }
        function downloadCaPDF() {
            if (!caState) return;
            if (!(window.jspdf && window.jspdf.jsPDF)) { showToast('PDF library still loading \u2014 try again in a second'); return; }
            window.trackConversion('pro_pdf_download', { page: '/tools' });
            const doc = new window.jspdf.jsPDF();
            const st = caState;
            doc.setFillColor(54, 54, 56); doc.rect(0, 0, 210, 32, 'F');
            doc.setTextColor(233, 196, 111); doc.setFontSize(18); doc.setFont(undefined, 'bold');
            doc.text('GRAPHINXT.', 14, 15);
            doc.setTextColor(255, 255, 255); doc.setFontSize(10); doc.setFont(undefined, 'normal');
            doc.text('Content SEO Report  \u00b7  ' + new Date().toLocaleDateString(), 14, 24);
            doc.setTextColor(40, 40, 40);
            let y = 44;
            doc.setFontSize(13); doc.setFont(undefined, 'bold'); doc.text('Overall Content Score: ' + st.score + ' / 100', 14, y); y += 10;
            doc.setFontSize(10); doc.setFont(undefined, 'normal');
            const stats = ['Words: ' + st.wordCount, 'Reading time: ' + st.readTime + ' min', 'Flesch readability: ' + st.flesch, 'Avg sentence: ' + st.avgSent.toFixed(1) + ' words', st.keyword ? 'Keyword "' + st.keyword + '": ' + st.kwCount + ' uses (' + st.kwDensity.toFixed(1) + '% density)' : 'No target keyword set'];
            stats.forEach(t => { doc.text('\u2022  ' + t, 16, y); y += 6.5; });
            y += 4; doc.setFont(undefined, 'bold'); doc.setFontSize(12); doc.text('Recommendations', 14, y); y += 8;
            doc.setFont(undefined, 'normal'); doc.setFontSize(9.5);
            (st.suggestsText || []).forEach(t => {
                const lines = doc.splitTextToSize('\u2022  ' + t, 180);
                if (y + lines.length * 5 > 280) { doc.addPage(); y = 20; }
                doc.text(lines, 16, y); y += lines.length * 5 + 2;
            });
            y += 6;
            if (y > 260) { doc.addPage(); y = 20; }
            doc.setFontSize(9); doc.setTextColor(120, 120, 120);
            doc.text('Generated free at graphinxt.com/tools \u00b7 Need it done for you? reach@graphinxt.com', 14, y + 6);
            doc.save('graphinxt-content-report.pdf');
        }

        function cgProHTML(st) {
            const T = cap(st.topic), tl = st.topic.toLowerCase();
            const times = {
                instagram: [['Mon\u2013Fri', '11:00\u201313:00'], ['Tue & Thu', '19:00\u201321:00'], ['Weekend', '10:00\u201312:00']],
                linkedin: [['Tue\u2013Thu', '08:00\u201310:00'], ['Tue & Wed', '12:00\u201313:00'], ['Avoid', 'Fri PM & weekends']],
                tiktok: [['Daily', '18:00\u201322:00'], ['Tue & Thu', '09:00\u201311:00'], ['Weekend', '11:00\u201314:00']],
                x: [['Mon\u2013Fri', '09:00\u201311:00'], ['Daily', '12:00\u201313:00'], ['News days', 'post within the hour']]
            }[st.platform];
            const calendar = [
                ['Mon', 'Announce: lead with the single biggest benefit of ' + tl],
                ['Tue', 'Behind the scenes: one photo/clip of the work behind ' + tl],
                ['Wed', 'Educate: 3 quick tips your audience can use today (related to ' + tl + ')'],
                ['Thu', 'Social proof: a result, review, or before/after tied to ' + tl],
                ['Fri', 'Engage: ask one specific question about ' + tl + ' \u2014 reply to every comment'],
                ['Sat', 'Casual: the human side \u2014 your team, your desk, your why'],
                ['Sun', 'Recap + CTA: what happened this week and the one link to click']
            ];
            const hooks = [
                'Nobody talks about this part of ' + tl + '\u2026',
                'I tested ' + tl + ' for 30 days. Here\u2019s what happened:',
                'The #1 mistake people make with ' + tl + ' (and the 10-second fix)',
                'If I started ' + tl + ' from zero today, I\u2019d do these 3 things:',
                'Unpopular opinion: ' + tl + ' is easier than everyone pretends.'
            ];
            const tag = hashify(st.topic);
            const ladder = ['Use ~20 tags on Instagram, 3\u20135 on LinkedIn/X, 4\u20136 on TikTok', 'Mix: 5 popular + 10 medium + 5 niche \u2014 niche tags convert, popular tags reach', 'Rotate 2\u20133 tags every post so the algorithm doesn\u2019t flag repetition', 'Create one branded tag (#' + tag + 'Official) and use it on every post'];
            return '<div class="pro-content">' +
                '<span class="pro-badge">Pro Report · Unlocked</span>' +
                '<div class="sec-title">7-Day Content Calendar for \u201c' + esc(T) + '\u201d</div>' +
                '<table class="mini-table"><tr><th>Day</th><th>Post</th></tr>' + calendar.map(c => '<tr><td>' + c[0] + '</td><td>' + esc(c[1]) + '</td></tr>').join('') + '</table>' +
                '<div class="sec-title">Best Posting Times \u2014 ' + cap(st.platform) + '</div>' +
                '<table class="mini-table"><tr><th>When</th><th>Window (local time)</th></tr>' + times.map(t => '<tr><td>' + t[0] + '</td><td>' + t[1] + '</td></tr>').join('') + '</table>' +
                '<div class="sec-title">5 Hook Formulas (first line = the whole game)</div>' +
                '<ul class="suggest-list">' + hooks.map(h => '<li class="fix">' + esc(h) + '</li>').join('') + '</ul>' +
                '<div class="sec-title">Hashtag Ladder Strategy</div>' +
                '<ul class="suggest-list">' + ladder.map(l => '<li class="good">' + esc(l) + '</li>').join('') + '</ul>' +
            '</div>';
        }

        // ---- zone renderer ----
        const PRO_BULLETS = {
            mg: ['Pixel-width audit \u2014 see which titles Google will actually truncate', '8 extra long-tail title angles with lower competition', 'Paste-ready &lt;head&gt; code block + JSON-LD structured data', 'Keyword placement checklist for H1, alt text &amp; slugs'],
            ac: ['Full keyword targeting plan with match types', '10 negative keywords that stop wasted spend', 'Ready-to-paste sitelinks, callouts &amp; structured snippets', 'One-click full campaign blueprint export'],
            ca: ['Your 5 longest sentences pinpointed for rewriting', 'Passive voice detection with examples', 'Transition &amp; paragraph flow analysis', 'Related-terms map + branded PDF report download'],
            cg: ['7-day content calendar built around your topic', 'Best posting times for your platform', '5 fill-in hook formulas that stop the scroll', 'Extended 20-tag hashtag ladder strategy'],
            wd: ['Your 90-day fix roadmap, week by week', 'Core Web Vitals targets Google actually scores you on', 'Competitor gap checklist to run this week', 'Which fixes to do first for fastest ranking gains'],
            sk: ['Brand positioning statement template (fill in the blanks)', 'Trademark &amp; domain protection checklist for your country', 'The 10 brand assets every business needs at launch', 'Social handle claiming strategy'],
            ba: ['Full 4-campaign structure blueprint', '13 negative keywords that stop wasted spend on day one', 'Your weekly optimization routine (Mon/Wed/Fri)', 'When to shift budget between Google and Meta'],
            ce: ['What must be in your contract before you sign', '5 red flags when comparing agency quotes', 'The 5 questions that expose a weak agency', 'Payment schedule &amp; file ownership guidance'],
            roi: ['The 3 levers that change your numbers most', 'Your break-even cost-per-lead formula', 'Where marketing budgets leak most often', 'Why landing pages beat bigger ad budgets'],
            kw: ['Your next 8 weeks of content, planned', 'The on-page formula for every article', 'Link building that works for small business', 'Which keyword to target first and why'],
            cw: ['5 hook formulas that stop the scroll', 'Repurposing map — turn 1 piece into 8', 'A publishing cadence you can actually sustain', 'Batch-creation workflow'],
            ls: ['Complete Google Business Profile optimization list', 'Citation sources that matter in your city', 'The review request script that gets responses', 'Map pack ranking factors explained']
        };
        // ===== PRO REPORTS FOR TOOLS 5–12 =====
        function proWrap(title, inner) {
            return '<div class="pro-content"><div class="pro-head">★ PRO DEEP REPORT — ' + title + '</div>' + inner + '</div>';
        }
        function proSection(t, body) { return '<div class="pro-sec"><h4>' + t + '</h4>' + body + '</div>'; }
        function proList(items) { return '<ul class="suggest-list">' + items.map(function(i){ return '<li class="fix">' + i + '</li>'; }).join('') + '</ul>'; }

        function wdProHTML() {
            var d = (typeof wdState !== 'undefined' && wdState) || {};
            var dom = d.domain || 'your site';
            return proWrap('Website Diagnostic', 
                proSection('90-Day Fix Roadmap', proList([
                    '<strong>Weeks 1–2:</strong> Security &amp; speed — force HTTPS, compress all images to WebP, enable caching. Target: LCP under 2.5s on mobile.',
                    '<strong>Weeks 3–5:</strong> SEO foundations — unique titles &amp; meta descriptions on every page, XML sitemap, Organization + LocalBusiness schema.',
                    '<strong>Weeks 6–9:</strong> Conversion — add trust signals above the fold, one clear CTA per page, click-to-call and WhatsApp buttons.',
                    '<strong>Weeks 10–12:</strong> AEO — convert key H2s to questions, add FAQ schema, publish 2 answer-first articles.'
                ])) +
                proSection('Core Web Vitals Targets', 
                    '<div class="pro-grid">' +
                    '<div class="pro-metric"><span class="v">&lt; 2.5s</span><span class="k">LCP (loading)</span></div>' +
                    '<div class="pro-metric"><span class="v">&lt; 200ms</span><span class="k">INP (interactivity)</span></div>' +
                    '<div class="pro-metric"><span class="v">&lt; 0.1</span><span class="k">CLS (stability)</span></div>' +
                    '</div><p class="pro-note">Google uses these as ranking signals. Test live at PageSpeed Insights for ' + esc(dom) + '.</p>') +
                proSection('Competitor Gap Checklist', proList([
                    'Search your main keyword — note the top 3 results',
                    'Compare their page speed to yours (PageSpeed Insights)',
                    'Count their reviews vs yours',
                    'Check if they answer questions your site doesn\u2019t',
                    'Note their main CTA — is yours clearer?'
                ]))
            );
        }
        function skProHTML() {
            return proWrap('Brand Launch Kit',
                proSection('Brand Positioning Statement Template',
                    '<div class="pro-code">For [target customer]<br>who [key need],<br>[your brand] is the [category]<br>that [key benefit].<br>Unlike [alternative],<br>we [key differentiator].</div>') +
                proSection('Trademark &amp; Domain Checklist', proList([
                    'Search your national company register (Companies House / ASIC / NZ Companies Office / Secretary of State)',
                    'Check trademark databases for your goods class',
                    'Secure the .com plus your local TLD (.co.uk, .com.au, .ca, .co.nz)',
                    'Claim matching handles on all social platforms — even unused ones',
                    'Buy 1–2 common misspellings and redirect them'
                ])) +
                proSection('First 10 Brand Assets You Need', proList([
                    'Primary logo + horizontal + icon-only versions',
                    'Colour palette with HEX, RGB &amp; CMYK values',
                    'Two fonts: heading + body, with web fallbacks',
                    'Business card &amp; email signature',
                    'Social profile + cover images (correct sizes per platform)',
                    'Invoice / quote template',
                    'One-page brand guideline PDF'
                ]))
            );
        }
        function baProHTML() {
            return proWrap('Budget Architect',
                proSection('Campaign Structure Blueprint', proList([
                    '<strong>Campaign 1 — Brand:</strong> your business name. Cheap clicks, protects against competitors bidding on you.',
                    '<strong>Campaign 2 — High intent:</strong> "emergency", "near me", "book" terms. Highest budget share.',
                    '<strong>Campaign 3 — Service terms:</strong> your core offerings, exact + phrase match.',
                    '<strong>Campaign 4 — Retargeting (Meta):</strong> site visitors from last 30 days. Cheapest conversions you\u2019ll get.'
                ])) +
                proSection('Negative Keywords to Add Day One',
                    '<div class="pro-code">free · cheap · jobs · salary · DIY · how to · course · training · wholesale · second hand · complaints · reviews of · near me jobs</div>' +
                    '<p class="pro-note">These stop the most common wasted spend for service businesses.</p>') +
                proSection('Weekly Optimization Routine', proList([
                    '<strong>Mon:</strong> check search terms report, add negatives',
                    '<strong>Wed:</strong> pause ads below 2% CTR, duplicate winners',
                    '<strong>Fri:</strong> review cost-per-lead vs target; shift budget to best performer',
                    '<strong>Monthly:</strong> refresh ad copy — creative fatigue is real'
                ]))
            );
        }
        function ceProHTML() {
            return proWrap('Project Planning',
                proSection('What Should Be In Your Contract', proList([
                    'Exact deliverables list with page/feature counts',
                    'Number of revision rounds included (2 is standard)',
                    'Payment schedule — typically 50% deposit, 50% on launch',
                    'Who owns the files &amp; domain after launch (should be you)',
                    'Post-launch support window (30 days minimum)',
                    'What happens if scope changes mid-project'
                ])) +
                proSection('Red Flags When Comparing Quotes', proList([
                    'No written scope — only a verbal price',
                    'Refusal to hand over source files or hosting access',
                    'Unlimited revisions promised (nobody delivers this profitably)',
                    'No mention of SEO setup, analytics or mobile testing',
                    'Price far below market — usually a template with your logo'
                ])) +
                proSection('Questions to Ask Any Agency',
                    proList([
                        'Can I see three live sites you built in my industry?',
                        'Who writes the content — me or you?',
                        'What happens if I want to leave in a year?',
                        'Is hosting included, and where is it?',
                        'How do you measure whether this worked?'
                    ]))
            );
        }
        function roiProHTML() {
            return proWrap('ROI &amp; Growth Model',
                proSection('The Three Levers That Change Everything',
                    '<div class="pro-grid">' +
                    '<div class="pro-metric"><span class="v">+1%</span><span class="k">conversion rate ≈ +30% leads</span></div>' +
                    '<div class="pro-metric"><span class="v">+10%</span><span class="k">close rate ≈ +10% revenue</span></div>' +
                    '<div class="pro-metric"><span class="v">+1</span><span class="k">repeat purchase ≈ ×2 LTV</span></div>' +
                    '</div><p class="pro-note">Improving your landing page is almost always cheaper than increasing ad spend.</p>') +
                proSection('Your Break-Even Formula',
                    '<div class="pro-code">Max cost per lead = Average sale × Close rate × Repeat purchases × Target margin<br><br>Spend below this = profit. Above = loss.<br>Track it weekly, not monthly.</div>') +
                proSection('Where Most Budgets Leak', proList([
                    'No conversion tracking — you can\u2019t optimize what you can\u2019t measure',
                    'Sending ad traffic to your homepage instead of a matched landing page',
                    'No retargeting — 97% of first visitors leave without converting',
                    'Slow lead response — contacting within 5 minutes multiplies close rates',
                    'No follow-up sequence for leads that don\u2019t buy immediately'
                ]))
            );
        }
        function kwProHTML() {
            var seed = (document.getElementById('kw-seed') || {}).value || 'your service';
            return proWrap('Keyword Strategy',
                proSection('Your Content Calendar — Next 8 Weeks', proList([
                    '<strong>Week 1–2:</strong> Cost/pricing guide for ' + esc(seed) + ' (highest commercial intent)',
                    '<strong>Week 3–4:</strong> "How to choose" comparison piece — captures research-stage buyers',
                    '<strong>Week 5–6:</strong> Local landing page: "' + esc(seed) + ' in [your city]"',
                    '<strong>Week 7–8:</strong> FAQ / answer hub — targets AI search &amp; featured snippets'
                ])) +
                proSection('On-Page Formula For Each Article',
                    '<div class="pro-code">Title: [Keyword] + [Year or Benefit] (under 60 chars)<br>H1: matches title, keyword in first 5 words<br>First sentence: answer the question directly<br>H2s: written as questions people actually ask<br>Body: 1,200+ words, one idea per paragraph<br>Schema: Article + FAQPage<br>Internal links: 2 to service pages, 1 to contact</div>') +
                proSection('Link Building That Works For Small Business', proList([
                    'Local chamber of commerce &amp; business directories',
                    'Supplier and partner websites — ask for a listing',
                    'Local news: offer expert comment on a relevant story',
                    'Sponsor a local team or event (usually earns a link)',
                    'Industry associations you already pay membership to'
                ]))
            );
        }
        function cwProHTML() {
            return proWrap('Content System',
                proSection('The 5 Hook Formulas That Stop Scrolling',
                    '<div class="pro-code">1. "Most [audience] don\u2019t know [surprising fact]"<br>2. "Stop doing [common mistake]. Do this instead."<br>3. "[Number] things I wish I knew before [action]"<br>4. "Here\u2019s what [amount] of [service] actually gets you"<br>5. "We almost didn\u2019t share this, but…"</div>') +
                proSection('Repurposing Map — 1 Piece Becomes 8', proList([
                    'Blog post → 3 social captions (one per key point)',
                    'Blog post → 1 email newsletter',
                    'Key stat → 1 quote graphic',
                    'How-to section → 1 reel/short script',
                    'FAQ answers → 1 Google Business post',
                    'Full piece → 1 LinkedIn article',
                    'Comments received → next piece\u2019s topic'
                ])) +
                proSection('Publishing Cadence That\u2019s Actually Sustainable',
                    '<div class="pro-grid">' +
                    '<div class="pro-metric"><span class="v">2/week</span><span class="k">social posts (minimum)</span></div>' +
                    '<div class="pro-metric"><span class="v">2/month</span><span class="k">blog articles</span></div>' +
                    '<div class="pro-metric"><span class="v">1/month</span><span class="k">email to your list</span></div>' +
                    '</div><p class="pro-note">Consistency beats volume. Batch-create once a month.</p>')
            );
        }
        function lsProHTML() {
            var city = (document.getElementById('ls-city') || {}).value || 'your city';
            return proWrap('Local SEO Playbook',
                proSection('Google Business Profile — Full Optimization', proList([
                    'Choose the most specific primary category, then add secondaries',
                    'Add every service with descriptions (most businesses skip this)',
                    'Upload 10+ real photos — exterior, interior, team, work samples',
                    'Fill the Q&amp;A section yourself with real customer questions',
                    'Post weekly: offers, updates, events — it directly affects map ranking',
                    'Enable messaging and respond within hours'
                ])) +
                proSection('Citation Sources That Matter in ' + esc(city),
                    '<div class="pro-code">Google Business Profile · Bing Places · Apple Maps<br>Facebook · Yelp · Yellow Pages<br>Chamber of commerce · Industry associations<br>Local council business directory<br><br>Rule: name, address &amp; phone must match EXACTLY everywhere.</div>') +
                proSection('Review Request Script That Works',
                    '<div class="pro-code">"Really glad you\u2019re happy with the work. Reviews genuinely help small businesses like ours get found — would you mind leaving one? It takes 30 seconds: [your short Google link]. Thank you!"</div>' +
                    '<p class="pro-note">Send by text within 2 hours of finishing the job — response rates are highest then.</p>') +
                proSection('Map Pack Ranking Factors', proList([
                    '<strong>Proximity</strong> — you can\u2019t change this, but service-area settings help',
                    '<strong>Relevance</strong> — categories, services, and website content alignment',
                    '<strong>Prominence</strong> — review count, review velocity, citations, backlinks'
                ]))
            );
        }

        window.renderProZone = function(tool) {
            const zone = document.getElementById(tool + '-pro');
            if (!zone) return;
            const NEW_TOOLS = { wd: wdProHTML, sk: skProHTML, ba: baProHTML, ce: ceProHTML, roi: roiProHTML, kw: kwProHTML, cw: cwProHTML, ls: lsProHTML };
            if (NEW_TOOLS[tool]) {
                if (!isPro()) { zone.innerHTML = teaserHTML(tool, PRO_BULLETS[tool] || []); return; }
                zone.innerHTML = NEW_TOOLS[tool]();
                const pcNew = zone.querySelector('.pro-content');
                if (pcNew) pcNew.insertAdjacentHTML('afterbegin', passBarHTML());
                return;
            }
            const state = { mg: (typeof mgState !== 'undefined' && mgState), ac: (typeof acState !== 'undefined' && acState), ca: (typeof caState !== 'undefined' && caState), cg: (typeof cgState !== 'undefined' && cgState) }[tool];
            if (!state) { zone.innerHTML = ''; return; }
            if (!isPro()) { zone.innerHTML = teaserHTML(tool, PRO_BULLETS[tool]); return; }
            if (tool === 'mg') { zone.innerHTML = mgProHTML(state); mgProAfterRender(); }
            if (tool === 'ac') { zone.innerHTML = acProHTML(state); }
            if (tool === 'ca') { zone.innerHTML = caProHTML(state); }
            if (tool === 'cg') { zone.innerHTML = cgProHTML(state); }
            const pc = zone.querySelector('.pro-content');
            if (pc) pc.insertAdjacentHTML('afterbegin', passBarHTML());
        };

        // ---- AdSense activation (only when configured & approved) ----
        (function() {
            if (!AD_CONFIG.adsensePublisherId) return;
            const sc = document.createElement('script');
            sc.async = true;
            sc.src = 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' + AD_CONFIG.adsensePublisherId;
            sc.crossOrigin = 'anonymous';
            document.head.appendChild(sc);
            Object.entries(AD_CONFIG.slots).forEach(([id, slotId]) => {
                const holder = document.getElementById(id);
                if (!holder) return;
                holder.classList.add('on');
                const ins = document.createElement('ins');
                ins.className = 'adsbygoogle';
                ins.style.display = 'block';
                ins.setAttribute('data-ad-client', AD_CONFIG.adsensePublisherId);
                if (slotId) ins.setAttribute('data-ad-slot', slotId);
                ins.setAttribute('data-ad-format', 'auto');
                ins.setAttribute('data-full-width-responsive', 'true');
                holder.appendChild(ins);
                try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch(e) {}
            });
        })();
    </script>

    <script>
    // Animated gold-particle background — matches Graphinxt homepage
    (function() {
        var canvas = document.getElementById('bg-canvas');
        if (!canvas) return;
        var ctx = (canvas.getContext) ? canvas.getContext('2d') : null;
        if (!ctx) return;
        if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
        var particles = [], w, h, animationId;
        function resize(){ w = canvas.width = window.innerWidth; h = canvas.height = window.innerHeight; }
        resize(); window.addEventListener('resize', resize);
        function create(){
            var count = Math.min(Math.floor(w / 18), 70); particles = [];
            for (var i=0;i<count;i++){ particles.push({ x:Math.random()*w, y:Math.random()*h, r:Math.random()*1.8+0.4, vy:-(Math.random()*0.4+0.1), vx:(Math.random()-0.5)*0.2, alpha:Math.random()*0.5+0.1, pulse:Math.random()*Math.PI*2, pulseSpeed:Math.random()*0.02+0.005 }); }
        }
        create();
        function animate(){
            if (!ctx) return;
            ctx.clearRect(0,0,w,h);
            particles.forEach(function(p){
                p.y+=p.vy; p.x+=p.vx; p.pulse+=p.pulseSpeed;
                var a = p.alpha*(0.5+0.5*Math.sin(p.pulse));
                if (p.y<-10){ p.y=h+10; p.x=Math.random()*w; }
                if (p.x<-10) p.x=w+10; if (p.x>w+10) p.x=-10;
                var g = ctx.createRadialGradient(p.x,p.y,0,p.x,p.y,p.r*6);
                g.addColorStop(0,'rgba(233,196,111,'+a+')'); g.addColorStop(1,'rgba(233,196,111,0)');
                ctx.fillStyle=g; ctx.beginPath(); ctx.arc(p.x,p.y,p.r*6,0,Math.PI*2); ctx.fill();
                ctx.fillStyle='rgba(233,196,111,'+(a*1.5)+')'; ctx.beginPath(); ctx.arc(p.x,p.y,p.r,0,Math.PI*2); ctx.fill();
            });
            animationId = requestAnimationFrame(animate);
        }
        function start(){ if(!animationId) animate(); }
        function stop(){ if(animationId){ cancelAnimationFrame(animationId); animationId=null; if(ctx) ctx.clearRect(0,0,w,h);} }
        function checkTheme(){ if(document.body.classList.contains('light-mode')) stop(); else start(); }
        checkTheme();
        var tt = document.getElementById('theme-toggle') || document.getElementById('theme-toggle-btn');
        if (tt) tt.addEventListener('click', function(){ setTimeout(checkTheme, 60); });
    })();
    </script>

    <script>
    /* Graphinxt — content protection layer */
    (function(){
        'use strict';
        // Disable right-click context menu on tool areas
        document.addEventListener('contextmenu', function(e){
            if (e.target.closest && (e.target.closest('.tool-card') || e.target.closest('.results'))) { e.preventDefault(); return false; }
        });
        // Block common devtools/view-source shortcuts (deterrent only)
        document.addEventListener('keydown', function(e){
            var k = (e.key || '').toLowerCase();
            if (e.keyCode === 123) { e.preventDefault(); return false; }                       // F12
            if (e.ctrlKey && e.shiftKey && (k==='i'||k==='j'||k==='c')) { e.preventDefault(); return false; }
            if (e.ctrlKey && (k==='u'||k==='s')) { e.preventDefault(); return false; }         // view-source / save
        });
        // Discourage bulk text selection & dragging of results
        document.addEventListener('selectstart', function(e){
            if (e.target.closest && e.target.closest('.pro-content')) { e.preventDefault(); return false; }
        });
        document.addEventListener('dragstart', function(e){ e.preventDefault(); return false; });
        // Console notice
        try {
            var css = 'color:#e9c46f;font-size:15px;font-weight:bold';
            console.log('%cGraphinxt', css);
            console.log('%cThis toolbox is proprietary software. © Graphinxt Digital Content Creator FZ LLC. Unauthorised copying, redistribution or reverse engineering is prohibited. Interested in licensing or a custom build? reach@graphinxt.com', 'color:#a1a1a5;font-size:12px');
        } catch(e){}
        // Domain lock: tools run only on approved hosts (blocks lazy site-cloners)
        (function(){
            var host = location.hostname.replace(/^www\./,'').toLowerCase();
            var allowed = ['graphinxt.com','localhost','127.0.0.1',''];
            var ok = allowed.indexOf(host) !== -1 || host.endsWith('.graphinxt.com') || location.protocol === 'file:';
            if (!ok) {
                document.addEventListener('DOMContentLoaded', function(){
                    document.querySelectorAll('.tool-card').forEach(function(c){
                        c.innerHTML = '<div style="text-align:center;padding:3rem 1rem;">'
                            + '<div style="font-size:2rem;margin-bottom:1rem;">\u26A0\uFE0F</div>'
                            + '<h3 style="margin-bottom:0.6rem;">This tool is licensed to Graphinxt</h3>'
                            + '<p style="color:#a1a1a5;font-size:0.9rem;">Use the official version at <a href="https://graphinxt.com/tools" style="color:#e9c46f;">graphinxt.com/tools</a></p></div>';
                    });
                });
            }
        })();
    })();
    </script>

    
 <?php include '../footer.php';?>
 <script src="../assets/js/script.js"></script>
</body>
</html>
