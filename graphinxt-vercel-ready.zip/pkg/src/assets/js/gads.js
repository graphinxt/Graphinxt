(function(){
var AWID='AW-18376191957';
var W=AWID+'/qJ1eCKvYluAcENXfubpE';
var F=AWID+'/Q9lSCK7YluAcENXfubpE';
var done={};
function fire(id,val){
if(done[id])return;
done[id]=true;
if(typeof gtag!=='function')return;
gtag('event','conversion',{send_to:id,value:val,currency:'AED'});
}
if(typeof gtag==='function'){gtag('config',AWID);}
document.addEventListener('click',function(e){
var t=e.target;
if(!t||!t.closest)return;
var a=t.closest('a[href*="wa.me"],a[href*="whatsapp"]');
if(a)fire(W,100);
},true);
document.addEventListener('submit',function(e){
var f=e.target;
if(f&&f.id==='contact-form')fire(F,200);
},true);
})();
