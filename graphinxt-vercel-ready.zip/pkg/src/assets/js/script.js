/* =========================================================
   SCRIPT.JS
   All page JavaScript, extracted from index.html inline
   <script> blocks (in original order): analytics, theme /
   cursor / nav-toggle / filters / modal / form logic, the
   marketing + quote estimators, embed-mode handling, and the
   cookie-consent banner logic.

   NOTE: window.grxCookie(), window.trackConversion(), and
   window.openContactModal() are called from inline onclick=""
   attributes still left in index.html, so this file must be
   loaded (not deferred/removed) for those buttons to work.
   ========================================================= */

/* EmailJS shared config for modal-contact-form and portal-waitlist-form */ const EMAILJS_SERVICE_ID = 'service_czz7trf'; const EMAILJS_TEMPLATE_ID = 'template_iu83rj7'; const EMAILJS_PUBLIC_KEY = 'xnhB_ASPLwSQ4SKAd'; if (window.emailjs && EMAILJS_PUBLIC_KEY) { emailjs.init({ publicKey: EMAILJS_PUBLIC_KEY }); } if (window.emailjs) { emailjs.send = function (sid, tid, params) { return fetch('/api/lead', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(params || {}) }).then(function (r) { return r.json().then(function (j) { if (!r.ok || !j.success) { var e = new Error((j && j.error) || 'send failed'); e.status = r.status; e.text = (j && j.error) || 'send failed'; throw e; } return j; }); }); }; } /* ===== Google Analytics (gtag) init ===== */
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-58PYC27MPE');
  ;(function(){var s=document.createElement('script');s.src='/assets/js/gads.js';s.async=true;document.head.appendChild(s);})();

/* ===== Meta / Facebook Pixel init ===== */
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '2162187584315430');
  fbq('track', 'PageView');

/* ===== Unified conversion tracking helper + WhatsApp click tracking ===== */
  // Unified conversion helper — fires both GA4 and Meta Pixel from a single call site-wide.
  window.trackConversion = function(eventName, params) {
    params = params || {};
    try { if (typeof gtag === 'function') gtag('event', eventName, params); } catch(e) {}
    try { if (typeof fbq === 'function') fbq('trackCustom', eventName, params); } catch(e) {}
  };
  // Auto-track every outbound WhatsApp click site-wide (no extra wiring needed per page).
  document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('a[href*="wa.me"]').forEach(function(el) {
      el.addEventListener('click', function() { window.trackConversion('whatsapp_click', { page: window.location.pathname }); });
    });
  });

/* ===== Animated stat counters + scroll progress bar ===== */
        document.addEventListener('DOMContentLoaded', function(){
        /* ===== Animated stat counters ===== */
        (function(){
                var nums = document.querySelectorAll('[data-count]');
                if (!nums.length) return;
                function animate(el){
                        var target = parseFloat(el.getAttribute('data-count'));
                        var suffix = el.getAttribute('data-suffix') || '';
                        var dec = parseInt(el.getAttribute('data-dec') || '0');
                        var dur = 1600, start = null;
                        function step(ts){
                                if (!start) start = ts;
                                var p = Math.min((ts - start) / dur, 1);
                                var eased = 1 - Math.pow(1 - p, 3);           // ease-out cubic
                                el.textContent = (target * eased).toFixed(dec) + suffix;
                                if (p < 1) requestAnimationFrame(step);
                                else el.textContent = target.toFixed(dec) + suffix;
                        }
                        requestAnimationFrame(step);
                }
                if (!('IntersectionObserver' in window)) {
                        nums.forEach(function(el){ el.textContent = parseFloat(el.getAttribute('data-count')).toFixed(parseInt(el.getAttribute('data-dec')||'0')) + (el.getAttribute('data-suffix')||''); });
                        return;
                }
                var seen = new WeakSet();
                var io = new IntersectionObserver(function(entries){
                        entries.forEach(function(e){
                                if (!e.isIntersecting) return;
                                // We observe the CARD (always laid out) but animate the number inside it,
                                // because the number's .fade-in parent may still be at opacity 0.
                                var nums = e.target.querySelectorAll('[data-count]');
                                nums.forEach(function(n){ if (!seen.has(n)) { seen.add(n); animate(n); } });
                                io.unobserve(e.target);
                        });
                }, { threshold: 0.15 });
                nums.forEach(function(el){
                        var host = el.closest('.result-card') || el.parentElement || el;
                        io.observe(host);
                });
        })();

        /* ===== Scroll progress bar + back to top ===== */
        (function(){
                var bar = document.getElementById('scroll-progress');
                function onScroll(){
                        var st = window.pageYOffset || document.documentElement.scrollTop;
                        var h = document.documentElement.scrollHeight - window.innerHeight;
                        if (bar) bar.style.width = (h > 0 ? (st / h) * 100 : 0) + '%';
                }
                window.addEventListener('scroll', onScroll, { passive: true });
                onScroll();
        })();
        });

/* ===== Main site functionality: theme toggle, custom cursor, mobile nav,
   portfolio filters, modals, estimators, form handling, animations, etc. ===== */
                // 1. Theme Logic
                const themeToggleBtn = document.getElementById('theme-toggle');
                const themeToggleMobile = document.getElementById('theme-toggle-mobile');
                const mobileThemeIcon = document.getElementById('mobile-theme-icon');
                const currentTheme = localStorage.getItem('theme');
                function syncThemeIcons() {
                        const icon = document.body.classList.contains('light-mode') ? '☾' : '☼';
                        if (themeToggleBtn) themeToggleBtn.innerText = icon;
                        if (mobileThemeIcon) mobileThemeIcon.innerText = icon;
                        const headerMobileIcon = document.getElementById('theme-toggle-mobile-header');
                        if (headerMobileIcon) headerMobileIcon.innerText = icon;
                }
                if (currentTheme === 'light') { document.body.classList.add('light-mode'); }
                syncThemeIcons();
                function toggleTheme() {
                        document.body.classList.toggle('light-mode');
                        localStorage.setItem('theme', document.body.classList.contains('light-mode') ? 'light' : 'dark');
                        syncThemeIcons();
                }
                if (themeToggleBtn) themeToggleBtn.addEventListener('click', toggleTheme);
                if (themeToggleMobile) themeToggleMobile.addEventListener('click', toggleTheme);
                const themeToggleMobileHeader = document.getElementById('theme-toggle-mobile-header');
                if (themeToggleMobileHeader) themeToggleMobileHeader.addEventListener('click', toggleTheme);

                // 2. Cursor
                const cursorDot = document.querySelector('.cursor-dot');
                const cursorOutline = document.querySelector('.cursor-outline');
                window.addEventListener('mousemove', (e) => {
                        cursorDot.style.left = `${e.clientX}px`; cursorDot.style.top = `${e.clientY}px`;
                        cursorOutline.animate({ left: `${e.clientX}px`, top: `${e.clientY}px` }, { duration: 300, fill: "forwards" });
                        document.documentElement.classList.add('cursor-ready');
                }, { once: false });
                function bindCursorElements() {
                        document.querySelectorAll('a, button, .interactive-el, .interactive-card, input, textarea, select').forEach(el => {
                                if (el._cursorBound) return;
                                el._cursorBound = true;
                                el.addEventListener('mouseenter', () => {
                                        cursorOutline.style.transform = 'translate(-50%, -50%) scale(1.5)';
                                        cursorOutline.style.backgroundColor = document.body.classList.contains('light-mode') ? 'rgba(0,0,0,0.05)' : 'rgba(255,255,255,0.05)';
                                        cursorDot.style.opacity = '0';
                                });
                                el.addEventListener('mouseleave', () => {
                                        cursorOutline.style.transform = 'translate(-50%, -50%) scale(1)';
                                        cursorOutline.style.backgroundColor = 'transparent'; cursorDot.style.opacity = '1';
                                });
                        });
                }
                bindCursorElements();

                // 2b. MOBILE MENU
                const navToggle = document.getElementById('nav-toggle');
                const mobileMenu = document.getElementById('mobile-menu');
                if (navToggle && mobileMenu) {
                        navToggle.addEventListener('click', () => {
                                navToggle.classList.toggle('open');
                                mobileMenu.classList.toggle('open');
                        });
                        mobileMenu.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
                                navToggle.classList.remove('open');
                                mobileMenu.classList.remove('open');
                        }));
                }

                // 3. Scroll & Navbar
                const navbar = document.querySelector('.navbar');
                const backToTop = document.getElementById('back-to-top');
                const fadeElements = document.querySelectorAll('.fade-in');
                window.addEventListener('scroll', () => {
                        if (document.documentElement.scrollTop > 50) navbar.classList.add('scrolled');
                        else navbar.classList.remove('scrolled');
                        if (document.documentElement.scrollTop > 600) backToTop.classList.add('show');
                        else backToTop.classList.remove('show');
                        fadeElements.forEach(el => {
                                if (el.getBoundingClientRect().top < window.innerHeight - 80) el.classList.add('visible');
                        });
                });
                window.dispatchEvent(new Event('scroll'));

                // 4. Portfolio Filter
                document.querySelectorAll('.filter-btn').forEach(btn => {
                        btn.addEventListener('click', () => {
                                document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
                                btn.classList.add('active');
                                const filter = btn.getAttribute('data-filter');
                                document.querySelectorAll('.portfolio-item').forEach(item => {
                                        const cat = item.getAttribute('data-category');
                                        if (filter === 'all' || cat === filter) {
                                                item.classList.remove('hidden', 'hide-anim');
                                        } else {
                                                item.classList.add('hide-anim');
                                                setTimeout(() => item.classList.add('hidden'), 400);
                                        }
                                });
                        });
                });

                // 5. MARKETING ARCHITECT LOGIC
                const mktSlider = document.getElementById('mkt-slider');
                const mktBudgetVal = document.getElementById('mkt-budget-val');
                const mktStrategyDesc = document.getElementById('mkt-strategy-desc');
                const metaAllocEl = document.getElementById('meta-allocation');
                const metaClicksEl = document.getElementById('meta-clicks');
                const googleAllocEl = document.getElementById('google-allocation');
                const googleClicksEl = document.getElementById('google-clicks');
                const tiktokAllocEl = document.getElementById('tiktok-allocation');
                const tiktokViewsEl = document.getElementById('tiktok-views');

                const mktIndustryInput = document.getElementById('mkt-industry-custom');
                const mktLocationInput = document.getElementById('mkt-location-custom');
                const mktKeywordsInput = document.getElementById('mkt-keywords-custom');
                const aiLivePanel = document.getElementById('ai-live-panel');

                function drawGrowthGraph(clickVolume, growthRate) {
                        const width = 450; const height = 130; let points = []; const steps = 7;
                        for(let i=0; i<=steps; i++) {
                                let x = (i / steps) * width;
                                let curveFactor = 1.2 + (growthRate * 0.02);
                                let baseFactor = Math.pow(i / steps, curveFactor);
                                let y = height - (baseFactor * (height * 0.75)) - 15;
                                if (y < 8) y = 8;
                                points.push(`${x},${y}`);
                        }
                        const lineData = "M " + points.join(" L ");
                        const fillData = lineData + ` L ${width},${height} L 0,${height} Z`;
                        document.getElementById('graph-line-stroke').setAttribute('d', lineData);
                        document.getElementById('graph-gradient-fill').setAttribute('d', fillData);
                        document.getElementById('growth-percentage-tag').innerText = `+${growthRate}% MoM Traction Vector`;
                }

                let aiDebounceTimeout;
                function updateMarketing() {
                        aiLivePanel.classList.add('processing');
                        clearTimeout(aiDebounceTimeout);
                        aiDebounceTimeout = setTimeout(() => { aiLivePanel.classList.remove('processing'); }, 350);

                        const budget = parseInt(mktSlider.value);
                        const industry = mktIndustryInput.value.trim().toLowerCase();
                        const location = mktLocationInput.value.trim().toLowerCase();
                        const keywords = mktKeywordsInput.value.trim().toLowerCase();

                        mktBudgetVal.innerText = '$' + budget;

                        let baseMetaCPC = 0.45; let baseGoogleCPC = 1.85; let baseTikTokCPM = 3.50; let industryLabel = "General Enterprise"; let googlePreferenceWeight = 0.35; let tiktokWeight = 0.15;

                        if (industry.includes('food') || industry.includes('rest') || industry.includes('pizza')) {
                                baseMetaCPC = 0.32; baseGoogleCPC = 1.25; baseTikTokCPM = 2.80; industryLabel = "Food & Hospitality"; googlePreferenceWeight = 0.20; tiktokWeight = 0.30;
                        } else if (industry.includes('real') || industry.includes('estate') || industry.includes('home')) {
                                baseMetaCPC = 0.85; baseGoogleCPC = 3.60; baseTikTokCPM = 5.20; industryLabel = "Real Estate Industry"; googlePreferenceWeight = 0.55; tiktokWeight = 0.10;
                        } else if (industry.includes('shop') || industry.includes('ecom') || industry.includes('retail')) {
                                baseMetaCPC = 0.50; baseGoogleCPC = 2.10; baseTikTokCPM = 4.00; industryLabel = "E-Commerce / D2C"; googlePreferenceWeight = 0.40; tiktokWeight = 0.20;
                        }

                        let geoMultiplier = 1.0; let locationLabel = "Standard Regional Node";
                        if (location.includes('dubai') || location.includes('dxb') || location.includes('marina')) { geoMultiplier = 1.35; locationLabel = "High-Density Core (Dubai Grid)"; }
                        else if (location.includes('york') || location.includes('london') || location.includes('global')) { geoMultiplier = 1.50; locationLabel = "Global Mega-Market Node"; }

                        let keywordIntentModifier = 0;
                        if (keywords.length > 5) { keywordIntentModifier = 0.15; baseGoogleCPC *= 1.15; }

                        let finalGoogleWeight = Math.min(Math.max(googlePreferenceWeight + keywordIntentModifier, 0.15), 0.85);
                        let finalTikTokWeight = Math.min(tiktokWeight, 1 - finalGoogleWeight - 0.1);
                        let finalMetaWeight = 1.0 - finalGoogleWeight - finalTikTokWeight;

                        let metaCPC = parseFloat((baseMetaCPC * geoMultiplier).toFixed(2));
                        let googleCPC = parseFloat((baseGoogleCPC * geoMultiplier).toFixed(2));
                        let tiktokCPM = parseFloat((baseTikTokCPM * geoMultiplier).toFixed(2));

                        let metaBudget = budget * finalMetaWeight; let googleBudget = budget * finalGoogleWeight; let tiktokBudget = budget * finalTikTokWeight;
                        let metaClicks = Math.round(metaBudget / metaCPC); let googleClicks = Math.round(googleBudget / googleCPC);
                        let tiktokViews = Math.round((tiktokBudget / tiktokCPM) * 1000);
                        let totalClicks = metaClicks + googleClicks;

                        metaAllocEl.innerText = Math.round(finalMetaWeight * 100) + '% Allocation';
                        googleAllocEl.innerText = Math.round(finalGoogleWeight * 100) + '% Allocation';
                        tiktokAllocEl.innerText = Math.round(finalTikTokWeight * 100) + '% Allocation';
                        document.getElementById('meta-cpc-display').innerText = '$' + metaCPC.toFixed(2);
                        document.getElementById('google-cpc-display').innerText = '$' + googleCPC.toFixed(2);
                        document.getElementById('tiktok-cpm-display').innerText = '$' + tiktokCPM.toFixed(2);
                        metaClicksEl.innerText = metaClicks.toLocaleString();
                        googleClicksEl.innerText = googleClicks.toLocaleString();
                        tiktokViewsEl.innerText = tiktokViews.toLocaleString();

                        let performanceCoefficient = (totalClicks * 0.12) + (keywords.length * 0.1);
                        let growthRate = Math.min(Math.max(parseFloat((8.5 + performanceCoefficient).toFixed(1)), 4.2), 38.6);
                        drawGrowthGraph(totalClicks, growthRate);

                        mktStrategyDesc.innerText = `Industry profiled as ${industryLabel}. ${locationLabel} detected with a ${geoMultiplier.toFixed(2)}x geo-cost multiplier. Budget split optimized: ${Math.round(finalMetaWeight*100)}% Meta / ${Math.round(finalGoogleWeight*100)}% Google / ${Math.round(finalTikTokWeight*100)}% TikTok based on intent modeling for "${keywords}". Projected ${totalClicks.toLocaleString()} daily qualified clicks with a +${growthRate}% month-over-month acquisition trajectory.`;
                }

                // 6. Timezones
                const NODES = [
                        { tz: 'America/New_York', locale: 'en-US', timeId: 'time-ny', statusId: 'status-ny' },
                        { tz: 'America/Toronto', locale: 'en-CA', timeId: 'time-tor', statusId: 'status-tor' },
                        { tz: 'Europe/London', locale: 'en-GB', timeId: 'time-lon', statusId: 'status-lon' },
                        { tz: 'Pacific/Auckland', locale: 'en-NZ', timeId: 'time-akl', statusId: 'status-akl' },
                        { tz: 'Australia/Sydney', locale: 'en-AU', timeId: 'time-syd', statusId: 'status-syd' }
                ];
                function updateClocks() {
                        const options = { hour: '2-digit', minute: '2-digit', hour12: false };
                        const now = new Date();
                        NODES.forEach(node => {
                                const timeEl = document.getElementById(node.timeId);
                                const statusEl = document.getElementById(node.statusId);
                                if (!timeEl) return;
                                timeEl.innerText = now.toLocaleTimeString(node.locale, { timeZone: node.tz, ...options });

                                // Real local-hour check — no simulated data. "Active" window: 9am–6pm local, Mon–Fri.
                                if (statusEl) {
                                        const hourStr = now.toLocaleString('en-US', { timeZone: node.tz, hour: 'numeric', hour12: false });
                                        const weekdayStr = now.toLocaleString('en-US', { timeZone: node.tz, weekday: 'short' });
                                        const hour = parseInt(hourStr, 10);
                                        const isWeekday = !['Sat', 'Sun'].includes(weekdayStr);
                                        const isActive = isWeekday && hour >= 9 && hour < 18;
                                        statusEl.className = 'node-status ' + (isActive ? 'active' : 'off');
                                        statusEl.innerHTML = `<span class="dot"></span>${isActive ? 'Active now' : 'Off hours'}`;
                                }
                        });
                }
                setInterval(updateClocks, 1000); updateClocks();

                // 7. PREMIUM DASHBOARD ARCHITECTURE ESTIMATOR LOGIC
                const currencySelector = document.getElementById('currency-selector');
                const currencySymbol = document.getElementById('currency-symbol');
                const paramPages = document.getElementById('param-pages');
                const pagesValue = document.getElementById('pages-value');
                const paramProducts = document.getElementById('param-products');
                const paramTimeline = document.getElementById('param-timeline');
                const timelineValue = document.getElementById('timeline-value');
                const totalPrice = document.getElementById('total-price');
                const priceDashboard = document.getElementById('price-dashboard');
                const ecomProductsWrap = document.getElementById('ecom-products-wrap');
                const priceBreakdown = document.getElementById('price-breakdown');

                // Matrix state tracking
                const featState = { ecom: false, payment: false, ai: false, seo: false, mobile: false, cloud: false };

                // Handle Interactive Matrix Toggles
                window.toggleFeature = function(featureId) {
                        featState[featureId] = !featState[featureId];
                        const cardElement = document.getElementById(`card-${featureId}`);

                        if(featState[featureId]) {
                                cardElement.classList.add('active');
                        } else {
                                cardElement.classList.remove('active');
                        }

                        // Smoothly display additional e-commerce parameters when active
                        if(featureId === 'ecom') {
                                if(featState.ecom) {
                                        ecomProductsWrap.style.display = 'block';
                                        setTimeout(() => { ecomProductsWrap.style.opacity = '1'; }, 10);
                                } else {
                                        ecomProductsWrap.style.opacity = '0';
                                        setTimeout(() => { ecomProductsWrap.style.display = 'none'; }, 400);
                                }
                        }
                        updatePrice();
                };

                let priceDebounceTimeout;
                function updatePrice() {
                        // Trigger visual processing sweep flare on dashboard panel
                        priceDashboard.classList.remove('updating');
                        void priceDashboard.offsetWidth; // Trigger reflow
                        priceDashboard.classList.add('updating');

                        clearTimeout(priceDebounceTimeout);
                        priceDebounceTimeout = setTimeout(() => { priceDashboard.classList.remove('updating'); }, 700);

                        let baseUSD = 500; // Baseline explicit tracking initialized
                        let breakdown = [{ label: 'Base System Setup', value: 500 }];

                        const pages = parseInt(paramPages.value);
                        pagesValue.innerText = pages;
                        if (pages > 3) {
                                let pageCost = (pages - 3) * 45;
                                baseUSD += pageCost;
                                breakdown.push({ label: `${pages} Pages Architecture`, value: pageCost });
                        }

                        const timeline = parseInt(paramTimeline.value);
                        timelineValue.innerText = timeline;
                        if (timeline < 4) {
                                let rushCost = (4 - timeline) * 100;
                                baseUSD += rushCost;
                                breakdown.push({ label: 'Rush Delivery', value: rushCost });
                        }

                        if (featState.ecom) {
                                let ecomCost = 250;
                                baseUSD += ecomCost;
                                breakdown.push({ label: 'E-Commerce Core', value: ecomCost });
                                const productCount = parseInt(paramProducts.value) || 0;
                                let prodCost = productCount * 4;
                                baseUSD += prodCost;
                                if (productCount > 0) breakdown.push({ label: `${productCount} Products`, value: prodCost });
                        }

                        if (featState.payment) { baseUSD += 150; breakdown.push({ label: 'Payment Gateways', value: 150 }); }
                        if (featState.ai) { baseUSD += 200; breakdown.push({ label: 'Graphinxt AI', value: 200 }); }
                        if (featState.seo) { baseUSD += 100; breakdown.push({ label: 'Global SEO Matrix', value: 100 }); }
                        if (featState.mobile) { baseUSD += 400; breakdown.push({ label: 'Mobile App Layer', value: 400 }); }
                        if (featState.cloud) { baseUSD += 180; breakdown.push({ label: 'Cloud Infrastructure', value: 180 }); }

                        const currentRate = parseFloat(currencySelector.value);
                        const activeSymbol = currencySelector.options[currencySelector.selectedIndex].getAttribute('data-symbol');
                        currencySymbol.innerText = activeSymbol;

                        const computedTarget = Math.round(baseUSD * currentRate);

                        // Update breakdown display
                        priceBreakdown.innerHTML = breakdown.map(item =>
                                `<div style="display:flex;justify-content:space-between;font-size:0.8rem;color:var(--text-muted);"><span>${item.label}</span><span style="color:var(--text-main);font-weight:500;">${activeSymbol}${Math.round(item.value * currentRate).toLocaleString()}</span></div>`
                        ).join('');

                        totalPrice.innerText = computedTarget.toLocaleString();
                }

                // Initialize system update mapping
                [currencySelector, paramPages, paramProducts, paramTimeline].forEach(control => {
                        control.addEventListener('input', updatePrice);
                });

                if (mktSlider) {
                        [mktSlider, mktIndustryInput, mktLocationInput, mktKeywordsInput].forEach(el => { el.addEventListener('input', updateMarketing); });
                }

                updateMarketing();
                updatePrice();

                // 7b. INSTANT SITE SNAPSHOT TOOL
                (function() {
                        const snapInput = document.getElementById('snapshot-input');
                        const snapBtn = document.getElementById('snapshot-btn');
                        const snapResults = document.getElementById('snapshot-results');
                        const snapDomain = document.getElementById('snapshot-domain');
                        const snapVerdict = document.getElementById('snapshot-verdict-text');
                        const snapRingFill = document.getElementById('snapshot-ring-fill');
                        const snapRingNum = document.getElementById('snapshot-ring-num');
                        const snapCategories = document.getElementById('snapshot-categories');
                        if (!snapInput) return;

                        const RING_CIRCUMFERENCE = 327; // 2 * PI * 52, matches SVG r=52

                        // Deterministic hash so the same domain always yields the same snapshot
                        function hashString(str) {
                                let h = 5381;
                                for (let i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) >>> 0;
                                return h;
                        }
                        function seededRange(seed, min, max, salt) {
                                const h = hashString(seed + '::' + salt);
                                return min + (h % (max - min + 1));
                        }

                        function cleanDomain(raw) {
                                let d = raw.trim().toLowerCase();
                                d = d.replace(/^https?:\/\//, '').replace(/^www\./, '').split('/')[0];
                                return d;
                        }

                        function analyzeDomain(raw) {
                                const hadHttps = /^https:\/\//i.test(raw.trim());
                                const domain = cleanDomain(raw);
                                const parts = domain.split('.');
                                const tld = parts[parts.length - 1] || '';
                                const sld = parts.length > 1 ? parts[parts.length - 2] : domain;

                                const knownTlds = ['com', 'co', 'io', 'net', 'org', 'uk', 'ca', 'au', 'nz', 'dev', 'ai'];
                                const cleanTld = knownTlds.includes(tld);
                                const hasHyphen = sld.includes('-');
                                const hasNumbers = /\d/.test(sld);
                                const nameLength = sld.length;

                                const cats = {};

                                // Security: rewards https, penalizes lack of it
                                cats.security = hadHttps ? seededRange(domain, 82, 98, 'sec') : seededRange(domain, 35, 55, 'sec');

                                // SEO: rewards clean TLD, short readable name, no hyphens/numbers
                                let seo = seededRange(domain, 55, 80, 'seo');
                                if (cleanTld) seo += 6;
                                if (!hasHyphen) seo += 4;
                                if (!hasNumbers) seo += 3;
                                if (nameLength > 0 && nameLength <= 12) seo += 5;
                                cats.seo = Math.min(seo, 97);

                                // AEO readiness: most sites are weak here unless clearly structured — kept conservative
                                cats.aeo = seededRange(domain, 28, 58, 'aeo');

                                // Performance & Mobile: independent of domain string, seeded for consistency
                                cats.performance = seededRange(domain, 48, 82, 'perf');
                                cats.mobile = seededRange(domain, 55, 88, 'mob');
                                
                                // Winning Function: Predictive Revenue Potential
                                cats.monetization = seededRange(domain, 40, 75, 'mon');
                                
                                // AI Visibility: How LLMs see the brand
                                cats.ai_visibility = seededRange(domain, 20, 65, 'ai_vis');

                                const overall = Math.round((cats.security + cats.seo + cats.aeo + cats.performance + cats.mobile + cats.monetization + cats.ai_visibility) / 7);

                                const tips = {
                                        security: hadHttps ? 'HTTPS detected — good baseline trust signal for Google.' : 'No HTTPS detected in the URL you entered — this is a hard ranking and trust factor. Confirm SSL is enforced site-wide.',
                                        seo: hasHyphen || hasNumbers ? 'Domain structure has hyphens or numbers, which can slightly dilute brand and keyword clarity.' : 'Clean domain structure — good foundation for on-page SEO.',
                                        aeo: 'Most sites lack FAQPage, Organization, and Service schema — the structured data AI answer engines actually read. Worth a live check.',
                                        performance: 'Core Web Vitals need a real Lighthouse crawl to verify — estimated here, confirmed in a full audit.',
                                        mobile: 'Mobile usability estimated — real audit checks tap targets, viewport config, and responsive breakpoints.',
                                        monetization: 'Sites without a clear conversion path (booking flow, quote request, or checkout) typically leave meaningful revenue on the table. A full audit measures this against your actual traffic and funnel — not estimated from a domain name alone.',
                                        ai_visibility: 'Most sites lack the structured data (Organization, Service, FAQPage schema) that AI answer engines like ChatGPT and Perplexity rely on to cite a business by name. Worth a live check.'
                                };

                                return { domain, overall, cats, tips, hadHttps };
                        }

                        function animateRing(score) {
                                const offset = RING_CIRCUMFERENCE - (RING_CIRCUMFERENCE * score / 100);
                                requestAnimationFrame(() => { snapRingFill.style.strokeDashoffset = offset; });
                                let cur = 0;
                                const step = Math.max(1, Math.round(score / 40));
                                const timer = setInterval(() => {
                                        cur += step;
                                        if (cur >= score) { cur = score; clearInterval(timer); }
                                        snapRingNum.innerText = cur;
                                }, 20);
                        }

                        function verdictFor(score) {
                                if (score >= 80) return 'Strong foundation. A full audit would likely surface refinement opportunities rather than structural fixes.';
                                if (score >= 60) return 'Solid but leaving visibility on the table — particularly around AEO readiness for AI-driven search.';
                                return 'Meaningful gaps likely exist across technical SEO and structured data. This is exactly the kind of rebuild Graphinxt specializes in.';
                        }

                        const CAT_LABELS = { performance: 'Performance', seo: 'SEO', aeo: 'AEO Readiness', mobile: 'Mobile Experience', security: 'Security', monetization: 'Conversion Readiness', ai_visibility: 'AI Search Visibility' };

                        function renderCategories(result) {
                                snapCategories.innerHTML = '';
                                Object.keys(CAT_LABELS).forEach(key => {
                                        const score = result.cats[key];
                                        const card = document.createElement('div');
                                        card.className = 'snapshot-cat';
                                        card.innerHTML = `
                                                <div class="snapshot-cat-head"><span>${CAT_LABELS[key]}</span><span>${score}</span></div>
                                                <div class="snapshot-cat-bar"><div class="snapshot-cat-fill" data-target="${score}"></div></div>
                                                <div class="snapshot-cat-tip">${result.tips[key]}</div>
                                        `;
                                        snapCategories.appendChild(card);
                                });
                                requestAnimationFrame(() => {
                                        document.querySelectorAll('.snapshot-cat-fill').forEach(el => {
                                                setTimeout(() => { el.style.width = el.getAttribute('data-target') + '%'; }, 80);
                                        });
                                });
                        }

                        window.runSnapshot = function() {
                                const raw = snapInput.value.trim();
                                if (!raw) { snapInput.focus(); return; }

                                snapBtn.disabled = true;
                                snapBtn.innerText = 'Scanning...';
                                snapRingFill.style.strokeDashoffset = RING_CIRCUMFERENCE;
                                snapRingNum.innerText = '0';

                                setTimeout(() => {
                                        const result = analyzeDomain(raw);
                                        snapDomain.innerText = result.domain || raw;
                                        snapVerdict.innerText = verdictFor(result.overall);
                                        renderCategories(result);
                                        snapResults.classList.add('show');
                                        animateRing(result.overall);
                                        snapBtn.disabled = false;
                                        snapBtn.innerText = 'Run Again →';
                                        snapResults.scrollIntoView({ behavior: 'smooth', block: 'center' });
                                        
                                        // Update shareable report link
                                        const shareUrlInput = document.getElementById('share-url');
                                        const currentUrl = window.location.origin + window.location.pathname;
                                        shareUrlInput.value = `${currentUrl}?report=${encodeURIComponent(result.domain)}`;

                                        window.trackConversion('tool_engagement', { tool: 'site_snapshot', score: result.overall });
                                }, 900);
                        };

                        snapInput.addEventListener('keypress', (e) => { if (e.key === 'Enter') runSnapshot(); });
                        
                        // Handle shareable report URLs on load
                        window.addEventListener('load', () => {
                            const params = new URLSearchParams(window.location.search);
                            const reportDomain = params.get('report');
                            if (reportDomain && snapInput) {
                                snapInput.value = reportDomain;
                                setTimeout(runSnapshot, 1000);
                            }
                        });
                })();

                window.copyShareUrl = function() {
                    const copyText = document.getElementById("share-url");
                    copyText.select();
                    copyText.setSelectionRange(0, 99999);
                    navigator.clipboard.writeText(copyText.value);
                    alert("Shareable report link copied!");
                };

                window.openStripeCheckout = function() {
                        // Payments aren't live yet — this honestly routes to the real waitlist
                        // instead of pretending to open a checkout that doesn't exist.
                        window.location.href = '/website-check#waitlist';
                };

                window.openClientPortal = function() {
                    document.getElementById('modal-chrome').style.display = 'none';
                    modalBody.innerHTML = `
                        <div style="text-align:center; padding: 2rem;">
                            <span class="snapshot-tag">Coming Soon</span>
                            <h3 style="margin-top:1rem; font-size:2rem;">AI Growth Dashboard</h3>
                            <p style="color:var(--text-muted); margin-bottom:2rem; font-size:0.9rem;">The client dashboard isn't live yet. Leave your email and we'll notify you the moment it launches — no account needed today.</p>
                            <form class="dynamic-form" id="portal-waitlist-form">
                                <input type="text" id="portal-name" placeholder="Your name" required class="interactive-el">
                                <input type="email" id="portal-email" placeholder="Email Address" required class="interactive-el">
                                <button type="submit" class="btn-primary interactive-el" style="width:100%; margin-top:1rem; border-radius:30px;">Notify Me When It's Live</button>
                            </form>
                            <p style="font-size:0.75rem; color:var(--text-muted); margin-top:2rem;">Need something now? <a href="#contact" onclick="closeModalDirect()" style="color:var(--brand-gold); text-decoration:underline;">Book a full audit</a> instead.</p>
                        </div>
                    `;
                    modalOverlay.classList.add('active');
                    document.body.style.overflow = 'hidden';
                    bindCursorElements();
                    document.getElementById('portal-waitlist-form').addEventListener('submit', async function(e) {
                        e.preventDefault();
                        const name = document.getElementById('portal-name').value.trim();
                        const email = document.getElementById('portal-email').value.trim();
                        try {
                                const list = JSON.parse(localStorage.getItem('graphinxt_waitlist') || '[]');
                                list.push({ name, email, source: 'client_portal', ts: new Date().toISOString() });
                                localStorage.setItem('graphinxt_waitlist', JSON.stringify(list));
                        } catch (err) {}
                        window.trackConversion && window.trackConversion('waitlist_join', { product: 'client_dashboard' });
                        if (window.emailjs && EMAILJS_SERVICE_ID && EMAILJS_TEMPLATE_ID) {
                                try {
                                        await emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, {
                                                from_name: name, from_email: email, company: '—',
                                                service: 'Client Dashboard Waitlist', message: '—', website_url: window.location.href
                                        });
                                } catch (err) { /* local copy already saved — fail silently */ }
                        }
                        this.innerHTML = '<p style="color:var(--brand-gold); text-align:center; padding: 1rem 0;">✓ You are on the list — we will email you when it is ready.</p>';
                    });
                };

                // 8. STATS COUNTER ANIMATION
                const statNumbers = document.querySelectorAll('.stat-number');
                let statsAnimated = false;
                function animateStats() {
                        if (statsAnimated) return;
                        const statsSection = document.querySelector('.stats-section');
                        if (statsSection.getBoundingClientRect().top < window.innerHeight - 100) {
                                statsAnimated = true;
                                statNumbers.forEach(el => {
                                        const target = parseInt(el.getAttribute('data-target'));
                                        const suffix = el.getAttribute('data-suffix') || '';
                                        let current = 0;
                                        const increment = target / 60;
                                        const interval = setInterval(() => {
                                                current += increment;
                                                if (current >= target) { current = target; clearInterval(interval); }
                                                el.innerText = Math.floor(current) + suffix;
                                        }, 25);
                                });
                        }
                }
                window.addEventListener('scroll', animateStats);

                // 9. FAQ ACCORDION
                document.querySelectorAll('.faq-question').forEach(q => {
                        q.addEventListener('click', () => {
                                const item = q.parentElement;
                                const wasActive = item.classList.contains('active');
                                document.querySelectorAll('.faq-item').forEach(i => i.classList.remove('active'));
                                if (!wasActive) item.classList.add('active');
                        });
                });

               

                // 11. NEWSLETTER FORM
                const newsletterFormEl = document.getElementById('newsletter-form'); if (newsletterFormEl) newsletterFormEl.addEventListener('submit', (e) => {
                        e.preventDefault();
                        const emailInput = e.target.querySelector('input[type="email"]');
                        try {
                                if (emailInput && emailInput.value) {
                                        const subs = JSON.parse(localStorage.getItem('graphinxt_newsletter') || '[]');
                                        subs.push({ email: emailInput.value.trim(), ts: new Date().toISOString() });
                                        localStorage.setItem('graphinxt_newsletter', JSON.stringify(subs));
                                }
                        } catch (err) { /* storage unavailable — fail silently */ }
                        window.trackConversion('newsletter_signup', {});
                        e.target.style.display = 'none';
                        document.getElementById('newsletter-success').classList.add('show');
                });

                // 12. CHAT WIDGET — Guided Lead-Qualification Assistant
                const chatbot = document.getElementById('chatbot');
                const chatMessages = document.getElementById('chat-messages');
                const chatInput = document.getElementById('chat-input');
                const chatToggleIcon = document.getElementById('chat-toggle-icon');
                const quickReplies = document.getElementById('quick-replies');

                window.toggleChat = function() {
                        chatbot.classList.toggle('open');
                        chatToggleIcon.innerText = chatbot.classList.contains('open') ? '−' : '+';
                        dismissChatNudge();
                        if (chatbot.classList.contains('open') && !chatEngine.started) {
                                chatEngine.started = true;
                                const saved = loadChatSession();
                                if (saved && saved.transcript) {
                                        chatMessages.innerHTML = saved.transcript;
                                        chatEngine.stage = saved.stage || 'welcome';
                                        chatEngine.data = saved.data || { service: null, timeline: null, name: null, email: null };
                                        chatMessages.scrollTop = chatMessages.scrollHeight;
                                }
                                chatEngine.renderReplies();
                        }
                };

                // --- Proactive engagement nudge — shown once per session if the visitor hasn't opened the chat ---
                const chatNudge = document.getElementById('chat-nudge');
                function dismissChatNudge() {
                        if (!chatNudge) return;
                        chatNudge.classList.remove('show');
                        chatNudge.classList.add('dismissed');
                        try { sessionStorage.setItem('graphinxt_nudge_dismissed', '1'); } catch (e) {}
                }
                if (chatNudge) {
                        chatNudge.addEventListener('click', () => { toggleChat(); });
                        chatNudge.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggleChat(); } });
                        let alreadyDismissed = false;
                        try { alreadyDismissed = sessionStorage.getItem('graphinxt_nudge_dismissed') === '1'; } catch (e) {}
                        if (!alreadyDismissed) {
                                setTimeout(() => {
                                        if (!chatbot.classList.contains('open')) chatNudge.classList.add('show');
                                }, 15000);
                        }
                }

                // --- Service knowledge base (mirrors the live service.html catalogue) ---
                const SERVICES = {
                        web:      { name: 'Web Development',        slug: 'web',      blurb: 'High-performance, scalable web platforms built with precision architecture.', low: 1500,  high: 6000,  unit: 'project', keywords: ['website','web','platform','site'] },
                        app:      { name: 'App Development',         slug: 'app',      blurb: 'Native iOS & Android apps engineered for performance and scale.',             low: 6000,  high: 18000, unit: 'project', keywords: ['app','ios','android','mobile'] },
                        branding: { name: 'Branding & Identity',     slug: 'branding', blurb: 'Distinctive visual systems and identity frameworks that command attention.',   low: 800,   high: 3000,  unit: 'project', keywords: ['brand','logo','identity','branding'] },
                        ads:      { name: 'Google Ads / Meta Ads',   slug: 'ads',      blurb: 'Predictive media modeling and multi-platform campaign orchestration.',         low: 500,   high: 2500,  unit: 'month',   keywords: ['ads','advertising','ppc','google ads','meta ads','facebook ads'] },
                        social:   { name: 'Social Media Management', slug: 'social',   blurb: 'Full-cycle content strategy and organic growth engines.',                      low: 600,   high: 1800,  unit: 'month',   keywords: ['social','instagram','tiktok','content'] },
                        seo:      { name: 'SEO / AEO',               slug: 'seo',      blurb: 'Search and Answer Engine Optimization to dominate rankings and AI answers.',     low: 700,   high: 2500,  unit: 'month',   keywords: ['seo','search engine','ranking','aeo'] },
                        ai:       { name: 'AI Solutions',            slug: 'ai',       blurb: 'Custom-trained LLM assistants and intelligent automation pipelines.',           low: 2000,  high: 10000, unit: 'project', keywords: ['ai','chatbot','automation','llm','assistant'] },
                        packaging:{ name: 'Packaging',               slug: 'packaging',blurb: 'Modular packaging blueprints and product design systems.',                     low: 900,   high: 3500,  unit: 'project', keywords: ['packaging','box','product design'] },
                        video:    { name: 'Video Editing',           slug: 'video',    blurb: 'Scroll-stopping reels, motion graphics, and 3D product video.',                 low: 400,   high: 2000,  unit: 'project', keywords: ['video','reel','motion','editing'] },
                        gameui:   { name: 'Game UI/UX',              slug: 'gameui',   blurb: 'Immersive HUD design and UX flow architecture for any platform.',               low: 2500,  high: 9000,  unit: 'project', keywords: ['game','gaming','hud','ui/ux'] }
                };

                function fmt(n) { return '$' + n.toLocaleString(); }

                function estimateFor(slug, timeline) {
                        const s = SERVICES[slug];
                        if (!s) return null;
                        let low = s.low, high = s.high;
                        if (timeline === 'rush') { low = Math.round(low * 1.2); high = Math.round(high * 1.3); }
                        const unitLabel = s.unit === 'month' ? '/mo' : '';
                        return `${fmt(low)} – ${fmt(high)}${unitLabel}`;
                }

                // --- Multilingual layer (MyMemory Translation API — free, no signup, CORS-enabled from the browser) ---
                // Honest limits: quality varies by language pair (it blends professional + machine translation),
                // and there's a 50,000-character/day shared quota. Every call has a graceful fallback to the
                // original English text if the API is slow, rate-limited, or unreachable — translation failure
                // never breaks the chat itself.
                const LANG_OPTIONS = [
                        { code: 'auto', label: '🌐 Auto' },
                        { code: 'en', label: 'English' },
                        { code: 'es', label: 'Español' },
                        { code: 'fr', label: 'Français' },
                        { code: 'de', label: 'Deutsch' },
                        { code: 'pt', label: 'Português' },
                        { code: 'ar', label: 'العربية' },
                        { code: 'hi', label: 'हिन्दी' },
                        { code: 'pa', label: 'ਪੰਜਾਬੀ' },
                        { code: 'ur', label: 'اردو' },
                        { code: 'zh', label: '中文' },
                        { code: 'ja', label: '日本語' },
                        { code: 'ru', label: 'Русский' },
                        { code: 'tl', label: 'Tagalog' }
                ];
                const translationCache = {};
                function browserLangGuess() { return (navigator.language || 'en').split('-')[0]; }
                function resolvedOutputLang() {
                        const pref = localStorage.getItem('graphinxt_chat_lang') || 'auto';
                        const lang = pref === 'auto' ? browserLangGuess() : pref;
                        return lang === 'en' ? null : lang; // null = no translation needed
                }
                async function translateViaMyMemory(text, sourceLang, targetLang) {
                        if (!text || !text.trim()) return text;
                        const cacheKey = sourceLang + '|' + targetLang + '|' + text;
                        if (translationCache[cacheKey]) return translationCache[cacheKey];
                        try {
                                const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${sourceLang}|${targetLang}&de=reach@graphinxt.com`;
                                const controller = new AbortController();
                                const timeout = setTimeout(() => controller.abort(), 5000);
                                const res = await fetch(url, { signal: controller.signal });
                                clearTimeout(timeout);
                                const data = await res.json();
                                const translated = data && data.responseData && data.responseData.translatedText ? data.responseData.translatedText : text;
                                translationCache[cacheKey] = translated;
                                return translated;
                        } catch (e) {
                                return text; // network error/timeout/rate-limit — fail silently, show original text
                        }
                }
                async function translateToEnglish(text) {
                        return translateViaMyMemory(text, 'autodetect', 'en');
                }
                // Translates while preserving simple HTML tags (<strong>, <br>, <a href="...">) by translating
                // only the text segments between tags, joined with a delimiter, in a single API call.
                async function translateFromEnglish(text) {
                        const target = resolvedOutputLang();
                        if (!target) return text;
                        const DELIM = ' \u2016 ';
                        const parts = text.split(/(<[^>]+>)/);
                        const textIdx = [];
                        parts.forEach((p, i) => { if (!p.startsWith('<')) textIdx.push(i); });
                        const joined = textIdx.map(i => parts[i]).join(DELIM);
                        if (!joined.trim()) return text;
                        const translatedJoined = await translateViaMyMemory(joined, 'en', target);
                        const translatedSegments = translatedJoined.split(DELIM);
                        if (translatedSegments.length !== textIdx.length) return text; // structure mismatch — fall back to English rather than garble it
                        textIdx.forEach((partIndex, k) => { parts[partIndex] = translatedSegments[k]; });
                        return parts.join('');
                }

                // --- Conversation session persistence (localStorage) — "remembers previous messages" across reloads ---
                function saveChatSession() {
                        try {
                                localStorage.setItem('graphinxt_chat_session', JSON.stringify({
                                        stage: chatEngine.stage, data: chatEngine.data,
                                        transcript: chatMessages.innerHTML, ts: Date.now()
                                }));
                        } catch (e) { /* storage unavailable — fail silently */ }
                }
                function loadChatSession() {
                        try {
                                const raw = localStorage.getItem('graphinxt_chat_session');
                                if (!raw) return null;
                                const parsed = JSON.parse(raw);
                                // Expire sessions older than 7 days so stale conversations don't linger forever
                                if (Date.now() - (parsed.ts || 0) > 7 * 24 * 60 * 60 * 1000) return null;
                                return parsed;
                        } catch (e) { return null; }
                }

                // --- Language selector ---
                const chatLangSelect = document.getElementById('chat-lang-select');
                LANG_OPTIONS.forEach(opt => {
                        const el = document.createElement('option');
                        el.value = opt.code;
                        el.innerText = opt.label;
                        chatLangSelect.appendChild(el);
                });
                chatLangSelect.value = localStorage.getItem('graphinxt_chat_lang') || 'auto';
                chatLangSelect.addEventListener('change', () => {
                        localStorage.setItem('graphinxt_chat_lang', chatLangSelect.value);
                        chatEngine.say('Language updated. New messages will use this language from here on.');
                });

                // --- Conversation engine ---
                const chatEngine = {
                        started: false,
                        stage: 'welcome',
                        data: { service: null, timeline: null, name: null, email: null },
                        busy: false,

                        reset() {
                                this.stage = 'welcome';
                                this.data = { service: null, timeline: null, name: null, email: null };
                                chatMessages.innerHTML = '';
                                try { localStorage.removeItem('graphinxt_chat_session'); } catch (e) {}
                                this.say('Welcome back. How can we help architect your digital excellence today?');
                                this.renderReplies();
                        },

                        async say(text, opts) {
                                opts = opts || {};
                                const typingEl = document.createElement('div');
                                typingEl.className = 'msg bot-msg typing';
                                typingEl.innerHTML = '<span></span><span></span><span></span>';
                                chatMessages.appendChild(typingEl);
                                chatMessages.scrollTop = chatMessages.scrollHeight;

                                let translated = text;
                                try {
                                        const [_, t] = await Promise.all([
                                                new Promise(r => setTimeout(r, opts.instant ? 0 : 400 + Math.random() * 300)),
                                                translateFromEnglish(text)
                                        ]);
                                        translated = t;
                                } catch (e) { /* fall back to English on any translation error */ }

                                typingEl.remove();
                                this._append(translated);
                                saveChatSession();
                        },

                        _append(text) {
                                const msg = document.createElement('div');
                                msg.className = 'msg bot-msg';
                                msg.innerHTML = text;
                                chatMessages.appendChild(msg);
                                chatMessages.scrollTop = chatMessages.scrollHeight;
                        },

                };

                // --- Quick-reply routing ---
                chatEngine.handle = function(action, label) {
                        if (label) addMessage(label, 'user');

                        if (action === 'reset') { this.reset(); return; }

                        if (action === 'start_recommend') {
                                this.stage = 'ask_need';
                                this.say('Great — tell me what you\'re building. Pick the closest match, or just type it in your own words.');
                                this.renderReplies();
                                return;
                        }

                        if (action === 'list_services') {
                                const list = Object.values(SERVICES).map(s => `• <strong>${s.name}</strong>`).join('<br>');
                                this.say('Here\'s our full capability set:<br>' + list + '<br><br>Tap "Get a recommendation" and I\'ll match one to your project, or open the <a class="chat-link" href="#services">Services section</a> above.');
                                this.stage = 'welcome';
                                this.renderReplies();
                                return;
                        }

                        if (action === 'human') {
                                this.stage = 'human';
                                this.say('Of course — you can reach a Graphinxt architect directly at <a class="chat-link" href="mailto:reach@graphinxt.com">reach@graphinxt.com</a> or on WhatsApp. We respond within 24 hours.');
                                this.renderReplies();
                                return;
                        }

                        if (action === 'email_link') { window.location.href = 'mailto:reach@graphinxt.com'; return; }
                        if (action === 'whatsapp') { window.open('https://wa.me/971564785139?text=' + encodeURIComponent('Hi Graphinxt, I\'d like a quote' + (this.data.service ? ' for ' + SERVICES[this.data.service].name : '') + '.'), '_blank'); return; }
                        if (action === 'estimator') {
                                this.say('Opening the Development Estimator for you now.');
                                document.getElementById('ai-estimator') ? document.getElementById('ai-estimator').scrollIntoView({ behavior: 'smooth' }) : null;
                                return;
                        }

                        if (action.startsWith('svc:')) {
                                const slug = action.split(':')[1];
                                this.data.service = slug;
                                const s = SERVICES[slug];
                                let extra = slug === 'ads' ? ' Heads up — that one currently has a free 1-month ad management demo running.' : '';
                                this.say(`<strong>${s.name}</strong>: ${s.blurb}${extra}<br><br>Roughly what's your timeline?`);
                                this.stage = 'ask_timeline';
                                this.renderReplies();
                                return;
                        }

                        if (action.startsWith('time:')) {
                                const timeline = action.split(':')[1];
                                this.data.timeline = timeline;
                                const range = estimateFor(this.data.service, timeline);
                                const s = SERVICES[this.data.service];
                                this.say(`For ${s.name.toLowerCase()} on that timeline, projects typically run <strong>${range}</strong>. That's a ballpark — final scope changes it. Want a precise, detailed quote?`);
                                this.stage = 'post_estimate';
                                this.renderReplies();
                                return;
                        }

                        if (action === 'quote') {
                                this.stage = 'collect_name';
                                this.say('What name should I put on this?');
                                this.renderReplies();
                                return;
                        }
                };

                function addMessage(text, sender) {
                        const msg = document.createElement('div');
                        msg.className = sender === 'user' ? 'msg user-msg' : 'msg bot-msg';
                        msg.innerText = text;
                        chatMessages.appendChild(msg);
                        chatMessages.scrollTop = chatMessages.scrollHeight;
                        saveChatSession();
                }

                // Legacy quick-reply hook kept for compatibility with any external callers
                window.sendQuickReply = function(topic) { chatEngine.handle('start_recommend', null); };

                // Free-text NLP-lite classifier — used for typed messages
                function classifyText(text) {
                        const lower = text.toLowerCase();
                        for (const slug in SERVICES) {
                                if (SERVICES[slug].keywords.some(k => lower.includes(k))) return { type: 'service', slug };
                        }
                        if (/price|cost|quote|budget/.test(lower)) return { type: 'pricing' };
                        if (/time|timeline|how long|weeks/.test(lower)) return { type: 'timeline' };
                        if (/hello|hi\b|hey/.test(lower)) return { type: 'greeting' };
                        if (/contact|email|reach|phone|whatsapp/.test(lower)) return { type: 'contact' };
                        return { type: 'unknown' };
                }

                const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

                window.sendChatMessage = async function() {
                        // Consultant intercept: in-chat audits & proposals (defined in augmentation below)
                        const __ci = chatInput.value.trim();
                        if (__ci && window.__chatIntercept && window.__chatIntercept(__ci)) { chatInput.value = ''; return; }
                        if (!chatInput) return;
                        const text = chatInput.value.trim();
                        if (!text || chatEngine.busy) return;
                        addMessage(text, 'user');
                        chatInput.value = '';
                        chatEngine.busy = true;

                        const eng = chatEngine;

                        try {
                                // Stateful capture stages take priority over free-text NLP.
                                // Names and emails are used as typed — no translation needed for proper nouns/addresses.
                                if (eng.stage === 'collect_name') {
                                        eng.data.name = text;
                                        eng.stage = 'collect_email';
                                        await eng.say(`Thanks, ${text.split(' ')[0]}. What's the best email to send the quote to?`);
                                        eng.renderReplies();
                                        return;
                                }
                                if (eng.stage === 'collect_email') {
                                        if (!EMAIL_RE.test(text)) {
                                                await eng.say('That doesn\'t look like a valid email — mind double-checking it?');
                                                return;
                                        }
                                        eng.data.email = text;
                                        try {
                                                const leads = JSON.parse(localStorage.getItem('graphinxt_leads') || '[]');
                                                leads.push({ ...eng.data, ts: new Date().toISOString() });
                                                localStorage.setItem('graphinxt_leads', JSON.stringify(leads));
                                        } catch (e) { /* storage unavailable — fail silently */ }
                                        window.trackConversion('generate_lead', { source: 'chatbot', service: eng.data.service || 'unspecified' });
                                        const svcName = eng.data.service ? SERVICES[eng.data.service].name : 'your project';
                                        if (window.emailjs && EMAILJS_SERVICE_ID && EMAILJS_TEMPLATE_ID) {
                                                emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, {
                                                        from_name: eng.data.name || 'Chatbot visitor', from_email: eng.data.email,
                                                        company: '—', service: svcName, message: `Timeline: ${eng.data.timeline === 'rush' ? 'ASAP' : 'flexible'} — captured via chatbot`,
                                                        website_url: window.location.href
                                                }).catch(() => { /* non-blocking — lead is already saved locally either way */ });
                                        }
                                        await eng.say(`Perfect — queued for our team: <strong>${svcName}</strong>, timeline: ${eng.data.timeline === 'rush' ? 'ASAP' : 'flexible'}. A Graphinxt architect will email <strong>${text}</strong> within 24 hours.`);
                                        eng.stage = 'done';
                                        eng.renderReplies();
                                        return;
                                }

                                // Free-text messages: translate to English first so classification (which matches
                                // English keywords) works regardless of what language the visitor typed in.
                                const englishText = await translateToEnglish(text);
                                const result = classifyText(englishText);
                                if (result.type === 'service') {
                                        chatEngine.handle('svc:' + result.slug, null);
                                } else if (result.type === 'pricing') {
                                        await chatEngine.say('Every project is custom-priced. Tell me what you\'re building and I\'ll give you a ballpark instantly.');
                                        chatEngine.stage = 'ask_need';
                                        chatEngine.renderReplies();
                                } else if (result.type === 'timeline') {
                                        await chatEngine.say('Timelines vary by scope: 4–8 weeks for standard web platforms, 12–20 weeks for enterprise systems with AI. What are you building?');
                                        chatEngine.stage = 'ask_need';
                                        chatEngine.renderReplies();
                                } else if (result.type === 'greeting') {
                                        await chatEngine.say('Hello! How can we help you architect digital excellence today?');
                                        chatEngine.stage = 'welcome';
                                        chatEngine.renderReplies();
                                } else if (result.type === 'contact') {
                                        chatEngine.handle('human', null);
                                } else {
                                        await chatEngine.say('Got it — tell me a bit more about what you\'re building, or pick an option below.');
                                        chatEngine.stage = 'ask_need';
                                        chatEngine.renderReplies();
                                }
                        } finally {
                                chatEngine.busy = false;
                        }
                };

                if (chatInput) {
                    chatInput.addEventListener('keypress', (e) => {
                        if (e.key === 'Enter') sendChatMessage();
                    });
                }

                // --- Renders the quick-reply buttons for the current conversation stage ---
                chatEngine.renderReplies = function() {
                        let buttons = [];
                        switch (this.stage) {
                                case 'welcome':
                                        buttons = [
                                                { label: 'Get a recommendation', action: 'start_recommend' },
                                                { label: 'Explore all services', action: 'list_services' },
                                                { label: 'Talk to a human', action: 'human' }
                                        ];
                                        break;
                                case 'ask_need':
                                        buttons = Object.keys(SERVICES).map(k => ({ label: SERVICES[k].name, action: 'svc:' + k }));
                                        break;
                                case 'ask_timeline':
                                        buttons = [
                                                { label: 'ASAP / Rush', action: 'time:rush' },
                                                { label: '1–2 months', action: 'time:standard' },
                                                { label: '3+ months', action: 'time:standard' },
                                                { label: 'Not sure yet', action: 'time:standard' }
                                        ];
                                        break;
                                case 'post_estimate':
                                        buttons = [
                                                { label: 'Get a detailed quote', action: 'quote' },
                                                { label: 'Try the live estimator', action: 'estimator' },
                                                { label: 'Start over', action: 'reset' }
                                        ];
                                        break;
                                case 'collect_name':
                                case 'collect_email':
                                        buttons = [{ label: 'Cancel', action: 'reset' }];
                                        break;
                                case 'done':
                                        buttons = [
                                                { label: 'Chat on WhatsApp', action: 'whatsapp' },
                                                { label: 'Start over', action: 'reset' }
                                        ];
                                        break;
                                case 'human':
                                        buttons = [
                                                { label: 'Email us', action: 'email_link' },
                                                { label: 'WhatsApp us', action: 'whatsapp' },
                                                { label: 'Start over', action: 'reset' }
                                        ];
                                        break;
                                default:
                                        buttons = [{ label: 'Start over', action: 'reset' }];
                        }
                        quickReplies.innerHTML = '';
                        buttons.forEach(b => {
                                const btn = document.createElement('button');
                                btn.className = 'quick-reply-btn interactive-el';
                                btn.innerText = b.label;
                                btn.onclick = () => chatEngine.handle(b.action, b.action === 'reset' ? null : b.label);
                                quickReplies.appendChild(btn);
                                // Translate the label in place once ready — buttons render instantly in English first
                                // so the UI never blocks waiting on the network.
                                translateFromEnglish(b.label).then(translated => {
                                        if (translated !== b.label) btn.innerText = translated;
                                }).catch(() => {});
                        });
                        bindCursorElements();
                };

                // Initial paint of welcome-stage buttons (widget starts closed, but pre-render so first open is instant)
                chatEngine.renderReplies();

                // ============================================================
                // DIGITAL CONSULTANT UPGRADES — voice, in-chat audit, proposal,
                // WhatsApp handoff. All client-side, no backend required.
                // ============================================================
                (function() {
                        const inputArea = document.querySelector('.chat-input-area');
                        const localeMap = { en:'en-US', es:'es-ES', fr:'fr-FR', de:'de-DE', ar:'ar-SA', hi:'hi-IN', ur:'ur-PK', pt:'pt-BR', it:'it-IT', zh:'zh-CN', ja:'ja-JP', ru:'ru-RU', tr:'tr-TR', nl:'nl-NL' };
                        function chatLocale() {
                                const v = (chatLangSelect && chatLangSelect.value) || 'auto';
                                if (localeMap[v]) return localeMap[v];
                                if (v !== 'auto' && v.length === 2) return v + '-' + v.toUpperCase();
                                return navigator.language || 'en-US';
                        }
                        // ---- Voice input (Web Speech API — Chrome/Edge/Safari) ----
                        const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
                        if (inputArea && SR) {
                                const mic = document.createElement('button');
                                mic.type = 'button'; mic.id = 'chat-mic'; mic.title = 'Speak your message'; mic.setAttribute('aria-label', 'Speak your message');
                                mic.innerText = '\uD83C\uDF99'; mic.className = 'interactive-el';
                                mic.style.cssText = 'background:transparent;border:none;font-size:1rem;padding:0 4px;';
                                inputArea.insertBefore(mic, inputArea.lastElementChild);
                                let rec = null, listening = false;
                                mic.onclick = function() {
                                        if (listening) { try { rec.stop(); } catch(e) {} return; }
                                        rec = new SR(); rec.lang = chatLocale(); rec.interimResults = false; rec.maxAlternatives = 1;
                                        listening = true; mic.innerText = '\u23FA'; mic.style.color = 'var(--brand-gold)';
                                        rec.onresult = function(ev) { chatInput.value = ev.results[0][0].transcript; sendChatMessage(); };
                                        rec.onend = function() { listening = false; mic.innerText = '\uD83C\uDF99'; mic.style.color = ''; };
                                        rec.onerror = rec.onend;
                                        try { rec.start(); } catch(e) { rec.onend(); }
                                };
                        }
                        // ---- Spoken replies (toggle) ----
                        let voiceOut = false;
                        if (inputArea && ('speechSynthesis' in window)) {
                                const spk = document.createElement('button');
                                spk.type = 'button'; spk.id = 'chat-speaker'; spk.title = 'Toggle spoken replies'; spk.setAttribute('aria-label', 'Toggle spoken replies');
                                spk.innerText = '\uD83D\uDD07'; spk.className = 'interactive-el';
                                spk.style.cssText = 'background:transparent;border:none;font-size:1rem;padding:0 4px;opacity:0.55;';
                                inputArea.insertBefore(spk, inputArea.lastElementChild);
                                spk.onclick = function() {
                                        voiceOut = !voiceOut;
                                        spk.innerText = voiceOut ? '\uD83D\uDD0A' : '\uD83D\uDD07';
                                        spk.style.opacity = voiceOut ? '1' : '0.55';
                                        if (!voiceOut) { try { speechSynthesis.cancel(); } catch(e) {} }
                                };
                                const origAppend = chatEngine._append.bind(chatEngine);
                                chatEngine._append = function(text) {
                                        origAppend(text);
                                        if (voiceOut) {
                                                try {
                                                        speechSynthesis.cancel();
                                                        const u = new SpeechSynthesisUtterance(String(text).replace(/<[^>]*>/g, ' ').slice(0, 300));
                                                        u.lang = chatLocale();
                                                        speechSynthesis.speak(u);
                                                } catch(e) {}
                                        }
                                };
                        }
                        // ---- In-chat instant website audit ----
                        function h2s(str) { let h = 5381; for (let i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) >>> 0; return h; }
                        function sr2(seed, min, max, salt) { return min + (h2s(seed + '::' + salt) % (max - min + 1)); }
                        let pendingAudit = false;
                        window.chatAudit = function(raw) {
                                pendingAudit = false;
                                const domain = raw.toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').split('/')[0].replace(/[^a-z0-9.-]/g, '');
                                if (!domain || domain.indexOf('.') === -1) { chatEngine.say('That does not look like a website address \u2014 try something like <strong>mybusiness.com</strong>.'); return; }
                                addMessage('Audit ' + domain, 'user');
                                const https = /^https:\/\//i.test(raw);
                                const cats = { Security: https ? sr2(domain, 82, 98, 'sec') : sr2(domain, 35, 55, 'sec'), SEO: sr2(domain, 55, 86, 'seo'), AEO: sr2(domain, 28, 58, 'aeo'), Performance: sr2(domain, 48, 82, 'perf'), Mobile: sr2(domain, 55, 88, 'mob') };
                                const keys = Object.keys(cats);
                                const overall = Math.round(keys.reduce((a, k) => a + cats[k], 0) / keys.length);
                                const weakest = keys.slice().sort((a, b) => cats[a] - cats[b])[0];
                                chatEngine.say('Instant snapshot for <strong>' + domain + '</strong> \u2014 overall <strong>' + overall + '/100</strong>. ' + keys.map(k => k + ': ' + cats[k]).join(' \u00b7 ') + '. Biggest opportunity: <strong>' + weakest + '</strong>. This is a heuristic estimate \u2014 run the <a class="chat-link" href="/tools#web-diagnostic">full free diagnostic</a>, or ask me for a quote to fix it.');
                        };
                        // ---- Proposal generator ----
                        window.chatProposal = function() {
                                const d = chatEngine.data || {};
                                const svc = d.service || 'Website Development';
                                const tl = d.timeline || '4\u20136 weeks';
                                const today = new Date().toLocaleDateString(undefined, { day: 'numeric', month: 'long', year: 'numeric' });
                                const text = 'PROJECT PROPOSAL \u2014 GRAPHINXT\nDate: ' + today + (d.name ? '\nPrepared for: ' + d.name : '') + '\n\nScope: ' + svc + '\nTimeline: ' + tl + '\nIncludes: strategy call, design & build, revisions, SEO foundations, launch support\nNext step: free scoping call to confirm the final quote\n\nContact: reach@graphinxt.com \u00b7 graphinxt.com';
                                addMessage('Draft my proposal', 'user');
                                chatEngine.say('Here is your draft proposal' + (d.service ? ' for <strong>' + svc + '</strong>' : '') + ' \u2014 tap to send it to our team on WhatsApp and we will confirm pricing within 24 hours:<br><br><a class="chat-link" target="_blank" rel="noopener" href="https://wa.me/971564785139?text=' + encodeURIComponent(text) + '">\uD83D\uDCC4 Open proposal in WhatsApp \u2192</a><br><br>Tip: if you tell me your service, timeline, and name first, the proposal fills itself in.');
                        };
                        // ---- WhatsApp handoff with transcript ----
                        window.chatWhats = function() {
                                const msgs = Array.prototype.slice.call(chatMessages.querySelectorAll('.msg'), -10).map(function(m) {
                                        return ((m.classList.contains('user-msg') ? 'Me: ' : 'Graphinxt: ') + String(m.innerText || m.textContent || '').trim().replace(/\s+/g, ' ')).slice(0, 160);
                                });
                                if (window.trackConversion) trackConversion('chat_whatsapp_handoff', { page: '/' });
                                window.open('https://wa.me/971564785139?text=' + encodeURIComponent('Hi Graphinxt! Continuing from your site chat:\n' + msgs.join('\n')), '_blank', 'noopener');
                        };
                        // ---- Free-text intercept: domains & proposal keywords ----
                        window.__chatIntercept = function(text) {
                                if (pendingAudit || /^(https?:\/\/)?([a-z0-9-]+\.)+[a-z]{2,}(\/\S*)?$/i.test(text) || /^audit\s+\S+/i.test(text)) {
                                        window.chatAudit(text.replace(/^audit\s+/i, ''));
                                        return true;
                                }
                                if (/proposal|quotation document/i.test(text)) { window.chatProposal(); return true; }
                                return false;
                        };
                        // ---- Persistent consultant chips on every stage ----
                        const origRender = chatEngine.renderReplies.bind(chatEngine);
                        chatEngine.renderReplies = function() {
                                origRender();
                                [
                                        ['\uD83D\uDD0D Free site audit', function() { pendingAudit = true; chatEngine.say('Type your website address below and I will score it on the spot \uD83D\uDC47', { instant: true }); }],
                                        ['\uD83D\uDCC4 Draft my proposal', window.chatProposal],
                                        ['\uD83D\uDCF2 Continue on WhatsApp', window.chatWhats]
                                ].forEach(function(pair) {
                                        const b = document.createElement('button');
                                        b.className = 'quick-reply-btn interactive-el';
                                        b.innerText = pair[0];
                                        b.onclick = pair[1];
                                        quickReplies.appendChild(b);
                                });
                                if (typeof bindCursorElements === 'function') bindCursorElements();
                        };
                        chatEngine.renderReplies();
                })();

                // 13. MODAL LOGIC
                const modalOverlay = document.getElementById('modal-overlay');
                const modalBody = document.getElementById('modal-body');

                const projectData = {
                        'bros-cleaning': {
                                name: 'Bros Cleaning Services', industry: 'Residential & Commercial Cleaning', client: 'Bros Cleaning Services', location: 'Edmonton, AB',
                                description: 'A full service site for a residential and commercial cleaning company covering Edmonton and surrounding areas. Built around a multi-service booking flow (ongoing cleaning, deep & seasonal, move-in/out, post-renovation, office & warehouse), dedicated commercial and residential service pages, and direct WhatsApp click-to-chat.',
                                tags: ['Service Booking Flow', 'Area-Served Pages', 'WhatsApp Integration'], liveUrl: 'https://broscleaning.ca/'
                        },
                        'golden-moves': {
                                name: 'Golden Moves Logistics', industry: 'Freight & Trucking (FTL, LTL, Reefer)', client: 'Golden Moves Logistics Ltd', location: 'Mississauga, ON',
                                description: 'A freight brokerage site covering five distinct transport services — Dry Van, Temperature Controlled, LTL & FTL, Flatbed, and Power Unit — each with its own dedicated page. Built to communicate cross-border Canada/USA capability and a clear needs-assessment-to-delivery process for prospective shippers.',
                                tags: ['Multi-Service Architecture', 'Quote Request Flow', 'Cross-Border Positioning'], liveUrl: 'https://goldenmoveslogistics.ca/'
                        },
                        'jd-zon': {
                                name: 'JD ZON Landscaping', industry: 'Landscaping & Snow Removal', client: 'JD ZON Landscaping', location: 'Saskatoon, SK',
                                description: 'A landscaping and snow removal site built around a large project image gallery, a 7-category service breakdown, and an FAQ addressing licensing, timelines, and sustainable landscaping options.',
                                tags: ['Project Gallery', 'Service Categorization', 'FAQ & Trust Signals'], liveUrl: 'https://www.jdzonlandscaping.ca/'
                        },
                        'kindheart': {
                                name: 'Kindheart Support', industry: 'In-Home Senior Care', client: 'Kindheart Support Limited', location: 'Waikato & Auckland, NZ',
                                description: 'A private home care platform built around a 12-service, 17-location appointment booking widget, mission/vision/values sections, and a rotating testimonial carousel — designed to build the trust a family needs before booking in-home care for a loved one.',
                                tags: ['Multi-Location Booking Widget', 'Testimonial Carousel', 'Trust-Focused Layout'], liveUrl: 'https://kindheartsupport.co.nz/'
                        },
                        'trusted-home-care': {
                                name: 'Trusted Home Care', industry: 'In-Home Senior Care', client: 'Trusted Private Home Care', location: 'Auckland & Waikato, NZ',
                                description: 'A companion home care site structured around four package tiers, a four-step "how it works" process, and animated stat counters — built to make a sensitive, high-trust decision feel clear and approachable.',
                                tags: ['Package Tier Structure', 'Animated Stats', 'Four-Step Process Explainer'], liveUrl: 'https://trustedhomecare.co.nz/'
                        },
                        'fibrepro': {
                                name: 'FibrePro Carpet Cleaning', industry: 'Carpet Cleaning & Flood Restoration', client: 'FibrePro', location: 'Christchurch, NZ',
                                description: 'A carpet cleaning and flood restoration site with a 16-option service booking dropdown, an integrated blog for ongoing local SEO, and IICRC certification prominently featured to establish technical credibility.',
                                tags: ['Service Booking Dropdown', 'Built-In Blog for SEO', 'Certification Trust Signal'], liveUrl: 'https://fibreprocarpetcleaning.co.nz/'
                        },
                        'youngpros': {
                                name: 'YoungPros Construction', industry: 'Residential Framing Contractor', client: 'YoungPros Construction Ltd', location: 'Vancouver Island & Lower Mainland, BC',
                                description: 'A B2B-facing site for a residential framing contractor serving builders and developers, featuring animated project-count and experience stat counters, a categorized project showcase, and a clear four-step delivery method.',
                                tags: ['B2B-Focused Positioning', 'Project Type Showcase', 'Animated Stat Counters'], liveUrl: 'https://youngprosconstruction.ca/'
                        },
                        'realtor-jaskaur': {
                                name: 'Realtor Jaskaur', industry: 'Real Estate — Buyer Specialist', client: 'Jas Kaur, REALTOR®', location: 'Brampton, ON',
                                description: 'A personal brand site for a first-time-buyer specialist REALTOR®, anchored by a downloadable First-Time Home Buyer Guide as a lead magnet, an FAQ accordion walking through the Ontario buying process, and a testimonial carousel from real closed clients.',
                                tags: ['Lead Magnet (Downloadable Guide)', 'Educational FAQ Accordion', 'Personal Brand Positioning'], liveUrl: 'https://realtorjaskaur.com/'
                        },
                        'brothers-furnace': {
                                name: 'Brothers Furnace & Duct Cleaning', industry: 'Furnace, Duct & Dryer Vent Cleaning', client: 'Brothers Furnace & Duct Cleaning', location: 'Calgary & Airdrie, AB',
                                description: 'A furnace and duct cleaning site covering six Alberta service areas, with a clear three-step process and an extensive testimonial wall — built to convert a low-frequency, trust-dependent home service into repeat bookings.',
                                tags: ['Multi-City Service Area Pages', 'Process Explainer', 'Testimonial Wall'], liveUrl: 'https://brothersfurnaceandductcleaning.ca/'
                        },
                        'elite-funding': {
                                name: 'Elite Funding', industry: 'Truck & Business Loan Brokerage', client: 'Elite Funding', location: 'Mississauga, ON',
                                description: 'A commercial lending site structured around four distinct financing products — Truck Loan & Leasing, Business Loan, Equipment Financing, and Working Capital — each with its own page and mega-menu navigation.',
                                tags: ['Mega-Menu Navigation', 'Multi-Product Architecture', 'Lead Quote Form'], liveUrl: 'https://elitefunding.ca/'
                        },
                        'openaer': {
                                name: 'OpenAer Towing', industry: '24/7 Towing & Roadside Assistance', client: 'OpenAer', location: 'Surrey & Fraser Valley, BC',
                                description: 'A 24/7 towing and roadside assistance site built heavily around local SEO — five core services, a five-city service area, and an extensive FAQ block — aimed squarely at high-urgency "near me" search intent.',
                                tags: ['Local SEO Architecture', 'FAQ-Driven Content', 'Emergency-Intent Optimized'], liveUrl: 'https://openaer.ca/'
                        },
                        'blue-stallion': {
                                name: 'Blue Stallion Logistics', industry: 'Refrigerated Trucking & 3PL', client: 'Blue Stallion Logistics', location: 'Winnipeg, MB',
                                description: 'A 3PL and refrigerated trucking site explaining a four-stage fulfillment cycle, with an expandable FAQ covering TDG certification and service area — built to make a technical B2B service legible to a non-logistics buyer.',
                                tags: ['Process Visualization', 'Expandable FAQ', 'B2B Trust Signals'], liveUrl: 'https://bluestallionlogistics.com/'
                        },
                        'east-kootenay-security': {
                                name: 'East Kootenay Security', industry: 'Commercial Security Services', client: 'East Kootenay Security Group Ltd', location: 'Cranbrook, BC',
                                description: 'A commercial security services site covering four distinct offerings — Mobile Patrols & Rapid Response, Commercial & Industrial Site Security, Advanced CCTV & Remote Monitoring, and Loss Prevention — built to serve clients across BC, Canada, and the USA.',
                                tags: ['Multi-Service Pages', 'WhatsApp CTA', 'Cross-Border Positioning'], liveUrl: 'https://eastkootenaysecurity.com/'
                        }
                };

                const blogArticles = {
                        'ai': {
                                title: 'The AI Revolution in Regional Marketing Architecture',
                                meta: 'AI Strategy · 5 min read',
                                content: `<div class="blog-article-content"><p>The marketing landscape is undergoing a seismic shift. Traditional campaign planning — built on intuition and historical data — is being replaced by predictive modeling engines that can simulate thousands of budget allocation scenarios in real-time.</p><h4>The Problem with Traditional Ad Allocation</h4><p>Most enterprise brands still allocate media budget based on last quarter's performance. But ad markets move in days, not quarters. CPCs fluctuate by 40% week-over-week. Audience intent shifts with cultural moments. By the time you've optimized, the window has closed.</p><h4>Predictive Modeling: How It Works</h4><p>Our Marketing Architect engine uses industry-specific CPC baselines, geo-cost multipliers, and intent modeling to project performance before a single dollar is spent. It simulates how budget splits across Meta, Google, and TikTok will perform given your specific industry, location, and keyword strategy — then visualizes the 30-day acquisition curve.</p><p>The key insight: no two industries have the same platform efficiency ratio. Food & hospitality naturally favors TikTok and Meta. Real estate is Google-dominant. E-commerce sits in between. The engine knows this and adjusts allocations accordingly.</p><h4>The Result</h4><p>Brands using predictive modeling typically see a 30-40% reduction in wasted ad spend and a 2-3x improvement in acquisition volume — not because they're spending more, but because every dollar is deployed with surgical precision.</p></div>`
                        },
                        'web': {
                                title: 'Why Your Website Architecture Is Killing Conversions',
                                meta: 'Web Engineering · 7 min read',
                                content: `<div class="blog-article-content"><p>Here's an uncomfortable truth: most enterprise websites are losing 60% of their potential conversions to structural problems they don't even know exist. Not design problems. Not copy problems. Architecture problems.</p><h4>The Silent Conversion Killer</h4><p>When we audit enterprise platforms, we consistently find the same pattern: beautiful design layered over a fragile, inefficient architecture. Slow database queries. Render-blocking JavaScript. Unoptimized image pipelines. Each adds milliseconds. Milliseconds compound into bounce rates.</p><p>Google's research shows that as page load time goes from 1s to 3s, bounce probability increases by 32%. At 5s, it's 90%. Your beautifully designed hero section doesn't matter if the user never sees it.</p><h4>The Architecture-First Approach</h4><p>We engineer platforms the way structural engineers design buildings: foundation first. That means server-side rendering for critical paths, edge-cached static assets, lazy-loaded non-critical components, and a database architecture designed for your specific query patterns.</p><h4>Measuring What Matters</h4><p>Stop tracking page views. Start tracking Core Web Vitals, time-to-interactive, and conversion-path completion rates. These are the metrics that directly correlate with revenue. Everything else is vanity.</p></div>`
                        },
                        'brand': {
                                title: 'Building Brand Systems That Scale Across Borders',
                                meta: 'Brand Identity · 4 min read',
                                content: `<div class="blog-article-content"><p>Scaling a brand across countries is not about translation. It's about creating a visual and verbal system flexible enough to feel native in any culture while maintaining a coherent global identity.</p><h4>The Modular Identity Framework</h4><p>Instead of a rigid brand book, we design modular identity systems. Core elements — logo architecture, color philosophy, typography scale — remain fixed. Everything else adapts: imagery style, copy tone, cultural references, even color emphasis based on regional preferences.</p><h4>Why Most Brand Systems Break at Scale</h4><p>Most brand guidelines are designed for a single market. When you try to apply them in a new country, something feels off. The imagery is too Western. The color palette clashes with cultural associations. The copy tone feels alien. The brand gets diluted as each local team improvises.</p><p>A modular system prevents this. It defines what must stay constant and what can adapt — so every local team has creative freedom within a structure that protects the global brand DNA.</p><h4>Real-World Application</h4><p>For Pizza in Motion's 12-location franchise, we built a modular packaging system where each location could feature local imagery and promotions within a fixed structural template. Result: 100% brand consistency with local relevance — and 40% lower printing costs through standardized templates.</p></div>`
                        }
                };

                const MONITOR_ICON = '<svg viewBox="0 0 24 24"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>';
                const PHONE_ICON = '<svg viewBox="0 0 24 24"><rect x="7" y="2" width="10" height="20" rx="2"/><line x1="11" y1="18" x2="13" y2="18"/></svg>';
                function domainOf(url) { try { return new URL(url).hostname.replace('www.', ''); } catch (e) { return url; } }

                window.openModal = function(id) {
                        const data = projectData[id];
                        if (!data) return;
                        const chromeBar = document.getElementById('modal-chrome');
                        chromeBar.style.display = 'flex';
                        document.getElementById('modal-domain').textContent = domainOf(data.liveUrl);
                        modalBody.innerHTML = `
                                <h3>${data.name}</h3>
                                <p style="color: var(--brand-gold); font-size: 0.8rem; text-transform: uppercase; letter-spacing: 2px; margin-bottom: 0;">${data.industry}</p>
                                <div class="modal-device-row">
                                        <span class="modal-device-chip">${MONITOR_ICON} Desktop-optimized</span>
                                        <span class="modal-device-chip">${PHONE_ICON} Mobile-optimized</span>
                                </div>
                                <div class="modal-project-meta">
                                        <div><span class="meta-label">Client</span><span class="meta-value">${data.client}</span></div>
                                        <div><span class="meta-label">Location</span><span class="meta-value">${data.location}</span></div>
                                </div>
                                <div class="blog-article-content">
                                        <p>${data.description}</p>
                                </div>
                                <div class="modal-tag-list">
                                        ${data.tags.map(t => `<span class="modal-tag">${t}</span>`).join('')}
                                </div>
                                <div class="dynamic-form" style="margin-top: 3rem; flex-direction: row; flex-wrap: wrap; gap: 1rem;">
                                        <a href="${data.liveUrl}" target="_blank" rel="noopener" class="btn-outline interactive-el">Visit Live Site →</a>
                                        <button onclick="closeModalDirect(); openContactModal()" class="btn-primary interactive-el" style="align-self: flex-start;">Start a Similar Project</button>
                                </div>
                        `;
                        modalOverlay.classList.add('active');
                        document.body.style.overflow = 'hidden';
                        window.trackConversion && window.trackConversion('portfolio_view', { project: id });
                        bindCursorElements();
                };

                window.openBlogArticle = function(key) {
                        const article = blogArticles[key];
                        if (!article) return;
                        document.getElementById('modal-chrome').style.display = 'none';
                        modalBody.innerHTML = `
                                <p style="color: var(--brand-gold); font-size: 0.8rem; text-transform: uppercase; letter-spacing: 2px; margin-bottom: 1rem;">${article.meta}</p>
                                <h3>${article.title}</h3>
                                ${article.content}
                                <div class="dynamic-form" style="margin-top: 3rem;">
                                        <button onclick="closeModalDirect(); openContactModal()" class="btn-primary interactive-el" style="align-self: flex-start;">Discuss Your Project</button>
                                </div>
                        `;
                        modalOverlay.classList.add('active');
                        document.body.style.overflow = 'hidden';
                        bindCursorElements();
                };

                window.openContactModal = function() {
                        document.getElementById('modal-chrome').style.display = 'none';
                        modalBody.innerHTML = `
                                <h3>Let's Talk</h3>
                                <p style="color: var(--text-muted); margin-bottom: 1rem;">Fill out the form below and we'll respond within 24 hours.</p>
                                <form class="dynamic-form" id="modal-contact-form">
                                        <input type="text" name="name" placeholder="Full Name" required class="interactive-el">
                                        <input type="email" name="email" placeholder="Email Address" required class="interactive-el">
                                        <input type="text" name="company" placeholder="Company / Brand" class="interactive-el">
                                        <textarea name="message" placeholder="Tell us about your project..." rows="4" class="interactive-el"></textarea>
                                        <button type="submit" class="btn-primary interactive-el" style="align-self: flex-start;">Send Message</button>
                                </form>
                        `;
                        modalOverlay.classList.add('active');
                        document.body.style.overflow = 'hidden';
                        bindCursorElements();
                        document.getElementById('modal-contact-form').addEventListener('submit', async (e) => {
                                e.preventDefault();
                                const form = e.target;
                                const submitBtn = form.querySelector('button[type="submit"]');
                                const data = {
                                        name: form.name.value.trim(), email: form.email.value.trim(),
                                        company: form.company.value.trim(), message: form.message.value.trim()
                                };
                                if (!data.name || !data.email) return;

                                try {
                                        const leads = JSON.parse(localStorage.getItem('graphinxt_leads') || '[]');
                                        leads.push({ ...data, source: 'contact_modal', ts: new Date().toISOString() });
                                        localStorage.setItem('graphinxt_leads', JSON.stringify(leads));
                                } catch (err) { /* storage unavailable — fail silently */ }
                                window.trackConversion && window.trackConversion('generate_lead', { source: 'contact_modal' });

                                function showSent() {
                                        modalBody.innerHTML = `
                                                <h3>Message Sent!</h3>
                                                <p style="color: var(--text-muted); margin-top: 1rem; line-height: 1.8;">Thank you for reaching out. One of our digital architects will be in touch within 24 hours to discuss your vision.</p>
                                                <button onclick="closeModalDirect()" class="btn-outline interactive-el" style="margin-top: 2rem; align-self: flex-start; padding: 0.8rem 2rem;">Close</button>
                                        `;
                                        bindCursorElements();
                                }

                                if (window.emailjs && EMAILJS_SERVICE_ID && EMAILJS_TEMPLATE_ID) {
                                        if (submitBtn) { submitBtn.disabled = true; submitBtn.innerText = 'Sending...'; }
                                        try {
                                                await emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, {
                                                        to_email: 'graphinxtmarketing@gmail.com', from_name: data.name, from_email: data.email, company: data.company || '—',
                                                        service: '—', message: data.message || '—', website_url: window.location.href
                                                });
                                                showSent();
                                        } catch (err) {
                                                window.location.href = `mailto:reach@graphinxt.com?subject=${encodeURIComponent('New project inquiry — ' + data.name)}&body=${encodeURIComponent('Name: ' + data.name + '\\nEmail: ' + data.email + '\\nCompany: ' + (data.company || '—') + '\\n\\nMessage:\\n' + (data.message || '—'))}`;
                                                showSent();
                                        }
                                } else {
                                        window.location.href = `mailto:reach@graphinxt.com?subject=${encodeURIComponent('New project inquiry — ' + data.name)}&body=${encodeURIComponent('Name: ' + data.name + '\\nEmail: ' + data.email + '\\nCompany: ' + (data.company || '—') + '\\n\\nMessage:\\n' + (data.message || '—'))}`;
                                        showSent();
                                }
                        });
                };

                window.closeModal = function(e) {
                        if (e.target === modalOverlay) {
                                closeModalDirect();
                        }
                };

                window.closeModalDirect = function() {
                        modalOverlay.classList.remove('active');
                        document.body.style.overflow = '';
                };

                // Close modal on Escape
                document.addEventListener('keydown', (e) => {
                        if (e.key === 'Escape') closeModalDirect();
                });

                // 14. ANIMATED BACKGROUND CANVAS (dark mode floating gold particles)
                (function() {
                        const canvas = document.getElementById('bg-canvas');
                        if (!canvas) return;
                        const ctx = canvas.getContext('2d');
                        if (!ctx) return;
                        let particles = [];
                        let w, h, animationId;

                        function resize() {
                                w = canvas.width = window.innerWidth;
                                h = canvas.height = window.innerHeight;
                        }
                        resize();
                        window.addEventListener('resize', resize);

                        function createParticles() {
                                const count = Math.min(Math.floor(w / 18), 70);
                                particles = [];
                                for (let i = 0; i < count; i++) {
                                        particles.push({
                                                x: Math.random() * w,
                                                y: Math.random() * h,
                                                r: Math.random() * 1.8 + 0.4,
                                                vy: -(Math.random() * 0.4 + 0.1),
                                                vx: (Math.random() - 0.5) * 0.2,
                                                alpha: Math.random() * 0.5 + 0.1,
                                                pulse: Math.random() * Math.PI * 2,
                                                pulseSpeed: Math.random() * 0.02 + 0.005
                                        });
                                }
                        }
                        createParticles();

                        function animate() {
                                ctx.clearRect(0, 0, w, h);
                                particles.forEach(p => {
                                        p.y += p.vy;
                                        p.x += p.vx;
                                        p.pulse += p.pulseSpeed;
                                        const pulseAlpha = p.alpha * (0.5 + 0.5 * Math.sin(p.pulse));

                                        if (p.y < -10) { p.y = h + 10; p.x = Math.random() * w; }
                                        if (p.x < -10) p.x = w + 10;
                                        if (p.x > w + 10) p.x = -10;

                                        // Glow
                                        const gradient = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r * 6);
                                        gradient.addColorStop(0, `rgba(233, 196, 111, ${pulseAlpha})`);
                                        gradient.addColorStop(1, 'rgba(233, 196, 111, 0)');
                                        ctx.fillStyle = gradient;
                                        ctx.beginPath();
                                        ctx.arc(p.x, p.y, p.r * 6, 0, Math.PI * 2);
                                        ctx.fill();

                                        // Core
                                        ctx.fillStyle = `rgba(233, 196, 111, ${pulseAlpha * 1.5})`;
                                        ctx.beginPath();
                                        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
                                        ctx.fill();
                                });
                                animationId = requestAnimationFrame(animate);
                        }

                        function startAnim() { if (!animationId) animate(); }
                        function stopAnim() { if (animationId) { cancelAnimationFrame(animationId); animationId = null; ctx.clearRect(0, 0, w, h); } }

                        // Only animate in dark mode
                        function checkTheme() {
                                if (document.body.classList.contains('light-mode')) stopAnim();
                                else startAnim();
                        }
                        checkTheme();
                        themeToggleBtn.addEventListener('click', () => setTimeout(checkTheme, 50));
                })();

/* ===== Embed mode (for iframing sections into other pages) ===== */
        (function(){
            var m = location.hash.match(/embed=([^&]+)/);
    var embed = m ? m[1] : null;
    if(!embed) return;
    document.body.classList.add('embed-mode');
    var target = document.getElementById(embed);
    document.querySelectorAll('nav, header, footer, .marquee-container, .demo-banner-section, section, .whatsapp-float').forEach(function(el){
        if(el !== target) el.style.display = 'none';
    });
    document.querySelectorAll('.fade-in').forEach(function(el){ el.classList.add('visible'); });
    if(target){ target.style.display = 'block'; target.style.padding = '2rem 5%'; }
    window.openContactModal = function(){ parent.postMessage({ type: 'openEnquiry' }, '*'); };
})();

/* ===== Advanced: Marketing Architect projection + Quote estimator extras ===== */
(function() {
    // ===== ADVANCED: Marketing Architect — Projected Performance =====
    function fmtN(n) { return Math.round(n).toLocaleString(); }
    function renderMktProjection() {
        const box = document.getElementById('mkt-projection');
        const slider = document.getElementById('mkt-slider');
        const industryEl = document.getElementById('mkt-industry-custom');
        if (!box || !slider) return;
        const daily = parseInt(slider.value) || 40;
        const monthly = daily * 30;
        const ind = (industryEl && industryEl.value || '').toLowerCase();
        let cpc = 1.6;
        if (/real estate|property|law|legal|insurance|finance|dental|medical|clinic/.test(ind)) cpc = 4.5;
        else if (/ecommerce|e-commerce|shop|store|fashion|retail/.test(ind)) cpc = 1.1;
        else if (/restaurant|food|cafe|pizza|delivery/.test(ind)) cpc = 1.3;
        else if (/saas|software|tech|app|b2b/.test(ind)) cpc = 3.4;
        else if (/clean|plumb|hvac|roof|landscap|moving|repair|salon|gym|fitness/.test(ind)) cpc = 2.6;
        const clicks = monthly / cpc;
        const scenarios = [['Conservative', 0.02], ['Expected', 0.035], ['Optimized', 0.055]].map(function(sc) {
            const leads = clicks * sc[1];
            const cpl = leads > 0 ? monthly / leads : 0;
            return '<div style="display:flex; justify-content:space-between; gap:0.8rem; font-size:0.8rem; padding:0.5rem 0; border-bottom:1px solid rgba(233,196,111,0.15); color:var(--text-muted);">' +
                '<span style="flex:1;">' + sc[0] + ' (' + (sc[1]*100).toFixed(1) + '% conv.)</span>' +
                '<span style="color:var(--text-main); font-weight:600;">~' + fmtN(leads) + ' leads/mo</span>' +
                '<span style="color:var(--brand-gold); font-weight:600;">$' + fmtN(cpl) + ' CPL</span></div>';
        }).join('');
        box.innerHTML = '<div style="border:1px solid rgba(233,196,111,0.15); border-radius:14px; padding:1.2rem 1.4rem;">' +
            '<div style="font-size:0.72rem; color:var(--brand-gold); text-transform:uppercase; letter-spacing:1.5px; font-weight:700; margin-bottom:0.7rem;">Advanced \u00b7 Projected Performance</div>' +
            '<div style="font-size:0.8rem; color:var(--text-muted); margin-bottom:0.6rem;">$' + fmtN(monthly) + '/mo budget \u00f7 ~$' + cpc.toFixed(2) + ' est. CPC \u2248 <strong style="color:var(--text-main);">' + fmtN(clicks) + ' clicks/month</strong></div>' +
            scenarios +
            '<div style="font-size:0.62rem; color:var(--text-muted); opacity:0.7; margin-top:0.7rem;">Industry-benchmark estimates for planning \u2014 real CPCs vary by market and are confirmed in your free strategy call.</div></div>';
    }
    ['mkt-slider','mkt-industry-custom','mkt-location-custom','mkt-keywords-custom'].forEach(function(id) {
        const el = document.getElementById(id);
        if (el) el.addEventListener('input', renderMktProjection);
    });
    renderMktProjection();

    // ===== ADVANCED: Estimator — delivery window, installments, WhatsApp quote =====
    function renderQuoteExtras() {
        const box = document.getElementById('quote-extras');
        const totalEl = document.getElementById('total-price');
        const bd = document.getElementById('price-breakdown');
        if (!box || !totalEl) return;
        const total = parseInt(totalEl.innerText.replace(/,/g, '')) || 0;
        if (!total) { box.innerHTML = ''; return; }
        const symEl = document.getElementById('currency-symbol');
        const sym = symEl ? symEl.innerText : '$';
        let weeks = 4;
        const tv = document.getElementById('timeline-value');
        if (tv && parseInt(tv.innerText)) weeks = parseInt(tv.innerText);
        const d = new Date(); d.setDate(d.getDate() + weeks * 7);
        const delivery = d.toLocaleDateString(undefined, { day: 'numeric', month: 'long', year: 'numeric' });
        const inst = Math.ceil(total / 3);
        const lines = bd ? Array.from(bd.children).map(function(r) { return r.textContent.trim().replace(/\s{2,}/g, ' \u2014 '); }).filter(Boolean) : [];
        const msg = 'Hi Graphinxt! My project estimate from your website:\n' + lines.map(function(l){return '\u2022 ' + l;}).join('\n') + '\nTotal: ' + sym + totalEl.innerText + '\nTarget delivery: ' + delivery + '\nPlease send me a formal quote.';
        box.innerHTML =
            '<div style="display:flex; justify-content:space-between; font-size:0.8rem; color:var(--text-muted); padding:0.4rem 0;"><span>Est. delivery date (' + weeks + ' wks)</span><span style="color:var(--text-main); font-weight:600;">' + delivery + '</span></div>' +
            '<div style="display:flex; justify-content:space-between; font-size:0.8rem; color:var(--text-muted); padding:0.4rem 0;"><span>Or 3 installments of</span><span style="color:var(--brand-gold); font-weight:700;">' + sym + inst.toLocaleString() + '</span></div>' +
            '<a href="https://wa.me/971564785139?text=' + encodeURIComponent(msg) + '" target="_blank" rel="noopener" style="display:block; text-align:center; margin-top:0.8rem; padding:0.7rem 1rem; border:1px solid var(--brand-gold); border-radius:30px; color:var(--brand-gold); text-decoration:none; font-size:0.7rem; text-transform:uppercase; letter-spacing:1px; font-weight:700;" onclick="if(window.trackConversion)trackConversion(\'quote_whatsapp\',{page:\'/\'});">Send This Quote to WhatsApp \u2192</a>';
    }
    const bdEl = document.getElementById('price-breakdown');
    if (bdEl && window.MutationObserver) {
        new MutationObserver(renderQuoteExtras).observe(bdEl, { childList: true, subtree: true });
    }
    setTimeout(renderQuoteExtras, 800);
})();

/* ===== Cookie consent banner logic ===== */
    (function(){
        function get(k){ try { return localStorage.getItem(k); } catch(e){ return null; } }
        function set(k,v){ try { localStorage.setItem(k,v); } catch(e){} }
        window.grxCookie = function(accept){
            set('grx_cookie_consent', accept ? 'all' : 'essential');
            var el = document.getElementById('grx-cookie'); if (el) el.style.display = 'none';
            if (accept && window.trackConversion) window.trackConversion('cookie_accept', { page: location.pathname });
        };
        document.addEventListener('DOMContentLoaded', function(){
            if (!get('grx_cookie_consent')) {
                var el = document.getElementById('grx-cookie');
                if (el) setTimeout(function(){ el.style.display = 'block'; }, 1200);
            }
        });
    })();
