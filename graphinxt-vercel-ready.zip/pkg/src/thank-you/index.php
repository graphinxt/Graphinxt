<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Thank You | Graphinxt</title>
<meta name="description" content="Thank you for reaching out to Graphinxt — AI web, branding, and marketing for growing businesses.">
<meta name="robots" content="noindex, follow">
<link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='14' fill='%23363638'/%3E%3Ctext x='32' y='44' font-family='Georgia, serif' font-size='36' font-weight='800' fill='%23e9c46f' text-anchor='middle'%3EG%3C/text%3E%3C/svg%3E">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@200;300;400;500;800&display=swap" rel="stylesheet">
     <link rel="stylesheet" href="../assets/style.css">
     <link rel="stylesheet" href="../assets/header.css">

<style>
  :root { --bg-dark:#363638; --brand-gold:#e9c46f; --text-main:#fff; --text-muted:#a1a1a5; --border-light:rgba(233,196,111,0.12); }
  * { margin:0; padding:0; box-sizing:border-box; font-family:'Montserrat', sans-serif; }
  body { background:var(--bg-dark); color:var(--text-main); min-height:100vh; display:flex; flex-direction:column; align-items:center; justify-content:center; text-align:center; padding:2rem; }
  .code { font-size:clamp(5rem,15vw,9rem); font-weight:800; color:var(--brand-gold); line-height:1; letter-spacing:-4px; padding-top:10rem; }
section  h1 { font-size:clamp(1.4rem,3vw,2rem); font-weight:300; margin:1rem 0 0.8rem; }
 section p { color:var(--text-muted);margin: auto; max-width:420px; margin-bottom:2.2rem; font-weight:300; line-height:1.6; 
 }
  section .actions { display:flex; gap:1rem; flex-wrap:wrap; justify-content:center; }
  section a.btn { text-decoration:none; padding:0.9rem 2rem; border-radius:30px; font-size:0.8rem; font-weight:800; text-transform:uppercase; letter-spacing:1px; transition:all .3s; }
  .btn-primary { background:#fff; color:var(--bg-dark); }
  .btn-primary:hover { background:var(--brand-gold); color:#fff; transform:scale(1.05); }
  .btn-outline { border:1px solid var(--border-light); color:var(--brand-gold); }
  .btn-outline:hover { border-color:var(--brand-gold); }
 
</style>

<!-- ===== ANALYTICS & CONVERSION TRACKING =====
     Replace G-58PYC27MPE with your real GA4 Measurement ID (analytics.google.com > Admin > Data Streams)
     Replace 2162187584315430 with your real Meta Pixel ID (business.facebook.com/events_manager > Data Sources)
     Until replaced, these load harmlessly but report no real data.
-->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-58PYC27MPE"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-58PYC27MPE');
</script>
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '2162187584315430');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=2162187584315430&ev=PageView&noscript=1" /></noscript>
<script>
  // Unified conversion helper — fires both GA4 and Meta Pixel from a single call site-wide.
  window.trackConversion = function(eventName, params) {
    params = params || {};
    try { if (typeof gtag === 'function') gtag('event', eventName, params); } catch(e) {}
    try { if (typeof fbq === 'function') fbq('trackCustom', eventName, params); } catch(e) {}
  };
  // Auto-track every outbound WhatsApp click site-wide (no extra wiring needed per page).
  document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('a[href*="wa.me"]').forEach(function(el) {
      el.addEventListener('click', function() { window.trackConversion('whatsapp_click', { page: window.location.pathname }); });
    });
  });
</script>
<!-- ===== END ANALYTICS ===== -->
</head>
<body>
              <?php include '../header.php';?>
<section>
  <div class="code">Thank You!</div>
  <p>Your message has been received. One of our digital architects will be in touch within 24 hours to discuss your vision.</p>
  <div class="actions">
    <a href="/" class="btn btn-primary">Back to Home</a>
    <a href="/#services" class="btn btn-outline">View Services</a>
    <a href="/blog" class="btn btn-outline">Read Insights</a>
  </div>
</section>
 <?php include '../footer.php';?>
 <script src="../assets/js/script.js"></script>
</body>
</html>
