// --- Custom Cursor Logic ---
const cursorDot = document.querySelector('.cursor-dot');
const cursorOutline = document.querySelector('.cursor-outline');

window.addEventListener('mousemove', (e) => {
    const posX = e.clientX;
    const posY = e.clientY;
    cursorDot.style.left = `${posX}px`;
    cursorDot.style.top = `${posY}px`;
    cursorOutline.animate({
        left: `${posX}px`,
        top: `${posY}px`
    }, { duration: 500, fill: "forwards" });
});

const interactables = document.querySelectorAll('a, button, .interactive-el, .interactive-card');
interactables.forEach(el => {
    el.addEventListener('mouseenter', () => {
        cursorOutline.style.transform = 'translate(-50%, -50%) scale(1.5)';
        cursorOutline.style.backgroundColor = 'rgba(233, 196, 111, 0.1)';
    });
    el.addEventListener('mouseleave', () => {
        cursorOutline.style.transform = 'translate(-50%, -50%) scale(1)';
        cursorOutline.style.backgroundColor = 'transparent';
    });
});

// --- Scroll Progress & Navbar Dynamics ---
const scrollProgress = document.getElementById('scroll-progress');
const navbar = document.querySelector('.navbar');

window.addEventListener('scroll', () => {
    const scrollTop = document.documentElement.scrollTop;
    const scrollHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
    const scrollPercentage = (scrollTop / scrollHeight) * 100;
    scrollProgress.style.width = scrollPercentage + '%';

    if (scrollTop > 50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({ behavior: 'smooth' });
    });
});

// --- NEW: Global Timezone Clocks ---
function updateClocks() {
    const options = { hour: '2-digit', minute: '2-digit', hour12: false };
    
    document.getElementById('time-ny').innerText = new Date().toLocaleTimeString('en-US', { timeZone: 'America/New_York', ...options });
    document.getElementById('time-ldn').innerText = new Date().toLocaleTimeString('en-GB', { timeZone: 'Europe/London', ...options });
    document.getElementById('time-dxb').innerText = new Date().toLocaleTimeString('en-AE', { timeZone: 'Asia/Dubai', ...options });
    document.getElementById('time-tky').innerText = new Date().toLocaleTimeString('ja-JP', { timeZone: 'Asia/Tokyo', ...options });
}
setInterval(updateClocks, 1000);
updateClocks(); // Init immediately

// --- Tab Logic ---
const tabBtns = document.querySelectorAll('.tab-btn');
const tabContents = document.querySelectorAll('.tab-content');

tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        tabBtns.forEach(b => b.classList.remove('active'));
        tabContents.forEach(c => c.classList.remove('active'));
        btn.classList.add('active');
        document.getElementById(btn.getAttribute('data-target')).classList.add('active');
    });
});

// --- Portfolio Filter Logic ---
const filterBtns = document.querySelectorAll('.filter-btn');
const portfolioItems = document.querySelectorAll('.portfolio-item');

filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        filterBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const filter = btn.getAttribute('data-filter');
        
        portfolioItems.forEach(item => {
            if (filter === 'all' || item.getAttribute('data-category') === filter) {
                item.classList.remove('hidden');
            } else {
                item.classList.add('hidden');
            }
        });
    });
});

// --- UPGRADED: Multi-Currency Estimator Logic ---
const currencySelector = document.getElementById('currency-selector');
const currencySymbol = document.getElementById('currency-symbol');
const projectType = document.getElementById('project-type');
const aiFeatures = document.getElementById('ai-features');
const projectScope = document.getElementById('project-scope');
const scopeValue = document.getElementById('scope-value');
const totalPrice = document.getElementById('total-price');

function updatePrice() {
    const baseAED = parseInt(projectType.value);
    const aiAED = parseInt(aiFeatures.value);
    const scopeMultiplierAED = parseInt(projectScope.value) * 150; 
    
    const totalAED = baseAED + aiAED + scopeMultiplierAED;
    
    // Apply currency multiplier
    const currencyMultiplier = parseFloat(currencySelector.value);
    const targetTotal = Math.round(totalAED * currencyMultiplier);
    
    // Update Symbol
    const selectedOption = currencySelector.options[currencySelector.selectedIndex];
    currencySymbol.innerText = selectedOption.getAttribute('data-symbol');

    let currentTotal = parseInt(totalPrice.innerText.replace(/,/g, '')) || 0;
    const increment = Math.ceil((targetTotal - currentTotal) / 15);
    
    if (currentTotal === targetTotal) return;

    const counter = setInterval(() => {
        currentTotal += increment;
        if ((increment > 0 && currentTotal >= targetTotal) || (increment < 0 && currentTotal <= targetTotal)) {
            currentTotal = targetTotal;
            clearInterval(counter);
        }
        totalPrice.innerText = currentTotal.toLocaleString();
    }, 20);
}

[currencySelector, projectType, aiFeatures, projectScope].forEach(el => {
    el.addEventListener('input', () => {
        scopeValue.innerText = projectScope.value;
        updatePrice();
    });
});
updatePrice();

// --- Interactive AI Chatbot Logic ---
const chatbotToggle = document.getElementById('chatbot-toggle');
const chatbotWidget = document.querySelector('.chatbot-widget');
const toggleIcon = document.querySelector('.toggle-icon');
const chatInput = document.getElementById('chat-input');
const chatSend = document.getElementById('chat-send');
const chatMessages = document.getElementById('chat-messages');

chatbotToggle.addEventListener('click', () => {
    chatbotWidget.classList.toggle('open');
    toggleIcon.innerText = chatbotWidget.classList.contains('open') ? '-' : '+';
});

function sendMessage() {
    const text = chatInput.value.trim();
    if (text === '') return;
    
    const userMsg = document.createElement('div');
    userMsg.className = 'msg user-msg';
    userMsg.innerText = text;
    chatMessages.appendChild(userMsg);
    
    chatInput.value = '';
    chatMessages.scrollTop = chatMessages.scrollHeight;

    setTimeout(() => {
        const botMsg = document.createElement('div');
        botMsg.className = 'msg bot-msg';
        botMsg.innerText = "Global systems updated. A Graphinxt architect from your region will respond shortly.";
        chatMessages.appendChild(botMsg);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }, 1200);
}

chatSend.addEventListener('click', sendMessage);
chatInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') sendMessage();
});

// --- Scroll Reveal Animations ---
const observerOptions = { threshold: 0.1, rootMargin: "0px 0px -50px 0px" };
const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = 1;
            entry.target.style.transform = 'translateY(0)';
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

document.querySelectorAll('.card, .timeline-item, .section-header, .estimator-container, .portfolio-item, .clock-card').forEach(el => {
    el.style.opacity = 0;
    el.style.transform = 'translateY(40px)';
    el.style.transition = 'opacity 0.8s ease-out, transform 0.8s ease-out';
    observer.observe(el);
});